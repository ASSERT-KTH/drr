import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.Chronology chronology9 = gregorianChronology7.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        long long12 = skipDateTimeField6.roundFloor((long) 4);
        int int13 = skipDateTimeField6.getMaximumValue();
        boolean boolean14 = skipDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime5.withPeriodAdded(readablePeriod11, 20);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        org.joda.time.DateTime dateTime16 = property14.addWrapFieldToCopy(110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        int int10 = gJChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField11 = gJChronology9.seconds();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, durationField11, dateTimeFieldType21);
        org.joda.time.DateTimeField dateTimeField23 = delegatedDateTimeField22.getWrappedField();
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField22.getAsShortText(59, locale25);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "59" + "'", str26.equals("59"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis((-69));
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime1.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        long long5 = dateTimeZone2.adjustOffset((long) (short) 1, false);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone2.getShortName(1739984400000L, locale8);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        boolean boolean27 = offsetDateTimeField25.isLeap((long) 99);
        long long29 = offsetDateTimeField25.roundCeiling((long) (-28800000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField36.getType();
        org.joda.time.ReadablePartial readablePartial38 = null;
        int int39 = skipDateTimeField36.getMinimumValue(readablePartial38);
        boolean boolean40 = iSOChronology30.equals((java.lang.Object) skipDateTimeField36);
        org.joda.time.Chronology chronology41 = iSOChronology30.withUTC();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.LocalDate.Property property43 = localDate42.yearOfCentury();
        org.joda.time.DateMidnight dateMidnight44 = localDate42.toDateMidnight();
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) localDate42, (-25200000), locale46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = offsetDateTimeField25.getAsText((long) 69, locale49);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-28800000L) + "'", long29 == (-28800000L));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateMidnight44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "-25200000" + "'", str47.equals("-25200000"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "57600168" + "'", str50.equals("57600168"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField12.getType();
        int int15 = dateTime5.get((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.DateTime dateTime18 = dateTime5.withDurationAdded((long) 5, (int) (short) 1);
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 110, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
//        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
//        int[] intArray16 = localDate12.getValues();
//        boolean boolean17 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.Chronology chronology24 = copticChronology20.withZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(10L, dateTimeZone23);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
//        java.lang.String str32 = dateTimeZone30.getShortName((long) (short) 10);
//        long long34 = dateTimeZone23.getMillisKeepLocal(dateTimeZone30, (long) (byte) 100);
//        java.lang.String str36 = dateTimeZone23.getShortName((-28800000L));
//        org.joda.time.DateTime dateTime37 = localDate12.toDateTime(localTime18, dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PST" + "'", str32.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PST" + "'", str36.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime37);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        org.joda.time.DateTime dateTime12 = dateTime1.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
        int int14 = dateTime12.getWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime12.year();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[America/Los_A...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        long long71 = remainderDateTimeField68.roundHalfEven((long) 59);
        org.joda.time.DurationField durationField72 = remainderDateTimeField68.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology73 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone74, readableInstant75);
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField78 = iSOChronology77.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField79 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology76, dateTimeField78);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipDateTimeField79.getType();
        org.joda.time.ReadablePartial readablePartial81 = null;
        int int82 = skipDateTimeField79.getMinimumValue(readablePartial81);
        boolean boolean83 = iSOChronology73.equals((java.lang.Object) skipDateTimeField79);
        org.joda.time.Chronology chronology84 = iSOChronology73.withUTC();
        org.joda.time.DateTimeField dateTimeField85 = iSOChronology73.weekyear();
        org.joda.time.DurationField durationField86 = iSOChronology73.centuries();
        org.joda.time.DateTimeZone dateTimeZone87 = null;
        org.joda.time.ReadableInstant readableInstant88 = null;
        org.joda.time.chrono.GJChronology gJChronology89 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone87, readableInstant88);
        org.joda.time.chrono.ISOChronology iSOChronology90 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField91 = iSOChronology90.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField92 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology89, dateTimeField91);
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = skipDateTimeField92.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField95 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField68, durationField86, dateTimeFieldType93, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException98 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType93, (java.lang.Number) 110, "millisOfSecond");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-230400000L) + "'", long71 == (-230400000L));
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(iSOChronology73);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(chronology84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(gJChronology89);
        org.junit.Assert.assertNotNull(iSOChronology90);
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.plusWeeks(0);
        org.joda.time.LocalDate.Property property16 = localDate12.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime16 = localDate15.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMinuteOfHour();
        org.joda.time.DateTime dateTime4 = dateTime1.withSecondOfMinute(4);
        int int5 = dateTime1.getDayOfMonth();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-1L));
        int int9 = dateTime8.getMinuteOfHour();
        int int10 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime8.millisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime8.minus((long) 1970);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(365, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 365");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        int int8 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime5.minusMonths((-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        try {
            long long9 = copticChronology0.getDateTimeMillis(365, (int) (byte) 0, (-9), 0, (-1), 2, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate18 = property13.withMinimumValue();
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate21 = property19.addWrapFieldToCopy(99);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = remainderDateTimeField68.getType();
        long long71 = remainderDateTimeField68.remainder((long) 57599999);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 287999999L + "'", long71 == 287999999L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = remainderDateTimeField68.getType();
        int int70 = remainderDateTimeField68.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-1L));
        int int15 = dateTime14.getYear();
        org.joda.time.DateMidnight dateMidnight16 = dateTime14.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateMidnight16.toDateTime(dateTimeZone17);
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        long long21 = iSOChronology0.set((org.joda.time.ReadablePartial) yearMonthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        org.joda.time.Chronology chronology34 = iSOChronology23.withUTC();
        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.LocalDate.Property property36 = localDate35.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipDateTimeField42.getType();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, readableInstant45);
        int int47 = gJChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField48 = gJChronology46.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, readableInstant50);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology51, dateTimeField53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField54.getType();
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = skipDateTimeField54.getMinimumValue(readablePartial56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = skipDateTimeField54.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField42, durationField48, dateTimeFieldType58);
        boolean boolean60 = property36.equals((java.lang.Object) durationField48);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, readableInstant62);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology63, dateTimeField65);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipDateTimeField66.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (java.lang.Number) 1L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, durationField48, dateTimeFieldType67, 10);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.chrono.GJChronology gJChronology77 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone75, readableInstant76);
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology78.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology77, dateTimeField79);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = skipDateTimeField80.getType();
        org.joda.time.ReadablePartial readablePartial82 = null;
        int int83 = skipDateTimeField80.getMinimumValue(readablePartial82);
        boolean boolean84 = iSOChronology74.equals((java.lang.Object) skipDateTimeField80);
        org.joda.time.Chronology chronology85 = iSOChronology74.withUTC();
        org.joda.time.LocalDate localDate86 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology74);
        org.joda.time.LocalDate.Property property87 = localDate86.yearOfCentury();
        org.joda.time.LocalDate localDate89 = localDate86.plusWeeks(0);
        java.util.Locale locale90 = null;
        try {
            java.lang.String str91 = remainderDateTimeField73.getAsText((org.joda.time.ReadablePartial) localDate86, locale90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(gJChronology77);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(chronology85);
        org.junit.Assert.assertNotNull(localDate86);
        org.junit.Assert.assertNotNull(property87);
        org.junit.Assert.assertNotNull(localDate89);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 63696153600000L, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        boolean boolean27 = offsetDateTimeField25.isLeap((long) 99);
        long long29 = offsetDateTimeField25.roundCeiling((long) (-28800000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField36.getType();
        org.joda.time.ReadablePartial readablePartial38 = null;
        int int39 = skipDateTimeField36.getMinimumValue(readablePartial38);
        boolean boolean40 = iSOChronology30.equals((java.lang.Object) skipDateTimeField36);
        org.joda.time.Chronology chronology41 = iSOChronology30.withUTC();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.LocalDate.Property property43 = localDate42.yearOfCentury();
        org.joda.time.DateMidnight dateMidnight44 = localDate42.toDateMidnight();
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) localDate42, (-25200000), locale46);
        boolean boolean49 = offsetDateTimeField25.isLeap(0L);
        long long51 = offsetDateTimeField25.roundCeiling((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-28800000L) + "'", long29 == (-28800000L));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateMidnight44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "-25200000" + "'", str47.equals("-25200000"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.plusYears(999);
        int int6 = dateTime1.getMillisOfDay();
        int int7 = dateTime1.getSecondOfMinute();
        boolean boolean9 = dateTime1.isBefore((long) 1970);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime1.toYearMonthDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField12.getType();
        int int15 = dateTime5.get((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = skipDateTimeField22.getMinimumValue(readablePartial24);
        boolean boolean26 = iSOChronology16.equals((java.lang.Object) skipDateTimeField22);
        org.joda.time.Chronology chronology27 = iSOChronology16.withUTC();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.LocalDate.Property property29 = localDate28.yearOfCentury();
        org.joda.time.Partial partial31 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = partial31.getFieldTypes();
        org.joda.time.Partial partial33 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray34 = partial33.getFieldTypes();
        org.joda.time.Chronology chronology35 = partial33.getChronology();
        int[] intArray36 = partial33.getValues();
        org.joda.time.Partial partial37 = new org.joda.time.Partial(dateTimeFieldTypeArray32, intArray36);
        try {
            int[] intArray39 = skipDateTimeField12.set((org.joda.time.ReadablePartial) localDate28, (int) (byte) 100, intArray36, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        int int80 = dividedDateTimeField79.getMinimumValue();
        try {
            long long83 = dividedDateTimeField79.set(4L, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for weekOfWeekyear must be in the range [0,17]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateMidnight9.toDateTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime.Property property13 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime11.plusYears(69);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withDurationAdded(readableDuration16, (int) '4');
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-1L));
        int int21 = dateTime20.getMinuteOfHour();
        org.joda.time.DateTime dateTime23 = dateTime20.withSecondOfMinute(4);
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime23);
        java.lang.String str25 = limitChronology24.toString();
        org.joda.time.DateTime dateTime26 = limitChronology24.getLowerLimit();
        try {
            long long32 = limitChronology24.getDateTimeMillis(4L, (-1), 0, 4, 110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 1969-12-18T23:59:04.999Z (JulianChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LimitChronology[JulianChronology[UTC], 1969-12-31T00:00:00.000-08:00, 1969-12-31T15:59:04.999-08:00]" + "'", str25.equals("LimitChronology[JulianChronology[UTC], 1969-12-31T00:00:00.000-08:00, 1969-12-31T15:59:04.999-08:00]"));
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property4 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        long long9 = skipDateTimeField5.roundFloor((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField5.getAsShortText(readablePartial10, (int) (short) 100, locale12);
        java.util.Locale locale16 = null;
        try {
            long long17 = skipDateTimeField5.set((long) 11, "Pacific Standard Time", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property4 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime7 = property4.roundHalfCeilingCopy();
        org.joda.time.Interval interval8 = property4.toInterval();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        long long9 = dateTimeZone4.convertLocalToUTC((long) (-28800000), true);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipDateTimeField8.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField8.getMinimumValue(readablePartial10);
        boolean boolean12 = iSOChronology2.equals((java.lang.Object) skipDateTimeField8);
        org.joda.time.Chronology chronology13 = iSOChronology2.withUTC();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-1L));
        int int18 = property15.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate localDate19 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight(dateTimeZone21);
        boolean boolean23 = iSOChronology0.equals((java.lang.Object) localDate19);
        org.joda.time.LocalDate.Property property24 = localDate19.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.DurationField durationField28 = skipDateTimeField6.getRangeDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, readableInstant31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField35.getType();
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = skipDateTimeField35.getMinimumValue(readablePartial37);
        boolean boolean39 = iSOChronology29.equals((java.lang.Object) skipDateTimeField35);
        org.joda.time.Chronology chronology40 = iSOChronology29.withUTC();
        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.LocalDate.Property property42 = localDate41.centuryOfEra();
        org.joda.time.DateTime dateTime43 = localDate41.toDateTimeAtStartOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology48, dateTimeField50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = skipDateTimeField51.getType();
        org.joda.time.ReadablePartial readablePartial53 = null;
        int int54 = skipDateTimeField51.getMinimumValue(readablePartial53);
        boolean boolean55 = iSOChronology45.equals((java.lang.Object) skipDateTimeField51);
        int int58 = skipDateTimeField51.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, readableInstant61);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology62, dateTimeField64);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField65.getType();
        org.joda.time.ReadablePartial readablePartial67 = null;
        int int68 = skipDateTimeField65.getMinimumValue(readablePartial67);
        boolean boolean69 = iSOChronology59.equals((java.lang.Object) skipDateTimeField65);
        org.joda.time.Chronology chronology70 = iSOChronology59.withUTC();
        org.joda.time.LocalDate localDate71 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology59);
        int int72 = skipDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) localDate71);
        java.util.Locale locale73 = null;
        int int74 = skipDateTimeField51.getMaximumShortTextLength(locale73);
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone76, readableInstant77);
        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField81 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology78, dateTimeField80);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = skipDateTimeField81.getType();
        org.joda.time.ReadablePartial readablePartial83 = null;
        int int84 = skipDateTimeField81.getMinimumValue(readablePartial83);
        boolean boolean85 = iSOChronology75.equals((java.lang.Object) skipDateTimeField81);
        org.joda.time.Chronology chronology86 = iSOChronology75.withUTC();
        org.joda.time.LocalDate localDate87 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology75);
        org.joda.time.LocalDate.Property property88 = localDate87.centuryOfEra();
        org.joda.time.LocalDate localDate90 = property88.addToCopy(2000);
        int[] intArray91 = new int[] {};
        int int92 = skipDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) localDate90, intArray91);
        try {
            int[] intArray94 = skipDateTimeField6.addWrapField((org.joda.time.ReadablePartial) localDate41, (int) (byte) 1, intArray91, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-69) + "'", int58 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 999 + "'", int72 == 999);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 3 + "'", int74 == 3);
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(iSOChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(chronology86);
        org.junit.Assert.assertNotNull(localDate87);
        org.junit.Assert.assertNotNull(property88);
        org.junit.Assert.assertNotNull(localDate90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks(1);
        org.joda.time.LocalDate.Property property18 = localDate17.dayOfWeek();
        org.joda.time.LocalDate.Property property19 = localDate17.weekyear();
        try {
            org.joda.time.LocalDate localDate21 = localDate17.withWeekOfWeekyear((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks(1);
        org.joda.time.LocalDate.Property property18 = localDate17.dayOfWeek();
        org.joda.time.DateTimeField[] dateTimeFieldArray19 = localDate17.getFields();
        org.joda.time.LocalDate localDate21 = localDate17.plusYears(2019);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology23.getZone();
        java.util.TimeZone timeZone25 = dateTimeZone24.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.DateTime dateTime27 = localDate21.toDateTimeAtCurrentTime(dateTimeZone26);
        try {
            org.joda.time.LocalDate localDate29 = localDate21.withDayOfWeek(20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldArray19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMinuteOfHour();
        int int3 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        int int10 = dateTimeZone8.getOffsetFromLocal((long) 57599);
        org.joda.time.DateTime dateTime11 = dateTime6.withZone(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3600000 + "'", int10 == 3600000);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate19 = localDate17.withEra((int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        int int33 = localDate32.getCenturyOfEra();
        org.joda.time.LocalDate localDate34 = localDate17.withFields((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, readableInstant37);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology38, dateTimeField40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField41.getType();
        org.joda.time.ReadablePartial readablePartial43 = null;
        int int44 = skipDateTimeField41.getMinimumValue(readablePartial43);
        boolean boolean45 = iSOChronology35.equals((java.lang.Object) skipDateTimeField41);
        org.joda.time.Chronology chronology46 = iSOChronology35.withUTC();
        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology35);
        int int48 = localDate47.getCenturyOfEra();
        java.util.Date date49 = localDate47.toDate();
        org.joda.time.LocalDate localDate50 = localDate34.withFields((org.joda.time.ReadablePartial) localDate47);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate52 = localDate34.minus(readablePeriod51);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 20 + "'", int33 == 20);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 20 + "'", int48 == 20);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(localDate52);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (java.lang.Number) 1L);
        java.lang.String str11 = illegalFieldValueException10.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipDateTimeField8.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField8.getMinimumValue(readablePartial10);
        boolean boolean12 = iSOChronology2.equals((java.lang.Object) skipDateTimeField8);
        org.joda.time.Chronology chronology13 = iSOChronology2.withUTC();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-1L));
        int int18 = property15.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate localDate19 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight(dateTimeZone21);
        boolean boolean23 = iSOChronology0.equals((java.lang.Object) localDate19);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        boolean boolean27 = offsetDateTimeField25.isLeap((long) 99);
        int int29 = offsetDateTimeField25.getMaximumValue((-210866774822000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.plusYears(999);
        int int6 = dateTime1.getMillisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipDateTimeField13.getMinimumValue(readablePartial15);
        boolean boolean17 = iSOChronology7.equals((java.lang.Object) skipDateTimeField13);
        org.joda.time.Chronology chronology18 = iSOChronology7.withUTC();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.LocalDate.Property property20 = localDate19.yearOfCentury();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((-1L));
        int int23 = property20.compareTo((org.joda.time.ReadableInstant) dateTime22);
        boolean boolean24 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime22);
        int int25 = dateTime22.getDayOfYear();
        int int26 = dateTime22.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57599999 + "'", int6 == 57599999);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 365 + "'", int25 == 365);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial3 = partial0.minus(readablePeriod2);
        org.joda.time.Chronology chronology4 = partial0.getChronology();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial0.plus(readablePeriod5);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        long long27 = offsetDateTimeField25.roundHalfCeiling(0L);
        try {
            long long30 = offsetDateTimeField25.set((-28800000L), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfSecond must be in the range [99,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        int int13 = localDate12.getCenturyOfEra();
        org.joda.time.LocalDate.Property property14 = localDate12.dayOfWeek();
        java.util.Locale locale16 = null;
        try {
            org.joda.time.LocalDate localDate17 = property14.setCopy("Property[yearOfCentury]", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[yearOfCentury]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipDateTimeField8.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField8.getMinimumValue(readablePartial10);
        boolean boolean12 = iSOChronology2.equals((java.lang.Object) skipDateTimeField8);
        org.joda.time.Chronology chronology13 = iSOChronology2.withUTC();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate.Property property15 = localDate14.yearOfCentury();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-1L));
        int int18 = property15.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate localDate19 = property15.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withEra((int) (byte) 1);
        org.joda.time.LocalTime localTime22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
        java.util.TimeZone timeZone26 = dateTimeZone25.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.DateTime dateTime28 = localDate21.toDateTime(localTime22, dateTimeZone27);
        boolean boolean29 = copticChronology0.equals((java.lang.Object) dateTimeZone27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        java.util.Date date11 = dateTime10.toDate();
        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
        boolean boolean14 = property12.equals((java.lang.Object) (-28800000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime5.withPeriodAdded(readablePeriod11, 20);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.minuteOfDay();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField15.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField15.getMinimumValue(readablePartial17);
        boolean boolean19 = iSOChronology9.equals((java.lang.Object) skipDateTimeField15);
        org.joda.time.Chronology chronology20 = iSOChronology9.withUTC();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology9);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        int int24 = skipDateTimeField6.getMaximumValue((long) 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField6);
        int int26 = skipDateTimeField6.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.DurationField durationField28 = skipDateTimeField6.getRangeDurationField();
        long long30 = skipDateTimeField6.roundCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = remainderDateTimeField68.getType();
        boolean boolean70 = remainderDateTimeField68.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        long long82 = dividedDateTimeField79.add((long) 0, 0);
        org.joda.time.DurationField durationField83 = dividedDateTimeField79.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property4 = dateTime1.secondOfMinute();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("CopticChronology[UTC]", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[UTC]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = remainderDateTimeField68.getType();
        int int70 = remainderDateTimeField68.getDivisor();
        long long72 = remainderDateTimeField68.roundFloor((long) 20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-230400000L) + "'", long72 == (-230400000L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.minus((long) 5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) 2000, locale7);
//        org.joda.time.DateTime dateTime9 = localDate0.toDateTimeAtStartOfDay(dateTimeZone4);
//        org.joda.time.LocalDate localDate11 = localDate0.plusDays(110);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate18 = property13.setCopy((int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology1.millisOfDay();
        org.joda.time.Partial partial13 = partial0.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = partial0.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.Partial partial16 = partial0.minus(readablePeriod15);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(partial13);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
        org.junit.Assert.assertNotNull(partial16);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1L));
        int int10 = dateTime9.getYear();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime9.withYear(1969);
        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfEra((int) ' ');
        int int16 = dateTime13.getEra();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime18 = property7.roundFloorCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.joda.time.Chronology chronology11 = copticChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(11, (int) '4', (-57599998), (int) (byte) 1, (int) '4', 32, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate29 = localDate26.withYear(10);
        org.joda.time.LocalDate.Property property30 = localDate29.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipDateTimeField14.getMinimumValue(readablePartial16);
        boolean boolean18 = iSOChronology8.equals((java.lang.Object) skipDateTimeField14);
        org.joda.time.Chronology chronology19 = iSOChronology8.withUTC();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology8);
        int int21 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate20);
        int int23 = skipDateTimeField5.getMaximumValue((long) 2000);
        int int24 = skipDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipDateTimeField5.getType();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, readableInstant28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.ReadablePartial readablePartial34 = null;
        int int35 = skipDateTimeField32.getMinimumValue(readablePartial34);
        boolean boolean36 = iSOChronology26.equals((java.lang.Object) skipDateTimeField32);
        org.joda.time.Chronology chronology37 = iSOChronology26.withUTC();
        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.LocalDate.Property property39 = localDate38.centuryOfEra();
        org.joda.time.DateTime dateTime40 = localDate38.toDateTimeAtStartOfDay();
        org.joda.time.DateMidnight dateMidnight41 = localDate38.toDateMidnight();
        int int42 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate38);
        try {
            org.joda.time.Instant instant43 = new org.joda.time.Instant((java.lang.Object) localDate38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 999 + "'", int21 == 999);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 999 + "'", int23 == 999);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateMidnight41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 999 + "'", int42 == 999);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.plusYears(69);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.withDurationAdded(readableDuration10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField18.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipDateTimeField18.getType();
        long long22 = skipDateTimeField18.roundCeiling(0L);
        int int23 = dateTime12.get((org.joda.time.DateTimeField) skipDateTimeField18);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((-1L));
        int int26 = dateTime25.getYear();
        org.joda.time.DateMidnight dateMidnight27 = dateTime25.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateMidnight27.toDateTime(dateTimeZone28);
        int int30 = dateTime29.getYearOfCentury();
        org.joda.time.DateTime.Property property31 = dateTime29.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "Pacific Standard Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "Pacific Standard Time");
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 69 + "'", int30 == 69);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        boolean boolean80 = dividedDateTimeField79.isLenient();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField81 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField79);
        long long84 = dividedDateTimeField79.add((long) (-25200000), 959);
        try {
            long long87 = dividedDateTimeField79.set((long) (byte) -1, 57599999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599999 for weekOfWeekyear must be in the range [0,17]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1739984400000L + "'", long84 == 1739984400000L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        java.lang.String str8 = skipDateTimeField5.getAsShortText((long) 1969);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "969" + "'", str8.equals("969"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate19 = localDate17.withEra((int) (byte) 1);
        org.joda.time.LocalDate.Property property20 = localDate17.monthOfYear();
        org.joda.time.LocalDate localDate21 = property20.withMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.plus((long) (byte) 10);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        long long9 = skipDateTimeField5.roundCeiling(0L);
        long long11 = skipDateTimeField5.roundFloor(4L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType12, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Pacific Standard Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Pacific Standard Time");
        java.lang.Number number17 = illegalFieldValueException16.getUpperBound();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weeks();
        try {
            long long6 = copticChronology0.getDateTimeMillis(0, 110, 59, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = copticChronology0.equals(obj1);
        java.lang.String str3 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.era();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str3.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.Chronology chronology16 = iSOChronology1.withZone(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone15);
        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        int int10 = gJChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField11 = gJChronology9.seconds();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, durationField11, dateTimeFieldType21);
        long long24 = skipDateTimeField5.roundHalfFloor((long) '4');
        long long26 = skipDateTimeField5.roundHalfEven((long) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (-1), (java.lang.Number) (byte) 10, (java.lang.Number) (short) 100);
        java.lang.Number number11 = illegalFieldValueException10.getUpperBound();
        illegalFieldValueException10.prependMessage("");
        java.lang.String str14 = illegalFieldValueException10.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 100 + "'", number11.equals((short) 100));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 52);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyear();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-1L));
//        int int15 = dateTime14.getYear();
//        org.joda.time.DateMidnight dateMidnight16 = dateTime14.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = dateMidnight16.toDateTime(dateTimeZone17);
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        long long21 = iSOChronology0.set((org.joda.time.ReadablePartial) yearMonthDay19, 0L);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology0.centuryOfEra();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        long long24 = dateTime23.getMillis();
//        org.joda.time.DateTime dateTime26 = dateTime23.withMillisOfSecond((int) '#');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560637608010L + "'", long24 == 1560637608010L);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((long) 57599, (-9), 52, (-1), 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.plusYears(69);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.withDurationAdded(readableDuration10, (int) '4');
        int int13 = dateTime12.getWeekyear();
        int int14 = dateTime12.getDayOfMonth();
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipDateTimeField5.getMinimumValue(readablePartial7);
        boolean boolean9 = skipDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
        int int9 = dateTime5.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        java.util.Locale locale28 = null;
        int int29 = skipDateTimeField6.getMaximumShortTextLength(locale28);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField31 = copticChronology30.weeks();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, readableInstant33);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField37.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, durationField31, dateTimeFieldType39, 1969);
        try {
            long long44 = remainderDateTimeField41.addWrapField((-28800000L), 110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1860 for millisOfSecond must be in the range [1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField12.getMinimumValue(readablePartial14);
        boolean boolean16 = iSOChronology6.equals((java.lang.Object) skipDateTimeField12);
        int int19 = skipDateTimeField12.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        int int33 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField12.getMaximumShortTextLength(locale34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField12);
        java.util.Locale locale37 = null;
        int int38 = skipDateTimeField12.getMaximumShortTextLength(locale37);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-69) + "'", int19 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipDateTimeField13.getMinimumValue(readablePartial15);
        boolean boolean17 = iSOChronology7.equals((java.lang.Object) skipDateTimeField13);
        org.joda.time.Chronology chronology18 = iSOChronology7.withUTC();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.LocalDate.Property property20 = localDate19.yearOfCentury();
        org.joda.time.LocalDate localDate22 = localDate19.withYear((int) (byte) -1);
        int[] intArray23 = localDate19.getValues();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate19.plus(readablePeriod24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField31.getType();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, readableInstant34);
        int int36 = gJChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField37 = gJChronology35.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField43.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, durationField37, dateTimeFieldType47);
        boolean boolean49 = localDate25.isSupported(dateTimeFieldType47);
        org.joda.time.DateTime dateTime51 = dateTime5.withField(dateTimeFieldType47, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateTime51);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-1L));
        int int9 = dateTime8.getYear();
        org.joda.time.DateMidnight dateMidnight10 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime8.withYear(1969);
        int int13 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime12);
        long long14 = dateTime12.getMillis();
        org.joda.time.DateTime dateTime16 = dateTime12.plusHours(59);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
        org.joda.time.Chronology chronology20 = julianChronology18.withUTC();
        org.joda.time.DateTime dateTime21 = dateTime16.withChronology(chronology20);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 212399999L + "'", long22 == 212399999L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        java.lang.String str2 = julianChronology0.toString();
        try {
            long long7 = julianChronology0.getDateTimeMillis(9, 11, 0, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        long long82 = dividedDateTimeField79.add((long) 0, 0);
        long long85 = dividedDateTimeField79.add(99L, 10);
        java.util.Locale locale86 = null;
        int int87 = dividedDateTimeField79.getMaximumTextLength(locale86);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 18140400099L + "'", long85 == 18140400099L);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2 + "'", int87 == 2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Property[yearOfCentury])");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Property[yearOfCentury])/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property4 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime7 = property4.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone3.getName((long) 2019, locale6);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.monthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.Chronology chronology14 = copticChronology10.withZone(dateTimeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone13.getName((long) 2019, locale16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.monthOfYear();
//        boolean boolean20 = julianChronology8.equals((java.lang.Object) julianChronology18);
//        int int21 = julianChronology8.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology8.dayOfYear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfCentury((int) ' ');
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L));
        int int4 = dateTime3.getYear();
        org.joda.time.DateMidnight dateMidnight5 = dateTime3.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime3.plusYears(999);
        int int8 = dateTime3.getMillisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField15.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField15.getMinimumValue(readablePartial17);
        boolean boolean19 = iSOChronology9.equals((java.lang.Object) skipDateTimeField15);
        org.joda.time.Chronology chronology20 = iSOChronology9.withUTC();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.LocalDate.Property property22 = localDate21.yearOfCentury();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((-1L));
        int int25 = property22.compareTo((org.joda.time.ReadableInstant) dateTime24);
        boolean boolean26 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.Instant instant27 = dateTime3.toInstant();
        org.joda.time.Instant instant29 = instant27.minus((long) 99);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57599999 + "'", int8 == 57599999);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(instant29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        long long9 = skipDateTimeField5.roundFloor((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField5.getAsShortText(readablePartial10, (int) (short) 100, locale12);
        long long16 = skipDateTimeField5.set((long) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
        org.joda.time.Chronology chronology10 = gregorianChronology7.withUTC();
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology10);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTime();
        int int12 = dateTimeFormatter11.getDefaultYear();
        java.lang.String str13 = dateTime5.toString(dateTimeFormatter11);
        org.joda.time.DateTime dateTime15 = dateTime5.plusSeconds((int) (byte) -1);
        int int16 = dateTime15.getSecondOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2000 + "'", int12 == 2000);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "T00:00:00.000-08:00" + "'", str13.equals("T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusYears(57599999);
        org.joda.time.DateTime.Property property7 = dateTime1.yearOfEra();
        java.lang.String str8 = property7.getName();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        java.lang.String str16 = dateTimeZone14.getID();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((-1L));
        int int20 = dateTime19.getYear();
        org.joda.time.DateMidnight dateMidnight21 = dateTime19.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateMidnight21.toDateTime(dateTimeZone22);
        int int24 = dateTime23.getYearOfCentury();
        org.joda.time.DateTime.Property property25 = dateTime23.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime23.withPeriodAdded(readablePeriod26, 4);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime23.withPeriodAdded(readablePeriod29, 20);
        org.joda.time.DateTime.Property property32 = dateTime31.hourOfDay();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfDay();
        org.joda.time.DateTime dateTime35 = dateTime31.plusYears((-1));
        boolean boolean36 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property37 = dateTime35.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 69 + "'", int24 == 69);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(property37);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
//        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
//        int[] intArray16 = localDate12.getValues();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate12.plus(readablePeriod17);
//        java.lang.String str19 = localDate18.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15" + "'", str19.equals("2019-06-15"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime1.toMutableDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = copticChronology1.years();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipDateTimeField9.getType();
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = skipDateTimeField9.getMinimumValue(readablePartial11);
        boolean boolean13 = iSOChronology3.equals((java.lang.Object) skipDateTimeField9);
        org.joda.time.Chronology chronology14 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.Chronology chronology18 = iSOChronology3.withZone(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology3.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        long long25 = julianChronology20.add(readablePeriod22, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, readableInstant28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.ReadablePartial readablePartial34 = null;
        int int35 = skipDateTimeField32.getMinimumValue(readablePartial34);
        boolean boolean36 = iSOChronology26.equals((java.lang.Object) skipDateTimeField32);
        int int39 = skipDateTimeField32.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField46.getType();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int int49 = skipDateTimeField46.getMinimumValue(readablePartial48);
        boolean boolean50 = iSOChronology40.equals((java.lang.Object) skipDateTimeField46);
        org.joda.time.Chronology chronology51 = iSOChronology40.withUTC();
        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology40);
        int int53 = skipDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate52);
        java.util.Locale locale54 = null;
        int int55 = skipDateTimeField32.getMaximumShortTextLength(locale54);
        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology20, (org.joda.time.DateTimeField) skipDateTimeField32);
        org.joda.time.DurationField durationField57 = skipDateTimeField56.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, readableInstant59);
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology61.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology60, dateTimeField62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = skipDateTimeField63.getType();
        org.joda.time.ReadablePartial readablePartial65 = null;
        int int66 = skipDateTimeField63.getMinimumValue(readablePartial65);
        int int68 = skipDateTimeField63.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipDateTimeField63.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dateTimeField19, durationField57, dateTimeFieldType69, 3);
        org.joda.time.DurationField durationField72 = remainderDateTimeField71.getLeapDurationField();
        long long74 = remainderDateTimeField71.roundHalfEven((long) 59);
        org.joda.time.DurationField durationField75 = remainderDateTimeField71.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology76 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.chrono.GJChronology gJChronology79 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone77, readableInstant78);
        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField82 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology79, dateTimeField81);
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = skipDateTimeField82.getType();
        org.joda.time.ReadablePartial readablePartial84 = null;
        int int85 = skipDateTimeField82.getMinimumValue(readablePartial84);
        boolean boolean86 = iSOChronology76.equals((java.lang.Object) skipDateTimeField82);
        org.joda.time.Chronology chronology87 = iSOChronology76.withUTC();
        org.joda.time.DateTimeField dateTimeField88 = iSOChronology76.weekyear();
        org.joda.time.DurationField durationField89 = iSOChronology76.centuries();
        org.joda.time.DateTimeZone dateTimeZone90 = null;
        org.joda.time.ReadableInstant readableInstant91 = null;
        org.joda.time.chrono.GJChronology gJChronology92 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone90, readableInstant91);
        org.joda.time.chrono.ISOChronology iSOChronology93 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField94 = iSOChronology93.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField95 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology92, dateTimeField94);
        org.joda.time.DateTimeFieldType dateTimeFieldType96 = skipDateTimeField95.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField98 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField71, durationField89, dateTimeFieldType96, (int) ' ');
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField99 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField2, dateTimeFieldType96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-69) + "'", int39 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 999 + "'", int53 == 999);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNull(durationField72);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-230400000L) + "'", long74 == (-230400000L));
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(iSOChronology76);
        org.junit.Assert.assertNotNull(gJChronology79);
        org.junit.Assert.assertNotNull(iSOChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(chronology87);
        org.junit.Assert.assertNotNull(dateTimeField88);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertNotNull(gJChronology92);
        org.junit.Assert.assertNotNull(iSOChronology93);
        org.junit.Assert.assertNotNull(dateTimeField94);
        org.junit.Assert.assertNotNull(dateTimeFieldType96);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.joda.time.DurationField durationField7 = gJChronology2.halfdays();
        org.joda.time.Instant instant8 = gJChronology2.getGregorianCutover();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMinuteOfHour();
        org.joda.time.DateTime dateTime4 = dateTime1.withSecondOfMinute(4);
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.minuteOfHour();
        org.joda.time.DateTime dateTime11 = dateTime1.toDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis(2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        long long9 = skipDateTimeField5.roundCeiling(0L);
        int int11 = skipDateTimeField5.getMaximumValue(15L);
        int int13 = skipDateTimeField5.get(110L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.LocalDate.Property property27 = localDate26.yearOfCentury();
        org.joda.time.LocalDate localDate29 = localDate26.withYear((int) (byte) -1);
        int[] intArray30 = localDate26.getValues();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate26.plus(readablePeriod31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, readableInstant34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField38.getType();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, readableInstant41);
        int int43 = gJChronology42.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField44 = gJChronology42.seconds();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, readableInstant46);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology47, dateTimeField49);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = skipDateTimeField50.getType();
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = skipDateTimeField50.getMinimumValue(readablePartial52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = skipDateTimeField50.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField38, durationField44, dateTimeFieldType54);
        boolean boolean56 = localDate32.isSupported(dateTimeFieldType54);
        org.joda.time.LocalDate.Property property57 = localDate32.year();
        org.joda.time.Partial partial59 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray60 = partial59.getFieldTypes();
        org.joda.time.Partial partial61 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray62 = partial61.getFieldTypes();
        org.joda.time.Chronology chronology63 = partial61.getChronology();
        int[] intArray64 = partial61.getValues();
        org.joda.time.Partial partial65 = new org.joda.time.Partial(dateTimeFieldTypeArray60, intArray64);
        try {
            int[] intArray67 = skipDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDate32, (int) (byte) -1, intArray64, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 999 + "'", int11 == 999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 110 + "'", int13 == 110);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray60);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        long long5 = dateTimeZone2.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800000L) + "'", long5 == (-28800000L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate18 = property13.addToCopy((-69));
        java.util.Locale locale20 = null;
        try {
            org.joda.time.LocalDate localDate21 = property13.setCopy("100", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfCentury((int) ' ');
        int int10 = dateTime5.getSecondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime5.minusHours((int) '4');
        org.joda.time.DateMidnight dateMidnight13 = dateTime5.toDateMidnight();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        boolean boolean27 = offsetDateTimeField25.isLeap((long) 99);
        long long29 = offsetDateTimeField25.roundCeiling((long) (-28800000));
        long long31 = offsetDateTimeField25.roundHalfFloor((long) 3600000);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-28800000L) + "'", long29 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3600000L + "'", long31 == 3600000L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField12.getMinimumValue(readablePartial14);
        boolean boolean16 = iSOChronology6.equals((java.lang.Object) skipDateTimeField12);
        org.joda.time.Chronology chronology17 = iSOChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology6.weekyear();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-1L));
        int int21 = dateTime20.getYear();
        org.joda.time.DateMidnight dateMidnight22 = dateTime20.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateMidnight22.toDateTime(dateTimeZone23);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
        long long27 = iSOChronology6.set((org.joda.time.ReadablePartial) yearMonthDay25, 0L);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField32, 69);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology6.yearOfEra();
        org.joda.time.Chronology chronology37 = iSOChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((int) (short) 1, 57599999, (int) (short) -1, 9, 10, 20, chronology37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime5.withPeriodAdded(readablePeriod11, 20);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-1L));
        int int19 = dateTime18.getYear();
        org.joda.time.DateMidnight dateMidnight20 = dateTime18.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateMidnight20.toDateTime(dateTimeZone21);
        int int23 = dateTime22.getYearOfCentury();
        org.joda.time.DateTime.Property property24 = dateTime22.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime22.withPeriodAdded(readablePeriod25, 4);
        int int28 = dateTime27.getWeekyear();
        int int29 = property14.getDifference((org.joda.time.ReadableInstant) dateTime27);
        int int30 = dateTime27.getSecondOfMinute();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1970 + "'", int28 == 1970);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.Interval interval18 = localDate17.toInterval();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipDateTimeField25.getMinimumValue(readablePartial27);
        boolean boolean29 = iSOChronology19.equals((java.lang.Object) skipDateTimeField25);
        org.joda.time.Chronology chronology30 = iSOChronology19.withUTC();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.LocalDate.Property property32 = localDate31.yearOfCentury();
        org.joda.time.LocalDate localDate34 = localDate31.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks(1);
        boolean boolean38 = localDate36.equals((java.lang.Object) 1.0f);
        org.joda.time.LocalDate localDate40 = localDate36.withCenturyOfEra(2000);
        int int41 = localDate17.compareTo((org.joda.time.ReadablePartial) localDate40);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((-1L));
        int int44 = dateTime43.getMinuteOfHour();
        int int45 = dateTime43.getMonthOfYear();
        org.joda.time.DateTime.Property property46 = dateTime43.millisOfSecond();
        org.joda.time.DateTime dateTime47 = property46.roundFloorCopy();
        org.joda.time.DateTime dateTime48 = property46.getDateTime();
        org.joda.time.DateTime dateTime49 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime dateTime51 = dateTime48.plusMonths(57599999);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = localDate12.toDateTimeAtStartOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = skipDateTimeField22.getMinimumValue(readablePartial24);
        boolean boolean26 = iSOChronology16.equals((java.lang.Object) skipDateTimeField22);
        org.joda.time.Chronology chronology27 = iSOChronology16.withUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.Chronology chronology31 = iSOChronology16.withZone(dateTimeZone30);
        java.lang.String str32 = dateTimeZone30.getID();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 99, dateTimeZone30);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, readableInstant37);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology38, dateTimeField40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField41.getType();
        org.joda.time.ReadablePartial readablePartial43 = null;
        int int44 = skipDateTimeField41.getMinimumValue(readablePartial43);
        boolean boolean45 = iSOChronology35.equals((java.lang.Object) skipDateTimeField41);
        org.joda.time.Chronology chronology46 = iSOChronology35.withUTC();
        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.LocalDate.Property property48 = localDate47.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
        org.joda.time.DateTime dateTime51 = dateTime34.withField(dateTimeFieldType49, 2000);
        boolean boolean52 = localDate12.isSupported(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "America/Los_Angeles" + "'", str32.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField12.getMinimumValue(readablePartial14);
        boolean boolean16 = iSOChronology6.equals((java.lang.Object) skipDateTimeField12);
        int int19 = skipDateTimeField12.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        int int33 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField12.getMaximumShortTextLength(locale34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField12);
        int int37 = skipDateTimeField12.getMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, readableInstant40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology41, dateTimeField43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipDateTimeField44.getType();
        org.joda.time.ReadablePartial readablePartial46 = null;
        int int47 = skipDateTimeField44.getMinimumValue(readablePartial46);
        boolean boolean48 = iSOChronology38.equals((java.lang.Object) skipDateTimeField44);
        org.joda.time.Chronology chronology49 = iSOChronology38.withUTC();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology38.weekyear();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((-1L));
        int int53 = dateTime52.getYear();
        org.joda.time.DateMidnight dateMidnight54 = dateTime52.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = dateMidnight54.toDateTime(dateTimeZone55);
        org.joda.time.YearMonthDay yearMonthDay57 = dateTime56.toYearMonthDay();
        long long59 = iSOChronology38.set((org.joda.time.ReadablePartial) yearMonthDay57, 0L);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology38.centuryOfEra();
        org.joda.time.DurationField durationField61 = iSOChronology38.centuries();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, readableInstant63);
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology65.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField67 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology64, dateTimeField66);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = skipDateTimeField67.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, durationField61, dateTimeFieldType68, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-69) + "'", int19 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1969 + "'", int53 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(yearMonthDay57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(gJChronology64);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) -1, '#', (int) 'a', 57599, 31, false, 5);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("DateTimeField[millisOfSecond]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("", 2019);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("LimitChronology[JulianChronology[UTC], 1969-12-31T00:00:00.000-08:00, 1969-12-31T15:59:04.999-08:00]", (int) '4', (int) (byte) 10, (int) (short) 10, 'a', 1, (-9), 31, true, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipDateTimeField13.getMinimumValue(readablePartial15);
        boolean boolean17 = iSOChronology7.equals((java.lang.Object) skipDateTimeField13);
        org.joda.time.Chronology chronology18 = iSOChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.Chronology chronology22 = iSOChronology7.withZone(dateTimeZone21);
        java.lang.String str23 = dateTimeZone21.getID();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone21);
        long long28 = dateTimeZone21.convertLocalToUTC((long) (-69), false, (long) '#');
        boolean boolean30 = dateTimeZone21.isStandardOffset((-57599800000L));
        org.joda.time.Chronology chronology31 = zonedChronology6.withZone(dateTimeZone21);
        java.lang.String str32 = zonedChronology6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "America/Los_Angeles" + "'", str23.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799931L + "'", long28 == 28799931L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str32.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear(959);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
//        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone14);
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
//        org.joda.time.Chronology chronology21 = copticChronology17.withZone(dateTimeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone20.getName((long) 2019, locale23);
//        org.joda.time.DateTime dateTime25 = localDate16.toDateTimeAtCurrentTime(dateTimeZone20);
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = localDate16.toString("2019-W24", locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate18 = property13.withMinimumValue();
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        long long20 = property19.remainder();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        int int9 = skipDateTimeField5.getDifference((long) 959, (long) (short) 1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 958 + "'", int9 == 958);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTime();
        int int12 = dateTimeFormatter11.getDefaultYear();
        java.lang.String str13 = dateTime5.toString(dateTimeFormatter11);
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((-25200000));
        int int16 = dateTime5.getDayOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2000 + "'", int12 == 2000);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "T00:00:00.000-08:00" + "'", str13.equals("T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField15.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField15.getMinimumValue(readablePartial17);
        boolean boolean19 = iSOChronology9.equals((java.lang.Object) skipDateTimeField15);
        org.joda.time.Chronology chronology20 = iSOChronology9.withUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        org.joda.time.Chronology chronology24 = iSOChronology9.withZone(dateTimeZone23);
        java.lang.String str25 = dateTimeZone23.getID();
        org.joda.time.DateTime dateTime26 = dateTime8.withZone(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "America/Los_Angeles" + "'", str25.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        long long81 = remainderDateTimeField68.roundHalfEven((-57599800000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-57686400000L) + "'", long81 == (-57686400000L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        java.util.Locale locale81 = null;
        java.lang.String str82 = remainderDateTimeField68.getAsShortText((long) (short) 0, locale81);
        long long85 = remainderDateTimeField68.addWrapField((long) (short) -1, 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "1" + "'", str82.equals("1"));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 604799999L + "'", long85 == 604799999L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks(1);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate19 = localDate17.minus(readablePeriod18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.LocalDate localDate33 = localDate19.withFields((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.LocalDate.Property property34 = localDate19.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(property34);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        boolean boolean70 = remainderDateTimeField68.isLeap((long) 57599999);
        long long73 = remainderDateTimeField68.addWrapField((long) 15, 15);
        long long75 = remainderDateTimeField68.roundCeiling(1560608754697L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 15L + "'", long73 == 15L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560754800000L + "'", long75 == 1560754800000L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField15.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField15.getMinimumValue(readablePartial17);
        boolean boolean19 = iSOChronology9.equals((java.lang.Object) skipDateTimeField15);
        org.joda.time.Chronology chronology20 = iSOChronology9.withUTC();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology9);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        int int24 = skipDateTimeField6.getMaximumValue((long) 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField6);
        long long27 = skipDateTimeField6.roundFloor((-210866673600000L));
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField34.getType();
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = skipDateTimeField34.getMinimumValue(readablePartial36);
        boolean boolean38 = iSOChronology28.equals((java.lang.Object) skipDateTimeField34);
        org.joda.time.Chronology chronology39 = iSOChronology28.withUTC();
        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.LocalDate.Property property41 = localDate40.yearOfCentury();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((-1L));
        int int44 = property41.compareTo((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.LocalDate localDate45 = property41.getLocalDate();
        org.joda.time.LocalDate localDate47 = localDate45.minusDays((-1));
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDate47, 1, locale49);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-210866673600000L) + "'", long27 == (-210866673600000L));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone3.getName((long) 2000, locale6);
//        long long10 = dateTimeZone3.convertLocalToUTC((-28799900L), false);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone3);
//        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.Chronology chronology16 = iSOChronology1.withZone(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.getID();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 99, dateTimeZone15);
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime19.toMutableDateTime(chronology21);
        org.joda.time.DateTime.Property property23 = dateTime19.era();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        int int6 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMinuteOfHour();
        int int3 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withTime(0, (int) (short) 100, (int) (byte) -1, (-69));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField12.getMinimumValue(readablePartial14);
        boolean boolean16 = iSOChronology6.equals((java.lang.Object) skipDateTimeField12);
        int int19 = skipDateTimeField12.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        int int33 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField12.getMaximumShortTextLength(locale34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField12);
        int int39 = skipDateTimeField12.getDifference((long) '4', 0L);
        long long41 = skipDateTimeField12.roundHalfCeiling((long) 5);
        long long43 = skipDateTimeField12.remainder((long) (-1));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-69) + "'", int19 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 5L + "'", long41 == 5L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        int int2 = dateTime1.getYear();
//        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
//        int int6 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField12.getType();
//        int int15 = dateTime5.get((org.joda.time.DateTimeField) skipDateTimeField12);
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
//        org.joda.time.Chronology chronology20 = copticChronology16.withZone(dateTimeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone19.getName((long) 2000, locale22);
//        long long26 = dateTimeZone19.convertLocalToUTC((-28799900L), false);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime5.toMutableDateTime(dateTimeZone19);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology29 = buddhistChronology28.withUTC();
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology28.halfdayOfDay();
//        java.lang.String str31 = buddhistChronology28.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str31.equals("BuddhistChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateMidnight9.toDateTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime.Property property13 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "Pacific Standard Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType14, (-1));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        int int3 = gJChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gJChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfYear();
        java.lang.String str6 = gJChronology2.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str6.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        java.util.Locale locale72 = null;
        try {
            long long73 = remainderDateTimeField68.set((-210866774822000L), "Property[monthOfYear]", locale72);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[monthOfYear]\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField12.getMinimumValue(readablePartial14);
        boolean boolean16 = iSOChronology6.equals((java.lang.Object) skipDateTimeField12);
        int int19 = skipDateTimeField12.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        int int33 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField12.getMaximumShortTextLength(locale34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField12);
        int int37 = skipDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-69) + "'", int19 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        java.util.Locale locale28 = null;
        int int29 = skipDateTimeField6.getMaximumShortTextLength(locale28);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField31 = copticChronology30.weeks();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, readableInstant33);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField37.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, durationField31, dateTimeFieldType39, 1969);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, readableInstant44);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipDateTimeField48.getType();
        org.joda.time.ReadablePartial readablePartial50 = null;
        int int51 = skipDateTimeField48.getMinimumValue(readablePartial50);
        boolean boolean52 = iSOChronology42.equals((java.lang.Object) skipDateTimeField48);
        org.joda.time.Chronology chronology53 = iSOChronology42.withUTC();
        org.joda.time.LocalDate localDate54 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology42);
        org.joda.time.LocalDate.Property property55 = localDate54.yearOfCentury();
        org.joda.time.LocalDate localDate57 = localDate54.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate59 = localDate57.minusWeeks(1);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.LocalDate localDate61 = localDate59.minus(readablePeriod60);
        org.joda.time.Chronology chronology62 = localDate59.getChronology();
        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(chronology62);
        int[] intArray65 = null;
        try {
            int[] intArray67 = remainderDateTimeField41.add((org.joda.time.ReadablePartial) localDate63, 57599999, intArray65, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(localDate63);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipDateTimeField5.getMinimumValue(readablePartial7);
        java.util.Locale locale9 = null;
        int int10 = skipDateTimeField5.getMaximumTextLength(locale9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        boolean boolean21 = iSOChronology11.equals((java.lang.Object) skipDateTimeField17);
        org.joda.time.Chronology chronology22 = iSOChronology11.withUTC();
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.LocalDate.Property property24 = localDate23.dayOfMonth();
        org.joda.time.LocalDate localDate25 = property24.withMaximumValue();
        org.joda.time.LocalDate localDate27 = localDate25.minusDays(9);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray30 = partial29.getFieldTypes();
        org.joda.time.Partial partial31 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = partial31.getFieldTypes();
        org.joda.time.Chronology chronology33 = partial31.getChronology();
        int[] intArray34 = partial31.getValues();
        org.joda.time.Partial partial35 = new org.joda.time.Partial(dateTimeFieldTypeArray30, intArray34);
        java.util.Locale locale37 = null;
        try {
            int[] intArray38 = skipDateTimeField5.set((org.joda.time.ReadablePartial) localDate27, 3, intArray34, "yearOfEra", locale37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"yearOfEra\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray30);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.Chronology chronology14 = copticChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology18 = gregorianChronology7.withZone(dateTimeZone13);
        org.joda.time.Chronology chronology19 = gregorianChronology7.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
//        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
//        org.joda.time.LocalDate localDate19 = localDate17.withEra((int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
//        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
//        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.LocalDate.Property property33 = localDate32.yearOfCentury();
//        org.joda.time.LocalDate localDate35 = localDate32.plusWeeks(0);
//        org.joda.time.LocalDate localDate36 = localDate17.withFields((org.joda.time.ReadablePartial) localDate35);
//        int int37 = localDate36.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.LocalDate localDate12 = dateTime1.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipDateTimeField19.getType();
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipDateTimeField19.getMinimumValue(readablePartial21);
        boolean boolean23 = iSOChronology13.equals((java.lang.Object) skipDateTimeField19);
        org.joda.time.Chronology chronology24 = iSOChronology13.withUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology26.getZone();
        org.joda.time.Chronology chronology28 = iSOChronology13.withZone(dateTimeZone27);
        java.lang.String str29 = dateTimeZone27.getID();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone27);
        long long34 = dateTimeZone27.convertLocalToUTC((long) (-69), false, (long) '#');
        boolean boolean36 = dateTimeZone27.isStandardOffset((-57599800000L));
        org.joda.time.DateTime dateTime37 = localDate12.toDateTimeAtCurrentTime(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28799931L + "'", long34 == 28799931L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (byte) -1);
        org.joda.time.LocalTime localTime16 = null;
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder17.addCutover((int) (short) -1, '#', (int) 'a', 57599, 31, false, 5);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("DateTimeField[millisOfSecond]", true);
        org.joda.time.DateTime dateTime29 = localDate12.toDateTime(localTime16, dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.LocalDate.Property property13 = localDate12.dayOfMonth();
//        org.joda.time.LocalDate localDate14 = property13.withMaximumValue();
//        org.joda.time.LocalDate localDate16 = localDate14.minusYears((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (short) 10);
//        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtMidnight(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.Interval interval18 = localDate17.toInterval();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipDateTimeField25.getMinimumValue(readablePartial27);
        boolean boolean29 = iSOChronology19.equals((java.lang.Object) skipDateTimeField25);
        org.joda.time.Chronology chronology30 = iSOChronology19.withUTC();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.LocalDate.Property property32 = localDate31.yearOfCentury();
        org.joda.time.LocalDate localDate34 = localDate31.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks(1);
        boolean boolean38 = localDate36.equals((java.lang.Object) 1.0f);
        org.joda.time.LocalDate localDate40 = localDate36.withCenturyOfEra(2000);
        int int41 = localDate17.compareTo((org.joda.time.ReadablePartial) localDate40);
        org.joda.time.LocalDate.Property property42 = localDate17.weekyear();
        org.joda.time.LocalDate localDate44 = localDate17.minusDays(99);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(localDate44);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfMonth();
        int int14 = localDate12.getYearOfEra();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-1L));
        int int17 = dateTime16.getYear();
        org.joda.time.DateMidnight dateMidnight18 = dateTime16.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateMidnight18.toDateTime(dateTimeZone19);
        int int21 = dateTime20.getYearOfCentury();
        org.joda.time.DateTime.Property property22 = dateTime20.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.LocalDate.Property property28 = localDate12.property(dateTimeFieldType23);
        try {
            java.lang.String str30 = localDate12.toString("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Property[yearOfCentury])");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 69 + "'", int21 == 69);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        int int13 = localDate12.getCenturyOfEra();
        org.joda.time.LocalDate.Property property14 = localDate12.dayOfWeek();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        org.joda.time.DurationField durationField17 = property14.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond(0);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        boolean boolean10 = mutableDateTime9.isBeforeNow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        int int3 = gJChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gJChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        try {
            long long10 = gJChronology2.getDateTimeMillis((int) '4', (-28800000), (int) (short) 10, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        java.lang.String str71 = remainderDateTimeField68.getAsShortText((long) 1970);
        org.joda.time.DurationField durationField72 = remainderDateTimeField68.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "1" + "'", str71.equals("1"));
        org.junit.Assert.assertNotNull(durationField72);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gJChronology2.withZone(dateTimeZone3);
        java.lang.String str5 = gJChronology2.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.plusYears(69);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.withDurationAdded(readableDuration10, (int) '4');
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfWeek();
        int int14 = property13.getMinimumValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        long long71 = remainderDateTimeField68.roundCeiling((long) (byte) 10);
        long long73 = remainderDateTimeField68.roundHalfCeiling(10L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 374400000L + "'", long71 == 374400000L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-230400000L) + "'", long73 == (-230400000L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.getLocalDate();
        org.joda.time.DateMidnight dateMidnight18 = localDate17.toDateMidnight();
        org.joda.time.DateMidnight dateMidnight19 = localDate17.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateMidnight dateMidnight21 = localDate17.toDateMidnight(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(dateMidnight21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField15.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField15.getMinimumValue(readablePartial17);
        boolean boolean19 = iSOChronology9.equals((java.lang.Object) skipDateTimeField15);
        org.joda.time.Chronology chronology20 = iSOChronology9.withUTC();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology9);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        int int24 = skipDateTimeField6.getMaximumValue((long) 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField6);
        java.lang.String str26 = skipDateTimeField6.getName();
        long long28 = skipDateTimeField6.roundHalfFloor((long) '4');
        int int30 = skipDateTimeField6.getLeapAmount((long) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "millisOfSecond" + "'", str26.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipDateTimeField14.getMinimumValue(readablePartial16);
        boolean boolean18 = iSOChronology8.equals((java.lang.Object) skipDateTimeField14);
        org.joda.time.Chronology chronology19 = iSOChronology8.withUTC();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology8);
        int int21 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate localDate23 = localDate20.withWeekyear(4);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property25 = localDate20.era();
        org.joda.time.Chronology chronology26 = localDate20.getChronology();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 999 + "'", int21 == 999);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        org.joda.time.DateTime dateTime12 = dateTime1.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth(99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusYears(20);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.LocalDate.Property property27 = localDate26.yearOfCentury();
        org.joda.time.LocalDate localDate29 = localDate26.withYear((int) (byte) -1);
        int[] intArray30 = localDate26.getValues();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate26.plus(readablePeriod31);
        boolean boolean33 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology37, dateTimeField39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField40.getType();
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = skipDateTimeField40.getMinimumValue(readablePartial42);
        boolean boolean44 = iSOChronology34.equals((java.lang.Object) skipDateTimeField40);
        org.joda.time.Chronology chronology45 = iSOChronology34.withUTC();
        org.joda.time.LocalDate localDate46 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.LocalDate.Property property47 = localDate46.yearOfCentury();
        org.joda.time.LocalDate localDate49 = localDate46.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate51 = localDate49.minusWeeks(1);
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.LocalDate localDate53 = localDate51.minus(readablePeriod52);
        org.joda.time.Chronology chronology54 = localDate51.getChronology();
        int int55 = localDate12.compareTo((org.joda.time.ReadablePartial) localDate51);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.Interval interval18 = localDate17.toInterval();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipDateTimeField25.getMinimumValue(readablePartial27);
        boolean boolean29 = iSOChronology19.equals((java.lang.Object) skipDateTimeField25);
        org.joda.time.Chronology chronology30 = iSOChronology19.withUTC();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.LocalDate.Property property32 = localDate31.yearOfCentury();
        org.joda.time.LocalDate localDate34 = localDate31.withYear((int) (byte) -1);
        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks(1);
        boolean boolean38 = localDate36.equals((java.lang.Object) 1.0f);
        org.joda.time.LocalDate localDate40 = localDate36.withCenturyOfEra(2000);
        int int41 = localDate17.compareTo((org.joda.time.ReadablePartial) localDate40);
        org.joda.time.LocalDate.Property property42 = localDate17.weekyear();
        org.joda.time.LocalDate localDate43 = property42.roundHalfFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.LocalDate localDate45 = localDate43.plus(readablePeriod44);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
//        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
//        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        org.joda.time.Chronology chronology16 = iSOChronology1.withZone(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone15);
//        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = property19.getDifference(readableInstant20);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-433510) + "'", int21 == (-433510));
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = julianChronology0.add(readablePeriod2, (long) 'a', (int) (byte) 0);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
//        int int8 = dateTime7.getYear();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateMidnight9.toDateTime(dateTimeZone10);
//        int int12 = dateTime11.getYearOfCentury();
//        org.joda.time.DateTime.Property property13 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusYears(69);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime11.withDurationAdded(readableDuration16, (int) '4');
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-1L));
//        int int21 = dateTime20.getMinuteOfHour();
//        org.joda.time.DateTime dateTime23 = dateTime20.withSecondOfMinute(4);
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime23);
//        java.lang.String str25 = limitChronology24.toString();
//        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology28.getZone();
//        org.joda.time.Chronology chronology30 = copticChronology26.withZone(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getName((long) 2000, locale32);
//        long long36 = dateTimeZone29.convertLocalToUTC((-28799900L), false);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((-1L));
//        int int39 = dateTime38.getYear();
//        org.joda.time.DateMidnight dateMidnight40 = dateTime38.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = dateMidnight40.toDateTime(dateTimeZone41);
//        int int43 = dateTime42.getYearOfCentury();
//        org.joda.time.DateTime.Property property44 = dateTime42.weekOfWeekyear();
//        int int45 = dateTime42.getYearOfCentury();
//        org.joda.time.DateTime.Property property46 = dateTime42.monthOfYear();
//        int int47 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.Chronology chronology48 = limitChronology24.withZone(dateTimeZone29);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LimitChronology[JulianChronology[UTC], 1969-12-31T00:00:00.000-08:00, 1969-12-31T15:59:04.999-08:00]" + "'", str25.equals("LimitChronology[JulianChronology[UTC], 1969-12-31T00:00:00.000-08:00, 1969-12-31T15:59:04.999-08:00]"));
//        org.junit.Assert.assertNotNull(copticChronology26);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pacific Standard Time" + "'", str33.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
//        org.junit.Assert.assertNotNull(dateMidnight40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 69 + "'", int43 == 69);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 69 + "'", int45 == 69);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-28800000) + "'", int47 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology48);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.LocalDate localDate12 = dateTime1.toLocalDate();
        boolean boolean14 = dateTime1.isEqual(0L);
        org.joda.time.DateTime dateTime16 = dateTime1.withMillisOfDay((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial0.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial6 = partial0.withPeriodAdded(readablePeriod4, (int) (byte) 100);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = partial0.getFieldTypes();
        int[] intArray10 = new int[] { 'a', 57599999 };
        org.joda.time.Chronology chronology11 = null;
        try {
            org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldTypeArray7, intArray10, chronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipDateTimeField13.getMinimumValue(readablePartial15);
        boolean boolean17 = iSOChronology7.equals((java.lang.Object) skipDateTimeField13);
        org.joda.time.Chronology chronology18 = iSOChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.Chronology chronology22 = iSOChronology7.withZone(dateTimeZone21);
        java.lang.String str23 = dateTimeZone21.getID();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone21);
        long long28 = dateTimeZone21.convertLocalToUTC((long) (-69), false, (long) '#');
        boolean boolean30 = dateTimeZone21.isStandardOffset((-57599800000L));
        org.joda.time.Chronology chronology31 = zonedChronology6.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone32 = zonedChronology6.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "America/Los_Angeles" + "'", str23.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799931L + "'", long28 == 28799931L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime5.withDayOfMonth(11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-1L));
        int int15 = dateTime14.getYear();
        org.joda.time.DateMidnight dateMidnight16 = dateTime14.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateMidnight16.toDateTime(dateTimeZone17);
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        long long21 = iSOChronology0.set((org.joda.time.ReadablePartial) yearMonthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        org.joda.time.Chronology chronology34 = iSOChronology23.withUTC();
        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.LocalDate.Property property36 = localDate35.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipDateTimeField42.getType();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, readableInstant45);
        int int47 = gJChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField48 = gJChronology46.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, readableInstant50);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology51, dateTimeField53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField54.getType();
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = skipDateTimeField54.getMinimumValue(readablePartial56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = skipDateTimeField54.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField42, durationField48, dateTimeFieldType58);
        boolean boolean60 = property36.equals((java.lang.Object) durationField48);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, readableInstant62);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology63, dateTimeField65);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipDateTimeField66.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (java.lang.Number) 1L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, durationField48, dateTimeFieldType67, 10);
        long long76 = durationField48.subtract((long) (byte) 0, 28800001L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-28800001000L) + "'", long76 == (-28800001000L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (byte) 1, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) (short) 1, false);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 2);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.LocalDate localDate12 = dateTime1.toLocalDate();
        org.joda.time.LocalDate.Property property13 = localDate12.weekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
//        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
//        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        org.joda.time.Chronology chronology16 = iSOChronology1.withZone(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone15.getName((long) 99, locale20);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        org.joda.time.DateTime dateTime12 = dateTime1.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipDateTimeField19.getType();
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipDateTimeField19.getMinimumValue(readablePartial21);
        int int24 = skipDateTimeField19.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipDateTimeField19.getType();
        int int26 = dateTime12.get(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 999 + "'", int26 == 999);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
        long long27 = offsetDateTimeField25.roundHalfCeiling(0L);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField33.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField33.getType();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipDateTimeField42.getType();
        org.joda.time.ReadablePartial readablePartial44 = null;
        int int45 = skipDateTimeField42.getMinimumValue(readablePartial44);
        boolean boolean46 = iSOChronology36.equals((java.lang.Object) skipDateTimeField42);
        org.joda.time.Chronology chronology47 = iSOChronology36.withUTC();
        org.joda.time.LocalDate localDate48 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology36);
        int int49 = skipDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.LocalDate localDate51 = localDate48.withWeekyear(4);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, readableInstant54);
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology55, dateTimeField57);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = skipDateTimeField58.getType();
        org.joda.time.ReadablePartial readablePartial60 = null;
        int int61 = skipDateTimeField58.getMinimumValue(readablePartial60);
        boolean boolean62 = iSOChronology52.equals((java.lang.Object) skipDateTimeField58);
        org.joda.time.Chronology chronology63 = iSOChronology52.withUTC();
        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.LocalDate.Property property65 = localDate64.yearOfCentury();
        org.joda.time.LocalDate localDate67 = localDate64.withYear((int) (byte) -1);
        int[] intArray68 = localDate64.getValues();
        int int69 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray68);
        int int71 = offsetDateTimeField25.getMaximumValue((-210866500800000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 999 + "'", int49 == 999);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 99 + "'", int69 == 99);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.Chronology chronology14 = copticChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology18 = gregorianChronology7.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology7.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology7.getZone();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 15, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1L));
        int int8 = dateTime7.getYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        boolean boolean11 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime13 = dateTime1.plusWeeks(32);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str15 = gJChronology14.toString();
        boolean boolean16 = dateTime13.equals((java.lang.Object) str15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[UTC]" + "'", str15.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 4);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.joda.time.DateTime.Property property12 = dateTime10.secondOfMinute();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Pacific Standard Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "Pacific Standard Time");
        java.lang.String str17 = illegalFieldValueException16.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Pacific Standard Time\" for weekOfWeekyear is not supported" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value \"Pacific Standard Time\" for weekOfWeekyear is not supported"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate19 = localDate17.withEra((int) (byte) 1);
        org.joda.time.LocalTime localTime20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        java.util.TimeZone timeZone24 = dateTimeZone23.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.DateTime dateTime26 = localDate19.toDateTime(localTime20, dateTimeZone25);
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
        int int28 = copticChronology27.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((-1L));
        int int31 = dateTime30.getYear();
        org.joda.time.DateMidnight dateMidnight32 = dateTime30.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTimeISO();
        boolean boolean34 = copticChronology27.equals((java.lang.Object) mutableDateTime33);
        boolean boolean35 = localDate19.equals((java.lang.Object) boolean34);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-9), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "59");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property4 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getMinuteOfHour();
        int int3 = dateTime1.getMinuteOfDay();
        boolean boolean5 = dateTime1.isBefore((long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 959 + "'", int3 == 959);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int int17 = skipDateTimeField14.getMinimumValue(readablePartial16);
//        boolean boolean18 = iSOChronology8.equals((java.lang.Object) skipDateTimeField14);
//        org.joda.time.Chronology chronology19 = iSOChronology8.withUTC();
//        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology8);
//        int int21 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate20);
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology25.getZone();
//        org.joda.time.Chronology chronology27 = copticChronology23.withZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, dateTimeZone26);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
//        java.lang.String str35 = dateTimeZone33.getShortName((long) (short) 10);
//        long long37 = dateTimeZone26.getMillisKeepLocal(dateTimeZone33, (long) (byte) 100);
//        org.joda.time.DateTime dateTime38 = localDate20.toDateTimeAtCurrentTime(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 999 + "'", int21 == 999);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(julianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PST" + "'", str35.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField5.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipDateTimeField14.getMinimumValue(readablePartial16);
        boolean boolean18 = iSOChronology8.equals((java.lang.Object) skipDateTimeField14);
        org.joda.time.Chronology chronology19 = iSOChronology8.withUTC();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.LocalDate.Property property21 = localDate20.era();
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial23.getFieldTypes();
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray26 = partial25.getFieldTypes();
        org.joda.time.Chronology chronology27 = partial25.getChronology();
        int[] intArray28 = partial25.getValues();
        org.joda.time.Partial partial29 = new org.joda.time.Partial(dateTimeFieldTypeArray24, intArray28);
        int[] intArray30 = new int[] {};
        org.joda.time.Partial partial31 = new org.joda.time.Partial(dateTimeFieldTypeArray24, intArray30);
        try {
            int[] intArray33 = skipDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, 0, intArray30, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Partial partial5 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray6 = partial5.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial5.minus(readablePeriod7);
        org.joda.time.Chronology chronology9 = partial5.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology(chronology9);
        org.joda.time.Chronology chronology11 = dateTimeFormatter10.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray6);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((-1L));
        int int72 = dateTime71.getYear();
        org.joda.time.DateMidnight dateMidnight73 = dateTime71.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateMidnight73.toDateTime(dateTimeZone74);
        int int76 = dateTime75.getYearOfCentury();
        org.joda.time.DateTime.Property property77 = dateTime75.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField79 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField68, dateTimeFieldType78);
        boolean boolean80 = dividedDateTimeField79.isLenient();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField81 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField79);
        long long84 = dividedDateTimeField79.add((long) (-25200000), 959);
        int int85 = dividedDateTimeField79.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 69 + "'", int76 == 69);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1739984400000L + "'", long84 == 1739984400000L);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 17 + "'", int85 == 17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        int int2 = dateTime1.getYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateMidnight3.toDateTime(dateTimeZone4);
        int int6 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (java.lang.Number) 1L);
        java.lang.Number number11 = illegalFieldValueException10.getUpperBound();
        java.lang.String str12 = illegalFieldValueException10.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType13 = illegalFieldValueException10.getDurationFieldType();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNull(durationFieldType13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
        org.joda.time.Chronology chronology6 = copticChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = copticChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.Chronology chronology19 = gregorianChronology8.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1970, dateTimeZone14);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int int20 = skipDateTimeField17.getMinimumValue(readablePartial19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField17.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType21, 99, (int) (byte) 1, 0);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField31.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField31.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology37, dateTimeField39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField40.getType();
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int int43 = skipDateTimeField40.getMinimumValue(readablePartial42);
//        boolean boolean44 = iSOChronology34.equals((java.lang.Object) skipDateTimeField40);
//        org.joda.time.Chronology chronology45 = iSOChronology34.withUTC();
//        org.joda.time.LocalDate localDate46 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology34);
//        int int47 = skipDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localDate46);
//        org.joda.time.LocalDate localDate49 = localDate46.withWeekyear(4);
//        org.joda.time.DateTime dateTime50 = localDate46.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate.Property property51 = localDate46.era();
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.ReadableInstant readableInstant54 = null;
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, readableInstant54);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology55, dateTimeField57);
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = skipDateTimeField58.getType();
//        org.joda.time.ReadablePartial readablePartial60 = null;
//        int int61 = skipDateTimeField58.getMinimumValue(readablePartial60);
//        boolean boolean62 = iSOChronology52.equals((java.lang.Object) skipDateTimeField58);
//        org.joda.time.Chronology chronology63 = iSOChronology52.withUTC();
//        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology52);
//        org.joda.time.LocalDate.Property property65 = localDate64.yearOfCentury();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((-1L));
//        int int68 = property65.compareTo((org.joda.time.ReadableInstant) dateTime67);
//        org.joda.time.LocalDate localDate69 = property65.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
//        org.joda.time.DateMidnight dateMidnight72 = localDate69.toDateMidnight(dateTimeZone71);
//        org.joda.time.DateTime dateTime73 = localDate46.toDateTimeAtMidnight(dateTimeZone71);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.lang.String str75 = localDate46.toString(dateTimeFormatter74);
//        org.joda.time.LocalDate localDate77 = localDate46.minusMonths(1969);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = offsetDateTimeField25.getAsText((org.joda.time.ReadablePartial) localDate77, 1, locale79);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 999 + "'", int47 == 999);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(chronology63);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(dateMidnight72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2019-W24" + "'", str75.equals("2019-W24"));
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "1" + "'", str80.equals("1"));
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isAfterNow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (java.lang.Number) 1L);
        java.lang.String str11 = illegalFieldValueException10.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for millisOfSecond must be in the range [10,1]" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value 0 for millisOfSecond must be in the range [10,1]"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = julianChronology17.add(readablePeriod19, (long) 'a', (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField29.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipDateTimeField29.getMinimumValue(readablePartial31);
        boolean boolean33 = iSOChronology23.equals((java.lang.Object) skipDateTimeField29);
        int int36 = skipDateTimeField29.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate49);
        java.util.Locale locale51 = null;
        int int52 = skipDateTimeField29.getMaximumShortTextLength(locale51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, (org.joda.time.DateTimeField) skipDateTimeField29);
        org.joda.time.DurationField durationField54 = skipDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, readableInstant56);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = skipDateTimeField60.getMinimumValue(readablePartial62);
        int int65 = skipDateTimeField60.get(100L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField60.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField54, dateTimeFieldType66, 3);
        org.joda.time.DurationField durationField69 = remainderDateTimeField68.getLeapDurationField();
        long long71 = remainderDateTimeField68.roundHalfEven((long) 59);
        org.joda.time.DurationField durationField72 = remainderDateTimeField68.getDurationField();
        java.util.Locale locale73 = null;
        int int74 = remainderDateTimeField68.getMaximumTextLength(locale73);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-69) + "'", int36 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(durationField69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-230400000L) + "'", long71 == (-230400000L));
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField7.getMinimumValue(readablePartial9);
        boolean boolean11 = iSOChronology1.equals((java.lang.Object) skipDateTimeField7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.Chronology chronology16 = iSOChronology1.withZone(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.getID();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 99, dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.DateTime dateTime36 = dateTime19.withField(dateTimeFieldType34, 2000);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone39 = julianChronology38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime19.toDateTime((org.joda.time.Chronology) julianChronology38);
        int int41 = dateTime19.getSecondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
//        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyear();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-1L));
//        int int15 = dateTime14.getYear();
//        org.joda.time.DateMidnight dateMidnight16 = dateTime14.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = dateMidnight16.toDateTime(dateTimeZone17);
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        long long21 = iSOChronology0.set((org.joda.time.ReadablePartial) yearMonthDay19, 0L);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology0.centuryOfEra();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        long long24 = dateTime23.getMillis();
//        boolean boolean26 = dateTime23.isEqual((long) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560637625287L + "'", long24 == 1560637625287L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        java.util.Locale locale28 = null;
        int int29 = skipDateTimeField6.getMaximumShortTextLength(locale28);
        int int31 = skipDateTimeField6.getLeapAmount((long) 2000);
        int int33 = skipDateTimeField6.get(212399999L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        int int13 = skipDateTimeField6.getDifference(0L, (long) 69);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField20.getMinimumValue(readablePartial22);
        boolean boolean24 = iSOChronology14.equals((java.lang.Object) skipDateTimeField20);
        org.joda.time.Chronology chronology25 = iSOChronology14.withUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology14);
        int int27 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.DurationField durationField28 = skipDateTimeField6.getRangeDurationField();
        int int30 = skipDateTimeField6.get(110L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-69) + "'", int13 == (-69));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 999 + "'", int27 == 999);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 110 + "'", int30 == 110);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = skipDateTimeField6.getMinimumValue(readablePartial8);
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) skipDateTimeField6);
        org.joda.time.Chronology chronology11 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1L));
        int int16 = property13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = property13.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate19 = localDate17.withEra((int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField26.getMinimumValue(readablePartial28);
        boolean boolean30 = iSOChronology20.equals((java.lang.Object) skipDateTimeField26);
        org.joda.time.Chronology chronology31 = iSOChronology20.withUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.LocalDate.Property property33 = localDate32.yearOfCentury();
        org.joda.time.LocalDate localDate35 = localDate32.plusWeeks(0);
        org.joda.time.LocalDate localDate36 = localDate17.withFields((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField43.getMinimumValue(readablePartial45);
        boolean boolean47 = iSOChronology37.equals((java.lang.Object) skipDateTimeField43);
        org.joda.time.Chronology chronology48 = iSOChronology37.withUTC();
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology37);
        org.joda.time.LocalDate.Property property50 = localDate49.dayOfMonth();
        int int51 = localDate49.getYearOfEra();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((-1L));
        int int54 = dateTime53.getYear();
        org.joda.time.DateMidnight dateMidnight55 = dateTime53.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = dateMidnight55.toDateTime(dateTimeZone56);
        int int58 = dateTime57.getYearOfCentury();
        org.joda.time.DateTime.Property property59 = dateTime57.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0d, (java.lang.Number) 110L);
        org.joda.time.LocalDate.Property property65 = localDate49.property(dateTimeFieldType60);
        org.joda.time.LocalDate localDate67 = localDate49.minusYears(32);
        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone69, readableInstant70);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = iSOChronology72.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField74 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField73);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = skipDateTimeField74.getType();
        org.joda.time.ReadablePartial readablePartial76 = null;
        int int77 = skipDateTimeField74.getMinimumValue(readablePartial76);
        boolean boolean78 = iSOChronology68.equals((java.lang.Object) skipDateTimeField74);
        org.joda.time.Chronology chronology79 = iSOChronology68.withUTC();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology68.weekyear();
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime((-1L));
        int int83 = dateTime82.getYear();
        org.joda.time.DateMidnight dateMidnight84 = dateTime82.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone85 = null;
        org.joda.time.DateTime dateTime86 = dateMidnight84.toDateTime(dateTimeZone85);
        org.joda.time.YearMonthDay yearMonthDay87 = dateTime86.toYearMonthDay();
        long long89 = iSOChronology68.set((org.joda.time.ReadablePartial) yearMonthDay87, 0L);
        int int90 = localDate67.compareTo((org.joda.time.ReadablePartial) yearMonthDay87);
        int int91 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate67);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 69 + "'", int58 == 69);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(iSOChronology68);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1969 + "'", int83 == 1969);
        org.junit.Assert.assertNotNull(dateMidnight84);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(yearMonthDay87);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.Chronology chronology14 = copticChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology18 = gregorianChronology7.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology7.hourOfHalfday();
        org.joda.time.Chronology chronology20 = gregorianChronology7.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
    }
}

