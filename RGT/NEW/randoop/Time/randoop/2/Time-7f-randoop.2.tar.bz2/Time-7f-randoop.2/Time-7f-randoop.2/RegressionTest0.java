import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', 0, (int) (byte) -1, (int) (short) 1, 0, (int) (short) 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 'a', chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 10, "hi!");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            int int2 = mutableDateTime0.get(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeField4, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.PreciseDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (short) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.millisOfSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) false, (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(19, (int) (short) 0, 10, 0, (int) (byte) 0, (int) '4', (int) '4', (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withYearOfEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology1);
        try {
            java.lang.String str6 = mutableDateTime4.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.addWeekyears((int) '#');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long10 = gregorianChronology1.add((long) 100, (long) '#', (int) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 450L + "'", long10 == 450L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '4', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1664 + "'", int2 == 1664);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) -1, (int) ' ', (int) '#', (int) (short) 10, (int) (short) 10, (int) '#', (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gregorianChronology1.add(readablePeriod6, 0L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withYear(10);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField6.getAsShortText(10L, locale8);
        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        long long19 = offsetDateTimeField5.roundHalfFloor(86400000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 86400000L + "'", long19 == 86400000L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(19, 0, 0, 4, (int) (byte) 1, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        try {
            long long6 = iSOChronology0.getDateTimeMillis(12, 0, 1970, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod5, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.addDays(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withSecondOfMinute((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, (int) (byte) 0, (int) (short) 1, (-1), (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 52, (-1), (int) (byte) 10, 100, (int) (byte) 10, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24405880L + "'", long2 == 24405880L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "PST");
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0, (-28800000), 6, (-28800000), 0, (int) (short) -1, (int) (byte) 10, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 1, (int) '#', (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for  must be in the range [35,-28800000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis(1664, 10, 2019, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis((int) (short) 100, (-1), 0, 0, (int) (byte) -1, 4, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int23 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology22);
        boolean boolean26 = gregorianChronology22.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
        org.joda.time.DateTime dateTime29 = dateTime27.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay30 = dateTime27.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '4');
        org.joda.time.ReadablePartial readablePartial38 = null;
        int[] intArray45 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int46 = offsetDateTimeField37.getMinimumValue(readablePartial38, intArray45);
        try {
            int[] intArray48 = offsetDateTimeField21.add((org.joda.time.ReadablePartial) timeOfDay30, 0, intArray45, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29 for hourOfDay must be in the range [56,79]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(timeOfDay30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType3, 52, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        try {
//            long long22 = limitChronology16.getDateTimeMillis((long) 6, 6, 6, (int) (byte) 1, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T12:18:04.252Z (GregorianChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
        try {
            mutableDateTime5.setDateTime(1, (int) (short) 0, (int) (short) 0, (int) '#', (int) (short) 100, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        java.util.Locale locale22 = null;
        try {
            long long23 = offsetDateTimeField5.set((long) 6, "dayOfMonth", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfMonth\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        try {
            long long8 = buddhistChronology3.getDateTimeMillis(0, 52, 2019, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 1, (-82800001L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-82800000L) + "'", long2 == (-82800000L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField7.getAsText((long) (short) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int18 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology17);
        boolean boolean21 = gregorianChronology17.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime22.toDateTimeISO();
        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime24.withYearOfCentury(0);
        org.joda.time.LocalDateTime localDateTime29 = dateTime24.toLocalDateTime();
        int[] intArray34 = new int[] { 1, (short) -1, 10 };
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) localDateTime29, (int) 'a', intArray34, "hi!", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.millisOfSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 10.0d, (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str11 = dateTimeZone10.toString();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) long9, dateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(julianChronology12);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        try {
            mutableDateTime2.setDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        try {
//            long long7 = julianChronology2.getDateTimeMillis(1, 12, 0, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(julianChronology2);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-06-12T12:18:00.916Z");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        try {
            mutableDateTime2.setHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) (short) 100, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 12, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for hourOfDay must be in the range [100,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType23, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        boolean boolean12 = skipUndoDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray20 = new int[] { (short) 10, 12, (-1), 4, 10 };
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology24.getZone();
        mutableDateTime23.setChronology((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology24.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField37);
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology33, locale39);
        dateTimeParserBucket40.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology43.getZone();
        dateTimeParserBucket40.setZone(dateTimeZone47);
        java.util.Locale locale49 = dateTimeParserBucket40.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology24, locale49, (java.lang.Integer) 0);
        try {
            int[] intArray52 = skipUndoDateTimeField7.set(readablePartial13, (int) (byte) -1, intArray20, "", locale49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(locale49);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        int int23 = offsetDateTimeField5.getOffset();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology24);
        boolean boolean28 = gregorianChronology24.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
        org.joda.time.DateTime dateTime31 = dateTime29.toDateTimeISO();
        org.joda.time.DateTime dateTime33 = dateTime31.withWeekyear((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime31.toYearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology37, dateTimeField41);
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology37, locale43);
        dateTimeParserBucket44.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology47.getZone();
        dateTimeParserBucket44.setZone(dateTimeZone51);
        java.util.Locale locale53 = dateTimeParserBucket44.getLocale();
        try {
            java.lang.String str54 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) yearMonthDay34, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(locale53);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(12, 2019, (int) (short) 0, 0, (int) (byte) -1, (int) 'a', (int) '#', chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) '#', (int) (short) 10, (int) (short) 10, 100, (-1), 0, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        try {
            long long16 = skipUndoDateTimeField7.set(2440588L, 1664);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1664 for dayOfMonth must be in the range [0,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        java.lang.String str7 = skipUndoDateTimeField6.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology8);
        boolean boolean12 = gregorianChronology8.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime13.toTimeOfDay();
        int[] intArray18 = null;
        try {
            int[] intArray20 = skipUndoDateTimeField6.addWrapField((org.joda.time.ReadablePartial) timeOfDay16, 3, intArray18, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str7.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(timeOfDay16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        boolean boolean6 = property4.isLeap();
        int int7 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1.0d, (java.lang.Number) 100L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 52, (java.lang.Number) 100.0d, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = dateTime5.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long23 = offsetDateTimeField21.roundCeiling((long) 0);
        long long26 = offsetDateTimeField21.getDifferenceAsLong((-82800001L), (-1L));
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology30.getZone();
        mutableDateTime29.setChronology((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology30.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology39);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology39, dateTimeField43);
        java.util.Locale locale45 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology39, locale45);
        dateTimeParserBucket46.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology49.getZone();
        dateTimeParserBucket46.setZone(dateTimeZone53);
        java.util.Locale locale55 = dateTimeParserBucket46.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology30, locale55, (java.lang.Integer) 0);
        try {
            java.lang.String str58 = offsetDateTimeField21.getAsShortText(readablePartial27, locale55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-23L) + "'", long26 == (-23L));
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(locale55);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) '4');
        org.joda.time.ReadablePartial readablePartial12 = null;
        int[] intArray19 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int20 = offsetDateTimeField11.getMinimumValue(readablePartial12, intArray19);
        int int23 = offsetDateTimeField11.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, 4);
        org.joda.time.DurationField durationField28 = offsetDateTimeField27.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime31 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology32.getZone();
        mutableDateTime31.setChronology((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology32.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology41, dateTimeField45);
        java.util.Locale locale47 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology41, locale47);
        dateTimeParserBucket48.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology51.getZone();
        dateTimeParserBucket48.setZone(dateTimeZone55);
        java.util.Locale locale57 = dateTimeParserBucket48.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology32, locale57, (java.lang.Integer) 0);
        java.lang.String str60 = offsetDateTimeField27.getAsShortText(10, locale57);
        try {
            org.joda.time.MutableDateTime mutableDateTime61 = property4.set("", locale57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(locale57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime17 = limitChronology16.getUpperLimit();
//        int int18 = dateTime17.getDayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime23 = dateTime17.withTime((int) (byte) -1, (int) (byte) 100, (-1), (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField9.getAsShortText(0L, locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField14 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField9, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '#');
        int int4 = dateTime3.getWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime3.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(dateTimeZone8);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
//        mutableDateTime2.setSecondOfDay(19);
//        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        long long11 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) (short) 100);
//        java.lang.String str13 = dateTimeZone7.getShortName(0L);
//        boolean boolean15 = dateTimeZone7.isStandardOffset((long) (byte) -1);
//        mutableDateTime2.setZoneRetainFields(dateTimeZone7);
//        mutableDateTime2.setYear(1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        long long4 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
//        try {
//            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        int int8 = skipUndoDateTimeField6.get((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime14.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay17 = dateTime14.toTimeOfDay();
        int[] intArray22 = new int[] { (byte) 100, (byte) 10, '#' };
        try {
            int[] intArray24 = skipUndoDateTimeField6.addWrapField((org.joda.time.ReadablePartial) timeOfDay17, (int) (byte) 1, intArray22, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        boolean boolean12 = skipUndoDateTimeField7.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        org.joda.time.DateTime dateTime20 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime20.withYearOfCentury(0);
        org.joda.time.LocalDateTime localDateTime25 = dateTime20.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) '4');
        org.joda.time.ReadablePartial readablePartial33 = null;
        int[] intArray40 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int41 = offsetDateTimeField32.getMinimumValue(readablePartial33, intArray40);
        try {
            int[] intArray43 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) localDateTime25, (int) ' ', intArray40, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', 4, 52, 1664, 6, (int) (short) -1, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1664 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) 10, 1664, (int) (byte) 100, 2019, 19, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '#');
//        int int13 = dateTime12.getWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withDayOfYear(10);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.DateTime dateTime18 = dateTime12.toDateTime(dateTimeZone17);
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            org.joda.time.DateTime dateTime22 = dateTime18.withField(dateTimeFieldType20, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        try {
            long long14 = gregorianChronology1.getDateTimeMillis(1664, (int) (byte) -1, 0, (int) (short) -1, (int) (byte) 10, (int) (short) 10, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, 10, 1970, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray30 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int31 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray30);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField22);
//        long long35 = skipDateTimeField32.getDifferenceAsLong(52L, (long) (short) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType6, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
        try {
            org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder4.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        java.lang.String str27 = offsetDateTimeField7.getAsShortText(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "52" + "'", str27.equals("52"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        org.joda.time.Instant instant5 = instant0.withDurationAdded((long) 18, 0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        org.joda.time.DurationField durationField26 = gregorianChronology0.millis();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int28 = gregorianChronology27.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology27);
        boolean boolean31 = gregorianChronology27.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime dateTime34 = dateTime32.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay35 = dateTime32.toTimeOfDay();
        int[] intArray41 = new int[] { (byte) 0, 'a', 1970, (-1), (short) -1 };
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) timeOfDay35, intArray41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must not be larger than 59");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(timeOfDay35);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("America/Los_Angeles", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 31, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1612 + "'", int2 == 1612);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 31, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) 450L, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology12);
        boolean boolean16 = gregorianChronology12.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime17.toTimeOfDay();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, dateTimeField27);
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField(chronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField28, 0);
        long long32 = skipUndoDateTimeField28.roundHalfCeiling(0L);
        long long34 = skipUndoDateTimeField28.roundHalfEven((long) 1970);
        int int36 = skipUndoDateTimeField28.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology40.getZone();
        mutableDateTime39.setChronology((org.joda.time.Chronology) gregorianChronology40);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology40.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean50 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology49);
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology49, dateTimeField53);
        java.util.Locale locale55 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology49, locale55);
        dateTimeParserBucket56.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology59.getZone();
        dateTimeParserBucket56.setZone(dateTimeZone63);
        java.util.Locale locale65 = dateTimeParserBucket56.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket67 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology40, locale65, (java.lang.Integer) 0);
        java.lang.String str68 = skipUndoDateTimeField28.getAsShortText((int) (short) 10, locale65);
        try {
            java.lang.String str69 = skipUndoDateTimeField6.getAsText((org.joda.time.ReadablePartial) timeOfDay20, locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 31 + "'", int36 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(locale65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10" + "'", str68.equals("10"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfMinute();
        org.joda.time.DateTime dateTime12 = dateTime7.plusYears(0);
        try {
            org.joda.time.DateTime dateTime16 = dateTime7.withDate(31, (int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
//        dateTimeParserBucket9.setOffset((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone12.toString();
//        dateTimeParserBucket9.setZone(dateTimeZone12);
//        long long16 = dateTimeParserBucket9.computeMillis(false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        dateTimeParserBucket9.setZone(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6L) + "'", long16 == (-6L));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        boolean boolean4 = instant0.isAfter(0L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.getDifferenceAsLong(24405880L, (long) '4');
        boolean boolean10 = skipUndoDateTimeField6.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = gregorianChronology11.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
        org.joda.time.DateTime dateTime18 = dateTime16.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay19 = dateTime16.toTimeOfDay();
        int[] intArray27 = new int[] { 1664, (-28800000), '#', '#', (byte) 0, (short) 10 };
        try {
            int[] intArray29 = skipUndoDateTimeField6.set((org.joda.time.ReadablePartial) timeOfDay19, 1970, intArray27, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(timeOfDay19);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(19);
        try {
            org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatterBuilder0.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
//        int int2 = dateTime1.getWeekyear();
//        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
//        int int5 = dateTime4.getMinuteOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            long long2 = dateTimeFormatter0.parseMillis("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        boolean boolean23 = offsetDateTimeField21.isLeap(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        int int8 = skipUndoDateTimeField6.get((long) (-1));
        boolean boolean9 = skipUndoDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (short) 0);
        org.joda.time.Instant instant5 = instant2.withDurationAdded((long) 31, 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology5);
        int int8 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        boolean boolean10 = mutableDateTime2.isBefore(35L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-28800000), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800000L + "'", long2 == 28800000L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"35\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getRangeDurationField();
        org.joda.time.DurationField durationField23 = offsetDateTimeField21.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.Instant instant4 = instant0.withMillis((long) 52);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long12 = skipUndoDateTimeField7.addWrapField((long) '#', 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType13, 960, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400035L + "'", long12 == 86400035L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(1439, 0, (int) ' ', 31, (int) (byte) 100, 19, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("56");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        java.lang.String str7 = skipUndoDateTimeField6.toString();
        long long10 = skipUndoDateTimeField6.addWrapField((long) ' ', 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str7.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 864000032L + "'", long10 == 864000032L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("56", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"56/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T12:18:13.918Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 'a', (long) 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1164 + "'", int2 == 1164);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        mutableDateTime2.setZoneRetainFields(dateTimeZone3);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:18:14.363Z" + "'", str1.equals("2019-06-12T12:18:14.363Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfMonth((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 1970);
        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.minusMonths(3);
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTimeISO();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(28800001L, (-82800000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 111600001L + "'", long2 == 111600001L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-12T12:18:13.918Z", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-12T12:18:13.918Z/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(19);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendLiteral("hi!");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        mutableDateTime3.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '#');
        int int13 = dateTime12.getWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime12.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime12.toDateTime(dateTimeZone17);
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.minusMonths((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime18.plusSeconds(2000);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) (byte) 1, 1970, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        mutableDateTime6.addSeconds(1);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        mutableDateTime1.setChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology11, locale17);
        dateTimeParserBucket18.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology21.getZone();
        dateTimeParserBucket18.setZone(dateTimeZone25);
        java.util.Locale locale27 = dateTimeParserBucket18.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology2, locale27, (java.lang.Integer) 0);
        int int30 = dateTimeParserBucket29.getOffset();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute(0, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(4, (int) '#', 960, (int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long13 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, (int) (byte) 0, 0, 31, 0, 0, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(28799949L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28799950L + "'", long2 == 28799950L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField9.getAsShortText(0L, locale11);
        int int13 = skipDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        try {
            long long30 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 31, 2019, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        org.joda.time.DurationField durationField26 = offsetDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long7 = julianChronology2.getDateTimeMillis(1612, 0, 1612, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfYear();
        java.lang.String str5 = property4.getAsString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        int int10 = mutableDateTime9.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime14 = property11.add((long) 3);
        int int15 = property11.getMinimumValue();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider16 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField23);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField(chronology17, (org.joda.time.DateTimeField) skipUndoDateTimeField24, 0);
        long long28 = skipUndoDateTimeField24.roundHalfCeiling(0L);
        long long30 = skipUndoDateTimeField24.roundHalfEven((long) 1970);
        int int32 = skipUndoDateTimeField24.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology36.getZone();
        mutableDateTime35.setChronology((org.joda.time.Chronology) gregorianChronology36);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology36.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology45);
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, dateTimeField49);
        java.util.Locale locale51 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology45, locale51);
        dateTimeParserBucket52.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology55.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone59 = gregorianChronology55.getZone();
        dateTimeParserBucket52.setZone(dateTimeZone59);
        java.util.Locale locale61 = dateTimeParserBucket52.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology36, locale61, (java.lang.Integer) 0);
        java.lang.String str64 = skipUndoDateTimeField24.getAsShortText((int) (short) 10, locale61);
        java.lang.String str67 = defaultNameProvider16.getShortName(locale61, "31", "PST");
        java.lang.String str68 = property11.getAsShortText(locale61);
        try {
            org.joda.time.MutableDateTime mutableDateTime69 = property4.set("ISOChronology[UTC]", locale61);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Sun" + "'", str68.equals("Sun"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear(6, (int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear((-7));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendFractionOfMinute(12, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
        mutableDateTime4.setMonthOfYear((int) (short) 1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 1970);
        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider9 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField16);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField(chronology10, (org.joda.time.DateTimeField) skipUndoDateTimeField17, 0);
        long long21 = skipUndoDateTimeField17.roundHalfCeiling(0L);
        long long23 = skipUndoDateTimeField17.roundHalfEven((long) 1970);
        int int25 = skipUndoDateTimeField17.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology29.getZone();
        mutableDateTime28.setChronology((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology29.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean39 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology38, dateTimeField42);
        java.util.Locale locale44 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology38, locale44);
        dateTimeParserBucket45.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology48.getZone();
        dateTimeParserBucket45.setZone(dateTimeZone52);
        java.util.Locale locale54 = dateTimeParserBucket45.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology29, locale54, (java.lang.Integer) 0);
        java.lang.String str57 = skipUndoDateTimeField17.getAsShortText((int) (short) 10, locale54);
        java.lang.String str60 = defaultNameProvider9.getShortName(locale54, "31", "PST");
        try {
            org.joda.time.DateTime dateTime61 = property7.setCopy("America/Los_Angeles", locale54);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(locale54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10" + "'", str57.equals("10"));
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(1612);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 1612);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime8.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear(12);
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withTime(0, 6, 1439, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = mutableDateTime2.isSupported(dateTimeFieldType6);
        try {
            mutableDateTime2.setMinuteOfHour((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray16 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int17 = offsetDateTimeField8.getMinimumValue(readablePartial9, intArray16);
        int int20 = offsetDateTimeField8.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '4');
        int int25 = offsetDateTimeField8.getDifference((long) '4', (long) '#');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int29 = gregorianChronology28.getMinimumDaysInFirstWeek();
        boolean boolean30 = iSOChronology0.equals((java.lang.Object) gregorianChronology28);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatterBuilder1.toFormatter();
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("T12:18:05.908Z", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T12:18:05.908Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.Chronology chronology15 = gregorianChronology10.withZone(dateTimeZone13);
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((int) '4', (int) (byte) 1, (int) (short) 1, 2000, (int) (short) 0, 6, (-7), dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 6, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 600 + "'", int2 == 600);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-82800000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        org.joda.time.DurationField durationField26 = gregorianChronology0.millis();
        org.joda.time.ReadablePartial readablePartial27 = null;
        try {
            int[] intArray29 = gregorianChronology0.get(readablePartial27, 28800001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        long long6 = gregorianChronology0.getDateTimeMillis((int) '#', 3, (int) (short) 10, 18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61056806399982L) + "'", long6 == (-61056806399982L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        int int28 = mutableDateTime2.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime2.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, (int) (byte) 10, 12, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for secondOfMinute must be in the range [12,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(174441601664L, (-23L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -4012156838272");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        dateTimeParserBucket9.setZone(dateTimeZone16);
        java.lang.Integer int18 = dateTimeParserBucket9.getOffsetInteger();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18.equals(1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        int int28 = mutableDateTime2.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        long long30 = offsetDateTimeField13.roundCeiling((long) 0);
        long long32 = offsetDateTimeField13.roundCeiling(86400000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        long long26 = offsetDateTimeField7.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField7.getType();
        try {
            org.joda.time.DateTime dateTime29 = dateTime0.withField(dateTimeFieldType27, 600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-82800001L) + "'", long26 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("2019-06-12T12:18:14.363Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        long long6 = durationField3.subtract(0L, 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        mutableDateTime3.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime8.addSeconds((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.year();
        mutableDateTime8.setYear(2000);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
//        mutableDateTime2.setSecondOfDay(19);
//        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        long long11 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) (short) 100);
//        java.lang.String str13 = dateTimeZone7.getShortName(0L);
//        boolean boolean15 = dateTimeZone7.isStandardOffset((long) (byte) -1);
//        mutableDateTime2.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 69");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(gJChronology17);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology10.getZone();
//        long long16 = dateTimeZone13.adjustOffset(1L, false);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField24);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology18, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
//        long long29 = skipUndoDateTimeField25.roundHalfCeiling(0L);
//        long long31 = skipUndoDateTimeField25.roundHalfEven((long) 1970);
//        int int33 = skipUndoDateTimeField25.getMaximumValue((long) (-28800000));
//        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology37.getZone();
//        mutableDateTime36.setChronology((org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology37.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField50);
//        java.util.Locale locale52 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology46, locale52);
//        dateTimeParserBucket53.setOffset((java.lang.Integer) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology56.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology56.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology56.getZone();
//        dateTimeParserBucket53.setZone(dateTimeZone60);
//        java.util.Locale locale62 = dateTimeParserBucket53.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology37, locale62, (java.lang.Integer) 0);
//        java.lang.String str65 = skipUndoDateTimeField25.getAsShortText((int) (short) 10, locale62);
//        java.lang.String str66 = dateTimeZone13.getName(52L, locale62);
//        try {
//            org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((int) (byte) 10, 3, (int) (short) 10, (int) '4', 1970, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 31 + "'", int33 == 31);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(locale62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Coordinated Universal Time" + "'", str66.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        int int28 = mutableDateTime2.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        long long30 = offsetDateTimeField13.roundCeiling((long) 0);
        try {
            long long33 = offsetDateTimeField13.set((long) 960, "365");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [52,75]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology7.getZone();
        mutableDateTime6.setChronology((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) '#', 75, 1612, 10, (int) (short) 100, 70, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(3, 0, 52, 19, 1164, 18, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1164 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        long long6 = dateTimeZone1.adjustOffset((long) 600, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 600L + "'", long6 == 600L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getDayOfWeek();
        mutableDateTime2.addHours((-1));
        try {
            mutableDateTime2.setDayOfYear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        long long10 = dateTimeParserBucket9.computeMillis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4L + "'", long10 == 4L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        mutableDateTime3.setSecondOfDay(19);
        mutableDateTime3.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray22 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial15, intArray22);
        int int26 = offsetDateTimeField14.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) '4');
        int int29 = mutableDateTime3.get((org.joda.time.DateTimeField) offsetDateTimeField14);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 31, 28800001L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800032L + "'", long2 == 28800032L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = mutableDateTime2.getZone();
        mutableDateTime2.setDate((int) '#', (int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray16 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int17 = offsetDateTimeField8.getMinimumValue(readablePartial9, intArray16);
        int int20 = offsetDateTimeField8.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, 4);
        long long27 = offsetDateTimeField8.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField8.getType();
        mutableDateTime2.set(dateTimeFieldType28, 0);
        int int31 = mutableDateTime2.getHourOfDay();
        mutableDateTime2.addMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-82800001L) + "'", long27 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.minuteOfDay();
        mutableDateTime4.setSecondOfDay(19);
        mutableDateTime4.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        int int30 = mutableDateTime4.get((org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime4.secondOfMinute();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology8);
        boolean boolean12 = gregorianChronology8.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime15.toYearMonthDay();
        try {
            int int19 = property4.compareTo((org.joda.time.ReadablePartial) yearMonthDay18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology5);
        int int8 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str10 = mutableDateTime2.toString(dateTimeFormatter9);
        boolean boolean11 = dateTimeFormatter9.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        int int8 = property4.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DurationField durationField10 = property6.getDurationField();
        org.joda.time.DateTime dateTime11 = property6.roundHalfEvenCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField17);
        java.lang.String str19 = skipUndoDateTimeField18.toString();
        boolean boolean20 = property6.equals((java.lang.Object) skipUndoDateTimeField18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int22 = gregorianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology21);
        boolean boolean25 = gregorianChronology21.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTime.Property property27 = dateTime26.yearOfCentury();
        org.joda.time.DateTime dateTime28 = dateTime26.toDateTimeISO();
        org.joda.time.DateTime dateTime30 = dateTime28.withWeekyear((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime28.toYearMonthDay();
        int[] intArray37 = new int[] { (short) 100, 1439, 2000, (byte) 0 };
        try {
            int[] intArray39 = skipUndoDateTimeField18.set((org.joda.time.ReadablePartial) yearMonthDay31, (int) (short) 10, intArray37, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1438");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str19.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str13 = dateTimeZone12.toString();
        dateTimeParserBucket9.setZone(dateTimeZone12);
        long long16 = dateTimeParserBucket9.computeMillis(false);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray30 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int31 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray30);
        int int34 = offsetDateTimeField22.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, 4);
        long long41 = offsetDateTimeField22.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField22.getType();
        dateTimeParserBucket9.saveField(dateTimeFieldType42, (int) (byte) -1);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (byte) 100, 52, 1664);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6L) + "'", long16 == (-6L));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-82800001L) + "'", long41 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (short) 1, 31);
        try {
            org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatterBuilder1.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        int int8 = mutableDateTime2.getYearOfEra();
        try {
            mutableDateTime2.setWeekOfWeekyear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        int int28 = mutableDateTime2.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        mutableDateTime2.add((long) (byte) 0);
        org.joda.time.DateTimeField dateTimeField31 = mutableDateTime2.getRoundingField();
        int int32 = mutableDateTime2.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        boolean boolean2 = instant1.isEqualNow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        org.joda.time.DurationField durationField26 = gregorianChronology0.millis();
        long long29 = durationField26.subtract((long) 100, (int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField8, 0);
        long long12 = skipUndoDateTimeField8.roundHalfCeiling(0L);
        long long14 = skipUndoDateTimeField8.roundHalfEven((long) 1970);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText((long) (short) -1, locale16);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31" + "'", str17.equals("31"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray16 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int17 = offsetDateTimeField8.getMinimumValue(readablePartial9, intArray16);
        int int20 = offsetDateTimeField8.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField8, 0);
        org.joda.time.DurationField durationField27 = gregorianChronology1.millis();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (-1), 3, 0, 1612);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1612 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        int int8 = dateTime5.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withYearOfCentury(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 100, (int) (byte) -1, (int) (byte) -1, (int) 'a', 19, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        java.lang.String str4 = property3.getAsText();
        java.lang.String str5 = property3.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "minuteOfDay" + "'", str5.equals("minuteOfDay"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.getDateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        int int8 = property4.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfFloor();
        int int10 = mutableDateTime9.getDayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        long long24 = offsetDateTimeField5.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int26 = gregorianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology25);
        boolean boolean29 = gregorianChronology25.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property31 = dateTime30.yearOfCentury();
        org.joda.time.DateTime dateTime32 = dateTime30.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay33 = dateTime30.toTimeOfDay();
        int[] intArray35 = new int[] {};
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfMonth();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField46);
        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField(chronology40, (org.joda.time.DateTimeField) skipUndoDateTimeField47, 0);
        long long51 = skipUndoDateTimeField47.roundHalfCeiling(0L);
        long long53 = skipUndoDateTimeField47.roundHalfEven((long) 1970);
        int int55 = skipUndoDateTimeField47.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology59.getZone();
        mutableDateTime58.setChronology((org.joda.time.Chronology) gregorianChronology59);
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology59.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean69 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology68);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology68, dateTimeField72);
        java.util.Locale locale74 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket75 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology68, locale74);
        dateTimeParserBucket75.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField79 = gregorianChronology78.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology78.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology78.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone82 = gregorianChronology78.getZone();
        dateTimeParserBucket75.setZone(dateTimeZone82);
        java.util.Locale locale84 = dateTimeParserBucket75.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology59, locale84, (java.lang.Integer) 0);
        java.lang.String str87 = skipUndoDateTimeField47.getAsShortText((int) (short) 10, locale84);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket89 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology38, locale84, (java.lang.Integer) 960);
        try {
            int[] intArray90 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) timeOfDay33, (int) 'a', intArray35, "2019-06-12T12:18:14.363Z", locale84);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T12:18:14.363Z\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(timeOfDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(gregorianChronology68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(gregorianChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertNotNull(locale84);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "10" + "'", str87.equals("10"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (long) (short) 100);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0, 0, 2, 1970, (int) (short) 1, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfMinute();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 2019, (int) (short) 0, 1164);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYear((int) 'a', 18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        int int19 = offsetDateTimeField5.getLeapAmount(52L);
        long long21 = offsetDateTimeField5.roundHalfEven((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField5.getType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfSecond(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
        int int10 = dateTime7.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime7.minusMonths(12);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.plus(readableDuration13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        int int5 = mutableDateTime4.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.add((long) 3);
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", 6);
        mutableDateTime9.setWeekyear((int) '4');
        mutableDateTime9.setWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-7) + "'", int12 == (-7));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.getDifferenceAsLong(24405880L, (long) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray24 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray24);
        int int28 = offsetDateTimeField16.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) '4');
        int int33 = offsetDateTimeField16.getDifference((long) '4', (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now(dateTimeZone36);
        int int38 = mutableDateTime37.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime37.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime40 = property39.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime42 = property39.add((long) 3);
        int int43 = property39.getMinimumValue();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider44 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology47);
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, dateTimeField51);
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField(chronology45, (org.joda.time.DateTimeField) skipUndoDateTimeField52, 0);
        long long56 = skipUndoDateTimeField52.roundHalfCeiling(0L);
        long long58 = skipUndoDateTimeField52.roundHalfEven((long) 1970);
        int int60 = skipUndoDateTimeField52.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime63 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology64.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology64.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology64.getZone();
        mutableDateTime63.setChronology((org.joda.time.Chronology) gregorianChronology64);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology64.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean74 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology73);
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology76.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology73, dateTimeField77);
        java.util.Locale locale79 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology73, locale79);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology83.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology83.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone87 = gregorianChronology83.getZone();
        dateTimeParserBucket80.setZone(dateTimeZone87);
        java.util.Locale locale89 = dateTimeParserBucket80.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket91 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology64, locale89, (java.lang.Integer) 0);
        java.lang.String str92 = skipUndoDateTimeField52.getAsShortText((int) (short) 10, locale89);
        java.lang.String str95 = defaultNameProvider44.getShortName(locale89, "31", "PST");
        java.lang.String str96 = property39.getAsShortText(locale89);
        java.lang.String str97 = offsetDateTimeField16.getAsText(3, locale89);
        java.lang.String str98 = skipUndoDateTimeField6.getAsShortText(1164, locale89);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 31 + "'", int60 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gregorianChronology73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertNotNull(dateTimeZone87);
        org.junit.Assert.assertNotNull(locale89);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "10" + "'", str92.equals("10"));
        org.junit.Assert.assertNull(str95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "Sun" + "'", str96.equals("Sun"));
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "3" + "'", str97.equals("3"));
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "1164" + "'", str98.equals("1164"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(450L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = gregorianChronology2.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay10 = dateTime7.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeField dateTimeField25 = julianChronology0.millisOfDay();
        try {
            long long33 = julianChronology0.getDateTimeMillis(1164, 0, 1664, 2019, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray17 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial10, intArray17);
        int int21 = offsetDateTimeField9.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, 4);
        long long28 = offsetDateTimeField9.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType29);
        java.lang.Number number33 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, number33, "GJChronology[America/Los_Angeles]");
        java.lang.Number number36 = illegalFieldValueException35.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-82800001L) + "'", long28 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNull(number36);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        boolean boolean7 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("35");
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        long long24 = offsetDateTimeField5.remainder(0L);
        int int26 = offsetDateTimeField5.getLeapAmount(28800001L);
        int int28 = offsetDateTimeField5.getMaximumValue((long) 31);
        long long31 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) 0, 24405880L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 75 + "'", int28 == 75);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-6L) + "'", long31 == (-6L));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.minuteOfDay();
//        mutableDateTime5.setSecondOfDay(19);
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime5.copy();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str11 = dateTimeZone10.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        long long14 = dateTimeZone10.getMillisKeepLocal(dateTimeZone12, (long) (short) 100);
//        java.lang.String str16 = dateTimeZone10.getShortName(0L);
//        boolean boolean18 = dateTimeZone10.isStandardOffset((long) (byte) -1);
//        mutableDateTime5.setZoneRetainFields(dateTimeZone10);
//        long long22 = dateTimeZone10.convertLocalToUTC((long) 1, false);
//        org.joda.time.Chronology chronology23 = gregorianChronology0.withZone(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField7.getAsText((long) (short) -1, locale15);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField7, (int) (short) 10, 10, (-7));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfMonth must be in the range [10,-7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        boolean boolean12 = skipUndoDateTimeField7.isSupported();
        long long15 = skipUndoDateTimeField7.add((long) (byte) 10, 1970);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 170208000010L + "'", long15 == 170208000010L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 6, (-6L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology1.add(readablePeriod9, 86400035L, 1);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400035L + "'", long12 == 86400035L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long24 = offsetDateTimeField5.add(0L, (long) 3);
        boolean boolean26 = offsetDateTimeField5.isLeap((long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10800000L + "'", long24 == 10800000L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendPattern("163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendDayOfYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        int int8 = property4.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfFloor();
        int int10 = mutableDateTime9.getYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.addWrapField((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = mutableDateTime6.toDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
//        int int10 = dateTime9.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 27 + "'", int10 == 27);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime7.withYearOfCentury(0);
        org.joda.time.LocalDateTime localDateTime12 = dateTime7.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) '4');
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int27 = offsetDateTimeField18.getMinimumValue(readablePartial19, intArray26);
        int int30 = offsetDateTimeField18.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, 4);
        long long37 = offsetDateTimeField18.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, "738");
        org.joda.time.DateTime.Property property41 = dateTime7.property(dateTimeFieldType38);
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology43.getZone();
        mutableDateTime42.setChronology((org.joda.time.Chronology) gregorianChronology43);
        org.joda.time.DurationField durationField49 = gregorianChronology43.weeks();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology51);
        org.joda.time.DurationField durationField53 = gregorianChronology51.weekyears();
        long long56 = durationField53.subtract(0L, (int) (byte) 0);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField57 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType38, durationField49, durationField53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-82800001L) + "'", long37 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField8);
        long long12 = skipUndoDateTimeField9.add((long) 0, (long) (byte) 1);
        java.lang.String str14 = skipUndoDateTimeField9.getAsText((long) (-28800000));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
        long long17 = skipUndoDateTimeField15.roundHalfEven(1L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400000L + "'", long12 == 86400000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
        mutableDateTime4.setMonthOfYear((int) (short) 1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.addWrapField(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-12T12:18:13.255Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T12:18:13.255Z' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        int int15 = skipUndoDateTimeField7.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        mutableDateTime18.setChronology((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, dateTimeField32);
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology28, locale34);
        dateTimeParserBucket35.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology38.getZone();
        dateTimeParserBucket35.setZone(dateTimeZone42);
        java.util.Locale locale44 = dateTimeParserBucket35.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology19, locale44, (java.lang.Integer) 0);
        java.lang.String str47 = skipUndoDateTimeField7.getAsShortText((int) (short) 10, locale44);
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean51 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology50);
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) '4');
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray62 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int63 = offsetDateTimeField54.getMinimumValue(readablePartial55, intArray62);
        try {
            int int64 = skipUndoDateTimeField7.getMaximumValue(readablePartial48, intArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10" + "'", str47.equals("10"));
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 52 + "'", int63 == 52);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '4');
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray18 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int19 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray18);
        int int22 = offsetDateTimeField10.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, 4);
        long long29 = offsetDateTimeField10.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType30);
        java.lang.Number number34 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, number34, "GJChronology[America/Los_Angeles]");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-82800001L) + "'", long29 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        try {
            mutableDateTime2.setSecondOfMinute(1164);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1164 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap16 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, dateTimeField28);
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology24, locale30);
        dateTimeParserBucket31.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology34.getZone();
        dateTimeParserBucket31.setZone(dateTimeZone38);
        java.util.Locale locale40 = dateTimeParserBucket31.getLocale();
        int int41 = offsetDateTimeField21.getMaximumShortTextLength(locale40);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        int int8 = mutableDateTime2.getYearOfEra();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
        org.joda.time.ReadableDuration readableDuration11 = null;
        mutableDateTime10.add(readableDuration11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("738");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str13 = dateTimeZone12.toString();
        dateTimeParserBucket9.setZone(dateTimeZone12);
        long long16 = dateTimeParserBucket9.computeMillis(false);
        long long17 = dateTimeParserBucket9.computeMillis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6L) + "'", long16 == (-6L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-6L) + "'", long17 == (-6L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str13 = dateTimeZone12.toString();
        dateTimeParserBucket9.setZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone21);
        org.joda.time.Chronology chronology23 = gregorianChronology18.withZone(dateTimeZone21);
        long long25 = dateTimeZone12.getMillisKeepLocal(dateTimeZone21, 0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology26);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        org.joda.time.DurationField durationField26 = gregorianChronology0.days();
        org.joda.time.Chronology chronology27 = null;
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) gregorianChronology0, chronology27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = buddhistChronology3.withUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology3.weeks();
        java.lang.String str6 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[UTC]" + "'", str6.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        int int8 = property4.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.MutableDateTime mutableDateTime11 = property4.addWrapField(0);
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology15.getZone();
        mutableDateTime14.setChronology((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology15.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, dateTimeField28);
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology24, locale30);
        dateTimeParserBucket31.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology34.getZone();
        dateTimeParserBucket31.setZone(dateTimeZone38);
        java.util.Locale locale40 = dateTimeParserBucket31.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology15, locale40, (java.lang.Integer) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime43 = property4.set("GJChronology[UTC]", locale40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(locale40);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) property6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        mutableDateTime8.addSeconds((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.year();
//        mutableDateTime8.addMinutes((int) (byte) 1);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
//        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
//        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        boolean boolean18 = gregorianChronology14.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTimeISO();
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime19.toTimeOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now(dateTimeZone24);
//        int int26 = mutableDateTime25.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime25.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime28 = property27.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime30 = property27.add((long) 3);
//        int int31 = property27.getMinimumValue();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider32 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology35);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology35, dateTimeField39);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField(chronology33, (org.joda.time.DateTimeField) skipUndoDateTimeField40, 0);
//        long long44 = skipUndoDateTimeField40.roundHalfCeiling(0L);
//        long long46 = skipUndoDateTimeField40.roundHalfEven((long) 1970);
//        int int48 = skipUndoDateTimeField40.getMaximumValue((long) (-28800000));
//        org.joda.time.MutableDateTime mutableDateTime51 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology52.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone56 = gregorianChronology52.getZone();
//        mutableDateTime51.setChronology((org.joda.time.Chronology) gregorianChronology52);
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology52.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean62 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology61);
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology61, dateTimeField65);
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology61, locale67);
//        dateTimeParserBucket68.setOffset((java.lang.Integer) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology71.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology71.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone75 = gregorianChronology71.getZone();
//        dateTimeParserBucket68.setZone(dateTimeZone75);
//        java.util.Locale locale77 = dateTimeParserBucket68.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket79 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology52, locale77, (java.lang.Integer) 0);
//        java.lang.String str80 = skipUndoDateTimeField40.getAsShortText((int) (short) 10, locale77);
//        java.lang.String str83 = defaultNameProvider32.getShortName(locale77, "31", "PST");
//        java.lang.String str84 = property27.getAsShortText(locale77);
//        try {
//            java.lang.String str85 = skipUndoDateTimeField7.getAsText((org.joda.time.ReadablePartial) timeOfDay22, locale77);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 31 + "'", int48 == 31);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(gregorianChronology64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(locale77);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "10" + "'", str80.equals("10"));
//        org.junit.Assert.assertNull(str83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Sun" + "'", str84.equals("Sun"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfFloor();
        int int5 = property3.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfCeiling();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1439 + "'", int5 == 1439);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear(6, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider24 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField31);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology25, (org.joda.time.DateTimeField) skipUndoDateTimeField32, 0);
        long long36 = skipUndoDateTimeField32.roundHalfCeiling(0L);
        long long38 = skipUndoDateTimeField32.roundHalfEven((long) 1970);
        int int40 = skipUndoDateTimeField32.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology44.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology44.getZone();
        mutableDateTime43.setChronology((org.joda.time.Chronology) gregorianChronology44);
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology44.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology53);
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology53.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, dateTimeField57);
        java.util.Locale locale59 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology53, locale59);
        dateTimeParserBucket60.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology63.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology63.getZone();
        dateTimeParserBucket60.setZone(dateTimeZone67);
        java.util.Locale locale69 = dateTimeParserBucket60.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology44, locale69, (java.lang.Integer) 0);
        java.lang.String str72 = skipUndoDateTimeField32.getAsShortText((int) (short) 10, locale69);
        java.lang.String str75 = defaultNameProvider24.getShortName(locale69, "31", "PST");
        java.lang.String str76 = offsetDateTimeField5.getAsText((long) 6, locale69);
        long long79 = offsetDateTimeField5.add(0L, (long) 75);
        long long81 = offsetDateTimeField5.roundHalfCeiling(270000000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10" + "'", str72.equals("10"));
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "52" + "'", str76.equals("52"));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 270000000L + "'", long79 == 270000000L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 270000000L + "'", long81 == 270000000L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        int int24 = offsetDateTimeField5.get((long) (short) 10);
        int int27 = offsetDateTimeField5.getDifference((long) (-7), 270000000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-75) + "'", int27 == (-75));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTime dateTime6 = dateTime1.minusHours((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime1.plusMinutes(70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatterBuilder2.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long24 = offsetDateTimeField5.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField5.getType();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider27 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, (org.joda.time.DateTimeField) skipUndoDateTimeField35, 0);
        long long39 = skipUndoDateTimeField35.roundHalfCeiling(0L);
        long long41 = skipUndoDateTimeField35.roundHalfEven((long) 1970);
        int int43 = skipUndoDateTimeField35.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology47.getZone();
        mutableDateTime46.setChronology((org.joda.time.Chronology) gregorianChronology47);
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology47.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean57 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology56);
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology56.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology56, dateTimeField60);
        java.util.Locale locale62 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology56, locale62);
        dateTimeParserBucket63.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology66.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology66.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone70 = gregorianChronology66.getZone();
        dateTimeParserBucket63.setZone(dateTimeZone70);
        java.util.Locale locale72 = dateTimeParserBucket63.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology47, locale72, (java.lang.Integer) 0);
        java.lang.String str75 = skipUndoDateTimeField35.getAsShortText((int) (short) 10, locale72);
        java.lang.String str78 = defaultNameProvider27.getShortName(locale72, "31", "PST");
        java.lang.String str79 = offsetDateTimeField5.getAsText(91L, locale72);
        org.joda.time.DurationField durationField80 = offsetDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-82800001L) + "'", long24 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(locale72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "10" + "'", str75.equals("10"));
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "52" + "'", str79.equals("52"));
        org.junit.Assert.assertNotNull(durationField80);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = mutableDateTime2.getZone();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            mutableDateTime2.add(durationFieldType4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField7 = gregorianChronology1.weeks();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray22 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial15, intArray22);
        int int26 = offsetDateTimeField14.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) '4');
        int int31 = offsetDateTimeField14.getDifference((long) '4', (long) '#');
        boolean boolean32 = julianChronology8.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology8.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology1.add(readablePeriod35, (long) 27, (int) (byte) 10);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 27L + "'", long38 == 27L);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfMinute();
//        java.lang.Object obj4 = mutableDateTime2.clone();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:18:32.742Z" + "'", str1.equals("2019-06-12T12:18:32.742Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(obj4);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology5);
        int int8 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            mutableDateTime2.add(durationFieldType9, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T12:18:27.046Z");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) '4', 2019);
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) 'a', 600, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long23 = offsetDateTimeField21.roundCeiling((long) 0);
        try {
            long long26 = offsetDateTimeField21.set(252000960L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.year();
        int int8 = property7.getLeapAmount();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.Instant instant3 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.plus(readableDuration4);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, (int) 'a', 19, (-1), 1612, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime8.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology11);
//        int int14 = mutableDateTime8.compareTo((org.joda.time.ReadableInstant) mutableDateTime13);
//        boolean boolean15 = mutableDateTime5.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) mutableDateTime5);
//        mutableDateTime5.addMinutes(1969);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 100);
//        java.lang.String str8 = dateTimeZone2.getShortName(0L);
//        boolean boolean9 = iSOChronology0.equals((java.lang.Object) str8);
//        org.joda.time.DurationField durationField10 = iSOChronology0.millis();
//        org.joda.time.DurationFieldType durationFieldType11 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField13 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType11, 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = mutableDateTime7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.monthOfYear();
        mutableDateTime7.setRounding(dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '4');
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray31 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int32 = offsetDateTimeField23.getMinimumValue(readablePartial24, intArray31);
        int int35 = offsetDateTimeField23.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, 4);
        long long42 = offsetDateTimeField23.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType43);
        java.lang.Number number48 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) (byte) 0, number48, (java.lang.Number) 0L);
        int int51 = mutableDateTime7.get(dateTimeFieldType43);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType43, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-82800001L) + "'", long42 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField(1);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime9 = property8.roundHalfEven();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        long long5 = durationField2.subtract((long) 4, (long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4L + "'", long5 == 4L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
        mutableDateTime4.setMonthOfYear((int) (short) 1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.year();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray24 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray24);
        int int28 = offsetDateTimeField16.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) offsetDateTimeField16, 0);
        long long37 = offsetDateTimeField16.add((long) 960, (long) 70);
        try {
            mutableDateTime4.setRounding((org.joda.time.DateTimeField) offsetDateTimeField16, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 18");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 252000960L + "'", long37 == 252000960L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 5, 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj0, dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withHourOfDay(3);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfDay(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 4);
        long long34 = offsetDateTimeField15.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "738");
        java.lang.Number number38 = illegalFieldValueException37.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = illegalFieldValueException37.getDateTimeFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-82800001L) + "'", long34 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField8 = gregorianChronology1.seconds();
        try {
            long long16 = gregorianChronology1.getDateTimeMillis((int) '4', 75, (int) (byte) 100, 1612, 75, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1612 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray17 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial10, intArray17);
        int int21 = offsetDateTimeField9.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, 4);
        long long28 = offsetDateTimeField9.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType29);
        java.lang.Number number33 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, number33, "GJChronology[America/Los_Angeles]");
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = illegalFieldValueException35.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-82800001L) + "'", long28 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 100, chronology1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = instant0.withDurationAdded(0L, 2019);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant6 = instant3.withDurationAdded(readableDuration4, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DurationField durationField9 = gregorianChronology7.days();
        org.joda.time.MutableDateTime mutableDateTime10 = instant3.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone6);
//        java.lang.String str10 = dateTimeZone6.getName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withDayOfYear(1612);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1612 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
        long long15 = dateTimeParserBucket9.computeMillis(true, "2019-06-12T12:18:00.916Z");
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-6L) + "'", long15 == (-6L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfWeek();
//        int int4 = mutableDateTime2.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.dayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) '4');
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        int[] intArray19 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int20 = offsetDateTimeField11.getMinimumValue(readablePartial12, intArray19);
//        int int23 = offsetDateTimeField11.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, 4);
//        org.joda.time.DurationField durationField28 = offsetDateTimeField27.getRangeDurationField();
//        long long31 = durationField28.subtract(0L, (long) 0);
//        boolean boolean32 = property5.equals((java.lang.Object) long31);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology5);
        int int8 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime7.minuteOfDay();
        int int10 = mutableDateTime7.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(1970, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendWeekOfWeekyear(1439);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.append(dateTimePrinter12, dateTimeParserArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology4 = buddhistChronology3.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) buddhistChronology3);
//        int int6 = mutableDateTime5.getSecondOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 44314 + "'", int6 == 44314);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime10 = property6.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime12 = property6.setCopy(1612);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1612 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = gregorianChronology4.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        boolean boolean11 = buddhistChronology3.equals((java.lang.Object) dateTime9);
        java.lang.String str12 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[UTC]" + "'", str12.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getRangeDurationField();
        long long25 = offsetDateTimeField21.add(0L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str23 = gJChronology22.toString();
        org.joda.time.Chronology chronology24 = gJChronology22.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField30);
        long long34 = skipUndoDateTimeField31.add((long) 0, (long) (byte) 1);
        java.lang.String str36 = skipUndoDateTimeField31.getAsText((long) (-28800000));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField31);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology39);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) '4');
        org.joda.time.ReadablePartial readablePartial44 = null;
        int[] intArray51 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int52 = offsetDateTimeField43.getMinimumValue(readablePartial44, intArray51);
        int int55 = offsetDateTimeField43.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, 4);
        org.joda.time.DurationField durationField60 = offsetDateTimeField59.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime63 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology64.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology64.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology64.getZone();
        mutableDateTime63.setChronology((org.joda.time.Chronology) gregorianChronology64);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology64.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean74 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology73);
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology76.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology73, dateTimeField77);
        java.util.Locale locale79 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology73, locale79);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology83.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology83.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone87 = gregorianChronology83.getZone();
        dateTimeParserBucket80.setZone(dateTimeZone87);
        java.util.Locale locale89 = dateTimeParserBucket80.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket91 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology64, locale89, (java.lang.Integer) 0);
        java.lang.String str92 = offsetDateTimeField59.getAsShortText(10, locale89);
        int int93 = skipUndoDateTimeField31.getMaximumTextLength(locale89);
        try {
            long long94 = offsetDateTimeField5.set((-1L), "", locale89);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GJChronology[UTC]" + "'", str23.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 86400000L + "'", long34 == 86400000L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(mutableDateTime63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gregorianChronology73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertNotNull(dateTimeZone87);
        org.junit.Assert.assertNotNull(locale89);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "10" + "'", str92.equals("10"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2 + "'", int93 == 2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.Instant instant4 = instant0.withMillis(100L);
        boolean boolean5 = instant4.isEqualNow();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime7.withYearOfCentury(0);
        org.joda.time.LocalDateTime localDateTime12 = dateTime7.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) '4');
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int27 = offsetDateTimeField18.getMinimumValue(readablePartial19, intArray26);
        int int30 = offsetDateTimeField18.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, 4);
        long long37 = offsetDateTimeField18.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, "738");
        org.joda.time.DateTime.Property property41 = dateTime7.property(dateTimeFieldType38);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType38, 12, (int) (short) 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for hourOfDay must be in the range [0,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-82800001L) + "'", long37 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property41);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sun");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12) + "'", int1 == (-12));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        boolean boolean12 = skipUndoDateTimeField7.isSupported();
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField7.getWrappedField();
        int int14 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-61056806399982L), (org.joda.time.Chronology) gJChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("ZonedChronology[GregorianChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendYear(30, (int) 'a');
        dateTimeFormatterBuilder11.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long12 = skipUndoDateTimeField7.addWrapField((long) '#', 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        org.joda.time.DateTime dateTime20 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime22 = dateTime20.withYear(10);
        org.joda.time.LocalDateTime localDateTime23 = dateTime20.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) '4');
        org.joda.time.ReadablePartial readablePartial31 = null;
        int[] intArray38 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int39 = offsetDateTimeField30.getMinimumValue(readablePartial31, intArray38);
        try {
            int[] intArray41 = skipUndoDateTimeField7.addWrapField((org.joda.time.ReadablePartial) localDateTime23, (-1), intArray38, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400035L + "'", long12 == 86400035L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology1);
//        mutableDateTime4.setMillisOfDay(1664);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getShortName((long) (short) 0, locale11);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime17 = limitChronology16.getUpperLimit();
//        try {
//            long long22 = limitChronology16.getDateTimeMillis(69, 0, (int) (byte) 100, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC((long) 'a', false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3L) + "'", long6 == (-3L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DurationField durationField10 = property6.getDurationField();
        org.joda.time.DateTime dateTime11 = property6.roundFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withTime((-7), 30, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        mutableDateTime0.add(readableDuration7);
//        int int9 = mutableDateTime0.getMinuteOfHour();
//        int int10 = mutableDateTime0.getRoundingMode();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime0.secondOfMinute();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.minuteOfDay();
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime8);
//        mutableDateTime8.setMinuteOfHour(10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T12:18:35.284Z" + "'", str11.equals("T12:18:35.284Z"));
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime10 = property6.withMinimumValue();
        org.joda.time.DateTime dateTime12 = property6.addToCopy(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfFloor();
        int int5 = property3.getMaximumValue();
        org.joda.time.DurationField durationField6 = property3.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1439 + "'", int5 == 1439);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendYear(30, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 600, number2, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology4);
        mutableDateTime2.setChronology((org.joda.time.Chronology) gregorianChronology4);
        try {
            long long16 = gregorianChronology4.getDateTimeMillis(52, 0, 10, 4, (-75), 0, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -75 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
//        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
//        int int10 = dateTime7.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime7.minusMonths(12);
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime7.withFieldAdded(durationFieldType13, 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        mutableDateTime2.setSecondOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        int int28 = mutableDateTime2.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 44314);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        org.joda.time.LocalDateTime localDateTime4 = dateTime1.toLocalDateTime();
        int int5 = dateTime1.getMillisOfDay();
        int int6 = dateTime1.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, (int) (byte) -1, 69, (-1), 12, 1164, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.append(dateTimePrinter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.Instant instant4 = instant0.minus((long) (-75));
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime3);
        try {
            long long9 = gJChronology4.getDateTimeMillis(18, (int) ' ', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray16 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int17 = offsetDateTimeField8.getMinimumValue(readablePartial9, intArray16);
        int int20 = offsetDateTimeField8.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '4');
        int int25 = offsetDateTimeField8.getDifference((long) '4', (long) '#');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        java.lang.String str28 = offsetDateTimeField8.getName();
        try {
            long long31 = offsetDateTimeField8.set((-82800000L), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for hourOfDay must be in the range [52,75]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hourOfDay" + "'", str28.equals("hourOfDay"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear(12);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("2019-06-12T12:18:31.460Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T12:18:31.460Z\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("3", 2000, 1969, 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for 3 must be in the range [1969,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
        int int8 = property4.getMinimumValue();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundCeiling();
        int int10 = property4.getLeapAmount();
        long long11 = property4.remainder();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 6, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 0);
        java.lang.Integer int5 = dateTimeParserBucket4.getOffsetInteger();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNull(int5);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        org.joda.time.DateTime dateTime3 = instant0.toDateTime();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
//        boolean boolean6 = instant0.isAfterNow();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:18:37.296Z" + "'", str1.equals("2019-06-12T12:18:37.296Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        long long21 = offsetDateTimeField19.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfFloor();
        int int5 = property3.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((long) 12);
        mutableDateTime7.addMinutes(2019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1439 + "'", int5 == 1439);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DateTime dateTime10 = property6.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField11 = property6.getField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        boolean boolean6 = property4.isLeap();
//        int int7 = property4.get();
//        java.lang.String str8 = property4.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[dayOfWeek]" + "'", str8.equals("Property[dayOfWeek]"));
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(31, 1612, 0, 5, 75, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute(70);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear(1, 31);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 3, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime17 = limitChronology16.getUpperLimit();
//        try {
//            long long23 = limitChronology16.getDateTimeMillis((long) 75, 1612, (int) '4', (int) ' ', 30);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T12:18:37.742Z (GregorianChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long23 = offsetDateTimeField21.roundCeiling((long) 0);
        org.joda.time.DurationField durationField24 = offsetDateTimeField21.getLeapDurationField();
        long long27 = offsetDateTimeField21.getDifferenceAsLong((long) (byte) 10, 170208000010L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-47280L) + "'", long27 == (-47280L));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19);
        boolean boolean10 = mutableDateTime3.equals((java.lang.Object) property7);
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property7.set("2019-06-12T12:18:07.929Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T12:18:07.929Z\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.Instant instant7 = instant4.plus((long) 5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        int int27 = skipDateTimeField25.get(0L);
        int int29 = skipDateTimeField25.get(0L);
        int int31 = skipDateTimeField25.get(28800001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 60 + "'", int31 == 60);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '+00:00:00.100' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
//        int int8 = property4.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField9 = property4.getField();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.minuteOfDay();
//        mutableDateTime12.setSecondOfDay(19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        boolean boolean17 = mutableDateTime12.isSupported(dateTimeFieldType16);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        mutableDateTime12.add(readableDuration18, 4);
//        mutableDateTime12.addHours(12);
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime12.dayOfWeek();
//        int int24 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeField dateTimeField25 = property4.getField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(28799949L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.833332743d + "'", double1 == 2440587.833332743d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Sun", "738");
        org.joda.time.IllegalInstantException illegalInstantException4 = new org.joda.time.IllegalInstantException("hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException4);
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Sun" + "'", str6.equals("Sun"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "738" + "'", str7.equals("738"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTime dateTime17 = limitChronology16.getUpperLimit();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField24);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology18, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
//        long long29 = skipUndoDateTimeField25.roundHalfCeiling(0L);
//        boolean boolean30 = skipUndoDateTimeField25.isSupported();
//        org.joda.time.DateTimeField dateTimeField31 = skipUndoDateTimeField25.getWrappedField();
//        boolean boolean32 = limitChronology16.equals((java.lang.Object) dateTimeField31);
//        try {
//            long long38 = limitChronology16.getDateTimeMillis((long) (-12), (int) (byte) 10, 31, 0, 1164);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T12:18:38.103Z (GregorianChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        java.lang.String str10 = skipUndoDateTimeField7.toString();
        int int11 = skipUndoDateTimeField7.getMaximumValue();
        int int13 = skipUndoDateTimeField7.get(0L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str10.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(27L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long23 = offsetDateTimeField21.roundCeiling((long) 0);
        org.joda.time.DurationField durationField24 = offsetDateTimeField21.getLeapDurationField();
        boolean boolean25 = offsetDateTimeField21.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(28800001L);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime1.add(readablePeriod2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long12 = skipDateTimeField9.add(1664L, 2019);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks((int) ' ');
        org.joda.time.LocalDateTime localDateTime17 = dateTime14.toLocalDateTime();
        int[] intArray19 = null;
        try {
            int[] intArray21 = skipDateTimeField9.add((org.joda.time.ReadablePartial) localDateTime17, 0, intArray19, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 174441601664L + "'", long12 == 174441601664L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withZoneUTC();
        java.lang.StringBuffer stringBuffer11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology12);
        boolean boolean16 = gregorianChronology12.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekyear((int) (short) 10);
        org.joda.time.DateTime.Property property22 = dateTime19.secondOfMinute();
        org.joda.time.DateTime dateTime24 = dateTime19.withWeekyear(19);
        try {
            dateTimeFormatter8.printTo(stringBuffer11, (org.joda.time.ReadableInstant) dateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime1.plus(readableDuration9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Sun");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Sun/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime12.setZone(dateTimeZone13);
        mutableDateTime12.addWeekyears((int) (byte) -1);
        boolean boolean17 = buddhistChronology9.equals((java.lang.Object) mutableDateTime12);
        try {
            mutableDateTime12.setDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        mutableDateTime1.setChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology11, locale17);
        dateTimeParserBucket18.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology21.getZone();
        dateTimeParserBucket18.setZone(dateTimeZone25);
        java.util.Locale locale27 = dateTimeParserBucket18.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology2, locale27, (java.lang.Integer) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.hourOfDay();
        dateTimeParserBucket29.saveField(dateTimeField33, (int) ' ');
        try {
            long long38 = dateTimeParserBucket29.computeMillis(false, "2019-06-12T12:18:27.046Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"2019-06-12T12:18:27.046Z\": Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("163", "56");
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        long long24 = offsetDateTimeField5.remainder(0L);
        int int26 = offsetDateTimeField5.getLeapAmount(28800001L);
        int int28 = offsetDateTimeField5.getMaximumValue((long) 31);
        long long30 = offsetDateTimeField5.roundHalfCeiling((long) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int32 = gregorianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology31);
        boolean boolean35 = gregorianChronology31.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
        org.joda.time.DateTime dateTime38 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime dateTime40 = dateTime38.withYear(10);
        org.joda.time.LocalDateTime localDateTime41 = dateTime38.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean45 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
        org.joda.time.ReadablePartial readablePartial49 = null;
        int[] intArray56 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int57 = offsetDateTimeField48.getMinimumValue(readablePartial49, intArray56);
        try {
            int[] intArray59 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDateTime41, (-7), intArray56, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [52,75]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 75 + "'", int28 == 75);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 52 + "'", int57 == 52);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
        long long14 = dateTimeParserBucket9.computeMillis(false);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-6L) + "'", long14 == (-6L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.secondOfDay();
        int int6 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399 + "'", int6 == 86399);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray16 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int17 = offsetDateTimeField8.getMinimumValue(readablePartial9, intArray16);
        int int20 = offsetDateTimeField8.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) '4');
        int int25 = offsetDateTimeField8.getDifference((long) '4', (long) '#');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) offsetDateTimeField8, 10);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, (org.joda.time.DateTimeField) skipUndoDateTimeField35, 0);
        long long39 = skipUndoDateTimeField35.roundHalfCeiling(0L);
        long long41 = skipUndoDateTimeField35.roundHalfEven((long) 1970);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipUndoDateTimeField35.getAsText((long) (short) -1, locale43);
        boolean boolean45 = iSOChronology0.equals((java.lang.Object) str44);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField6);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField15, 0);
        long long19 = skipUndoDateTimeField15.roundHalfCeiling(0L);
        long long21 = skipUndoDateTimeField15.roundHalfEven((long) 1970);
        int int23 = skipUndoDateTimeField15.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology27.getZone();
        mutableDateTime26.setChronology((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology27.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology36, dateTimeField40);
        java.util.Locale locale42 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology36, locale42);
        dateTimeParserBucket43.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology46.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology46.getZone();
        dateTimeParserBucket43.setZone(dateTimeZone50);
        java.util.Locale locale52 = dateTimeParserBucket43.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology27, locale52, (java.lang.Integer) 0);
        java.lang.String str55 = skipUndoDateTimeField15.getAsShortText((int) (short) 10, locale52);
        boolean boolean56 = iSOChronology0.equals((java.lang.Object) skipUndoDateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(locale52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10" + "'", str55.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(86399, 5, 70, (int) (byte) 0, 19, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = mutableDateTime2.isSupported(dateTimeFieldType6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime2.add(readableDuration8, 4);
        mutableDateTime2.addHours(12);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        mutableDateTime2.add(readablePeriod13, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime2.withDate(5, 5, 1);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 69, (long) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 414 + "'", int2 == 414);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        mutableDateTime1.setChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology11, locale17);
        dateTimeParserBucket18.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology21.getZone();
        dateTimeParserBucket18.setZone(dateTimeZone25);
        java.util.Locale locale27 = dateTimeParserBucket18.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology2, locale27, (java.lang.Integer) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.hourOfDay();
        dateTimeParserBucket29.saveField(dateTimeField33, (int) ' ');
        try {
            long long36 = dateTimeParserBucket29.computeMillis();
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        int int5 = mutableDateTime4.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.add((long) 3);
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology14);
        int int18 = mutableDateTime17.getRoundingMode();
        boolean boolean19 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-7) + "'", int12 == (-7));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(44314, 1969, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.getDifferenceAsLong(24405880L, (long) '4');
        long long11 = skipUndoDateTimeField6.roundHalfEven((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3) + "'", int1 == (-3));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (short) 1, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekOfWeekyear(600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray17 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial10, intArray17);
        int int21 = offsetDateTimeField9.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, 4);
        long long28 = offsetDateTimeField9.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType29);
        java.lang.Number number33 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, number33, "GJChronology[America/Los_Angeles]");
        java.lang.Number number36 = illegalFieldValueException35.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-82800001L) + "'", long28 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNull(number36);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime3 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(0L, 3);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        int int8 = dateTime6.getDayOfWeek();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.String str2 = dateTimeFormatter0.print(0L);
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01" + "'", str2.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology1);
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour(2019, (-28800000));
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.append(dateTimePrinter13, dateTimeParserArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Sun", "738");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "738" + "'", str3.equals("738"));
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
//        dateTimeParserBucket9.setOffset((int) (short) 10);
//        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        mutableDateTime16.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology19);
//        int int22 = mutableDateTime16.compareTo((org.joda.time.ReadableInstant) mutableDateTime21);
//        boolean boolean23 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '#');
//        int int26 = dateTime25.getWeekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withDayOfYear(10);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.DateTime dateTime31 = dateTime25.toDateTime(dateTimeZone30);
//        mutableDateTime13.setMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTimeParserBucket9.restoreState((java.lang.Object) dateTime31);
//        org.joda.time.DateTime dateTime35 = dateTime31.plusHours((int) (byte) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour((-12), (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        mutableDateTime2.setZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.copy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime5.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withEra(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sun");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 6, (org.joda.time.Chronology) gregorianChronology3, locale4, (java.lang.Integer) 0);
        jodaTimePermission1.checkGuard((java.lang.Object) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 4);
        long long32 = offsetDateTimeField13.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField13.getType();
        jodaTimePermission1.checkGuard((java.lang.Object) offsetDateTimeField13);
        java.lang.String str35 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-82800001L) + "'", long32 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime3);
//        java.lang.String str6 = dateTimeZone1.getShortName(4L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long24 = offsetDateTimeField5.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "738");
        java.lang.String str28 = illegalFieldValueException27.getIllegalStringValue();
        java.lang.String str29 = illegalFieldValueException27.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-82800001L) + "'", long24 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "738" + "'", str28.equals("738"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "738" + "'", str29.equals("738"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField8);
        long long12 = skipUndoDateTimeField9.add((long) 0, (long) (byte) 1);
        java.lang.String str14 = skipUndoDateTimeField9.getAsText((long) (-28800000));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '4');
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray29 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int30 = offsetDateTimeField21.getMinimumValue(readablePartial22, intArray29);
        int int33 = offsetDateTimeField21.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, 4);
        org.joda.time.DurationField durationField38 = offsetDateTimeField37.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology42.getZone();
        mutableDateTime41.setChronology((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology42.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology51);
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology51, dateTimeField55);
        java.util.Locale locale57 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology51, locale57);
        dateTimeParserBucket58.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology61.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology61.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology61.getZone();
        dateTimeParserBucket58.setZone(dateTimeZone65);
        java.util.Locale locale67 = dateTimeParserBucket58.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket69 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology42, locale67, (java.lang.Integer) 0);
        java.lang.String str70 = offsetDateTimeField37.getAsShortText(10, locale67);
        int int71 = skipUndoDateTimeField9.getMaximumTextLength(locale67);
        long long73 = skipUndoDateTimeField9.roundHalfEven(4L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400000L + "'", long12 == 86400000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gregorianChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(locale67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10" + "'", str70.equals("10"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology11.getZone();
        long long17 = dateTimeZone14.adjustOffset(1L, false);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0L, dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(5, 12, 5, 18, (-1), dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
//        dateTimeParserBucket9.setOffset((int) (short) 10);
//        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        mutableDateTime16.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology19);
//        int int22 = mutableDateTime16.compareTo((org.joda.time.ReadableInstant) mutableDateTime21);
//        boolean boolean23 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '#');
//        int int26 = dateTime25.getWeekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withDayOfYear(10);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.DateTime dateTime31 = dateTime25.toDateTime(dateTimeZone30);
//        mutableDateTime13.setMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTimeParserBucket9.restoreState((java.lang.Object) dateTime31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatterBuilder34.toFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendHourOfDay((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder34.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendHourOfHalfday(10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder39.appendWeekOfWeekyear((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology45);
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean50 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology49, dateTimeField53);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField(chronology47, (org.joda.time.DateTimeField) skipUndoDateTimeField54, 0);
//        long long58 = skipUndoDateTimeField54.roundHalfCeiling(0L);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, (org.joda.time.DateTimeField) skipUndoDateTimeField54, 600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean63 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology62.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, (int) '4');
//        org.joda.time.ReadablePartial readablePartial67 = null;
//        int[] intArray74 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int75 = offsetDateTimeField66.getMinimumValue(readablePartial67, intArray74);
//        int int78 = offsetDateTimeField66.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField66, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField66, 4);
//        long long85 = offsetDateTimeField66.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType86 = offsetDateTimeField66.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField90 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField54, dateTimeFieldType86, (-75), 75, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder39.appendFixedSignedDecimal(dateTimeFieldType86, (int) (short) 1);
//        org.joda.time.DateTime dateTime94 = dateTime31.withField(dateTimeFieldType86, 0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 52 + "'", int75 == 52);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-82800001L) + "'", long85 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType86);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//        org.junit.Assert.assertNotNull(dateTime94);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField(1);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.centuryOfEra();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        int int32 = offsetDateTimeField15.getDifference((long) '4', (long) '#');
        boolean boolean33 = julianChronology9.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone34 = julianChronology9.getZone();
        mutableDateTime7.setChronology((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.Chronology chronology37 = julianChronology9.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.50000037d + "'", double1 == 2440587.50000037d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 960, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3840L + "'", long2 == 3840L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        mutableDateTime0.add(readablePeriod11);
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            mutableDateTime0.add(durationFieldType13, 1439);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        long long4 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        try {
//            int[] intArray10 = buddhistChronology7.get(readablePeriod8, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfCentury(1612, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendFractionOfSecond(2000, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        long long23 = offsetDateTimeField21.roundCeiling((long) 0);
        long long25 = offsetDateTimeField21.roundHalfEven(0L);
        long long28 = offsetDateTimeField21.addWrapField(10800000L, 18);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 75600000L + "'", long28 == 75600000L);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        boolean boolean13 = gregorianChronology9.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DurationField durationField18 = gregorianChronology0.years();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) 1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(19, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '#');
//        int int13 = dateTime12.getWeekyear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withDayOfYear(10);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.DateTime dateTime18 = dateTime12.toDateTime(dateTimeZone17);
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property20 = dateTime18.hourOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property20);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        dateTimeParserBucket9.setZone(dateTimeZone16);
        dateTimeParserBucket9.setOffset((java.lang.Integer) (-7));
        java.lang.Object obj20 = dateTimeParserBucket9.saveState();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        int int34 = offsetDateTimeField17.getDifference((long) '4', (long) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeek(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray52 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial45, intArray52);
//        int int56 = offsetDateTimeField44.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, 4);
//        long long63 = offsetDateTimeField44.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField44.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "738");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder37.appendText(dateTimeFieldType64);
//        java.lang.Number number69 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, number69, (java.lang.Number) 0L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType64);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType64);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str75 = iSOChronology74.toString();
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str77 = dateTimeZone76.toString();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        long long80 = dateTimeZone76.getMillisKeepLocal(dateTimeZone78, (long) (short) 100);
//        java.lang.String str82 = dateTimeZone76.getShortName(0L);
//        boolean boolean83 = iSOChronology74.equals((java.lang.Object) str82);
//        org.joda.time.DurationField durationField84 = iSOChronology74.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField84);
//        try {
//            long long87 = unsupportedDateTimeField85.roundHalfFloor(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 52 + "'", int53 == 52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-82800001L) + "'", long63 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ISOChronology[UTC]" + "'", str75.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "UTC" + "'", str77.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "UTC" + "'", str82.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        int int34 = offsetDateTimeField17.getDifference((long) '4', (long) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeek(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray52 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial45, intArray52);
//        int int56 = offsetDateTimeField44.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, 4);
//        long long63 = offsetDateTimeField44.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField44.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "738");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder37.appendText(dateTimeFieldType64);
//        java.lang.Number number69 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, number69, (java.lang.Number) 0L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType64);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType64);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str75 = iSOChronology74.toString();
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str77 = dateTimeZone76.toString();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        long long80 = dateTimeZone76.getMillisKeepLocal(dateTimeZone78, (long) (short) 100);
//        java.lang.String str82 = dateTimeZone76.getShortName(0L);
//        boolean boolean83 = iSOChronology74.equals((java.lang.Object) str82);
//        org.joda.time.DurationField durationField84 = iSOChronology74.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField84);
//        boolean boolean86 = unsupportedDateTimeField85.isSupported();
//        try {
//            long long89 = unsupportedDateTimeField85.addWrapField((long) (byte) 0, 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 52 + "'", int53 == 52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-82800001L) + "'", long63 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ISOChronology[UTC]" + "'", str75.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "UTC" + "'", str77.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "UTC" + "'", str82.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sun");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 6, (org.joda.time.Chronology) gregorianChronology3, locale4, (java.lang.Integer) 0);
        jodaTimePermission1.checkGuard((java.lang.Object) 0);
        java.security.PermissionCollection permissionCollection8 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(permissionCollection8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        int int3 = mutableDateTime2.getYearOfCentury();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField12);
        long long16 = skipUndoDateTimeField13.getDifferenceAsLong(24405880L, (long) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '4');
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray31 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int32 = offsetDateTimeField23.getMinimumValue(readablePartial24, intArray31);
        int int35 = offsetDateTimeField23.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, (int) '4');
        int int40 = offsetDateTimeField23.getDifference((long) '4', (long) '#');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider42 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology45);
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, dateTimeField49);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField(chronology43, (org.joda.time.DateTimeField) skipUndoDateTimeField50, 0);
        long long54 = skipUndoDateTimeField50.roundHalfCeiling(0L);
        long long56 = skipUndoDateTimeField50.roundHalfEven((long) 1970);
        int int58 = skipUndoDateTimeField50.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime61 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology62.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology62.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone66 = gregorianChronology62.getZone();
        mutableDateTime61.setChronology((org.joda.time.Chronology) gregorianChronology62);
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology62.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology71);
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology71.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology74.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField76 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology71, dateTimeField75);
        java.util.Locale locale77 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket78 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology71, locale77);
        dateTimeParserBucket78.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology81 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField82 = gregorianChronology81.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField83 = gregorianChronology81.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology81.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone85 = gregorianChronology81.getZone();
        dateTimeParserBucket78.setZone(dateTimeZone85);
        java.util.Locale locale87 = dateTimeParserBucket78.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket89 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology62, locale87, (java.lang.Integer) 0);
        java.lang.String str90 = skipUndoDateTimeField50.getAsShortText((int) (short) 10, locale87);
        java.lang.String str93 = defaultNameProvider42.getShortName(locale87, "31", "PST");
        java.lang.String str94 = offsetDateTimeField23.getAsText((long) 6, locale87);
        java.lang.String str95 = skipUndoDateTimeField13.getAsText((long) 2, locale87);
        try {
            org.joda.time.MutableDateTime mutableDateTime96 = property4.set("1970", locale87);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 31 + "'", int58 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime61);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(gregorianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(gregorianChronology81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(dateTimeZone85);
        org.junit.Assert.assertNotNull(locale87);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "10" + "'", str90.equals("10"));
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "52" + "'", str94.equals("52"));
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "1" + "'", str95.equals("1"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime5.plus(0L);
        org.joda.time.DateTime dateTime9 = dateTime7.minusHours(414);
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(70);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        int int11 = skipUndoDateTimeField7.getLeapAmount(600L);
        try {
            long long14 = skipUndoDateTimeField7.set((long) 60, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [0,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay(0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField(1);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
//        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
//        int int32 = offsetDateTimeField15.getDifference((long) '4', (long) '#');
//        boolean boolean33 = julianChronology9.equals((java.lang.Object) '4');
//        org.joda.time.DateTimeZone dateTimeZone34 = julianChronology9.getZone();
//        mutableDateTime7.setChronology((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = dateTimeZone39.getShortName((long) (short) 0, locale41);
//        org.joda.time.DateTime dateTime43 = dateTime36.withZoneRetainFields(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "UTC" + "'", str42.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        try {
            long long17 = buddhistChronology9.getDateTimeMillis(1439, (int) 'a', 0, 0, (int) (short) 1, 60, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.minuteOfHour();
//        int int6 = mutableDateTime4.getYearOfEra();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:18:46.136Z" + "'", str1.equals("2019-06-12T12:18:46.136Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
    }
}

