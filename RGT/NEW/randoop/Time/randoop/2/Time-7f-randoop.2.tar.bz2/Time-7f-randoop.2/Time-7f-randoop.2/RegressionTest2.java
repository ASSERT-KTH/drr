import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test001");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfWeek();
//        int int4 = mutableDateTime2.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.dayOfWeek();
//        mutableDateTime2.addYears(69);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(60, '#', (int) (short) 100, (int) (short) 1, 10, true, 45);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("GJChronology[UTC]", 70);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("hi!", (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int[] intArray21 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial14, intArray21);
//        int int25 = offsetDateTimeField13.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) '4');
//        int int30 = offsetDateTimeField13.getDifference((long) '4', (long) '#');
//        boolean boolean31 = julianChronology7.equals((java.lang.Object) '4');
//        org.joda.time.DateTimeZone dateTimeZone32 = julianChronology7.getZone();
//        mutableDateTime6.setZone(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        long long4 = iSOChronology0.add((long) '#', 0L, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone5.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (long) (short) 100);
//        java.lang.String str11 = dateTimeZone5.getShortName(0L);
//        boolean boolean13 = dateTimeZone5.isStandardOffset((long) (byte) -1);
//        org.joda.time.Chronology chronology14 = iSOChronology0.withZone(dateTimeZone5);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        java.lang.String str16 = julianChronology15.toString();
//        int int17 = julianChronology15.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[UTC]" + "'", str16.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        mutableDateTime16.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology19);
        int int22 = mutableDateTime16.compareTo((org.joda.time.ReadableInstant) mutableDateTime21);
        boolean boolean23 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '#');
        int int26 = dateTime25.getWeekyear();
        org.joda.time.DateTime dateTime28 = dateTime25.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime31 = dateTime25.toDateTime(dateTimeZone30);
        mutableDateTime13.setMillis((org.joda.time.ReadableInstant) dateTime31);
        boolean boolean33 = dateTimeParserBucket9.restoreState((java.lang.Object) dateTime31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now(dateTimeZone35);
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime38 = property37.roundHalfFloor();
        boolean boolean39 = dateTime31.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.DateTime.Property property40 = dateTime31.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField33);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField(chronology27, (org.joda.time.DateTimeField) skipUndoDateTimeField34, 0);
        long long38 = skipUndoDateTimeField34.roundHalfCeiling(0L);
        long long40 = skipUndoDateTimeField34.roundHalfEven((long) 1970);
        long long42 = skipUndoDateTimeField34.roundHalfCeiling(52L);
        long long45 = skipUndoDateTimeField34.add((long) (byte) 10, 100);
        int int47 = skipUndoDateTimeField34.get((long) 2000);
        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField34, (-75));
        int int52 = skipDateTimeField49.getDifference(174441601664L, (long) 414);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 8640000010L + "'", long45 == 8640000010L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 4);
        long long34 = offsetDateTimeField15.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType35, 6);
        int int41 = dividedDateTimeField40.getDivisor();
        int int42 = dividedDateTimeField40.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
        int int44 = dividedDateTimeField40.getDivisor();
        long long47 = dividedDateTimeField40.getDifferenceAsLong((long) 27, 44329147L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-82800001L) + "'", long34 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2L) + "'", long47 == (-2L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 4);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology26.getZone();
        mutableDateTime25.setChronology((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology26.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology35, dateTimeField39);
        java.util.Locale locale41 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology35, locale41);
        dateTimeParserBucket42.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology45.getZone();
        dateTimeParserBucket42.setZone(dateTimeZone49);
        java.util.Locale locale51 = dateTimeParserBucket42.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology26, locale51, (java.lang.Integer) 0);
        java.lang.String str54 = offsetDateTimeField21.getAsShortText(10, locale51);
        boolean boolean55 = offsetDateTimeField21.isSupported();
        org.joda.time.DurationField durationField56 = offsetDateTimeField21.getLeapDurationField();
        java.lang.String str58 = offsetDateTimeField21.getAsText(28799950L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(locale51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(durationField56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "63" + "'", str58.equals("63"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology9.withUTC();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        mutableDateTime11.setChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField18 = gregorianChronology12.weeks();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) '4');
        org.joda.time.ReadablePartial readablePartial26 = null;
        int[] intArray33 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int34 = offsetDateTimeField25.getMinimumValue(readablePartial26, intArray33);
        int int37 = offsetDateTimeField25.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, (int) '4');
        int int42 = offsetDateTimeField25.getDifference((long) '4', (long) '#');
        boolean boolean43 = julianChronology19.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone44 = julianChronology19.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone44);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
        org.joda.time.Chronology chronology47 = buddhistChronology9.withZone(dateTimeZone44);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(zonedChronology45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(chronology47);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) ' ');
        long long10 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = property5.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        long long4 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, (long) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology6.getZone();
//        mutableDateTime5.setChronology((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime5.year();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime5);
//        java.lang.String str14 = gJChronology13.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GJChronology[UTC,cutover=1969-12-31T23:59:59.997Z]" + "'", str14.equals("GJChronology[UTC,cutover=1969-12-31T23:59:59.997Z]"));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfCentury();
        mutableDateTime4.setYear(27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology11, locale17);
        dateTimeParserBucket18.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology21.getZone();
        dateTimeParserBucket18.setZone(dateTimeZone25);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter8.withZone(dateTimeZone25);
        mutableDateTime4.setZoneRetainFields(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
//        int int2 = dateTime1.getWeekyear();
//        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 1970);
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = property7.getDifference(readableInstant8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 777600038 + "'", int9 == 777600038);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 414);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '4');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int16 = offsetDateTimeField7.getMinimumValue(readablePartial8, intArray15);
        int int19 = offsetDateTimeField7.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, 4);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 0);
        int int27 = skipDateTimeField25.get(0L);
        int int29 = skipDateTimeField25.getLeapAmount((long) 69);
        int int30 = skipDateTimeField25.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 75 + "'", int30 == 75);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1664);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 1664");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        org.joda.time.Instant instant20 = org.joda.time.Instant.now();
        org.joda.time.Instant instant22 = instant20.minus((long) (short) 0);
        org.joda.time.Instant instant23 = instant22.toInstant();
        org.joda.time.DateTime dateTime24 = instant23.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) '4');
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray39 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int40 = offsetDateTimeField31.getMinimumValue(readablePartial32, intArray39);
        int int41 = offsetDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay25, intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 52 + "'", int40 == 52);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 127 + "'", int41 == 127);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime5.add(readablePeriod6, 960);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField15);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField(chronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField16, 0);
        int int20 = skipUndoDateTimeField16.getLeapAmount(600L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField16.getType();
        try {
            mutableDateTime5.set(dateTimeFieldType21, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime0.getZone();
//        java.lang.String str8 = mutableDateTime0.toString();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime0.year();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T23:59:59.997Z" + "'", str8.equals("1969-12-31T23:59:59.997Z"));
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (-3L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.getDifferenceAsLong(24405880L, (long) '4');
        boolean boolean10 = skipUndoDateTimeField6.isLenient();
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField6.getLeapDurationField();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField6.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        org.joda.time.DateTime dateTime20 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime20.withYearOfCentury(0);
        org.joda.time.LocalDateTime localDateTime25 = dateTime20.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) '4');
        org.joda.time.ReadablePartial readablePartial33 = null;
        int[] intArray40 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int41 = offsetDateTimeField32.getMinimumValue(readablePartial33, intArray40);
        try {
            int[] intArray43 = skipUndoDateTimeField6.addWrapField((org.joda.time.ReadablePartial) localDateTime25, (int) '#', intArray40, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        mutableDateTime8.setZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 10, 0, (-12), 1164, 6, 75, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1164 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear(12);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        int int8 = property7.getMinimumValueOverall();
        org.joda.time.DateTime dateTime9 = property7.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        int int15 = skipUndoDateTimeField7.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        mutableDateTime18.setChronology((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, dateTimeField32);
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology28, locale34);
        dateTimeParserBucket35.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology38.getZone();
        dateTimeParserBucket35.setZone(dateTimeZone42);
        java.util.Locale locale44 = dateTimeParserBucket35.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology19, locale44, (java.lang.Integer) 0);
        java.lang.String str47 = skipUndoDateTimeField7.getAsShortText((int) (short) 10, locale44);
        long long49 = skipUndoDateTimeField7.remainder((-6L));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10" + "'", str47.equals("10"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 86399994L + "'", long49 == 86399994L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField8 = gregorianChronology1.seconds();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
//        int int5 = mutableDateTime4.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.add((long) 3);
//        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", 6);
//        mutableDateTime9.setWeekyear((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology16);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        int[] intArray28 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int29 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray28);
//        int int32 = offsetDateTimeField20.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, (int) '4');
//        int int37 = offsetDateTimeField20.getDifference((long) '4', (long) '#');
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider39 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.Chronology chronology40 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology42);
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField46);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField(chronology40, (org.joda.time.DateTimeField) skipUndoDateTimeField47, 0);
//        long long51 = skipUndoDateTimeField47.roundHalfCeiling(0L);
//        long long53 = skipUndoDateTimeField47.roundHalfEven((long) 1970);
//        int int55 = skipUndoDateTimeField47.getMaximumValue((long) (-28800000));
//        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology59.getZone();
//        mutableDateTime58.setChronology((org.joda.time.Chronology) gregorianChronology59);
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology59.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean69 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology68);
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology68, dateTimeField72);
//        java.util.Locale locale74 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket75 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology68, locale74);
//        dateTimeParserBucket75.setOffset((java.lang.Integer) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField79 = gregorianChronology78.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology78.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology78.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone82 = gregorianChronology78.getZone();
//        dateTimeParserBucket75.setZone(dateTimeZone82);
//        java.util.Locale locale84 = dateTimeParserBucket75.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology59, locale84, (java.lang.Integer) 0);
//        java.lang.String str87 = skipUndoDateTimeField47.getAsShortText((int) (short) 10, locale84);
//        java.lang.String str90 = defaultNameProvider39.getShortName(locale84, "31", "PST");
//        java.lang.String str91 = offsetDateTimeField20.getAsText((long) 6, locale84);
//        mutableDateTime9.setRounding((org.joda.time.DateTimeField) offsetDateTimeField20);
//        mutableDateTime9.setMillisOfDay(19);
//        java.lang.Object obj95 = mutableDateTime9.clone();
//        try {
//            mutableDateTime9.setSecondOfMinute((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-7) + "'", int12 == (-7));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(gregorianChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "10" + "'", str87.equals("10"));
//        org.junit.Assert.assertNull(str90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "52" + "'", str91.equals("52"));
//        org.junit.Assert.assertNotNull(obj95);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour(2019, (-28800000));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfDay((int) ' ', 86399);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfWeek();
//        int int4 = mutableDateTime2.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.secondOfMinute();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(19);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime5.add(readablePeriod6, 960);
        mutableDateTime5.setDate((long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GJChronology[UTC,cutover=1969-12-31T23:59:59.997Z]", 0, 2, (-12));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for GJChronology[UTC,cutover=1969-12-31T23:59:59.997Z] must be in the range [2,-12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test035");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        int int34 = offsetDateTimeField17.getDifference((long) '4', (long) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeek(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray52 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial45, intArray52);
//        int int56 = offsetDateTimeField44.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, 4);
//        long long63 = offsetDateTimeField44.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField44.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "738");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder37.appendText(dateTimeFieldType64);
//        java.lang.Number number69 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, number69, (java.lang.Number) 0L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType64);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType64);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str75 = iSOChronology74.toString();
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str77 = dateTimeZone76.toString();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        long long80 = dateTimeZone76.getMillisKeepLocal(dateTimeZone78, (long) (short) 100);
//        java.lang.String str82 = dateTimeZone76.getShortName(0L);
//        boolean boolean83 = iSOChronology74.equals((java.lang.Object) str82);
//        org.joda.time.DurationField durationField84 = iSOChronology74.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField84);
//        boolean boolean86 = unsupportedDateTimeField85.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 52 + "'", int53 == 52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-82800001L) + "'", long63 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ISOChronology[UTC]" + "'", str75.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "UTC" + "'", str77.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "UTC" + "'", str82.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
//        int int8 = property4.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundCeiling();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, 4);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology10, (org.joda.time.DateTimeField) offsetDateTimeField17, 0);
//        int int37 = skipDateTimeField35.get(0L);
//        int int39 = skipDateTimeField35.getLeapAmount((long) 69);
//        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipDateTimeField35, 2);
//        org.joda.time.DateTimeField dateTimeField42 = skipDateTimeField35.getWrappedField();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider43 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) '4');
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        int[] intArray58 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int59 = offsetDateTimeField50.getMinimumValue(readablePartial51, intArray58);
//        int int62 = offsetDateTimeField50.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, 4);
//        long long69 = offsetDateTimeField50.addWrapField((-1L), 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean74 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology73);
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology76.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology73, dateTimeField77);
//        java.util.Locale locale79 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology73, locale79);
//        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology83.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology83.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone87 = gregorianChronology83.getZone();
//        dateTimeParserBucket80.setZone(dateTimeZone87);
//        java.util.Locale locale89 = dateTimeParserBucket80.getLocale();
//        java.lang.String str90 = offsetDateTimeField50.getAsShortText((-28800000), locale89);
//        java.lang.String str93 = defaultNameProvider43.getName(locale89, "", "10");
//        int int94 = skipDateTimeField35.getMaximumTextLength(locale89);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 52 + "'", int37 == 52);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 52 + "'", int59 == 52);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-82800001L) + "'", long69 == (-82800001L));
//        org.junit.Assert.assertNotNull(gregorianChronology73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(gregorianChronology76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(gregorianChronology83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(dateTimeField85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(dateTimeZone87);
//        org.junit.Assert.assertNotNull(locale89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "-28800000" + "'", str90.equals("-28800000"));
//        org.junit.Assert.assertNull(str93);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2 + "'", int94 == 2);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.Chronology chronology12 = dateTimeParserBucket9.getChronology();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        mutableDateTime16.setMonthOfYear((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology19);
        int int22 = mutableDateTime16.compareTo((org.joda.time.ReadableInstant) mutableDateTime21);
        boolean boolean23 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '#');
        int int26 = dateTime25.getWeekyear();
        org.joda.time.DateTime dateTime28 = dateTime25.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime31 = dateTime25.toDateTime(dateTimeZone30);
        mutableDateTime13.setMillis((org.joda.time.ReadableInstant) dateTime31);
        boolean boolean33 = dateTimeParserBucket9.restoreState((java.lang.Object) dateTime31);
        org.joda.time.DateTime.Property property34 = dateTime31.monthOfYear();
        org.joda.time.DateTime.Property property35 = dateTime31.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        dateTimeParserBucket9.setZone(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.Chronology chronology19 = julianChronology18.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Sun", "738");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28799949L, number2, (java.lang.Number) 174441600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfEven();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        int int34 = offsetDateTimeField17.getDifference((long) '4', (long) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeek(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray52 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial45, intArray52);
//        int int56 = offsetDateTimeField44.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, 4);
//        long long63 = offsetDateTimeField44.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField44.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "738");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder37.appendText(dateTimeFieldType64);
//        java.lang.Number number69 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, number69, (java.lang.Number) 0L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType64);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType64);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str75 = iSOChronology74.toString();
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str77 = dateTimeZone76.toString();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        long long80 = dateTimeZone76.getMillisKeepLocal(dateTimeZone78, (long) (short) 100);
//        java.lang.String str82 = dateTimeZone76.getShortName(0L);
//        boolean boolean83 = iSOChronology74.equals((java.lang.Object) str82);
//        org.joda.time.DurationField durationField84 = iSOChronology74.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField84);
//        java.lang.String str86 = unsupportedDateTimeField85.toString();
//        long long89 = unsupportedDateTimeField85.add(28799950L, 1560341928206L);
//        long long92 = unsupportedDateTimeField85.add(1969L, (long) 'a');
//        int int95 = unsupportedDateTimeField85.getDifference(450L, (long) 2000);
//        java.util.Locale locale97 = null;
//        try {
//            java.lang.String str98 = unsupportedDateTimeField85.getAsText((int) (short) 1, locale97);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 52 + "'", int53 == 52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-82800001L) + "'", long63 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ISOChronology[UTC]" + "'", str75.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "UTC" + "'", str77.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "UTC" + "'", str82.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "UnsupportedDateTimeField" + "'", str86.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560370728156L + "'", long89 == 1560370728156L);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 2066L + "'", long92 == 2066L);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1550) + "'", int95 == (-1550));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendCenturyOfEra(2, 1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMillisOfDay((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray17 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial10, intArray17);
        int int21 = offsetDateTimeField9.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) '4');
        int int26 = offsetDateTimeField9.getDifference((long) '4', (long) '#');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField9, 10);
        java.lang.String str29 = offsetDateTimeField9.getName();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField37);
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField(chronology31, (org.joda.time.DateTimeField) skipUndoDateTimeField38, 0);
        long long42 = skipUndoDateTimeField38.roundHalfCeiling(0L);
        long long44 = skipUndoDateTimeField38.roundHalfEven((long) 1970);
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField38.getAsText((long) (short) -1, locale46);
        org.joda.time.DurationField durationField48 = skipUndoDateTimeField38.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime50 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology51.getZone();
        mutableDateTime50.setChronology((org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology51.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean61 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology60);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology60.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology60, dateTimeField64);
        java.util.Locale locale66 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket67 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology60, locale66);
        dateTimeParserBucket67.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology70.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology70.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone74 = gregorianChronology70.getZone();
        dateTimeParserBucket67.setZone(dateTimeZone74);
        java.util.Locale locale76 = dateTimeParserBucket67.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket78 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology51, locale76, (java.lang.Integer) 0);
        int int79 = skipUndoDateTimeField38.getMaximumTextLength(locale76);
        java.lang.String str80 = offsetDateTimeField9.getAsText(2159999999L, locale76);
        java.lang.String str83 = defaultNameProvider0.getShortName(locale76, "America/Los_Angeles", "2019-06-12T12:18:32.742Z");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfDay" + "'", str29.equals("hourOfDay"));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31" + "'", str47.equals("31"));
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(locale76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "75" + "'", str80.equals("75"));
        org.junit.Assert.assertNull(str83);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withDayOfYear(22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(52L);
        boolean boolean16 = skipUndoDateTimeField7.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 4);
        long long34 = offsetDateTimeField15.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType35, 6);
        int int41 = dividedDateTimeField40.getDivisor();
        int int42 = dividedDateTimeField40.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
        int int44 = dividedDateTimeField40.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40, dateTimeFieldType45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-82800001L) + "'", long34 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.Appendable appendable2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology3);
        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(10);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField6.getRangeDurationField();
        int int14 = skipUndoDateTimeField6.get(10L);
        org.joda.time.DurationField durationField15 = skipUndoDateTimeField6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(1970, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendDayOfWeek(44314);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((-12));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("", "2019-06-12T12:18:32.631Z", true, (-1), 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 4);
        long long34 = offsetDateTimeField15.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType35, 6);
        int int41 = dividedDateTimeField40.getDivisor();
        int int42 = dividedDateTimeField40.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
        long long45 = remainderDateTimeField43.remainder(32L);
        long long47 = remainderDateTimeField43.roundFloor((long) 600);
        boolean boolean49 = remainderDateTimeField43.isLeap((-82800001L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-82800001L) + "'", long34 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 32L + "'", long45 == 32L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray17 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial10, intArray17);
        int int21 = offsetDateTimeField9.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, 4);
        long long28 = offsetDateTimeField9.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatterBuilder35.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-82800001L) + "'", long28 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25, (int) (byte) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(julianChronology27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-75));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.499999132d + "'", double1 == 2440587.499999132d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        int int13 = skipUndoDateTimeField7.get(2440588L);
        java.lang.String str14 = skipUndoDateTimeField7.getName();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test061");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTimeISO();
//        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone14);
//        int int16 = mutableDateTime15.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime18 = property17.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime20 = property17.add((long) 3);
//        int int23 = dateTimeFormatter11.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime20, "", 6);
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime20.dayOfMonth();
//        mutableDateTime20.setMonthOfYear((int) (short) 10);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime20, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-7) + "'", int23 == (-7));
//        org.junit.Assert.assertNotNull(property24);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) "35");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(chronology3);
        mutableDateTime4.setDate((long) 18);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            mutableDateTime4.set(dateTimeFieldType7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(19);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendWeekOfWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        long long16 = dateTimeZone12.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
//        java.lang.String str18 = dateTimeZone12.getShortName(0L);
//        boolean boolean20 = dateTimeZone12.isStandardOffset((long) (byte) -1);
//        long long22 = dateTimeZone12.convertUTCToLocal(0L);
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) 52L, dateTimeZone12);
//        org.joda.time.DateTime dateTime24 = dateTime8.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond(0, 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        int int9 = mutableDateTime8.getDayOfWeek();
//        mutableDateTime8.addHours((-1));
//        int int12 = mutableDateTime8.getRoundingMode();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology15);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField19);
//        java.util.Locale locale21 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology15, locale21);
//        dateTimeParserBucket22.setOffset((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str26 = dateTimeZone25.toString();
//        dateTimeParserBucket22.setZone(dateTimeZone25);
//        long long29 = dateTimeParserBucket22.computeMillis(false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) '4');
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int[] intArray43 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int44 = offsetDateTimeField35.getMinimumValue(readablePartial36, intArray43);
//        int int47 = offsetDateTimeField35.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField35, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField35, 4);
//        long long54 = offsetDateTimeField35.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField35.getType();
//        dateTimeParserBucket22.saveField(dateTimeFieldType55, (int) (byte) -1);
//        int int58 = mutableDateTime8.get(dateTimeFieldType55);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 4L, "2019-06-12T12:18:07.929Z");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-6L) + "'", long29 == (-6L));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-82800001L) + "'", long54 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 22 + "'", int58 == 22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        int int6 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology9, locale15);
        dateTimeParserBucket16.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        dateTimeParserBucket16.setZone(dateTimeZone23);
        java.util.Locale locale25 = dateTimeParserBucket16.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale25);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(locale25);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long12 = skipUndoDateTimeField7.addWrapField((long) '#', 1);
        java.lang.String str13 = skipUndoDateTimeField7.getName();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400035L + "'", long12 == 86400035L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfMonth" + "'", str13.equals("dayOfMonth"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(4, 1612);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1616 + "'", int2 == 1616);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute(70);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear(1, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendTimeZoneOffset("738", false, 12, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(6, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(18, 75, 414, 52, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2);
        org.joda.time.Instant instant3 = instant1.minus(28799949L);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear(12);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        mutableDateTime2.setZone(dateTimeZone3);
        mutableDateTime2.addHours(292278993);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendSecondOfMinute(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute(70);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear(1, 31);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) '4');
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray27 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial20, intArray27);
        int int31 = offsetDateTimeField19.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, (int) '4');
        int int36 = offsetDateTimeField19.getDifference((long) '4', (long) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, (int) '4');
        org.joda.time.ReadablePartial readablePartial47 = null;
        int[] intArray54 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int55 = offsetDateTimeField46.getMinimumValue(readablePartial47, intArray54);
        int int58 = offsetDateTimeField46.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField46, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField46, 4);
        long long65 = offsetDateTimeField46.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField46.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder39.appendText(dateTimeFieldType66);
        java.lang.Number number71 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, (java.lang.Number) (byte) 0, number71, (java.lang.Number) 0L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType66);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder8.appendDecimal(dateTimeFieldType66, 19, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder8.appendSecondOfMinute(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 1, 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-82800001L) + "'", long65 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((long) 777600038, (-28800000), 0, 0, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling(0L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1970);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(52L);
        long long18 = skipUndoDateTimeField7.add((long) (byte) 10, 100);
        int int20 = skipUndoDateTimeField7.get((long) 2000);
        int int22 = skipUndoDateTimeField7.get((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8640000010L + "'", long18 == 8640000010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        org.joda.time.DateTime dateTime3 = instant0.toDateTime();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Instant instant6 = instant0.withDurationAdded(readableDuration4, 600);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField13);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField14, 0);
//        int int18 = skipUndoDateTimeField14.getLeapAmount(600L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField14.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
//        boolean boolean21 = instant0.isSupported(dateTimeFieldType20);
//        long long22 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31T23:59:59.997Z" + "'", str1.equals("1969-12-31T23:59:59.997Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-3L) + "'", long22 == (-3L));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime3 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTimeISO();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (short) -1, (-1550), 600, 60, 75, (int) (byte) 10, (-7));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (short) 0);
        org.joda.time.DateTime dateTime3 = instant0.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.plus(readableDuration4);
        org.joda.time.DateTime dateTime6 = instant0.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays(31);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        long long10 = skipUndoDateTimeField7.getDifferenceAsLong(24405880L, (long) '4');
        boolean boolean11 = skipUndoDateTimeField7.isLenient();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField7.getLeapDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 18);
        int int15 = skipUndoDateTimeField7.getMinimumValue();
        long long17 = skipUndoDateTimeField7.roundFloor(27L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray24 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray24);
        int int28 = offsetDateTimeField16.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) '4');
        int int33 = offsetDateTimeField16.getDifference((long) '4', (long) '#');
        int int34 = offsetDateTimeField16.getOffset();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) offsetDateTimeField16, (-75));
        long long40 = gregorianChronology6.add(170208000010L, 111600001L, (int) (short) 1);
        try {
            long long48 = gregorianChronology6.getDateTimeMillis(1612, 30, 52, (int) (byte) 10, 100, 0, (-75));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 170319600011L + "'", long40 == 170319600011L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMillis((-28800000));
        org.joda.time.DateTime.Property property7 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime1.minusHours((-101));
        try {
            org.joda.time.DateTime dateTime13 = dateTime1.withYearOfEra((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) (-12), (-12));
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-12T12:18:27.046Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T12:18:27.046Z' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 1970);
        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withWeekOfWeekyear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
        int int11 = skipUndoDateTimeField6.getMaximumValue((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        int int10 = dateTimeParserBucket9.getOffset();
        java.util.Locale locale11 = dateTimeParserBucket9.getLocale();
        java.lang.Object obj12 = null;
        boolean boolean13 = dateTimeParserBucket9.restoreState(obj12);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(2440588L, 172800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 421733606400000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.minuteOfDay();
        mutableDateTime2.setSecondOfDay(19);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
        int int7 = mutableDateTime2.getMinuteOfHour();
        mutableDateTime2.addWeekyears(1969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime8 = dateTime5.plusSeconds(27);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        int int9 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withFields(readablePartial11);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5520000 + "'", int9 == 5520000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.setMonthOfYear((int) (short) 10);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((long) (byte) 10);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology0.getZone();
        boolean boolean27 = dateTimeZone25.isStandardOffset((long) 75);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.Chronology chronology30 = gJChronology29.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int24 = offsetDateTimeField15.getMinimumValue(readablePartial16, intArray23);
        int int27 = offsetDateTimeField15.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 4);
        long long34 = offsetDateTimeField15.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "738");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType35, 6);
        int int41 = dividedDateTimeField40.getDivisor();
        int int42 = dividedDateTimeField40.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
        int int45 = remainderDateTimeField43.get(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = remainderDateTimeField43.getType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-82800001L) + "'", long34 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) '4');
        org.joda.time.DurationField durationField10 = property6.getDurationField();
        org.joda.time.DateTime dateTime11 = property6.roundHalfEvenCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField17);
        java.lang.String str19 = skipUndoDateTimeField18.toString();
        boolean boolean20 = property6.equals((java.lang.Object) skipUndoDateTimeField18);
        org.joda.time.DateTime dateTime22 = property6.addToCopy(18);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfYear();
        int int25 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.centuryOfEra();
        boolean boolean27 = property6.equals((java.lang.Object) gregorianChronology23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str19.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay(0);
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) (-23408), 18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        long long4 = iSOChronology0.add((long) '#', 0L, (int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology10.getZone();
//        java.lang.String str14 = dateTimeZone13.getID();
//        long long16 = dateTimeZone13.convertUTCToLocal((long) (short) 10);
//        org.joda.time.Chronology chronology17 = iSOChronology0.withZone(dateTimeZone13);
//        org.joda.time.Instant instant18 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime19 = instant18.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
//        org.joda.time.Instant instant22 = instant18.withMillis(100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now(dateTimeZone24);
//        int int26 = mutableDateTime25.getDayOfWeek();
//        mutableDateTime25.addHours((-1));
//        int int29 = mutableDateTime25.getRoundingMode();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean33 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology32, dateTimeField36);
//        java.util.Locale locale38 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology32, locale38);
//        dateTimeParserBucket39.setOffset((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str43 = dateTimeZone42.toString();
//        dateTimeParserBucket39.setZone(dateTimeZone42);
//        long long46 = dateTimeParserBucket39.computeMillis(false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean49 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology48);
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) '4');
//        org.joda.time.ReadablePartial readablePartial53 = null;
//        int[] intArray60 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int61 = offsetDateTimeField52.getMinimumValue(readablePartial53, intArray60);
//        int int64 = offsetDateTimeField52.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, 4);
//        long long71 = offsetDateTimeField52.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField52.getType();
//        dateTimeParserBucket39.saveField(dateTimeFieldType72, (int) (byte) -1);
//        int int75 = mutableDateTime25.get(dateTimeFieldType72);
//        int int76 = instant22.get(dateTimeFieldType72);
//        int int77 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.Instant instant79 = instant22.minus(252000960L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-6L) + "'", long46 == (-6L));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 52 + "'", int61 == 52);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-82800001L) + "'", long71 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 22 + "'", int75 == 22);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(instant79);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (short) 0);
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        boolean boolean6 = dateTime4.isAfterNow();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset(1512L, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1512L + "'", long5 == 1512L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withHourOfDay(3);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours(1612);
        org.joda.time.DateTime dateTime6 = dateTime2.minusHours((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime3.withYear(19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology2, locale8);
        dateTimeParserBucket9.setOffset((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str13 = dateTimeZone12.toString();
        dateTimeParserBucket9.setZone(dateTimeZone12);
        long long16 = dateTimeParserBucket9.computeMillis(false);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray30 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int31 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray30);
        int int34 = offsetDateTimeField22.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, 4);
        long long41 = offsetDateTimeField22.addWrapField((-1L), 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField22.getType();
        dateTimeParserBucket9.saveField(dateTimeFieldType42, (int) (byte) -1);
        try {
            long long45 = dateTimeParserBucket9.computeMillis();
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6L) + "'", long16 == (-6L));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-82800001L) + "'", long41 == (-82800001L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        int int2 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.withDayOfYear(10);
        org.joda.time.DateTime dateTime6 = dateTime1.minusHours((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime1.plusSeconds((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime1.withDayOfMonth(12);
        org.joda.time.DateTime dateTime12 = dateTime10.withSecondOfMinute((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology0.getZone();
        boolean boolean27 = dateTimeZone25.isStandardOffset((long) 75);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology29.getZone();
        org.joda.time.DurationField durationField31 = gJChronology29.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test113");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        mutableDateTime3.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
//        boolean boolean10 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        int int11 = mutableDateTime0.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        mutableDateTime0.setZoneRetainFields(dateTimeZone12);
//        mutableDateTime0.addMonths((int) (short) 1);
//        try {
//            mutableDateTime0.setHourOfDay(1616);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1616 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(19, 4, (int) (short) 10, 1, (int) ' ', (org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology14.getZone();
        long long19 = dateTimeZone6.getMillisKeepLocal(dateTimeZone17, (long) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(buddhistChronology20);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: PST");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime2.setMonthOfYear((int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology5);
//        int int8 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        java.lang.String str10 = mutableDateTime2.toString(dateTimeFormatter9);
//        mutableDateTime2.addMonths((int) (byte) 100);
//        int int13 = mutableDateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        boolean boolean4 = dateTimeFormatter3.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(2440588L, (org.joda.time.Chronology) gregorianChronology3);
        mutableDateTime4.setMillisOfSecond(6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        long long5 = durationField2.subtract(170208000010L, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 170207965010L + "'", long5 == 170207965010L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeField dateTimeField25 = julianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfWeek();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = property7.set((-3));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 0);
        int int11 = skipUndoDateTimeField7.getLeapAmount(600L);
        long long13 = skipUndoDateTimeField7.roundHalfEven((long) 1664);
        int int15 = skipUndoDateTimeField7.getLeapAmount((long) 3);
        int int17 = skipUndoDateTimeField7.getMaximumValue(252000960L);
        long long19 = skipUndoDateTimeField7.roundHalfCeiling((long) 86399);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField6 = gregorianChronology1.years();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis((int) (short) 10, 777600038, (-3), 414, 1439, 0, 1164);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 414 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2);
        org.joda.time.Instant instant4 = instant1.withDurationAdded((long) (byte) 100, (int) ' ');
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField7 = gregorianChronology1.weeks();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray22 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial15, intArray22);
        int int26 = offsetDateTimeField14.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) '4');
        int int31 = offsetDateTimeField14.getDifference((long) '4', (long) '#');
        boolean boolean32 = julianChronology8.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology8.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone33);
        org.joda.time.DurationField durationField35 = gregorianChronology1.days();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(durationField35);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test128");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfWeek();
//        int int4 = mutableDateTime2.getDayOfWeek();
//        mutableDateTime2.addMonths((int) 'a');
//        int int7 = mutableDateTime2.getRoundingMode();
//        mutableDateTime2.setSecondOfMinute(52);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(1560370728156L, dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.getID();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray13 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray13);
        int int17 = offsetDateTimeField5.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4');
        int int22 = offsetDateTimeField5.getDifference((long) '4', (long) '#');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider24 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField31);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology25, (org.joda.time.DateTimeField) skipUndoDateTimeField32, 0);
        long long36 = skipUndoDateTimeField32.roundHalfCeiling(0L);
        long long38 = skipUndoDateTimeField32.roundHalfEven((long) 1970);
        int int40 = skipUndoDateTimeField32.getMaximumValue((long) (-28800000));
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology44.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology44.getZone();
        mutableDateTime43.setChronology((org.joda.time.Chronology) gregorianChronology44);
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology44.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology53);
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology53.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, dateTimeField57);
        java.util.Locale locale59 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology53, locale59);
        dateTimeParserBucket60.setOffset((java.lang.Integer) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology63.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology63.getZone();
        dateTimeParserBucket60.setZone(dateTimeZone67);
        java.util.Locale locale69 = dateTimeParserBucket60.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(28800001L, (org.joda.time.Chronology) gregorianChronology44, locale69, (java.lang.Integer) 0);
        java.lang.String str72 = skipUndoDateTimeField32.getAsShortText((int) (short) 10, locale69);
        java.lang.String str75 = defaultNameProvider24.getShortName(locale69, "31", "PST");
        java.lang.String str76 = offsetDateTimeField5.getAsText((long) 6, locale69);
        long long78 = offsetDateTimeField5.remainder(0L);
        org.joda.time.ReadablePartial readablePartial79 = null;
        java.util.Locale locale81 = null;
        java.lang.String str82 = offsetDateTimeField5.getAsText(readablePartial79, 0, locale81);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10" + "'", str72.equals("10"));
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "52" + "'", str76.equals("52"));
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "0" + "'", str82.equals("0"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology0.getZone();
        boolean boolean27 = dateTimeZone25.isStandardOffset((long) 75);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        int int31 = dateTimeZone25.getOffsetFromLocal(75600000L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sun");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 6, (org.joda.time.Chronology) gregorianChronology3, locale4, (java.lang.Integer) 0);
        jodaTimePermission1.checkGuard((java.lang.Object) 0);
        java.security.Permission permission8 = null;
        boolean boolean9 = jodaTimePermission1.implies(permission8);
        java.lang.String str10 = jodaTimePermission1.getActions();
        java.lang.String str11 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Sun\")" + "'", str11.equals("(\"org.joda.time.JodaTimePermission\" \"Sun\")"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = mutableDateTime2.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.monthOfYear();
        mutableDateTime2.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = mutableDateTime12.getZone();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) 44314);
        org.joda.time.DateTime dateTime16 = mutableDateTime9.toDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sun");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Sun\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"Sun\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test136");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((long) 3);
//        int int8 = property4.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundCeiling();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean14 = gregorianChronology10.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfMonth();
//        mutableDateTime9.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField18 = null;
//        mutableDateTime9.setRounding(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) ' ');
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        int int6 = property5.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray14);
        int int18 = offsetDateTimeField6.getDifference((long) (-1), (long) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) '4');
        int int23 = offsetDateTimeField6.getDifference((long) '4', (long) '#');
        boolean boolean24 = julianChronology0.equals((java.lang.Object) '4');
        int int25 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField26 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 91L, 4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        java.util.TimeZone timeZone10 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, 91L, 4);
        org.joda.time.Chronology chronology14 = gJChronology6.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5);
//        long long9 = skipUndoDateTimeField6.add((long) 0, (long) (byte) 1);
//        java.lang.String str11 = skipUndoDateTimeField6.getAsText((long) (-28800000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray25 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray25);
//        int int29 = offsetDateTimeField17.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) '4');
//        int int34 = offsetDateTimeField17.getDifference((long) '4', (long) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeek(4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) '4');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray52 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial45, intArray52);
//        int int56 = offsetDateTimeField44.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, 4);
//        long long63 = offsetDateTimeField44.addWrapField((-1L), 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField44.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "738");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder37.appendText(dateTimeFieldType64);
//        java.lang.Number number69 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, number69, (java.lang.Number) 0L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType64);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType64);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str75 = iSOChronology74.toString();
//        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str77 = dateTimeZone76.toString();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        long long80 = dateTimeZone76.getMillisKeepLocal(dateTimeZone78, (long) (short) 100);
//        java.lang.String str82 = dateTimeZone76.getShortName(0L);
//        boolean boolean83 = iSOChronology74.equals((java.lang.Object) str82);
//        org.joda.time.DurationField durationField84 = iSOChronology74.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField85 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField84);
//        long long88 = unsupportedDateTimeField85.add((long) 'a', (long) 1439);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 52 + "'", int53 == 52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-82800001L) + "'", long63 == (-82800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ISOChronology[UTC]" + "'", str75.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "UTC" + "'", str77.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 100L + "'", long80 == 100L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "UTC" + "'", str82.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField85);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1536L + "'", long88 == 1536L);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.addWrapField((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = mutableDateTime6.toDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
//        org.joda.time.DurationField durationField10 = property9.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.dayOfMonth();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField(chronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 0);
        long long14 = skipUndoDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 600);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology3.getZone();
//        mutableDateTime2.setChronology((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DurationField durationField9 = gregorianChronology3.weeks();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) gregorianChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int[] intArray24 = new int[] { 19, ' ', (short) 1, (short) -1, 4, 4 };
//        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray24);
//        int int28 = offsetDateTimeField16.getDifference((long) (-1), (long) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) '4');
//        int int33 = offsetDateTimeField16.getDifference((long) '4', (long) '#');
//        boolean boolean34 = julianChronology10.equals((java.lang.Object) '4');
//        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology10.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone35);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now(dateTimeZone38);
//        int int40 = mutableDateTime39.getYearOfCentury();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime39.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime42 = property41.roundHalfEven();
//        org.joda.time.MutableDateTime mutableDateTime44 = property41.add((long) 3);
//        int int45 = property41.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property41.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime48 = property41.addWrapField(0);
//        int int49 = dateTimeZone35.getOffset((org.joda.time.ReadableInstant) mutableDateTime48);
//        org.joda.time.Chronology chronology50 = julianChronology0.withZone(dateTimeZone35);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 69 + "'", int40 == 69);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(chronology50);
//    }
//}

