import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusDays(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.getMillis();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gregorianChronology8.centuries();
        org.joda.time.Period period10 = new org.joda.time.Period(100L, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Period period12 = period10.minusSeconds((int) (short) 10);
        org.joda.time.Period period14 = period10.withMonths((int) (byte) 1);
        java.lang.String str15 = period14.toString();
        org.joda.time.Period period16 = period3.plus((org.joda.time.ReadablePeriod) period14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "P1MT0.100S" + "'", str15.equals("P1MT0.100S"));
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
        long long11 = offsetDateTimeField9.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType12, (int) ' ');
        boolean boolean23 = offsetDateTimeField21.isLeap(0L);
        long long25 = offsetDateTimeField21.roundCeiling((-9223372036854775808L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9223372016300048394L) + "'", long25 == (-9223372016300048394L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusMonths((-1));
        org.joda.time.Period period9 = period7.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationTo(readableInstant10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gregorianChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology18, dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology14.withZone(dateTimeZone20);
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) duration11, (org.joda.time.Chronology) gregorianChronology14);
        int int24 = period23.getWeeks();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period21 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        boolean boolean22 = lenientChronology12.equals((java.lang.Object) (short) -1);
        org.joda.time.DurationField durationField23 = lenientChronology12.centuries();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology25 = lenientChronology12.withZone(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology12.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
//        org.joda.time.DurationField durationField6 = zonedChronology5.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology5.getZone();
//        org.joda.time.DurationField durationField8 = zonedChronology5.minutes();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
//        boolean boolean12 = zonedChronology5.equals((java.lang.Object) readableInstant10);
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology5.dayOfMonth();
//        org.joda.time.Chronology chronology14 = zonedChronology5.withUTC();
//        org.joda.time.DurationField durationField15 = zonedChronology5.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology5.getZone();
//        java.lang.String str17 = zonedChronology5.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(zonedChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +10:00]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], +10:00]"));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfWeek();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(359991, 360000000, (int) ' ', 36000000, 5760, 8639, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', '#', (int) '4', (int) (byte) -1, (int) (short) 0, true, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("6", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period3 = period1.withMonths((int) (byte) 1);
        org.joda.time.Period period5 = org.joda.time.Period.hours(0);
        org.joda.time.Period period6 = period1.minus((org.joda.time.ReadablePeriod) period5);
        int int7 = period5.getDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        org.joda.time.Period period9 = period5.withPeriodType(periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        int int28 = dividedDateTimeField23.getMaximumValue();
        int int29 = dividedDateTimeField23.getMaximumValue();
        int int30 = dividedDateTimeField23.getMaximumValue();
        int int31 = dividedDateTimeField23.getMaximumValue();
        int int33 = dividedDateTimeField23.getMaximumValue((long) (short) 1);
        boolean boolean34 = dividedDateTimeField23.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8639 + "'", int28 == 8639);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8639 + "'", int29 == 8639);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8639 + "'", int30 == 8639);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8639 + "'", int31 == 8639);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 8639 + "'", int33 == 8639);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusMonths((-1));
        org.joda.time.Period period9 = period7.minusMonths((int) (byte) 100);
        org.joda.time.Period period10 = period9.normalizedStandard();
        org.joda.time.Period period11 = period9.negated();
        org.joda.time.Period period13 = period9.multipliedBy(0);
        int int14 = period9.getHours();
        int int15 = period9.getMonths();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-99) + "'", int15 == (-99));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.centuries();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Period period8 = period6.minusMonths((-1));
        org.joda.time.Period period10 = period8.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationTo(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType17 = periodType16.withMinutesRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration12, periodType17);
        org.joda.time.Period period20 = period18.minusDays(0);
        org.joda.time.Period period22 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period24 = period22.withMonths((int) (byte) 1);
        org.joda.time.Period period26 = org.joda.time.Period.hours(0);
        org.joda.time.Period period27 = period22.minus((org.joda.time.ReadablePeriod) period26);
        int int28 = period26.getDays();
        org.joda.time.Period period30 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period32 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period33 = period30.minus((org.joda.time.ReadablePeriod) period32);
        org.joda.time.format.PeriodFormatter periodFormatter34 = null;
        java.lang.String str35 = period32.toString(periodFormatter34);
        org.joda.time.Period period44 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period45 = period44.negated();
        int int46 = period44.getHours();
        org.joda.time.DurationFieldType durationFieldType48 = period44.getFieldType(5);
        org.joda.time.Period period50 = period32.withFieldAdded(durationFieldType48, 86409);
        int int51 = period26.indexOf(durationFieldType48);
        boolean boolean52 = period20.isSupported(durationFieldType48);
        org.joda.time.Seconds seconds53 = period20.toStandardSeconds();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PT0S" + "'", str35.equals("PT0S"));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(seconds53);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.eras();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = gregorianChronology2.set(readablePartial7, (long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(401L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 401L + "'", long2 == 401L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusMonths((-1));
        org.joda.time.Period period9 = period7.minusMonths((int) (byte) 100);
        org.joda.time.Period period10 = period9.normalizedStandard();
        org.joda.time.Period period11 = period9.negated();
        int int12 = period9.getMonths();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-99) + "'", int12 == (-99));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0S", (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, number3);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100.0f, number7, (java.lang.Number) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException9.getDurationFieldType();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = illegalFieldValueException9.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException9.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertNull(durationFieldType11);
        org.junit.Assert.assertNull(dateTimeFieldType13);
        org.junit.Assert.assertNull(dateTimeFieldType14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        java.util.Locale locale27 = null;
        int int28 = dividedDateTimeField23.getMaximumShortTextLength(locale27);
        boolean boolean29 = dividedDateTimeField23.isLenient();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period21 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        boolean boolean22 = lenientChronology12.equals((java.lang.Object) (short) -1);
        java.lang.String str23 = lenientChronology12.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        long long27 = dateTimeZone25.convertUTCToLocal((long) 10);
        org.joda.time.Chronology chronology28 = lenientChronology12.withZone(dateTimeZone25);
        org.joda.time.DurationField durationField29 = lenientChronology12.millis();
        org.joda.time.Chronology chronology30 = lenientChronology12.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str23.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 36000010L + "'", long27 == 36000010L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        int int4 = period1.getMonths();
        org.joda.time.Days days5 = period1.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(days5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField7 = gregorianChronology4.weekyears();
        int int8 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (-1), periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Period period11 = period9.withDays(0);
        org.joda.time.Period period13 = period9.minusDays(0);
        try {
            org.joda.time.Period period15 = period13.plusMonths((-1560266));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("8");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"8\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        try {
            long long20 = gregorianChronology2.getDateTimeMillis(115202048, 43210, (int) 'a', (int) (short) 1, 3, 36000000, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period3 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period4 = period1.minus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period3.toString(periodFormatter5);
        org.joda.time.MutablePeriod mutablePeriod7 = period3.toMutablePeriod();
        int int8 = period3.getDays();
        int[] intArray9 = period3.getValues();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 10);
        org.joda.time.Period period3 = period1.withHours(8639);
        org.joda.time.Period period5 = period1.minusHours((int) '#');
        org.joda.time.Period period7 = period5.plusMinutes((int) (short) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5, chronology8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        int int28 = dividedDateTimeField23.getMaximumValue();
        int int29 = dividedDateTimeField23.getMaximumValue();
        int int30 = dividedDateTimeField23.getMaximumValue();
        int int31 = dividedDateTimeField23.getMaximumValue();
        int int33 = dividedDateTimeField23.getMaximumValue((long) (short) 1);
        long long36 = dividedDateTimeField23.addWrapField((-35991903L), (int) (byte) 100);
        org.joda.time.DurationField durationField37 = dividedDateTimeField23.getDurationField();
        long long40 = dividedDateTimeField23.add(3155759999999L, 311073096990L);
        int int42 = dividedDateTimeField23.getMinimumValue(3157320626599990L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8639 + "'", int28 == 8639);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8639 + "'", int29 == 8639);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8639 + "'", int30 == 8639);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8639 + "'", int31 == 8639);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 8639 + "'", int33 == 8639);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-34991903L) + "'", long36 == (-34991903L));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 3113886729899999L + "'", long40 == 3113886729899999L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test027");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        long long5 = iSOChronology0.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
//        org.joda.time.Chronology chronology6 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology7 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone12.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone12.getUncachedZone();
//        boolean boolean15 = cachedDateTimeZone12.isFixed();
//        org.joda.time.Chronology chronology16 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology0.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62174426399996L) + "'", long5 == (-62174426399996L));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560626600990000000L, 3155759999999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560629756749999999L + "'", long2 == 1560629756749999999L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100.0f, number2, (java.lang.Number) (short) 0);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", number1, (java.lang.Number) (-11L), (java.lang.Number) (short) -1);
        illegalFieldValueException4.prependMessage("32");
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("PT0S", (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, number10);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        illegalFieldValueException4.prependMessage("1");
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "ISOChronology[+00:00:00.010]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "UTC", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long14 = offsetDateTimeField12.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType15, 10);
        long long27 = dividedDateTimeField24.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = dividedDateTimeField24.getType();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.DurationField durationField33 = gregorianChronology31.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField33);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType28, 115202048);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str5 = cachedDateTimeZone3.getShortName(7200010L);
        boolean boolean6 = cachedDateTimeZone3.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.plusWeeks(0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560626600990L, (java.lang.Number) 3155760000032L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.DurationField durationField4 = gregorianChronology2.seconds();
        org.joda.time.Period period6 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period9 = period6.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period8.toString(periodFormatter10);
        org.joda.time.Period period20 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period21 = period20.negated();
        int int22 = period20.getHours();
        org.joda.time.DurationFieldType durationFieldType24 = period20.getFieldType(5);
        org.joda.time.Period period26 = period8.withFieldAdded(durationFieldType24, 86409);
        org.joda.time.field.DecoratedDurationField decoratedDurationField27 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType24);
        long long30 = decoratedDurationField27.add(0L, (int) '#');
        long long33 = decoratedDurationField27.getDifferenceAsLong((long) 360000000, 1560626600720L);
        java.lang.String str34 = decoratedDurationField27.toString();
        org.joda.time.DurationField durationField35 = decoratedDurationField27.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35000L + "'", long30 == 35000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1560266600L) + "'", long33 == (-1560266600L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "DurationField[minutes]" + "'", str34.equals("DurationField[minutes]"));
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long26 = remainderDateTimeField24.roundCeiling(35999990L);
        org.joda.time.DurationField durationField27 = remainderDateTimeField24.getRangeDurationField();
        int int28 = remainderDateTimeField24.getDivisor();
        int int30 = remainderDateTimeField24.get(360000000000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35999990L + "'", long26 == 35999990L);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.centuries();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Period period9 = period7.minusMonths((-1));
        org.joda.time.Period period11 = period9.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationTo(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant14, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration13);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant19);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "P-100W", "");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-62167219200010L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2175852672000350L) + "'", long2 == (-2175852672000350L));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField7 = gregorianChronology4.weekyears();
        int int8 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (-1), periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Period period11 = period9.withDays(0);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.withFields(readablePeriod12);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period3 = period1.withMonths((int) (byte) 1);
        org.joda.time.Period period5 = org.joda.time.Period.hours(0);
        org.joda.time.Period period6 = period1.minus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.Period period8 = period6.minusHours(0);
        int int9 = period6.size();
        org.joda.time.Period period11 = period6.plusDays(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekyear();
        int int6 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0S", (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, number3);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (byte) 10, 0, (int) '#');
        boolean boolean10 = offsetDateTimeField5.isLenient();
        boolean boolean12 = offsetDateTimeField5.isLeap(1560266600990L);
        long long15 = offsetDateTimeField5.addWrapField(0L, (-1560266));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 81334000L + "'", long15 == 81334000L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period3 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period4 = period1.minus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period3.toString(periodFormatter5);
        org.joda.time.Period period8 = period3.plusMinutes((int) (short) -1);
        org.joda.time.Period period10 = period3.withMillis((int) '#');
        org.joda.time.Period period12 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period14 = period12.withMonths((int) (byte) 1);
        org.joda.time.Period period16 = org.joda.time.Period.hours(0);
        org.joda.time.Period period17 = period12.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period19 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period20 = period16.plus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant21, readableInstant22, periodType23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period16, periodType23);
        org.joda.time.PeriodType periodType26 = periodType23.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = gregorianChronology29.centuries();
        org.joda.time.DurationField durationField31 = gregorianChronology29.millis();
        org.joda.time.DurationField durationField32 = gregorianChronology29.days();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.Period period34 = new org.joda.time.Period((java.lang.Object) period3, periodType26, (org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.Weeks weeks35 = period3.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(weeks35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        try {
            java.lang.String str35 = unsupportedDateTimeField33.getAsShortText(362828L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (byte) 10, 0, (int) '#');
        int int11 = offsetDateTimeField5.getLeapAmount(100L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField5.getAsShortText(100000L, locale13);
        long long17 = offsetDateTimeField5.add(362828L, (-7));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "110" + "'", str14.equals("110"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 355828L + "'", long17 == 355828L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = null;
        int int8 = offsetDateTimeField5.getMaximumValue(readablePartial6, intArray7);
        int int9 = offsetDateTimeField5.getOffset();
        boolean boolean11 = offsetDateTimeField5.isLeap(100097L);
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(776L);
        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86409 + "'", int8 == 86409);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.joda.time.DateTimeField dateTimeField25 = dividedDateTimeField23.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField31, (int) (byte) 10, 0, (int) '#');
        long long37 = offsetDateTimeField31.roundFloor((long) (-1));
        long long39 = offsetDateTimeField31.roundHalfFloor(0L);
        long long42 = offsetDateTimeField31.add(1560626597870L, 3155759999999L);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray46 = new int[] { (-1), 36000000 };
        int int47 = offsetDateTimeField31.getMaximumValue(readablePartial43, intArray46);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 10);
        long long55 = offsetDateTimeField53.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType56, 4, (-100), 86409);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField31, dateTimeFieldType56, (-1), 10, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23, dateTimeFieldType56);
        org.joda.time.ReadablePartial readablePartial66 = null;
        int int67 = dividedDateTimeField23.getMaximumValue(readablePartial66);
        org.joda.time.DurationField durationField68 = dividedDateTimeField23.getDurationField();
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType70 = periodType69.withWeeksRemoved();
        org.joda.time.Period period79 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period80 = period79.negated();
        int int81 = period79.getHours();
        org.joda.time.DurationFieldType durationFieldType83 = period79.getFieldType(5);
        boolean boolean84 = periodType70.isSupported(durationFieldType83);
        org.joda.time.field.ScaledDurationField scaledDurationField86 = new org.joda.time.field.ScaledDurationField(durationField68, durationFieldType83, 86409);
        long long89 = scaledDurationField86.getMillis((-10), 36000010L);
        long long92 = scaledDurationField86.add((-3599978L), (long) (-99));
        int int93 = scaledDurationField86.getScalar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-10L) + "'", long39 == (-10L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3157320626596870L + "'", long42 == 3157320626596870L);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86409 + "'", int47 == 86409);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-10L) + "'", long55 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 8639 + "'", int67 == 8639);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(durationFieldType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-8640900000L) + "'", long89 == (-8640900000L));
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-85548509978L) + "'", long92 == (-85548509978L));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 86409 + "'", int93 == 86409);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField33.getAsText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        long long40 = iSOChronology35.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Chronology chronology41 = iSOChronology35.withUTC();
        org.joda.time.Period period43 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period45 = period43.withMonths((int) (byte) 1);
        org.joda.time.Period period47 = org.joda.time.Period.hours(0);
        org.joda.time.Period period48 = period43.minus((org.joda.time.ReadablePeriod) period47);
        org.joda.time.Period period50 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period51 = period47.plus((org.joda.time.ReadablePeriod) period50);
        org.joda.time.Period period53 = period51.plusHours((int) (short) 100);
        org.joda.time.Period period55 = period53.plusMillis(36000000);
        int[] intArray57 = iSOChronology35.get((org.joda.time.ReadablePeriod) period53, 0L);
        try {
            int int58 = unsupportedDateTimeField33.getMinimumValue(readablePartial34, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62174426399996L) + "'", long40 == (-62174426399996L));
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.PeriodType periodType7 = periodType5.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        long long13 = iSOChronology8.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Chronology chronology14 = iSOChronology8.withUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((long) 2, 360000000000L, periodType5, chronology14);
        org.joda.time.PeriodType periodType16 = periodType5.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        long long22 = iSOChronology17.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 19, (-210858120000000L), periodType5, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Period period24 = new org.joda.time.Period(32035L, periodType5);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62174426399996L) + "'", long13 == (-62174426399996L));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62174426399996L) + "'", long22 == (-62174426399996L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalFieldValueException: Value null for 32 must be in the range [36000010,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: Value null for 32 must be in the range [36000010,1]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.joda.time.DateTimeField dateTimeField25 = dividedDateTimeField23.getWrappedField();
        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) 100, (long) 4);
        long long31 = dividedDateTimeField23.addWrapField(25L, (int) (byte) 0);
        int int33 = dividedDateTimeField23.getMinimumValue(1227241024L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 25L + "'", long31 == 25L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField13 = lenientChronology12.halfdays();
        java.lang.String str14 = lenientChronology12.toString();
        java.lang.String str15 = lenientChronology12.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gregorianChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology18, dateTimeZone20);
        org.joda.time.DurationField durationField22 = zonedChronology21.halfdays();
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology21.getZone();
        org.joda.time.DurationField durationField24 = zonedChronology21.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology21.getZone();
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) str15, (org.joda.time.Chronology) zonedChronology21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"LenientChronology[GregorianChron...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str14.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str15.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = null;
        int int8 = offsetDateTimeField5.getMaximumValue(readablePartial6, intArray7);
        long long10 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86409 + "'", int8 == 86409);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-10L) + "'", long10 == (-10L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        long long12 = iSOChronology7.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Chronology chronology13 = iSOChronology7.withUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((long) 2, 360000000000L, periodType4, chronology13);
        org.joda.time.PeriodType periodType15 = periodType4.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        long long21 = iSOChronology16.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Period period22 = new org.joda.time.Period((long) 19, (-210858120000000L), periodType4, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period24 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period26 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period27 = period24.minus((org.joda.time.ReadablePeriod) period26);
        org.joda.time.format.PeriodFormatter periodFormatter28 = null;
        java.lang.String str29 = period26.toString(periodFormatter28);
        org.joda.time.Period period38 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period39 = period38.negated();
        int int40 = period38.getHours();
        org.joda.time.DurationFieldType durationFieldType42 = period38.getFieldType(5);
        org.joda.time.Period period44 = period26.withFieldAdded(durationFieldType42, 86409);
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(durationFieldType42, "LenientChronology[GregorianChronology[+00:00:00.010]]");
        try {
            org.joda.time.Period period48 = period22.withFieldAdded(durationFieldType42, 36000000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'minutes'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62174426399996L) + "'", long12 == (-62174426399996L));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62174426399996L) + "'", long21 == (-62174426399996L));
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PT0S" + "'", str29.equals("PT0S"));
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertNotNull(period44);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField7 = gregorianChronology4.weekyears();
        int int8 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (-1), periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.PeriodType periodType10 = periodType1.withMonthsRemoved();
        org.joda.time.PeriodType periodType11 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType12 = periodType1.withHoursRemoved();
        boolean boolean14 = periodType1.equals((java.lang.Object) (-210866716790000L));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period21 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        boolean boolean22 = lenientChronology12.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeField dateTimeField23 = lenientChronology12.clockhourOfHalfday();
        org.joda.time.Chronology chronology24 = lenientChronology12.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        long long30 = dividedDateTimeField23.getDifferenceAsLong(36000032L, 35000L);
        boolean boolean32 = dividedDateTimeField23.isLeap(776L);
        java.lang.String str34 = dividedDateTimeField23.getAsText((long) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3596L + "'", long30 == 3596L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int6 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField5.getAsText(readablePartial7, (int) ' ', locale9);
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLeap((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(43186, (int) '4', 5, 5760, 36000000, 10, 6, (int) '#', periodType8);
        org.joda.time.Period period11 = period9.withMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, periodType1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        long long16 = lenientChronology12.add(0L, (long) 8, (int) 'a');
        java.lang.String str17 = lenientChronology12.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 776L + "'", long16 == 776L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str17.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[+10:00]" + "'", str2.equals("ISOChronology[+10:00]"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', '#', (int) '4', (int) (byte) -1, (int) (short) 0, true, (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("LenientChronology[GregorianChronology[+00:00:00.010]]", 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset((-35999));
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder11.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period14 = period13.negated();
        int int15 = period13.getHours();
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(5);
        boolean boolean18 = periodType4.isSupported(durationFieldType17);
        int int19 = periodType2.indexOf(durationFieldType17);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = null;
        int int8 = offsetDateTimeField5.getMaximumValue(readablePartial6, intArray7);
        int int9 = offsetDateTimeField5.getOffset();
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField5.getMaximumShortTextLength(locale10);
        try {
            long long14 = offsetDateTimeField5.set((-1560266600L), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [10,86409]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86409 + "'", int8 == 86409);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period(100L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusSeconds((int) (short) 10);
        org.joda.time.Period period9 = period5.minusSeconds(69);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        try {
            int int34 = unsupportedDateTimeField33.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.DurationField durationField4 = gregorianChronology2.seconds();
        org.joda.time.Period period6 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period9 = period6.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period8.toString(periodFormatter10);
        org.joda.time.Period period20 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period21 = period20.negated();
        int int22 = period20.getHours();
        org.joda.time.DurationFieldType durationFieldType24 = period20.getFieldType(5);
        org.joda.time.Period period26 = period8.withFieldAdded(durationFieldType24, 86409);
        org.joda.time.field.DecoratedDurationField decoratedDurationField27 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType24);
        boolean boolean28 = decoratedDurationField27.isSupported();
        int int31 = decoratedDurationField27.getDifference((-1560266600L), (long) (short) -1);
        long long34 = decoratedDurationField27.getDifferenceAsLong(0L, (long) 0);
        long long37 = decoratedDurationField27.add((long) 2, (-316799725));
        boolean boolean38 = decoratedDurationField27.isPrecise();
        int int41 = decoratedDurationField27.getValue(986L, 0L);
        long long44 = decoratedDurationField27.getMillis((int) '#', 160000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1560266) + "'", int31 == (-1560266));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-316799724998L) + "'", long37 == (-316799724998L));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35000L + "'", long44 == 35000L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.Chronology chronology11 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology3.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField14 = lenientChronology13.halfdays();
        java.lang.String str15 = lenientChronology13.toString();
        org.joda.time.Period period17 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period19 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period20 = period17.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period22 = period20.plusMillis((int) (short) -1);
        org.joda.time.Period period24 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period26 = period24.withMonths((int) (byte) 1);
        org.joda.time.Period period28 = org.joda.time.Period.hours(0);
        org.joda.time.Period period29 = period24.minus((org.joda.time.ReadablePeriod) period28);
        int int30 = period28.getDays();
        org.joda.time.Period period31 = period22.withFields((org.joda.time.ReadablePeriod) period28);
        int int32 = period28.size();
        boolean boolean33 = lenientChronology13.equals((java.lang.Object) period28);
        org.joda.time.DateTimeField dateTimeField34 = lenientChronology13.secondOfDay();
        org.joda.time.Period period35 = new org.joda.time.Period(1000L, (org.joda.time.Chronology) lenientChronology13);
        org.joda.time.DurationField durationField36 = lenientChronology13.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str15.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.DurationField durationField4 = gregorianChronology2.seconds();
        org.joda.time.Period period6 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period9 = period6.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period8.toString(periodFormatter10);
        org.joda.time.Period period20 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period21 = period20.negated();
        int int22 = period20.getHours();
        org.joda.time.DurationFieldType durationFieldType24 = period20.getFieldType(5);
        org.joda.time.Period period26 = period8.withFieldAdded(durationFieldType24, 86409);
        org.joda.time.field.DecoratedDurationField decoratedDurationField27 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType24);
        boolean boolean28 = decoratedDurationField27.isSupported();
        int int31 = decoratedDurationField27.getDifference((-1560266600L), (long) (short) -1);
        long long34 = decoratedDurationField27.getDifferenceAsLong(0L, (long) 0);
        long long37 = decoratedDurationField27.add((long) 2, (-316799725));
        boolean boolean38 = decoratedDurationField27.isPrecise();
        int int41 = decoratedDurationField27.getValue(986L, 0L);
        int int44 = decoratedDurationField27.getValue(10L, (-62174390399996L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1560266) + "'", int31 == (-1560266));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-316799724998L) + "'", long37 == (-316799724998L));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.joda.time.DateTimeField dateTimeField25 = dividedDateTimeField23.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField31, (int) (byte) 10, 0, (int) '#');
        long long37 = offsetDateTimeField31.roundFloor((long) (-1));
        long long39 = offsetDateTimeField31.roundHalfFloor(0L);
        long long42 = offsetDateTimeField31.add(1560626597870L, 3155759999999L);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray46 = new int[] { (-1), 36000000 };
        int int47 = offsetDateTimeField31.getMaximumValue(readablePartial43, intArray46);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 10);
        long long55 = offsetDateTimeField53.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType56, 4, (-100), 86409);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField31, dateTimeFieldType56, (-1), 10, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23, dateTimeFieldType56);
        org.joda.time.ReadablePartial readablePartial66 = null;
        int int67 = dividedDateTimeField23.getMaximumValue(readablePartial66);
        org.joda.time.DurationField durationField68 = dividedDateTimeField23.getDurationField();
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType70 = periodType69.withWeeksRemoved();
        org.joda.time.Period period79 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period80 = period79.negated();
        int int81 = period79.getHours();
        org.joda.time.DurationFieldType durationFieldType83 = period79.getFieldType(5);
        boolean boolean84 = periodType70.isSupported(durationFieldType83);
        org.joda.time.field.ScaledDurationField scaledDurationField86 = new org.joda.time.field.ScaledDurationField(durationField68, durationFieldType83, 86409);
        long long89 = scaledDurationField86.getMillis((-10), 36000010L);
        long long92 = scaledDurationField86.add((-3599978L), (long) (-99));
        long long95 = scaledDurationField86.add((-210866762090000L), 19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-10L) + "'", long39 == (-10L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3157320626596870L + "'", long42 == 3157320626596870L);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86409 + "'", int47 == 86409);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-10L) + "'", long55 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 8639 + "'", int67 == 8639);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(durationFieldType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-8640900000L) + "'", long89 == (-8640900000L));
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-85548509978L) + "'", long92 == (-85548509978L));
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-210850344380000L) + "'", long95 == (-210850344380000L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gregorianChronology10.centuries();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.Period period14 = period12.minusMonths((-1));
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 100);
        org.joda.time.Period period17 = period16.normalizedStandard();
        org.joda.time.Period period19 = period16.minusMillis(0);
        org.joda.time.Period period28 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period29 = period28.negated();
        int int30 = period28.getHours();
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(5);
        org.joda.time.Period period34 = period19.withField(durationFieldType32, (-10));
        boolean boolean35 = period6.equals((java.lang.Object) period19);
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period39 = period37.withMonths((int) (byte) 1);
        org.joda.time.Period period41 = org.joda.time.Period.hours(0);
        org.joda.time.Period period42 = period37.minus((org.joda.time.ReadablePeriod) period41);
        org.joda.time.Period period44 = period42.minusHours(0);
        boolean boolean45 = period19.equals((java.lang.Object) period44);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.centuries();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withMinutesRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration7, readableInstant8, periodType11);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) durationField6, periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period4 = period2.withMonths((int) (byte) 1);
        org.joda.time.Period period6 = org.joda.time.Period.hours(0);
        org.joda.time.Period period7 = period2.minus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period7.minusHours(0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationFrom(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period14 = period12.plusHours((int) (byte) 10);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (-1));
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("70", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, 0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone4.getUncachedZone();
        long long8 = cachedDateTimeZone4.previousTransition((-35991903L));
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone4.getUncachedZone();
        boolean boolean10 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-35991903L) + "'", long8 == (-35991903L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", number1, (java.lang.Number) (-11L), (java.lang.Number) (short) -1);
        illegalFieldValueException4.prependMessage("32");
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("PT0S", (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, number10);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.String str13 = illegalFieldValueException11.getFieldName();
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException11.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException11.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException11.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0S" + "'", str13.equals("PT0S"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationFieldType16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, 6, 6, 0);
        org.joda.time.Duration duration5 = period4.toStandardDuration();
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str13 = lenientChronology12.toString();
        java.lang.Number number16 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100.0f, number16, (java.lang.Number) (short) 0);
        org.joda.time.DurationFieldType durationFieldType19 = illegalFieldValueException18.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType20 = illegalFieldValueException18.getDurationFieldType();
        java.lang.String str21 = illegalFieldValueException18.getIllegalValueAsString();
        illegalFieldValueException18.prependMessage("+00:00:00.010");
        boolean boolean24 = lenientChronology12.equals((java.lang.Object) illegalFieldValueException18);
        java.lang.Number number25 = illegalFieldValueException18.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str13.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNull(durationFieldType19);
        org.junit.Assert.assertNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100.0" + "'", str21.equals("100.0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weeks();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone7.getName((long) (short) 1, locale10);
        java.lang.String str13 = dateTimeZone7.getName((long) (short) -1);
        org.joda.time.Chronology chronology14 = gregorianChronology2.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.010" + "'", str13.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField33.getDurationField();
        try {
            long long37 = unsupportedDateTimeField33.set(11L, "org.joda.time.IllegalFieldValueException: Value null for 32 must be in the range [36000010,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period21 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        boolean boolean22 = lenientChronology12.equals((java.lang.Object) (short) -1);
        java.lang.String str23 = lenientChronology12.toString();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) lenientChronology12);
        org.joda.time.DurationField durationField25 = lenientChronology12.hours();
        org.joda.time.DurationField durationField26 = lenientChronology12.days();
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.Period period29 = org.joda.time.Period.months((int) (short) 0);
        int[] intArray30 = period29.getValues();
        try {
            lenientChronology12.validate(readablePartial27, intArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str23.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long7 = offsetDateTimeField5.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.era();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.Period period22 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period24 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period25 = period22.minus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period24.toString(periodFormatter26);
        org.joda.time.Period period36 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period37 = period36.negated();
        int int38 = period36.getHours();
        org.joda.time.DurationFieldType durationFieldType40 = period36.getFieldType(5);
        org.joda.time.Period period42 = period24.withFieldAdded(durationFieldType40, 86409);
        org.joda.time.field.DecoratedDurationField decoratedDurationField43 = new org.joda.time.field.DecoratedDurationField(durationField20, durationFieldType40);
        long long45 = decoratedDurationField43.getMillis(0L);
        org.joda.time.DurationField durationField46 = decoratedDurationField43.getWrappedField();
        long long48 = decoratedDurationField43.getValueAsLong((long) (short) 0);
        long long51 = decoratedDurationField43.getDifferenceAsLong(52000L, 36000032L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, (org.joda.time.DurationField) decoratedDurationField43);
        java.util.Locale locale53 = null;
        try {
            int int54 = unsupportedDateTimeField52.getMaximumTextLength(locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-10L) + "'", long7 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT0S" + "'", str27.equals("PT0S"));
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-35948L) + "'", long51 == (-35948L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusMonths((-1));
        org.joda.time.Period period9 = period7.minusMonths((int) (byte) 100);
        int int10 = period7.getMillis();
        int int11 = period7.size();
        org.joda.time.Period period13 = period7.withMinutes(10);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "P1MT10M0.001S" + "'", str15.equals("P1MT10M0.001S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        int int29 = dividedDateTimeField23.getDifference((-71998L), (long) 10);
        long long32 = dividedDateTimeField23.getDifferenceAsLong((long) (byte) 0, (long) (byte) 10);
        long long35 = dividedDateTimeField23.getDifferenceAsLong(1227241024L, 3155846409990L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-7) + "'", int29 == (-7));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-315461916L) + "'", long35 == (-315461916L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        long long30 = dividedDateTimeField23.getDifferenceAsLong(36000032L, 35000L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        int int32 = remainderDateTimeField31.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial33 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 10);
        long long42 = offsetDateTimeField40.roundHalfEven(35L);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField50, (int) (byte) 10, 0, (int) '#');
        long long56 = offsetDateTimeField50.roundFloor((long) (-1));
        long long58 = offsetDateTimeField50.roundHalfFloor(0L);
        long long61 = offsetDateTimeField50.add(1560626597870L, 3155759999999L);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int[] intArray65 = new int[] { (-1), 36000000 };
        int int66 = offsetDateTimeField50.getMaximumValue(readablePartial62, intArray65);
        int[] intArray68 = offsetDateTimeField40.add(readablePartial43, 360000000, intArray65, (int) (short) 0);
        try {
            int[] intArray70 = remainderDateTimeField31.set(readablePartial33, 100, intArray65, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3596L + "'", long30 == 3596L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-10L) + "'", long42 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-10L) + "'", long56 == (-10L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-10L) + "'", long58 == (-10L));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 3157320626596870L + "'", long61 == 3157320626596870L);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 86409 + "'", int66 == 86409);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weekyears();
        int int6 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology(chronology7);
        boolean boolean9 = gregorianChronology2.equals((java.lang.Object) chronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.hourOfDay();
        int int11 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long7 = offsetDateTimeField5.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.era();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.Period period22 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period24 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period25 = period22.minus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period24.toString(periodFormatter26);
        org.joda.time.Period period36 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        org.joda.time.Period period37 = period36.negated();
        int int38 = period36.getHours();
        org.joda.time.DurationFieldType durationFieldType40 = period36.getFieldType(5);
        org.joda.time.Period period42 = period24.withFieldAdded(durationFieldType40, 86409);
        org.joda.time.field.DecoratedDurationField decoratedDurationField43 = new org.joda.time.field.DecoratedDurationField(durationField20, durationFieldType40);
        long long45 = decoratedDurationField43.getMillis(0L);
        org.joda.time.DurationField durationField46 = decoratedDurationField43.getWrappedField();
        long long48 = decoratedDurationField43.getValueAsLong((long) (short) 0);
        long long51 = decoratedDurationField43.getDifferenceAsLong(52000L, 36000032L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, (org.joda.time.DurationField) decoratedDurationField43);
        java.util.Locale locale53 = null;
        try {
            int int54 = unsupportedDateTimeField52.getMaximumShortTextLength(locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-10L) + "'", long7 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT0S" + "'", str27.equals("PT0S"));
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-35948L) + "'", long51 == (-35948L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long27 = dividedDateTimeField23.add((long) 8, (-100));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-999992L) + "'", long27 == (-999992L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("8", "100.0", 10, 6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long7 = offsetDateTimeField5.roundHalfEven(35L);
        long long9 = offsetDateTimeField5.remainder(32L);
        java.lang.String str11 = offsetDateTimeField5.getAsText(42L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-10L) + "'", long7 == (-10L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 42L + "'", long9 == 42L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology2.centuries();
        long long9 = durationField6.subtract(1560266600990L, 8639);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-27260490587799010L) + "'", long9 == (-27260490587799010L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period(100L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period7 = period5.minusSeconds((int) (short) 10);
        org.joda.time.Period period9 = period5.withMonths((int) (byte) 1);
        java.lang.String str10 = period9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField16, (int) (byte) 10, 0, (int) '#');
        boolean boolean21 = offsetDateTimeField16.isLenient();
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField16.getMinimumValue(readablePartial22);
        long long25 = offsetDateTimeField16.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
        long long34 = offsetDateTimeField32.roundHalfEven(35L);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, 10);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField42, (int) (byte) 10, 0, (int) '#');
        long long48 = offsetDateTimeField42.roundFloor((long) (-1));
        long long50 = offsetDateTimeField42.roundHalfFloor(0L);
        long long53 = offsetDateTimeField42.add(1560626597870L, 3155759999999L);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray57 = new int[] { (-1), 36000000 };
        int int58 = offsetDateTimeField42.getMaximumValue(readablePartial54, intArray57);
        int[] intArray60 = offsetDateTimeField32.add(readablePartial35, 360000000, intArray57, (int) (short) 0);
        int int61 = offsetDateTimeField16.getMaximumValue(readablePartial26, intArray60);
        org.joda.time.DurationField durationField62 = offsetDateTimeField16.getLeapDurationField();
        boolean boolean63 = period9.equals((java.lang.Object) offsetDateTimeField16);
        java.lang.String str64 = offsetDateTimeField16.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P1MT0.100S" + "'", str10.equals("P1MT0.100S"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-10L) + "'", long25 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-10L) + "'", long34 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-10L) + "'", long48 == (-10L));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-10L) + "'", long50 == (-10L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3157320626596870L + "'", long53 == 3157320626596870L);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 86409 + "'", int58 == 86409);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 86409 + "'", int61 == 86409);
        org.junit.Assert.assertNull(durationField62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[secondOfDay]" + "'", str64.equals("DateTimeField[secondOfDay]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("DayTime", "America/Los_Angeles", (-1560266), (-316799725));
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(32000L);
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        long long10 = fixedDateTimeZone4.convertUTCToLocal(3155846408999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1560266) + "'", int6 == (-1560266));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-316799725) + "'", int8 == (-316799725));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155844848733L + "'", long10 == 3155844848733L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.era();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.yearOfEra();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Period period10 = period8.plusHours(2);
        try {
            org.joda.time.Period period12 = period10.minusWeeks(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.year();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (byte) 0, (-100), 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(43210);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.Period period3 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.PeriodType periodType4 = period3.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone9);
        org.joda.time.DurationField durationField11 = zonedChronology10.halfdays();
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology10.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology10.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 3, 32010L, periodType4, (org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        long long23 = dateTimeZone18.getMillisKeepLocal(dateTimeZone20, (long) ' ');
        long long27 = dateTimeZone20.convertLocalToUTC((long) 'a', false, (long) 100);
        long long31 = dateTimeZone20.convertLocalToUTC((long) '#', true, (long) (short) -1);
        long long33 = dateTimeZone20.convertUTCToLocal((-210858120000000L));
        long long37 = dateTimeZone20.convertLocalToUTC((-11L), true, 1560626600720L);
        org.joda.time.Chronology chronology38 = zonedChronology10.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.Chronology chronology40 = zonedChronology10.withZone(dateTimeZone39);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-3599978L) + "'", long23 == (-3599978L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 87L + "'", long27 == 87L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 25L + "'", long31 == 25L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-210858119999990L) + "'", long33 == (-210858119999990L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-21L) + "'", long37 == (-21L));
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long7 = offsetDateTimeField5.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField5.getType();
        boolean boolean9 = offsetDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-10L) + "'", long7 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology13 = lenientChronology12.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 100);
        org.joda.time.Period period3 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period5 = period3.withMonths((int) (byte) 1);
        org.joda.time.Period period7 = org.joda.time.Period.hours(0);
        org.joda.time.Period period8 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period11 = period7.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period11.plusHours((int) (short) 100);
        org.joda.time.Period period15 = period13.plusMillis(36000000);
        org.joda.time.Period period16 = period1.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period16.minusWeeks((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "America/Los_Angeles", 100, (int) (byte) 0);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        int int13 = offsetDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField12.getAsText(readablePartial14, (int) ' ', locale16);
        int int19 = offsetDateTimeField12.getLeapAmount((long) '4');
        java.lang.String str21 = offsetDateTimeField12.getAsShortText(52L);
        int int24 = offsetDateTimeField12.getDifference(35L, 0L);
        boolean boolean25 = fixedDateTimeZone4.equals((java.lang.Object) offsetDateTimeField12);
        long long27 = fixedDateTimeZone4.previousTransition((-1054333843200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32" + "'", str17.equals("32"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1054333843200000L) + "'", long27 == (-1054333843200000L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long5 = iSOChronology0.getDateTimeMillis((int) (short) -1, (int) (short) 10, (int) (byte) 10, 4);
        org.joda.time.Chronology chronology6 = iSOChronology0.withUTC();
        org.joda.time.Period period8 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period10 = period8.withMonths((int) (byte) 1);
        org.joda.time.Period period12 = org.joda.time.Period.hours(0);
        org.joda.time.Period period13 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period16 = period12.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period16.plusHours((int) (short) 100);
        org.joda.time.Period period20 = period18.plusMillis(36000000);
        int[] intArray22 = iSOChronology0.get((org.joda.time.ReadablePeriod) period18, 0L);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62174426399996L) + "'", long5 == (-62174426399996L));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        java.lang.String str34 = unsupportedDateTimeField33.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDateTimeField" + "'", str34.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.centuries();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Period period8 = period6.minusMonths((-1));
        org.joda.time.Period period10 = period8.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationTo(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType17 = periodType16.withMinutesRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration12, periodType17);
        org.joda.time.PeriodType periodType19 = periodType17.withDaysRemoved();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period3 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period4 = period1.minus((org.joda.time.ReadablePeriod) period3);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period1.toString(periodFormatter5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField32);
        try {
            long long36 = unsupportedDateTimeField33.set(52L, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
        int int10 = offsetDateTimeField9.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField9.getAsText(readablePartial11, (int) ' ', locale13);
        java.lang.String str16 = offsetDateTimeField9.getAsText((long) (short) 1);
        boolean boolean17 = periodType2.equals((java.lang.Object) (short) 1);
        org.joda.time.PeriodType periodType18 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32" + "'", str14.equals("32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int6 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField5.getAsText(readablePartial7, (int) ' ', locale9);
        int int12 = offsetDateTimeField5.getLeapAmount((long) '4');
        java.lang.String str14 = offsetDateTimeField5.getAsShortText(52L);
        int int17 = offsetDateTimeField5.getDifference(35L, 0L);
        int int19 = offsetDateTimeField5.getMinimumValue(52L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField5.getAsText((-10), locale21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(1, 'a', (int) (byte) 10, 0, (int) 'a', false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("UTC", 100);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.yearOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period21 = new org.joda.time.Period((int) '4', (int) (short) -1, 10, (int) (short) -1, 0, (int) (byte) -1, 0, (-1));
        boolean boolean22 = lenientChronology12.equals((java.lang.Object) (short) -1);
        java.lang.String str23 = lenientChronology12.toString();
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (short) 0);
        org.joda.time.Period period27 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Period period28 = period25.minus((org.joda.time.ReadablePeriod) period27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Duration duration30 = period28.toDurationTo(readableInstant29);
        org.joda.time.Period period31 = period28.normalizedStandard();
        boolean boolean32 = lenientChronology12.equals((java.lang.Object) period28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[+00:00:00.010]]" + "'", str23.equals("LenientChronology[GregorianChronology[+00:00:00.010]]"));
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(duration30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("DayTime", "America/Los_Angeles", (-1560266), (-316799725));
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(32000L);
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period12.multipliedBy((int) (byte) 1);
        org.joda.time.Period period16 = period14.minusDays(0);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1560266) + "'", int6 == (-1560266));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-316799725) + "'", int8 == (-316799725));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-316799725));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long26 = remainderDateTimeField24.roundCeiling(35999990L);
        long long28 = remainderDateTimeField24.roundHalfCeiling((long) 359991);
        long long30 = remainderDateTimeField24.roundHalfFloor((long) (-1560266));
        long long32 = remainderDateTimeField24.roundCeiling((-316799724998L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35999990L + "'", long26 == 35999990L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 359990L + "'", long28 == 359990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1560010L) + "'", long30 == (-1560010L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-316799724010L) + "'", long32 == (-316799724010L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.Period period1 = org.joda.time.Period.years(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(43186);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long13 = offsetDateTimeField11.roundHalfEven(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0d, "PT0S");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (-62174426399996L), (java.lang.Number) (-1054333800000000L), (java.lang.Number) (-1));
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 10);
        long long26 = dividedDateTimeField23.addWrapField((long) 1, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = dividedDateTimeField23.getType();
        long long30 = dividedDateTimeField23.getDifferenceAsLong(36000032L, 35000L);
        int int31 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField32.getType();
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale36 = null;
        java.lang.String str37 = remainderDateTimeField32.getAsText(readablePartial34, (-35999), locale36);
        int int38 = remainderDateTimeField32.getDivisor();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3596L + "'", long30 == 3596L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8639 + "'", int31 == 8639);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-35999" + "'", str37.equals("-35999"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
    }
}

