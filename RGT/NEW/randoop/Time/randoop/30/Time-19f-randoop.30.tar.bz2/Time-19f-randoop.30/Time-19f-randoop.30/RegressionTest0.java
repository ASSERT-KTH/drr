import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, 0, (int) (byte) -1, (int) (byte) -1, (int) (byte) -1, (-1), (int) '4', chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.field.FieldUtils.verifyValueBounds("", 52, (int) (short) -1, 100);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) 10, 52, 10, (int) ' ', 2019, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getYearOfEra();
        org.joda.time.DateTime dateTime10 = dateTime7.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) (byte) 0, 55285468, (int) '#', 2019, 1, 55284984, 0, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
//        org.joda.time.DurationFieldType durationFieldType4 = null;
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime3.withFieldAdded(durationFieldType4, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 55285914 + "'", int1 == 55285914);
//        org.junit.Assert.assertNotNull(dateTime3);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(0, 55285468, (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55285468 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfYear();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis((int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime3.withField(dateTimeFieldType4, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 166 + "'", int1 == 166);
//        org.junit.Assert.assertNotNull(dateTime3);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(35, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(166, (int) (short) 10, 166, (int) (byte) 0, 52, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getYearOfEra();
        org.joda.time.DateTime dateTime10 = dateTime7.plusDays(52);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (byte) -1, (int) ' ', 0, 0, 55285468, (int) (short) 1, (int) (byte) 10, chronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55285468 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = iSOChronology3.get(readablePeriod4, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 55287035 + "'", int3 == 55287035);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        long long5 = durationField2.subtract((long) 55284984, (int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 58884984L + "'", long5 == 58884984L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) 52);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
        org.joda.time.DurationField durationField7 = iSOChronology5.seconds();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(55287837, 366, 166, (int) (byte) 1, (int) 'a', (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.hours();
        org.joda.time.DurationField durationField5 = iSOChronology3.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        int int6 = dateTime5.getYearOfEra();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0, (int) (byte) 0, 35, (-1), 55286536, 0, 55288370, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 55288370, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((-1L), locale2);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 55288711);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 55288711");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.plus(readablePeriod3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        int[] intArray12 = new int[] { '#', '4', 52, '#', 55289029, 100 };
//        try {
//            iSOChronology0.validate((org.joda.time.ReadablePartial) localDate5, intArray12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55289291 + "'", int2 == 55289291);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(2019, 55285468, (int) (short) -1, (int) ' ', (int) (byte) 10, 55289170, (int) (byte) 10, (org.joda.time.Chronology) iSOChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53L) + "'", long2 == (-53L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withWeekOfWeekyear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(55287943, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(366);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '4', 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(55288711, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55288743 + "'", int2 == 55288743);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(55288370, (int) 'a', (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        int int2 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "America/Los_Angeles", 0);
        boolean boolean12 = mutableDateTime7.isAfter((long) 55285468);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(1);
        boolean boolean5 = dateTimeFormatter2.isParser();
        java.io.Writer writer6 = null;
        try {
            dateTimeFormatter2.printTo(writer6, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 100);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePeriod3, (long) 55288370, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime5 = dateTime0.withCenturyOfEra((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime8 = property5.withMaximumValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate7);
//        try {
//            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadablePartial) localDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55291805 + "'", int4 == 55291805);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        try {
            long long9 = iSOChronology0.getDateTimeMillis(58884984L, 55286536, 0, 25, 55288743);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55286536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 55291445);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        int int3 = dateTimeFormatter0.getDefaultYear();
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getYearOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
//        int int6 = dateTime3.getMinuteOfDay();
//        java.lang.Class<?> wildcardClass7 = dateTime3.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 921 + "'", int6 == 921);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        java.io.Writer writer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusWeeks((int) (byte) -1);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
//        int int12 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "America/Los_Angeles", 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter2.withDefaultYear(55287619);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.LocalDate localDate19 = dateTime18.toLocalDate();
//        java.lang.String str20 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) localDate19);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 55292694 + "'", int16 == 55292694);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019-W24-6" + "'", str20.equals("2019-W24-6"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(55287837, (-1), 25, 55291445, 55288370, 86399999, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55291445 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long5 = iSOChronology0.getDateTimeMillis(55288711, (int) '4', 55287837, 55287619);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(55284984, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime3.minuteOfDay();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        int int2 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withDefaultYear(55287619);
        boolean boolean13 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfHalfday(55287837);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder11.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.append(dateTimePrinter12);
        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.append(dateTimePrinter12, dateTimeParser14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        int int3 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.plusDays(52);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime3.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.hourOfDay();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 100, 55287619, (int) '4', 0, 0, 55294075, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55294075 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
//        org.joda.time.DateTime.Property property7 = dateTime6.era();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfSecond(55291874);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55291874 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 55294613 + "'", int1 == 55294613);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getYearOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusDays(25);
//        org.joda.time.DateTime.Property property14 = dateTime13.era();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        try {
//            int int16 = property6.compareTo((org.joda.time.ReadablePartial) localDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 55294639 + "'", int8 == 55294639);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate15);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("America/Los_Angeles", 2019, 55288743, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for America/Los_Angeles must be in the range [55288743,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        org.joda.time.DurationField durationField8 = property5.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long6 = iSOChronology0.getDateTimeMillis(10L, (int) '4', 2019, (-55285890), 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
//        boolean boolean3 = dateTime0.isEqualNow();
//        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
//        int int6 = dateTime0.getMillisOfSecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58 + "'", int6 == 58);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfYear();
//        java.lang.String str2 = dateTime0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 166 + "'", int1 == 166);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T15:21:35.165-07:00" + "'", str2.equals("2019-06-15T15:21:35.165-07:00"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        int int2 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withDefaultYear(55287619);
        java.lang.StringBuffer stringBuffer13 = null;
        try {
            dateTimeFormatter12.printTo(stringBuffer13, (long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 55291445, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DurationField durationField3 = iSOChronology1.days();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(58884984L, chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Property[dayOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZone(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
        boolean boolean13 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withEra(921);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 921 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusDays(25);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.minus(readablePeriod9);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 55295514 + "'", int3 == 55295514);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        org.joda.time.Instant instant9 = dateTime6.toInstant();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (byte) 10);
//        int int9 = dateTime8.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 55295984 + "'", int1 == 55295984);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getYearOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.plus(readablePeriod6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        int int11 = dateTime10.getYearOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusWeeks((int) (byte) -1);
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime(dateTimeZone15);
//        int int19 = dateTimeFormatter9.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime16, "America/Los_Angeles", 0);
//        int int22 = dateTimeFormatter8.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime16, "", 55285889);
//        boolean boolean23 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime16);
//        int int24 = mutableDateTime16.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-55285890) + "'", int22 == (-55285890));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
//        int int14 = property13.getMaximumValueOverall();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
//        boolean boolean18 = property13.equals((java.lang.Object) dateTimeFormatter17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        int int20 = dateTime19.getYearOfEra();
//        org.joda.time.DateTime dateTime22 = dateTime19.plusHours((int) (short) 100);
//        int int23 = property13.getDifference((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        int int25 = dateTime24.getYearOfEra();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusWeeks((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime24.withDurationAdded(readableDuration28, 166);
//        org.joda.time.DateTime.Property property31 = dateTime30.era();
//        org.joda.time.DateTime dateTime32 = property31.roundCeilingCopy();
//        try {
//            int int33 = property13.compareTo((org.joda.time.ReadableInstant) dateTime32);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 55296626 + "'", int8 == 55296626);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-3) + "'", int23 == (-3));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (short) 100, 55287943, 218);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for year must be in the range [55287943,218]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(55292509, 218, 0, 10, 55293568, 25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55293568 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 55287943, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
//        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 55296873 + "'", int8 == 55296873);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNull(durationField14);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            long long2 = dateTimeFormatter0.parseMillis("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(55289170, (int) '4', 166, 2, (int) (byte) 10, 55291874, 55284984);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55291874 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[dayOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[dayOfYear]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2000, 55294660);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(921, (-3), (int) (short) 10, (-28800000), 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.centuryOfEra();
        try {
            long long9 = iSOChronology0.getDateTimeMillis(52, 55284984, (int) '4', 2000, 55284984, (int) (byte) 100, 218);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(55291445);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(55287943, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 86399999);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, 55285889, 366, 55287619);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.getMaximumValueOverall();
        java.util.Locale locale8 = null;
        int int9 = property5.getMaximumTextLength(locale8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withYearOfEra(55284984);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        try {
            java.lang.String str11 = dateTime8.toString("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        long long5 = durationField2.subtract((long) 55294075, 55285468);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8607L + "'", long5 == 8607L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology14 = iSOChronology13.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withChronology(chronology14);
        boolean boolean16 = gregorianChronology7.equals((java.lang.Object) chronology14);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-55285890), (int) (short) -1, (int) (short) 10, 55287837, 921, 3, 55294075, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55287837 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        boolean boolean4 = dateTime2.isEqual((long) (short) 100);
        boolean boolean5 = dateTime2.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        java.lang.String str8 = property7.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType9, 0, 0, 55296976);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-53L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57599999 + "'", int1 == 57599999);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        java.util.Date date4 = dateTime3.toDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 55291445);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(55294660, 166, 0, 166, 55287861);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-15T15:21:35.165-07:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-15T15:21:35.165-07:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 55287861, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55287861L + "'", long2 == 55287861L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 55289029);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55289029 + "'", int2 == 55289029);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 55290702);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(58787984L, 28800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 87587984L + "'", long2 == 87587984L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        int int2 = dateTime0.getMillisOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime0.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57599999 + "'", int2 == 57599999);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property5.setCopy("Coordinated Universal Time", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(durationFieldType4);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((-1L), locale2);
//        boolean boolean5 = dateTimeZone0.isStandardOffset(1L);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName((long) 55285889, locale7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendFractionOfHour((-55285890), 55294389);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendLiteral('#');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
        org.joda.time.DurationField durationField20 = iSOChronology18.days();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        boolean boolean24 = dateTime22.isEqual((long) (short) 100);
        boolean boolean25 = dateTime22.isEqualNow();
        org.joda.time.DateTime dateTime26 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property27 = dateTime22.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType29, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        int int36 = dateTime35.getYearOfEra();
        org.joda.time.DateTime dateTime38 = dateTime35.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTime(dateTimeZone40);
        int int44 = dateTimeFormatter34.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime41, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter34.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime();
        int int48 = dateTime47.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime50 = dateTime47.plus(readablePeriod49);
        org.joda.time.LocalDate localDate51 = dateTime50.toLocalDate();
        java.lang.String str52 = dateTimeFormatter46.print((org.joda.time.ReadablePartial) localDate51);
        int[] intArray53 = null;
        int int54 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray53);
        int[] intArray59 = new int[] { 292278993, 55285468, (short) 0 };
        try {
            int[] intArray61 = offsetDateTimeField15.set((org.joda.time.ReadablePartial) localDate51, 55290702, intArray59, 55289170);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55289170 for weekyear must be in the range [10,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1970 + "'", int36 == 1970);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 57599999 + "'", int48 == 57599999);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1970-W01-4" + "'", str52.equals("1970-W01-4"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        int int38 = dateTime37.getYearOfEra();
        org.joda.time.DateTime dateTime40 = dateTime37.minusWeeks((int) (byte) -1);
        org.joda.time.TimeOfDay timeOfDay41 = dateTime37.toTimeOfDay();
        int[] intArray48 = new int[] { 55289029, (short) 0, 55291445, 55288743, 6 };
        try {
            int[] intArray50 = offsetDateTimeField15.addWrapField((org.joda.time.ReadablePartial) timeOfDay41, 292278993, intArray48, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 292278993");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57599999 + "'", int30 == 57599999);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-4" + "'", str34.equals("1970-W01-4"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1970 + "'", int38 == 1970);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(timeOfDay41);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendFractionOfMinute(0, 55289170);
        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendHourOfDay(55288743);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 58, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime dateTime10 = dateTime0.withYearOfEra(2019);
        org.joda.time.DateTime dateTime12 = dateTime0.minusSeconds(166);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readableDuration13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfYear]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfYear]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 55284984, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        int int6 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime5.withTimeAtStartOfDay();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.lang.String str5 = dateTimeZone4.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology(chronology7);
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) chronology7);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay(55291874);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.hours();
        org.joda.time.DurationField durationField8 = iSOChronology6.days();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        boolean boolean12 = dateTime10.isEqual((long) (short) 100);
        boolean boolean13 = dateTime10.isEqualNow();
        org.joda.time.DateTime dateTime14 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property15 = dateTime10.weekyear();
        java.lang.String str16 = property15.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType17, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsText((long) 55291874, locale23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField21.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType25, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "20" + "'", str24.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readablePeriod7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute(55287619);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55287619 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57599999 + "'", int1 == 57599999);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        org.joda.time.DateTime dateTime8 = property5.roundHalfEvenCopy();
        java.lang.Object obj9 = null;
        boolean boolean10 = property5.equals(obj9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime();
        boolean boolean7 = dateTime5.isAfter((long) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime0.year();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 100, 0, 2000, 55287837, 59, 55287837, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55287837 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(55288711, 55291874);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 55291874");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        int int9 = dateTime6.getHourOfDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withEra(20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property5.roundHalfEvenCopy();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int int11 = property5.compareTo(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "53" + "'", str8.equals("53"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        long long5 = durationField2.subtract(58884984L, (long) 'a');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 58787984L + "'", long5 == 58787984L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.withDayOfYear((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57599999 + "'", int1 == 57599999);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print(55293568L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(0);
        boolean boolean9 = dateTime0.equals((java.lang.Object) dateTimeFormatterBuilder8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimeFormatter10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime0.plusMillis(1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(55289678);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        try {
            long long14 = zonedChronology6.getDateTimeMillis((int) '4', 55291445, (int) (byte) 100, 55286536, (-3), 53, (-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55286536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(55294389);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (-53L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        java.lang.String str6 = property5.getAsString();
        int int7 = property5.get();
        java.lang.String str8 = property5.getName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "weekyear" + "'", str8.equals("weekyear"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970-W01-4", 55290702, (int) (byte) 10, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55290702 for 1970-W01-4 must be in the range [10,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(55294075);
        java.lang.String str7 = dateTime3.toString("1970");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.lang.String str5 = dateTimeZone4.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology(chronology7);
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) chronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"-W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(55288743, 35, (int) (byte) 100, 55295984, (-3), chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55295984 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) -1, 57599999, 58, 0, 55290263, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55290263 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.millisOfDay();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        boolean boolean13 = dateTime11.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.plus(readablePeriod14);
        org.joda.time.DateTime dateTime17 = dateTime11.withDayOfMonth(10);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.DateTime dateTime23 = dateTime11.withFields((org.joda.time.ReadablePartial) localDate22);
        long long25 = iSOChronology7.set((org.joda.time.ReadablePartial) localDate22, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology7.secondOfDay();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) iSOChronology7);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(55296749, 10, 55285468, (int) '#', 55289678, 921, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57600000 + "'", int19 == 57600000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31112163L) + "'", long25 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        int int4 = dateTime0.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        try {
            long long20 = offsetDateTimeField15.addWrapField((long) 55296749, 55289170);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.millisOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime5.withDayOfMonth(10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        org.joda.time.DateTime dateTime17 = dateTime5.withFields((org.joda.time.ReadablePartial) localDate16);
        long long19 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate16, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology1.secondOfDay();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600000 + "'", int13 == 57600000);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31112163L) + "'", long19 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.lang.String str5 = dateTimeZone4.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology(chronology7);
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) chronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField11 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField12 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 604800000L + "'", long7 == 604800000L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        int int19 = dateTime18.getYearOfEra();
        org.joda.time.DateTime dateTime21 = dateTime18.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.withZone(dateTimeZone22);
        org.joda.time.LocalTime localTime24 = dateTime21.toLocalTime();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localTime24, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        long long38 = offsetDateTimeField15.roundHalfCeiling((-53L));
        long long40 = offsetDateTimeField15.roundHalfFloor((long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600000 + "'", int30 == 57600000);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 946713600000L + "'", long38 == 946713600000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 946713600000L + "'", long40 == 946713600000L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        try {
            boolean boolean34 = unsupportedDateTimeField32.isLeap((long) 55296976);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        java.util.Date date5 = dateTime3.toDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readablePeriod3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(25);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.LocalDate localDate9 = dateTime7.toLocalDate();
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate9);
        java.lang.StringBuffer stringBuffer11 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer11, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.DateTime dateTime9 = property5.addToCopy((long) 55291874);
        org.joda.time.DurationField durationField10 = property5.getDurationField();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime9 = dateTime0.withDurationAdded(10L, (int) (byte) 1);
        org.joda.time.DateTime.Property property10 = dateTime0.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime12 = property10.setCopy(55288743);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55288743 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DurationField durationField18 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        boolean boolean23 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime24 = dateTime20.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property25 = dateTime20.weekyear();
        java.lang.String str26 = property25.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType27, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType11, dateTimeFieldType27 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList33 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, dateTimeFieldTypeArray32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, true);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (short) -1, (int) (byte) 100, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for  must be in the range [100,-28800000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.lang.String str17 = offsetDateTimeField15.getAsShortText((long) 55296976);
        java.util.Locale locale20 = null;
        try {
            long long21 = offsetDateTimeField15.set((long) 55290263, "1970-W01-3", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W01-3\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.millisOfDay();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.plus(readablePeriod23);
        org.joda.time.DateTime dateTime26 = dateTime20.withDayOfMonth(10);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        int int28 = dateTime27.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
        org.joda.time.LocalDate localDate31 = dateTime30.toLocalDate();
        org.joda.time.DateTime dateTime32 = dateTime20.withFields((org.joda.time.ReadablePartial) localDate31);
        long long34 = iSOChronology16.set((org.joda.time.ReadablePartial) localDate31, (long) 55287837);
        int[] intArray36 = null;
        try {
            int[] intArray38 = offsetDateTimeField15.addWrapPartial((org.joda.time.ReadablePartial) localDate31, 0, intArray36, 55286536);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 57600000 + "'", int28 == 57600000);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31112163L) + "'", long34 == (-31112163L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 55294881, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55294881L + "'", long2 == 55294881L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        org.joda.time.DateTime dateTime8 = property5.roundHalfEvenCopy();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField10 = iSOChronology9.hours();
        org.joda.time.DurationField durationField11 = iSOChronology9.days();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.year();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        boolean boolean15 = dateTime13.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime13.withDayOfMonth(10);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        int int21 = dateTime20.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime25 = dateTime13.withFields((org.joda.time.ReadablePartial) localDate24);
        long long27 = iSOChronology9.set((org.joda.time.ReadablePartial) localDate24, (long) 55293568);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime8.toMutableDateTime((org.joda.time.Chronology) iSOChronology9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600000 + "'", int21 == 57600000);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31106432L) + "'", long27 == (-31106432L));
        org.junit.Assert.assertNotNull(mutableDateTime28);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        boolean boolean35 = dateTime33.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.plus(readablePeriod36);
        org.joda.time.DateTime dateTime39 = dateTime33.withDayOfMonth(10);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
        int int41 = dateTime40.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime40.plus(readablePeriod42);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        org.joda.time.DateTime dateTime45 = dateTime33.withFields((org.joda.time.ReadablePartial) localDate44);
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate44, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 57600000 + "'", int41 == 57600000);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withHourOfDay(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField34 = iSOChronology33.hours();
        org.joda.time.DurationField durationField35 = iSOChronology33.days();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        boolean boolean39 = dateTime37.isEqual((long) (short) 100);
        boolean boolean40 = dateTime37.isEqualNow();
        org.joda.time.DateTime dateTime41 = dateTime37.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime37.weekyear();
        java.lang.String str43 = property42.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType44, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime();
        int int51 = dateTime50.getYearOfEra();
        org.joda.time.DateTime dateTime53 = dateTime50.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forTimeZone(timeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = dateTime53.toMutableDateTime(dateTimeZone55);
        int int59 = dateTimeFormatter49.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime56, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter49.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime();
        int int63 = dateTime62.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.plus(readablePeriod64);
        org.joda.time.LocalDate localDate66 = dateTime65.toLocalDate();
        java.lang.String str67 = dateTimeFormatter61.print((org.joda.time.ReadablePartial) localDate66);
        int[] intArray68 = null;
        int int69 = offsetDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) localDate66, intArray68);
        int[] intArray71 = new int[] { 292278993 };
        try {
            int int72 = unsupportedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate66, intArray71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970" + "'", str43.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1969 + "'", int51 == 1969);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 57600000 + "'", int63 == 57600000);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1970-W01-3" + "'", str67.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
        org.junit.Assert.assertNotNull(intArray71);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        long long38 = offsetDateTimeField15.roundHalfCeiling((-53L));
        java.util.Locale locale39 = null;
        int int40 = offsetDateTimeField15.getMaximumShortTextLength(locale39);
        try {
            long long43 = offsetDateTimeField15.add((long) (-292275054), (long) 55294075);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 5529407500");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600000 + "'", int30 == 57600000);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 946713600000L + "'", long38 == 946713600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        try {
            int int34 = unsupportedDateTimeField32.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField34 = iSOChronology33.hours();
        org.joda.time.DurationField durationField35 = iSOChronology33.days();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        boolean boolean39 = dateTime37.isEqual((long) (short) 100);
        boolean boolean40 = dateTime37.isEqualNow();
        org.joda.time.DateTime dateTime41 = dateTime37.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime37.weekyear();
        java.lang.String str43 = property42.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType44, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime();
        int int51 = dateTime50.getYearOfEra();
        org.joda.time.DateTime dateTime53 = dateTime50.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forTimeZone(timeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = dateTime53.toMutableDateTime(dateTimeZone55);
        int int59 = dateTimeFormatter49.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime56, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter49.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime();
        int int63 = dateTime62.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.plus(readablePeriod64);
        org.joda.time.LocalDate localDate66 = dateTime65.toLocalDate();
        java.lang.String str67 = dateTimeFormatter61.print((org.joda.time.ReadablePartial) localDate66);
        int[] intArray68 = null;
        int int69 = offsetDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) localDate66, intArray68);
        try {
            int int70 = unsupportedDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) localDate66);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970" + "'", str43.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1969 + "'", int51 == 1969);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 57600000 + "'", int63 == 57600000);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1970-W01-3" + "'", str67.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.util.Locale locale34 = null;
        try {
            int int35 = unsupportedDateTimeField32.getMaximumTextLength(locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        try {
            long long34 = unsupportedDateTimeField32.roundFloor((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime9 = dateTime3.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime11 = dateTime3.withDayOfWeek(55288743);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55288743 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        int int6 = dateTime3.getYear();
        org.joda.time.LocalDateTime localDateTime7 = dateTime3.toLocalDateTime();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.util.Locale locale34 = null;
        try {
            int int35 = unsupportedDateTimeField32.getMaximumShortTextLength(locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.lang.String str5 = dateTimeZone4.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology(chronology7);
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) chronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField11 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField12 = gregorianChronology0.weekyears();
        java.lang.String str13 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str13.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 10, 0, 55296976, 2019, 33, (-28800000), dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime0.withFieldAdded(durationFieldType4, 55286536);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime();
        int int6 = dateTime5.getMinuteOfHour();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        int int34 = dateTime33.getYearOfEra();
        org.joda.time.DateTime dateTime36 = dateTime33.minusWeeks((int) (byte) -1);
        org.joda.time.TimeOfDay timeOfDay37 = dateTime33.toTimeOfDay();
        int[] intArray44 = new int[] { (-292275054), 55288711, (short) 1, (byte) 0, 55288711 };
        try {
            int[] intArray46 = unsupportedDateTimeField32.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay37, 55294660, intArray44, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(timeOfDay37);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Coordinated Universal Time", 55289499, 0, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55289499 for Coordinated Universal Time must be in the range [0,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.DateTime dateTime5 = dateTime0.withMillisOfSecond(33);
        int int6 = dateTime5.getEra();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTime();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        try {
            long long22 = offsetDateTimeField15.set(0L, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for weekyear must be in the range [10,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.centuryOfEra();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        int int6 = dateTime5.getSecondOfMinute();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600000 + "'", int30 == 57600000);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        boolean boolean2 = dateTimeFormatter1.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withDefaultYear(55293568);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        int int18 = offsetDateTimeField15.getOffset();
        int int19 = offsetDateTimeField15.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        int int12 = property9.getMaximumValueOverall();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime4.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.withDurationAdded(0L, 292278993);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        long long35 = unsupportedDateTimeField32.getDifferenceAsLong(946713600000L, (long) 0);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
        boolean boolean38 = dateTime36.isEqual((long) (short) 100);
        boolean boolean39 = dateTime36.isEqualNow();
        org.joda.time.Instant instant40 = dateTime36.toInstant();
        org.joda.time.TimeOfDay timeOfDay41 = dateTime36.toTimeOfDay();
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = unsupportedDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) timeOfDay41, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 30L + "'", long35 == 30L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(instant40);
        org.junit.Assert.assertNotNull(timeOfDay41);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        try {
            long long6 = iSOChronology0.getDateTimeMillis(55285889, (-55285890), 15, 55290702);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55285890 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        long long39 = zeroIsMaxDateTimeField36.add((long) 2, (long) 55296976);
        long long42 = zeroIsMaxDateTimeField36.set((long) '4', (int) (short) 10);
        long long44 = zeroIsMaxDateTimeField36.roundHalfCeiling((long) 10);
        try {
            long long47 = zeroIsMaxDateTimeField36.set((long) 53, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyear must be in the range [1,86400]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600000 + "'", int12 == 57600000);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55296976002L + "'", long39 == 55296976002L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-57589948L) + "'", long42 == (-57589948L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("T16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T16:00:00-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.plusDays(52);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime8.monthOfYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4492800000L + "'", long11 == 4492800000L);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1970", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is malformed at \"70\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTime.Property property13 = dateTime0.yearOfEra();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600000 + "'", int8 == 57600000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumTextLength(locale16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime.Property property10 = dateTime8.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime14 = dateTime8.withZoneRetainFields(dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime16 = dateTime8.withHourOfDay(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendYearOfEra(55287943, 10);
        boolean boolean12 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear(55288743);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55288743 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (short) 1, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        try {
            int int35 = unsupportedDateTimeField32.getMaximumValue((long) 55287861);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        boolean boolean4 = dateTime2.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readablePeriod5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getYearOfEra();
        org.joda.time.DateTime dateTime10 = dateTime7.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withZone(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.plus(readablePeriod13);
        boolean boolean15 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean16 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime18 = dateTime0.plusHours(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str5 = dateTimeZone1.getName(0L);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(0);
        boolean boolean9 = dateTime0.equals((java.lang.Object) dateTimeFormatterBuilder8);
        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimeParser10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("weekyear", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.lang.String str17 = offsetDateTimeField15.getAsShortText((long) 55296976);
        int int19 = offsetDateTimeField15.getMaximumValue(0L);
        java.lang.String str21 = offsetDateTimeField15.getAsText(58787984L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20" + "'", str21.equals("20"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.DateTime dateTime8 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(55289678);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        long long39 = zeroIsMaxDateTimeField36.add((long) 2, (long) 55296976);
        java.util.Locale locale40 = null;
        int int41 = zeroIsMaxDateTimeField36.getMaximumTextLength(locale40);
        try {
            long long44 = zeroIsMaxDateTimeField36.set((long) 57599999, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for weekyear must be in the range [1,86400]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600000 + "'", int12 == 57600000);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55296976002L + "'", long39 == 55296976002L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 55295984);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        try {
            long long35 = unsupportedDateTimeField32.set((long) 55287861, "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "GregorianChronology[America/Los_Angeles]");
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        java.lang.Number number23 = illegalFieldValueException22.getLowerBound();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 55288743, (java.lang.Number) (short) 0, (java.lang.Number) 55284984);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.DateTime dateTime5 = dateTime0.withMillisOfSecond(33);
        boolean boolean6 = dateTime5.isAfterNow();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        int int6 = dateTime0.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 100);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        java.lang.String str7 = zonedChronology6.toString();
        try {
            long long13 = zonedChronology6.getDateTimeMillis((long) 86399999, (int) (short) 0, (int) '4', 55284984, 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55284984 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        boolean boolean8 = dateTime6.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfMonth(10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        org.joda.time.DateTime dateTime18 = dateTime6.withFields((org.joda.time.ReadablePartial) localDate17);
        long long20 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate17, (long) 55287837);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57600000 + "'", int14 == 57600000);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31112163L) + "'", long20 == (-31112163L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(921);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", "20");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        int int2 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withDefaultYear(55287619);
        try {
            org.joda.time.LocalTime localTime14 = dateTimeFormatter0.parseLocalTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendLiteral('#');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTimeZoneOffset("86400", true, 55287837, 55287619);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfHalfday(55287837);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendHourOfDay(55287619);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        int int3 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks((int) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) 33);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        long long39 = zeroIsMaxDateTimeField36.add((long) 2, (long) 55296976);
        org.joda.time.DurationField durationField40 = zeroIsMaxDateTimeField36.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600000 + "'", int12 == 57600000);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55296976002L + "'", long39 == 55296976002L);
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        boolean boolean8 = dateTime6.isEqual((long) (short) 100);
        boolean boolean9 = dateTime6.isEqualNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property11 = dateTime6.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology18.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField22 = iSOChronology21.hours();
        org.joda.time.DurationField durationField23 = iSOChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.centuryOfEra();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        boolean boolean27 = dateTime25.isEqual((long) (short) 100);
        boolean boolean28 = dateTime25.isEqualNow();
        org.joda.time.DateTime dateTime29 = dateTime25.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property30 = dateTime25.weekyear();
        java.lang.String str31 = property30.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType32, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
        int int39 = dateTime38.getYearOfEra();
        org.joda.time.DateTime dateTime41 = dateTime38.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forTimeZone(timeZone42);
        org.joda.time.MutableDateTime mutableDateTime44 = dateTime41.toMutableDateTime(dateTimeZone43);
        int int47 = dateTimeFormatter37.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime44, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter37.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime();
        int int51 = dateTime50.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.plus(readablePeriod52);
        org.joda.time.LocalDate localDate54 = dateTime53.toLocalDate();
        java.lang.String str55 = dateTimeFormatter49.print((org.joda.time.ReadablePartial) localDate54);
        int[] intArray56 = null;
        int int57 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) localDate54, intArray56);
        long long59 = offsetDateTimeField36.roundHalfCeiling((-53L));
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime();
        int int61 = dateTime60.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime63 = dateTime60.plus(readablePeriod62);
        org.joda.time.LocalDate localDate64 = dateTime63.toLocalDate();
        org.joda.time.DateTime dateTime66 = dateTime63.minusDays(25);
        org.joda.time.DateTime.Property property67 = dateTime66.era();
        org.joda.time.LocalDate localDate68 = dateTime66.toLocalDate();
        int[] intArray73 = new int[] { 55291445, 1970, (-28800000), 3 };
        int int74 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) localDate68, intArray73);
        long long76 = gregorianChronology18.set((org.joda.time.ReadablePartial) localDate68, 0L);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField17.getAsText((org.joda.time.ReadablePartial) localDate68, locale77);
        int[] intArray80 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate68, (long) 921);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 57600000 + "'", int51 == 57600000);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1970-W01-3" + "'", str55.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 946713600000L + "'", long59 == 946713600000L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 57600000 + "'", int61 == 57600000);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-2160000000L) + "'", long76 == (-2160000000L));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "1969" + "'", str78.equals("1969"));
        org.junit.Assert.assertNotNull(intArray80);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra(0);
        int int8 = dateTime3.getEra();
        boolean boolean10 = dateTime3.isEqual(2930303389L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("218");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"218\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        int int4 = dateTime0.getHourOfDay();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder12.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.millisOfDay();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        boolean boolean17 = dateTime15.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.plus(readablePeriod18);
        org.joda.time.DateTime dateTime21 = dateTime15.withDayOfMonth(10);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime15.withFields((org.joda.time.ReadablePartial) localDate26);
        long long29 = iSOChronology11.set((org.joda.time.ReadablePartial) localDate26, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology11.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField32 = iSOChronology31.hours();
        org.joda.time.DurationField durationField33 = iSOChronology31.days();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.centuryOfEra();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        boolean boolean37 = dateTime35.isEqual((long) (short) 100);
        boolean boolean38 = dateTime35.isEqualNow();
        org.joda.time.DateTime dateTime39 = dateTime35.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property40 = dateTime35.weekyear();
        java.lang.String str41 = property40.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType42, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField30, dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType42, 53, (int) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 70, (java.lang.Number) 2, (java.lang.Number) 55285468);
        illegalFieldValueException54.prependMessage("1");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 57600000 + "'", int23 == 57600000);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31112163L) + "'", long29 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970" + "'", str41.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.util.Locale locale36 = null;
        try {
            long long37 = unsupportedDateTimeField32.set((long) (short) 10, "", locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField10 = iSOChronology9.hours();
        org.joda.time.DurationField durationField11 = iSOChronology9.days();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.centuryOfEra();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        boolean boolean15 = dateTime13.isEqual((long) (short) 100);
        boolean boolean16 = dateTime13.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property18 = dateTime13.weekyear();
        java.lang.String str19 = property18.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType20, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField24.getAsText((long) 55291874, locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType28, 55288711, 55294389);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatterBuilder4.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-06-15T15:21:35.165-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        int int4 = dateTime0.getHourOfDay();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        long long19 = dividedDateTimeField16.add(55287861L, (long) (short) 100);
        java.lang.String str20 = dividedDateTimeField16.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        try {
            long long24 = dividedDateTimeField16.set((long) 55285468, 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for weekyear must be in the range [0,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55297561L + "'", long19 == 55297561L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[weekyear]" + "'", str20.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withZone(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
        boolean boolean13 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = dateTime4.withLaterOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getRangeDurationField();
        try {
            long long36 = unsupportedDateTimeField32.roundHalfEven((long) 58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime10 = dateTime6.withYearOfEra((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime6.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(3, 55285468, 20, 55296749, (int) (byte) 0, (org.joda.time.Chronology) zonedChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55296749 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        int int14 = property13.getMaximumValueOverall();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
        boolean boolean18 = property13.equals((java.lang.Object) dateTimeFormatter17);
        org.joda.time.Interval interval19 = property13.toInterval();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600000 + "'", int8 == 57600000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(interval19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        int int14 = property13.getMaximumValueOverall();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
        boolean boolean18 = property13.equals((java.lang.Object) dateTimeFormatter17);
        org.joda.time.DateTime dateTime20 = property13.setCopy(55290263);
        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfDay();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600000 + "'", int8 == 57600000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = iSOChronology3.get(readablePeriod5, 44L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePeriod3, (long) (-28800000), 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.lang.String str34 = unsupportedDateTimeField32.toString();
        try {
            long long36 = unsupportedDateTimeField32.roundHalfFloor((-53L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDateTimeField" + "'", str34.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfHalfday((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendYearOfCentury(55295377, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear(55286536);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        long long19 = offsetDateTimeField15.roundHalfCeiling((long) (-292275054));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 946713600000L + "'", long19 == 946713600000L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendFractionOfMinute(0, 55289170);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.millisOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime5.withDayOfMonth(10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        org.joda.time.DateTime dateTime17 = dateTime5.withFields((org.joda.time.ReadablePartial) localDate16);
        long long19 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate16, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology1.secondOfDay();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600000 + "'", int13 == 57600000);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31112163L) + "'", long19 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.lang.String str17 = offsetDateTimeField15.getAsShortText((long) 55296976);
        int int19 = offsetDateTimeField15.getMaximumValue(0L);
        try {
            long long22 = offsetDateTimeField15.add((long) 20, 55295984);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 5529598400");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 55288370, 55287619);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.lang.String str7 = dateTimeZone6.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        java.lang.String str10 = dateTimeZone6.getName(0L);
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
//        org.joda.time.Chronology chronology13 = iSOChronology3.withZone(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded(readableDuration9, 166);
        int int12 = dateTime5.getDayOfMonth();
        int int13 = instant4.compareTo((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        int int20 = offsetDateTimeField15.getDifference(0L, (long) 2000);
        int int21 = offsetDateTimeField15.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.plus(readablePeriod6);
        boolean boolean9 = dateTime3.isAfter(0L);
        boolean boolean10 = dateTime3.isAfterNow();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readablePeriod7);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime11 = dateTime3.plusDays(166);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfMinute(55289170, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendPattern("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getLeapDurationField();
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField32.getRangeDurationField();
        long long38 = unsupportedDateTimeField32.add((long) 55289678, 31);
        try {
            long long40 = unsupportedDateTimeField32.roundHalfFloor((long) 55284984);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 978362489678L + "'", long38 == 978362489678L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2, 2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        int int10 = dateTime9.getYearOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        long long16 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.DateTime dateTime18 = property5.addToCopy((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 45L + "'", long16 == 45L);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-2160000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "2019-W24-6", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "UTC", "53");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "hi!", "");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getShortName(locale13, "T16:00:00-08:00", "Pacific Standard Time");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(55296976);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(55289029, 55289678, 292278993, 55289678, 0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55289678 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        long long8 = iSOChronology0.add((long) (short) 100, (long) 10, 55296976);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 552969860L + "'", long8 == 552969860L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-28800000));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DurationField durationField18 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        boolean boolean23 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime24 = dateTime20.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property25 = dateTime20.weekyear();
        java.lang.String str26 = property25.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType27, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType11, dateTimeFieldType27 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList33 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, dateTimeFieldTypeArray32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, true);
        org.joda.time.ReadablePartial readablePartial38 = null;
        try {
            java.lang.String str39 = dateTimeFormatter37.print(readablePartial38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long2 = dateTimeZone0.convertUTCToLocal((long) 55290263);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 55290263L + "'", long2 == 55290263L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime.Property property10 = dateTime8.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime14 = dateTime8.withZoneRetainFields(dateTimeZone13);
        java.util.TimeZone timeZone15 = dateTimeZone13.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        org.joda.time.DateTime dateTime15 = property13.addWrapFieldToCopy(55287837);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600000 + "'", int8 == 57600000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfHalfday((int) '4');
        boolean boolean15 = dateTimeFormatterBuilder12.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.plusDays(52);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.Chronology chronology12 = dateTime8.getChronology();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4492800000L + "'", long11 == 4492800000L);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("America/Los_Angeles");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.millisOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        boolean boolean10 = dateTime8.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime8.withDayOfMonth(10);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.LocalDate localDate19 = dateTime18.toLocalDate();
        org.joda.time.DateTime dateTime20 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate19);
        long long22 = iSOChronology4.set((org.joda.time.ReadablePartial) localDate19, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology4.secondOfDay();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) iSOChronology4);
        boolean boolean25 = jodaTimePermission1.equals((java.lang.Object) 10);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.hours();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.dayOfYear();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.millisOfDay();
        java.util.TimeZone timeZone30 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
        org.joda.time.Chronology chronology32 = iSOChronology26.withZone(dateTimeZone31);
        boolean boolean33 = jodaTimePermission1.equals((java.lang.Object) iSOChronology26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600000 + "'", int16 == 57600000);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31112163L) + "'", long22 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendDayOfYear(33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(52, (-55285890));
        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.append(dateTimeParser18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        long long19 = dividedDateTimeField16.add(55287861L, (long) (short) 100);
        java.lang.String str20 = dividedDateTimeField16.toString();
        int int21 = dividedDateTimeField16.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55297561L + "'", long19 == 55297561L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[weekyear]" + "'", str20.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getLeapDurationField();
        try {
            long long36 = unsupportedDateTimeField32.remainder(55296976002L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getLeapDurationField();
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField32.getRangeDurationField();
        long long38 = unsupportedDateTimeField32.add((long) 55289678, 31);
        try {
            java.lang.String str40 = unsupportedDateTimeField32.getAsShortText((long) 57599999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 978362489678L + "'", long38 == 978362489678L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        java.lang.String str7 = zonedChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readablePeriod7);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy("1970-W01-3");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W01-3\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(55291445);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfHour(55294075);
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfMinute(55289170, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendSecondOfMinute(366);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.DurationField durationField6 = iSOChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        boolean boolean10 = dateTime8.isEqual((long) (short) 100);
        boolean boolean11 = dateTime8.isEqualNow();
        org.joda.time.DateTime dateTime12 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime8.weekyear();
        java.lang.String str14 = property13.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType15, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField19.getAsText((long) 55291874, locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField19.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType23, 86400);
        org.joda.time.DurationField durationField26 = dividedDateTimeField25.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970" + "'", str14.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(100L);
        java.lang.String str8 = property5.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[millisOfSecond]" + "'", str8.equals("Property[millisOfSecond]"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        try {
            long long35 = unsupportedDateTimeField32.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withWeekyear((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        try {
            long long12 = zonedChronology6.getDateTimeMillis((long) (short) 10, 55294075, 97, 0, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55294075 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        try {
            int[] intArray23 = iSOChronology0.get(readablePeriod20, (long) 366, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600000 + "'", int12 == 57600000);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        int int6 = property5.getMinimumValueOverall();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMinutes(55294881);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getLeapDurationField();
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField32.getRangeDurationField();
        long long38 = unsupportedDateTimeField32.add((long) 55289678, 31);
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField32.getAsShortText(readablePartial39, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 978362489678L + "'", long38 == 978362489678L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(55293568, 55296976);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 55296976");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(55287619);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[millisOfSecond]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[millisOfSecond]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        int int10 = dateTimeZone8.getOffsetFromLocal(0L);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getShortName(1560608487837L, locale12);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(55295984, (-3), 16, 55295984, (int) '4', 55290263, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55295984 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PDT" + "'", str13.equals("PDT"));
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        try {
            int int34 = unsupportedDateTimeField32.getMinimumValue((long) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withYearOfEra(55284984);
        org.joda.time.DateTime dateTime10 = dateTime0.minusMillis(2000);
        org.joda.time.DateTime dateTime12 = dateTime0.minusMinutes(0);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime0.toMutableDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            int int15 = dateTime0.get(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 55290702);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, 55295984);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 55295984");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.millisOfDay();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.plus(readablePeriod23);
        org.joda.time.DateTime dateTime26 = dateTime20.withDayOfMonth(10);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        int int28 = dateTime27.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
        org.joda.time.LocalDate localDate31 = dateTime30.toLocalDate();
        org.joda.time.DateTime dateTime32 = dateTime20.withFields((org.joda.time.ReadablePartial) localDate31);
        long long34 = iSOChronology16.set((org.joda.time.ReadablePartial) localDate31, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology16.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField37 = iSOChronology36.hours();
        org.joda.time.DurationField durationField38 = iSOChronology36.days();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.centuryOfEra();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
        boolean boolean42 = dateTime40.isEqual((long) (short) 100);
        boolean boolean43 = dateTime40.isEqualNow();
        org.joda.time.DateTime dateTime44 = dateTime40.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property45 = dateTime40.weekyear();
        java.lang.String str46 = property45.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType47, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField52 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField35, dateTimeFieldType47);
        long long55 = zeroIsMaxDateTimeField52.add((long) 2, (long) 55296976);
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime();
        int int57 = dateTime56.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
        org.joda.time.LocalDate localDate60 = dateTime59.toLocalDate();
        org.joda.time.DateTime dateTime62 = dateTime59.minusDays(25);
        org.joda.time.DateTime.Property property63 = dateTime62.era();
        org.joda.time.LocalDate localDate64 = dateTime62.toLocalDate();
        int[] intArray68 = new int[] { (-3), (byte) 10, 59 };
        int int69 = zeroIsMaxDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) localDate64, intArray68);
        int int70 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDate64);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 57600000 + "'", int28 == 57600000);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31112163L) + "'", long34 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1970" + "'", str46.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 55296976002L + "'", long55 == 55296976002L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 57600000 + "'", int57 == 57600000);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 86400 + "'", int69 == 86400);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime0.plusMillis(1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(55289678);
        boolean boolean9 = dateTime7.isBefore((long) 1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear(10);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withFieldAdded(durationFieldType11, (-55285890));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = iSOChronology0.seconds();
        long long9 = iSOChronology0.add((long) 55294389, (long) (byte) 0, 57600000);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 55294389L + "'", long9 == 55294389L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime6.toGregorianCalendar();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.plusSeconds(55288370);
        try {
            org.joda.time.DateTime dateTime13 = dateTime0.withTime((int) (short) 100, 0, 55288711, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfWeek();
        java.lang.String str8 = property7.getAsShortText();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed" + "'", str8.equals("Wed"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfHalfday(55287837);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        boolean boolean11 = dateTime9.isEqual((long) (short) 100);
        boolean boolean12 = dateTime9.isEqualNow();
        org.joda.time.DateTime dateTime13 = dateTime9.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime9.weekyear();
        java.lang.String str15 = property14.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType16, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField20.getAsText((long) 55291874, locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField20.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMinuteOfDay(55295984);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970" + "'", str15.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime8 = property5.roundHalfFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, 55290702);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 366 + "'", int7 == 366);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) -1, 292278993, 57600, (-28800000), 100, 55291445);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str10 = dateTime6.toString(dateTimeFormatter8);
        java.io.Writer writer11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        boolean boolean14 = dateTime12.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.plus(readablePeriod15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant17);
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime(chronology18);
        org.joda.time.DateTime dateTime20 = dateTime19.withTimeAtStartOfDay();
        try {
            dateTimeFormatter8.printTo(writer11, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00-08:00" + "'", str10.equals("T16:00:00-08:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime dateTime10 = dateTime0.withYearOfEra(2019);
        org.joda.time.DateTime.Property property11 = dateTime0.minuteOfHour();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        int int13 = dateTime12.getYearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.plusDays(52);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.dayOfYear();
        java.lang.String str18 = property17.toString();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime21 = property17.roundHalfEvenCopy();
        int int22 = dateTime21.getCenturyOfEra();
        int int23 = property11.getDifference((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[dayOfYear]" + "'", str18.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "52" + "'", str20.equals("52"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-75360) + "'", int23 == (-75360));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZone(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        java.lang.String str37 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600000 + "'", int30 == 57600000);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DateTimeField[weekyear]" + "'", str37.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getDayOfYear();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 365 + "'", int1 == 365);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime dateTime10 = dateTime8.withEra((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendHourOfDay(55288743);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneName(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 70);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundFloor(0L);
        int int20 = offsetDateTimeField15.getDifference(0L, (long) 2000);
        try {
            long long23 = offsetDateTimeField15.add(0L, 0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for weekyear must be in the range [10,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208960000000L) + "'", long17 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55293568);
        org.joda.time.DurationField durationField19 = iSOChronology0.centuries();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600070 + "'", int12 == 57600070);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31106432L) + "'", long18 == (-31106432L));
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = iSOChronology0.seconds();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatterBuilder12.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.append(dateTimePrinter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendClockhourOfHalfday((int) '4');
        boolean boolean21 = iSOChronology0.equals((java.lang.Object) dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        long long38 = offsetDateTimeField15.roundHalfCeiling((-53L));
        int int40 = offsetDateTimeField15.getLeapAmount((long) 55285889);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600070 + "'", int30 == 57600070);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 946713600000L + "'", long38 == 946713600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.plusMonths(55288743);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, 55290263);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekOfWeekyear();
        java.lang.String str3 = property2.getAsText();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.DateTime dateTime7 = property2.addToCopy(4492800000L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationField durationField7 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        int int18 = dividedDateTimeField16.get((long) (-1));
        boolean boolean20 = dividedDateTimeField16.isLeap((long) 86400);
        long long23 = dividedDateTimeField16.add(0L, (long) 366);
        long long25 = dividedDateTimeField16.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35502L + "'", long23 == 35502L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(55294075);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withMonthOfYear((-75360));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -75360 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600070 + "'", int1 == 57600070);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        long long39 = zeroIsMaxDateTimeField36.add((long) 2, (long) 55296976);
        long long42 = zeroIsMaxDateTimeField36.add((long) 55293568, (-2160000000L));
        long long44 = zeroIsMaxDateTimeField36.roundHalfCeiling(58787984L);
        long long47 = zeroIsMaxDateTimeField36.getDifferenceAsLong((long) 55287943, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600070 + "'", int12 == 57600070);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55296976002L + "'", long39 == 55296976002L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2159944706432L) + "'", long42 == (-2159944706432L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 58788000L + "'", long44 == 58788000L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 55287L + "'", long47 == 55287L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        java.lang.String str7 = zonedChronology6.toString();
        java.lang.String str8 = zonedChronology6.toString();
        org.joda.time.DurationField durationField9 = zonedChronology6.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str8.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DurationField durationField9 = property5.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        int int18 = dateTime17.getYearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime20.toMutableDateTime(dateTimeZone22);
        int int26 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withDefaultYear(55287619);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readablePeriod31);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray35 = null;
        int int36 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate33, intArray35);
        boolean boolean38 = offsetDateTimeField15.isLeap(86399999L);
        int int39 = offsetDateTimeField15.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 57600070 + "'", int30 == 57600070);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-W01-3" + "'", str34.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(55294075);
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfMonth(3);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays(1969);
        int int10 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600070 + "'", int1 == 57600070);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        try {
            int int33 = unsupportedDateTimeField32.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-3), (java.lang.Number) 55294389L, (java.lang.Number) 6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendLiteral('#');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendTimeZoneOffset("PST", "1970-W01-3", false, 58, 86400);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        java.lang.Object obj4 = null;
        boolean boolean5 = dateTime0.equals(obj4);
        org.joda.time.DateTime dateTime7 = dateTime0.withEra(0);
        org.joda.time.DateTime.Property property8 = dateTime0.dayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(55294389);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        int int4 = dateTime3.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        java.util.GregorianCalendar gregorianCalendar8 = dateTime6.toGregorianCalendar();
        java.lang.String str9 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime6);
        java.util.Locale locale10 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600070 + "'", int4 == 57600070);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W01-3" + "'", str9.equals("1970-W01-3"));
        org.junit.Assert.assertNull(locale10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.lang.String str34 = unsupportedDateTimeField32.toString();
        java.lang.String str35 = unsupportedDateTimeField32.toString();
        java.util.Locale locale37 = null;
        try {
            java.lang.String str38 = unsupportedDateTimeField32.getAsShortText(55295377, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDateTimeField" + "'", str34.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UnsupportedDateTimeField" + "'", str35.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        int int18 = dividedDateTimeField16.get((long) (-1));
        java.util.Locale locale20 = null;
        java.lang.String str21 = dividedDateTimeField16.getAsText((-31106432L), locale20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        long long22 = iSOChronology0.add(10L, (long) 55288743, 53);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        int int24 = dateTime23.getYearOfEra();
        org.joda.time.DateTime dateTime26 = dateTime23.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime29 = dateTime23.withDurationAdded(readableDuration27, 166);
        org.joda.time.DateTime dateTime31 = dateTime23.withDayOfYear(100);
        org.joda.time.DateTime dateTime33 = dateTime23.withYearOfEra(2019);
        org.joda.time.DateTime dateTime35 = dateTime23.minusSeconds(166);
        java.util.GregorianCalendar gregorianCalendar36 = dateTime35.toGregorianCalendar();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        int int38 = dateTime37.getYearOfEra();
        org.joda.time.DateTime dateTime40 = dateTime37.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.withZone(dateTimeZone41);
        int int43 = dateTime42.getSecondOfMinute();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime();
        int int45 = dateTime44.getYearOfEra();
        org.joda.time.DateTime dateTime47 = dateTime44.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone48 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forTimeZone(timeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = dateTime47.toMutableDateTime(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = dateTime42.withZoneRetainFields(dateTimeZone49);
        org.joda.time.MutableDateTime mutableDateTime52 = dateTime35.toMutableDateTime(dateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone53 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
        org.joda.time.chrono.ZonedChronology zonedChronology54 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology54.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600070 + "'", int12 == 57600070);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2930303389L + "'", long22 == 2930303389L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(gregorianCalendar36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone53);
        org.junit.Assert.assertNotNull(zonedChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DurationField durationField18 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        boolean boolean23 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime24 = dateTime20.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property25 = dateTime20.weekyear();
        java.lang.String str26 = property25.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType27, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType11, dateTimeFieldType27 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList33 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, dateTimeFieldTypeArray32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter37.withZoneUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.lang.String str17 = offsetDateTimeField15.getAsText(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField15.getType();
        int int20 = offsetDateTimeField15.get((long) 55285468);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.lang.String str8 = dateTimeZone7.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        java.lang.String str11 = dateTimeZone7.getName(0L);
//        long long13 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, 0L);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-55287862), 0, 86399999, 0, (int) (short) -1, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        long long35 = unsupportedDateTimeField32.getDifferenceAsLong(946713600000L, (long) 0);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
        int int37 = dateTime36.getYearOfEra();
        org.joda.time.DateTime dateTime39 = dateTime36.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = dateTime39.withZone(dateTimeZone40);
        org.joda.time.LocalTime localTime42 = dateTime39.toLocalTime();
        int[] intArray43 = null;
        try {
            int int44 = unsupportedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localTime42, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 30L + "'", long35 == 30L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localTime42);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = unsupportedDateTimeField32.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.hours();
        org.joda.time.DurationField durationField37 = iSOChronology35.days();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.centuryOfEra();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime();
        boolean boolean41 = dateTime39.isEqual((long) (short) 100);
        boolean boolean42 = dateTime39.isEqualNow();
        org.joda.time.DateTime dateTime43 = dateTime39.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property44 = dateTime39.weekyear();
        java.lang.String str45 = property44.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType46, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale51 = null;
        int int52 = offsetDateTimeField50.getMaximumShortTextLength(locale51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime();
        int int54 = dateTime53.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.DateTime dateTime56 = dateTime53.plus(readablePeriod55);
        org.joda.time.LocalDate localDate57 = dateTime56.toLocalDate();
        boolean boolean58 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate57);
        int int59 = offsetDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) localDate57);
        java.util.Locale locale61 = null;
        try {
            java.lang.String str62 = unsupportedDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate57, 0, locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970" + "'", str45.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 57600070 + "'", int54 == 57600070);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        long long19 = dividedDateTimeField16.add(55287861L, (long) (short) 100);
        java.lang.String str20 = dividedDateTimeField16.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        long long23 = remainderDateTimeField21.roundHalfEven((long) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55297561L + "'", long19 == 55297561L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[weekyear]" + "'", str20.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays(25);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.minus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        int int14 = cachedDateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime7);
        int int16 = cachedDateTimeZone3.getStandardOffset((long) 55285468);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600070 + "'", int5 == 57600070);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        int int7 = dateTime6.getYearOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime6.withDurationAdded(readableDuration10, 166);
        org.joda.time.DateTime dateTime14 = dateTime6.withYearOfEra(55284984);
        boolean boolean16 = dateTime14.isEqual((-1L));
        int int17 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str18 = dateTime14.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600070 + "'", int1 == 57600070);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "55284984-12-31T16:00:00.070-08:00" + "'", str18.equals("55284984-12-31T16:00:00.070-08:00"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        org.joda.time.DateTime dateTime8 = property5.roundHalfEvenCopy();
        java.lang.String str9 = property5.getAsShortText();
        java.lang.String str10 = property5.getAsText();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(55287943);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(25);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime6, (java.lang.Object) 55293568L);
        org.joda.time.DateTime dateTime11 = dateTime6.plusSeconds(366);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(55285468);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55285468 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600070 + "'", int1 == 57600070);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.lang.String str10 = dateTimeZone9.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        java.lang.String str13 = dateTimeZone9.getName(0L);
//        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, 0L);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 1, 52, 15, 55291445, 55296873, 86400, 59, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55291445 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long5 = cachedDateTimeZone3.nextTransition((long) 1970);
        int int7 = cachedDateTimeZone3.getOffset(87587984L);
        long long9 = cachedDateTimeZone3.previousTransition((long) 55286536);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9972000000L + "'", long5 == 9972000000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-5756400001L) + "'", long9 == (-5756400001L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 55288743, (java.lang.Number) (short) 0, (java.lang.Number) 55284984);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.plusMonths(55288743);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) '4');
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("Property[dayOfYear]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
        org.joda.time.DurationField durationField18 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        boolean boolean22 = dateTime20.isEqual((long) (short) 100);
        boolean boolean23 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime24 = dateTime20.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property25 = dateTime20.weekyear();
        java.lang.String str26 = property25.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType27, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType11, dateTimeFieldType27 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList33 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, dateTimeFieldTypeArray32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, true);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury(1, 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(55294389);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendDayOfYear(33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendHourOfHalfday(55287837);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField35.getAsText((long) 55291874, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder10.appendHourOfDay(55288711);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        int int16 = offsetDateTimeField15.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.lang.String str10 = dateTimeZone9.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        java.lang.String str13 = dateTimeZone9.getName(0L);
//        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, 0L);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, 55289170, 55295984, 55292509, 1969, 55287837, 55294881, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55292509 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded(readableDuration4, 166);
        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(100);
        org.joda.time.DateTime dateTime10 = dateTime0.withYearOfEra(2019);
        org.joda.time.DateTime dateTime12 = dateTime0.minusSeconds(166);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 86399999);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 166, (org.joda.time.DateTimeZone) cachedDateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        illegalFieldValueException22.prependMessage("53");
        java.lang.Number number25 = illegalFieldValueException22.getUpperBound();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.withDayOfMonth(10);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate15);
        long long18 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, (long) 55287837);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
        org.joda.time.DurationField durationField22 = iSOChronology20.days();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        boolean boolean26 = dateTime24.isEqual((long) (short) 100);
        boolean boolean27 = dateTime24.isEqualNow();
        org.joda.time.DateTime dateTime28 = dateTime24.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime24.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) (short) 1, 10, (int) (short) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        long long39 = zeroIsMaxDateTimeField36.add((long) 2, (long) 55296976);
        long long42 = zeroIsMaxDateTimeField36.set((long) '4', (int) (short) 10);
        long long44 = zeroIsMaxDateTimeField36.roundHalfCeiling((long) 10);
        int int45 = zeroIsMaxDateTimeField36.getMinimumValue();
        java.lang.String str46 = zeroIsMaxDateTimeField36.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600070 + "'", int12 == 57600070);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31112163L) + "'", long18 == (-31112163L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55296976002L + "'", long39 == 55296976002L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-57589948L) + "'", long42 == (-57589948L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[weekyear]" + "'", str46.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        long long35 = unsupportedDateTimeField32.getDifferenceAsLong(946713600000L, (long) 0);
        long long38 = unsupportedDateTimeField32.add((long) 55292509, (int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField40 = iSOChronology39.hours();
        org.joda.time.DurationField durationField41 = iSOChronology39.days();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.year();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
        boolean boolean45 = dateTime43.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime47 = dateTime43.plus(readablePeriod46);
        org.joda.time.DateTime dateTime49 = dateTime43.withDayOfMonth(10);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime();
        int int51 = dateTime50.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.plus(readablePeriod52);
        org.joda.time.LocalDate localDate54 = dateTime53.toLocalDate();
        org.joda.time.DateTime dateTime55 = dateTime43.withFields((org.joda.time.ReadablePartial) localDate54);
        long long57 = iSOChronology39.set((org.joda.time.ReadablePartial) localDate54, (long) 55293568);
        try {
            int int58 = unsupportedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate54);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 30L + "'", long35 == 30L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 31591292509L + "'", long38 == 31591292509L);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 57600070 + "'", int51 == 57600070);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-31106432L) + "'", long57 == (-31106432L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ZonedChronology[ISOChronology[UTC], America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        boolean boolean6 = dateTime4.isEqual((long) (short) 100);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.weekyear();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, (int) (short) 1, 10, (int) (short) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) 55291874, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 2019, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.millisOfSecond();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        long long31 = durationField28.subtract((long) 55291445, (long) 2019);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField28);
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
        java.lang.String str34 = unsupportedDateTimeField32.toString();
        java.lang.String str35 = unsupportedDateTimeField32.toString();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
        int int37 = dateTime36.getYearOfEra();
        org.joda.time.DateTime dateTime39 = dateTime36.minusWeeks((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime42 = dateTime36.withDurationAdded(readableDuration40, 166);
        int int43 = dateTime36.getDayOfMonth();
        org.joda.time.LocalDate localDate44 = dateTime36.toLocalDate();
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, 2, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-63713465130555L) + "'", long31 == (-63713465130555L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnsupportedDateTimeField" + "'", str34.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UnsupportedDateTimeField" + "'", str35.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
        org.junit.Assert.assertNotNull(localDate44);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (short) -1, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-3), (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -292275054");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 15);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText(2000, locale7);
        long long10 = offsetDateTimeField5.roundCeiling((long) (-100));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2000" + "'", str8.equals("2000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean2 = dateTime0.isEqual((long) (short) 100);
        boolean boolean3 = dateTime0.isEqualNow();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime0.toTimeOfDay();
        int int6 = dateTime0.getYear();
        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 2019, 4492800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4492797981L) + "'", long2 == (-4492797981L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property5.roundHalfEvenCopy();
        int int10 = dateTime9.getEra();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        int int3 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks((int) (byte) -1);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        int int11 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "America/Los_Angeles", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter1.withDefaultYear(55287619);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.hourOfDay();
        org.joda.time.DurationField durationField16 = gregorianChronology14.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology14.getZone();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getYearOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(52);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        java.lang.String str8 = property5.getAsText();
        org.joda.time.DateTimeField dateTimeField9 = property5.getField();
        org.joda.time.DateTime dateTime10 = property5.roundHalfCeilingCopy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfYear]" + "'", str6.equals("Property[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(55294075, 55289029, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        boolean boolean7 = dateTime5.isEqual((long) (short) 100);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType12, (int) 'a');
        long long19 = dividedDateTimeField16.add(55287861L, (long) (short) 100);
        java.lang.String str20 = dividedDateTimeField16.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField16);
        long long23 = remainderDateTimeField21.remainder(86399999L);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        int int25 = dateTime24.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
        org.joda.time.DateTime dateTime30 = dateTime27.minusDays(25);
        org.joda.time.DateTime.Property property31 = dateTime30.era();
        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
        boolean boolean33 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate32);
        java.util.Locale locale35 = null;
        java.lang.String str36 = remainderDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate32, 3, locale35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55297561L + "'", long19 == 55297561L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[weekyear]" + "'", str20.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 57600070 + "'", int25 == 57600070);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "3" + "'", str36.equals("3"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(55294075);
        try {
            java.lang.String str7 = dateTime3.toString("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600070 + "'", int1 == 57600070);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear(1);
        boolean boolean7 = dateTimeFormatter4.isParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        boolean boolean11 = dateTime9.isEqual((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.plus(readablePeriod12);
        boolean boolean15 = dateTime13.isAfter((long) 55288711);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withPeriodAdded(readablePeriod16, 55289170);
        try {
            java.lang.String str19 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime18);
    }
}

