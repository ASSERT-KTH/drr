import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(100L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.50000037d + "'", double1 == 2440587.50000037d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withFieldAdded(durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) (byte) -1, (int) '4', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 100L, (java.lang.Number) 58936847);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "", (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = dateTime0.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) (byte) 1, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) 10, 0, 1, (int) (short) 1, 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfDay();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField3, dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfDay();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField3, dateTimeFieldType4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray1 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0, 1, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000006016d + "'", double1 == 2440587.5000006016d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, durationField4, dateTimeFieldType5, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withEra((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        java.util.Locale locale3 = null;
        try {
            org.joda.time.DateTime dateTime4 = property1.setCopy("", locale3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 0, 0, (int) '#', (int) (short) 0, 58937835, (-25200000), 20, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58937835 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.Partial.Property property6 = partial0.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) -1, 58938682, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        try {
            org.joda.time.DateTime dateTime6 = dateTime0.withDayOfMonth(166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withField(dateTimeFieldType2, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            long long9 = gJChronology1.getDateTimeMillis((int) (short) 100, (int) '4', (int) (byte) -1, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 0, (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hi! must be in the range [1,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes((-1));
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        try {
            org.joda.time.LocalDate localDate3 = localDate1.withMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            long long9 = gJChronology1.getDateTimeMillis((int) (short) 0, (int) (byte) 10, (int) (short) 10, 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        java.util.Locale locale4 = null;
        try {
            org.joda.time.LocalDate localDate5 = property2.setCopy("hi!", locale4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((int) ' ');
//        int int10 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 1);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(58939619, 58936847, (int) (byte) -1, (int) (short) 1, (-10), dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28799999L) + "'", long12 == (-28799999L));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology6);
        try {
            boolean boolean10 = partial0.isAfter((org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            java.lang.String str4 = dateTimeFormatter2.print(readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.era();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfDay();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withField(dateTimeFieldType3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        try {
            long long6 = gJChronology0.getDateTimeMillis(0, 6, (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMaximumValue();
        java.lang.String str5 = localDate3.toString("58939886");
        int int7 = localDate3.getValue((int) (byte) 0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "58939886" + "'", str5.equals("58939886"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278969 + "'", int7 == 292278969);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        try {
            org.joda.time.DateTime dateTime3 = property1.setCopy((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusDays((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
//        int int4 = dateTime0.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.Partial partial3 = partial0.with(dateTimeFieldType1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        org.joda.time.Interval interval5 = property1.toInterval();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property1.setCopy("Pacific Standard Time", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.yearOfEra();
//        org.joda.time.DurationField durationField5 = gJChronology3.millis();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology3);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfMonth();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        int int9 = dateTime8.getCenturyOfEra();
//        int int10 = dateTime8.getDayOfYear();
//        org.joda.time.YearMonthDay yearMonthDay11 = dateTime8.toYearMonthDay();
//        boolean boolean12 = localDate6.equals((java.lang.Object) dateTime8);
//        try {
//            boolean boolean13 = partial0.isAfter((org.joda.time.ReadablePartial) localDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 166 + "'", int10 == 166);
//        org.junit.Assert.assertNotNull(yearMonthDay11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 58937835, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType4, 292278969, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalTime localTime5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = localDate3.toDateTime(localTime5, dateTimeZone6);
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate3.getFields();
        try {
            boolean boolean9 = localDateTime1.isAfter((org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("58939886", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"58939886\": Value 98 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        int int6 = dateTime5.getYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        java.util.Locale locale6 = null;
//        int int7 = property1.getMaximumShortTextLength(locale6);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58942414 + "'", int2 == 58942414);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate.Property property7 = localDate4.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 166);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.plusYears((int) ' ');
        int int11 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long14 = dateTimeZone7.adjustOffset(0L, false);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (byte) 10, 6, 0, 15, 292278969, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        try {
            org.joda.time.LocalDate localDate4 = property2.setCopy("58941222");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58941222 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate1.getFields();
        int int7 = localDate1.getYearOfEra();
        try {
            org.joda.time.LocalDate localDate9 = localDate1.withDayOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.String str4 = dateTimeFormatter0.print((long) 1978);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "16" + "'", str4.equals("16"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType12, 292278969, (int) (short) -1, 58939619);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.with(dateTimeFieldType4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("58941222");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"58941222/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@409a44d6");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("58939886");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58939886\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 1, 4, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DurationField durationField6 = gJChronology1.days();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.hourOfHalfday();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(1, 0, 10, 100, 2019, 6, (int) ' ', (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology4.getZone();
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatter0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getCenturyOfEra();
//        int int2 = dateTime0.getDayOfYear();
//        int int3 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime5 = dateTime0.plusMonths(1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            org.joda.time.DateTime.Property property7 = dateTime5.property(dateTimeFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 166 + "'", int2 == 166);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray4 = new int[] { 58944326, 8, 1 };
        try {
            org.joda.time.Partial partial5 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (short) 100, (long) 1978);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) 'a', 0, 58938682, (int) (short) 10, (int) '#', 10, 1969, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-10), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = dateTime4.getClass();
        org.joda.time.DateTime dateTime9 = dateTime4.plusMonths(10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours(58938682);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfYear(1978);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1978 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter3.parseLocalDate("-10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getCenturyOfEra();
//        int int2 = dateTime0.getDayOfYear();
//        int int3 = dateTime0.getDayOfMonth();
//        boolean boolean5 = dateTime0.isAfter((long) 166);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay(58940097);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58940097 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 166 + "'", int2 == 166);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        long long5 = durationField2.subtract((long) 2019, (long) 100);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-8643597981L) + "'", long5 == (-8643597981L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("58941222", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime4 = dateTime2.plusDays((int) (byte) 100);
//        int int5 = dateTime2.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 58946008 + "'", int5 == 58946008);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 292278969, "19");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) -1, "1969");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, (int) (byte) -1, 1, 10, 10, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(100, 8, 1969, (int) (byte) 100, 19, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime2.minusHours(1);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalTime localTime5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = localDate3.toDateTime(localTime5, dateTimeZone6);
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate3.getFields();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        java.lang.String str6 = property1.getAsString();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58946632 + "'", int2 == 58946632);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "58946632" + "'", str6.equals("58946632"));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField9 = gregorianChronology8.months();
        try {
            long long17 = gregorianChronology8.getDateTimeMillis(0, (int) (short) 10, 0, (int) (byte) -1, 10, (int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-25200000) + "'", int5 == (-25200000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTime5.getCenturyOfEra();
        int int7 = dateTime5.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime5.toYearMonthDay();
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) yearMonthDay8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-10", 58946008, (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58946008 for -10 must be in the range [1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        int int5 = offsetDateTimeField3.getLeapAmount((long) 10);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfWeek();
        org.joda.time.LocalDate localDate10 = localDate7.minusWeeks((-1));
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial12.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = partial12.getFieldTypes();
        int[] intArray15 = partial12.getValues();
        try {
            int[] intArray17 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDate10, 10, intArray15, 58937835);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        int int6 = localDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "58946008");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        int int4 = dateTime3.getMinuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        org.joda.time.DurationField durationField7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, durationField7, dateTimeFieldType22, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField3.getType();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        org.joda.time.Partial partial16 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = partial16.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray18 = partial16.getFieldTypes();
        int[] intArray19 = partial16.getValues();
        boolean boolean20 = partial15.isBefore((org.joda.time.ReadablePartial) partial16);
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = partial22.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial22.getFieldTypes();
        int[] intArray25 = partial22.getValues();
        java.util.Locale locale27 = null;
        try {
            int[] intArray28 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) partial16, 10, intArray25, "58939886", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate3);
        try {
            org.joda.time.LocalDate localDate8 = localDate3.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-28799999L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2699186673600000L) + "'", long1 == (-2699186673600000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate3);
        int int7 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone1);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = localDate3.toString("GregorianChronology[America/Los_Angeles]", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        int[] intArray3 = partial0.getValues();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial0.withFieldAdded(durationFieldType4, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 292278969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 292278969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant7 = instant5.plus((long) 166);
        org.joda.time.Instant instant9 = instant5.plus((long) 2019);
        boolean boolean10 = copticChronology2.equals((java.lang.Object) instant9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        java.lang.String str5 = dateTimeFormatter2.print((long) 58938682);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "08" + "'", str5.equals("08"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add(0L, (long) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, (int) (byte) 10, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for yearOfEra must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        int[] intArray4 = new int[] { 1969 };
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology6);
        try {
            org.joda.time.Partial partial10 = new org.joda.time.Partial(dateTimeFieldTypeArray2, intArray4, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "PST");
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(15, 1, (int) (byte) -1, 58946632, 12, (-28800000), 292278969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58946632 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-28799999L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) gJChronology1, (org.joda.time.Chronology) copticChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(copticChronology6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 58938682, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("-10");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(0L, chronology1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMonths((-1));
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property16 = localDate15.dayOfWeek();
        int[] intArray18 = null;
        try {
            int[] intArray20 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDate15, 1978, intArray18, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for yearOfEra must be in the range [9,292279001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        int int4 = localDate3.getEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        try {
            long long6 = copticChronology1.getDateTimeMillis((-25200000), 1978, 0, 58942414);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1978 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.getLeapAmount((long) 58940097);
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial12.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = partial12.getFieldTypes();
        int[] intArray15 = partial12.getValues();
        int[] intArray16 = new int[] {};
        int int17 = delegatedDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) partial12, intArray16);
        try {
            iSOChronology0.validate(readablePartial3, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "58946008");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 100, 1978, 69, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1978 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(31536000000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 315532800000L, (java.lang.Number) (-28798081L), (java.lang.Number) 58944579);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str7 = property1.getAsShortText();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "57600000" + "'", str7.equals("57600000"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsShortText(readablePartial6, 58946008, locale8);
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 58944326);
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial12.getFormatter();
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) partial12, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "58946008" + "'", str9.equals("58946008"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNull(dateTimeFormatter13);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsShortText(readablePartial6, 58946008, locale8);
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 58944326);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.yearOfEra();
        org.joda.time.DurationField durationField15 = gJChronology13.millis();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.DateMidnight dateMidnight17 = localDate16.toDateMidnight();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = partial19.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = partial19.getFieldTypes();
        int[] intArray22 = partial19.getValues();
        try {
            int[] intArray24 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDate16, 4, intArray22, 58939619);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "58946008" + "'", str9.equals("58946008"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial0.without(dateTimeFieldType3);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType6 = partial0.getFieldType((-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -25200000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1978, 292278969, (int) (short) 1, 58944987, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944987 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DurationField durationField6 = delegatedDateTimeField5.getDurationField();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 8);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate15 = localDate12.plus(readablePeriod14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate15, 20, locale17);
        long long20 = offsetDateTimeField10.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField10.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField22 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField6, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter0.getPrinter();
        java.lang.StringBuffer stringBuffer5 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property8.withMaximumValue();
        java.lang.String str11 = localDate9.toString("58939886");
        try {
            dateTimeFormatter0.printTo(stringBuffer5, (org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58939886" + "'", str11.equals("58939886"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology11);
        org.joda.time.Partial partial16 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = partial16.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray18 = partial16.getFieldTypes();
        int[] intArray19 = partial16.getValues();
        try {
            int[] intArray21 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDate14, (int) (byte) 1, intArray19, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray18);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusDays((int) (byte) 100);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(58942414);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-58942414) + "'", int1 == (-58942414));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
        int int10 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        org.joda.time.LocalTime localTime14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime14, dateTimeZone15);
        int int17 = localDate12.getCenturyOfEra();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = partial19.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = partial19.getFieldTypes();
        int[] intArray22 = partial19.getValues();
        try {
            int[] intArray24 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) localDate12, 58946632, intArray22, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58946632");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        java.util.Locale locale4 = null;
        try {
            org.joda.time.LocalDate localDate5 = property2.setCopy("PST", locale4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.DateTime dateTime6 = property1.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property1.withMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        int int13 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime10);
        long long15 = dateTimeZone9.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime17 = dateTime7.withZone(dateTimeZone9);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28799999L) + "'", long15 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long8 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getName(3600000L, locale11);
//        int int14 = dateTimeZone1.getOffsetFromLocal(31536000000L);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfMonth();
        java.lang.String str3 = property2.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfMonth" + "'", str3.equals("dayOfMonth"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime7 = dateTime2.plusYears(960);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(58938682);
        boolean boolean11 = dateTimeFormatterBuilder8.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter0.getPrinter();
        boolean boolean5 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField2, dateTimeFieldType31, 57600000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfMonth();
        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.LocalDate localDate12 = localDate7.withFieldAdded(durationFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property1.getAsText(locale3);
        org.joda.time.DateTime dateTime5 = property1.roundHalfEvenCopy();
        int int6 = property1.get();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "57600000" + "'", str4.equals("57600000"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600000 + "'", int6 == 57600000);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) ' ');
        int int7 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = dateTime4.plusMonths((int) (byte) -1);
        int int10 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime12 = dateTime4.withMillis(3600000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 100, 9, (int) (short) 0, (int) (short) 10, 57600000, (int) (byte) -1, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withEra(58946008);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58946008 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis(19, 4, 166, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1978");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1978/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@409a44d6");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) 2019);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (-58942414));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -58942414");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28798081L) + "'", long5 == (-28798081L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime0.toGregorianCalendar();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar4);
        try {
            org.joda.time.LocalDate localDate7 = localDate5.withDayOfMonth(58944579);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944579 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) ' ');
        int int7 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime4);
        long long9 = dateTimeZone3.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField11 = gregorianChronology10.months();
        try {
            org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldType0, 0, (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28799999L) + "'", long9 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2019, (java.lang.Object) 69);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.joda.time.DurationField durationField11 = property9.getDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        boolean boolean6 = delegatedDateTimeField4.isLeap(3600000L);
        long long9 = delegatedDateTimeField4.add(1560640937788L, 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1844724137788L + "'", long9 == 1844724137788L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.LocalDate localDate5 = localDate1.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime1.minusWeeks(58944326);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
        org.joda.time.ReadableInstant readableInstant9 = null;
        try {
            int int10 = dateTime1.compareTo(readableInstant9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime1.minusWeeks(58944326);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime13 = dateTime1.withTime(1969, 58938682, 1978, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone8 = dateTimeZone7.toTimeZone();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(58940097, 58942414, 58946008, (int) (byte) 100, (-25200000), (-58942414), dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(15);
        org.joda.time.LocalDate.Property property4 = localDate1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) ' ');
        int int7 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = dateTime4.plusMonths((int) (byte) -1);
        int int10 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime12 = dateTime4.minus(1560640937788L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        try {
            org.joda.time.LocalDate localDate7 = localDate5.withDayOfYear(58936847);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58936847 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is malformed at \"69\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-28800000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28800000 + "'", int1 == 28800000);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(57600001, 960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral('4');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType11, 58946632, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        int int2 = dateTime0.getYearOfCentury();
        int int3 = dateTime0.getYearOfCentury();
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        java.lang.String str19 = offsetDateTimeField3.getAsText((long) (short) 100);
        try {
            long long22 = offsetDateTimeField3.set((long) 58940097, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1978" + "'", str19.equals("1978"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        int int3 = dateTime2.getCenturyOfEra();
        int int4 = dateTime2.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1978");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1978\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendPattern("70");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendSecondOfMinute(70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-25200000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            long long12 = gJChronology1.getDateTimeMillis(58946008, 9, (int) (byte) 0, 58938682, 58944987, 58946632, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58938682 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale9 = null;
        long long10 = offsetDateTimeField3.set((-28798081L), "08", locale9);
        int int12 = offsetDateTimeField3.getMaximumValue((long) 57600001);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-53998081L) + "'", long10 == (-53998081L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        int int8 = dateTime6.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight9 = dateTime6.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.plus(readableDuration10);
        org.joda.time.DateTime.Property property12 = dateTime6.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 8);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate21 = localDate18.plus(readablePeriod20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate21, 20, locale23);
        long long26 = offsetDateTimeField16.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField16.getType();
        int int28 = dateTime6.get(dateTimeFieldType27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType27, 1970, 1969);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType27, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "20" + "'", str24.equals("20"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1970 + "'", int28 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(57600001, (-10));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-10), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        java.io.Writer writer8 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 0);
        try {
            dateTimeFormatter0.printTo(writer8, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28798081L) + "'", long6 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 58939619, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        boolean boolean3 = dateTime0.isEqual(0L);
        try {
            org.joda.time.DateTime dateTime8 = dateTime0.withTime(292279001, 20, (int) (byte) 10, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279001 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        boolean boolean3 = dateTime0.isBefore((long) 2002);
        org.joda.time.DateTime dateTime5 = dateTime0.minusMonths(292278993);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(0, '4', (-10), (-1), 70, false, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMinuteOfDay(1978);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        try {
            org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((-58942414), 70, (-10), (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsShortText(readablePartial6, 58946008, locale8);
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 58944326);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate15 = localDate13.withCenturyOfEra(15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = partial17.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = partial17.getFieldTypes();
        int[] intArray20 = partial17.getValues();
        try {
            int[] intArray22 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate15, 58946008, intArray20, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58946008");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "58946008" + "'", str9.equals("58946008"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths((int) (byte) -1);
        int int8 = dateTime7.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        int int11 = dateTime10.getMillisOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) "58939886");
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.yearOfEra();
        org.joda.time.DurationField durationField6 = gJChronology4.millis();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology4.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial0.without(dateTimeFieldType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial4.withFieldAddWrapped(durationFieldType5, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial0.without(dateTimeFieldType3);
        java.lang.String str5 = partial4.toString();
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.monthOfYear();
        try {
            long long10 = copticChronology2.getDateTimeMillis((-10), 292279001, 4, 1978);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279001 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.Partial partial10 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = partial10.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = partial10.getFieldTypes();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology15);
        int[] intArray19 = localDate18.getValues();
        try {
            int[] intArray21 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) partial10, (int) 'a', intArray19, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        long long12 = delegatedDateTimeField4.getDifferenceAsLong((long) '4', (long) (short) 1);
        int int14 = delegatedDateTimeField4.get((long) 292278993);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime dateTime10 = dateTime6.plusSeconds((int) (byte) -1);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 9, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate1.getFields();
        int int7 = localDate1.getYearOfEra();
        java.lang.String str8 = localDate1.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31" + "'", str8.equals("1969-12-31"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime16 = dateTime11.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) '4');
        boolean boolean19 = gregorianChronology9.equals((java.lang.Object) dateTime16);
        boolean boolean21 = dateTime16.isBefore((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            long long3 = dateTimeFormatter1.parseMillis("1978");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1978\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.hourOfHalfday();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(70, (int) (byte) 1, 9, 2000, (int) (short) 100, 2000, 16, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime7 = dateTime2.minusHours((int) (short) -1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((-1));
        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime18);
        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        int int23 = dateTime15.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600000 + "'", int2 == 57600000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property3 = localDate2.dayOfWeek();
        org.joda.time.LocalDate localDate5 = localDate2.minusWeeks((-1));
        int int6 = localDate2.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 8);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate15 = localDate12.plus(readablePeriod14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate15, 20, locale17);
        long long20 = offsetDateTimeField10.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField10.getType();
        boolean boolean22 = localDate2.isSupported(dateTimeFieldType21);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTime();
        int int39 = dateTime37.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime37.plus(readableDuration41);
        org.joda.time.DateTime.Property property43 = dateTime37.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 8);
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property50 = localDate49.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate52 = localDate49.plus(readablePeriod51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate52, 20, locale54);
        long long57 = offsetDateTimeField47.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField47.getType();
        int int59 = dateTime37.get(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType58, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType58);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertNotNull(dateMidnight40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1970 + "'", int59 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMinuteOfDay(1978);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField9 = gregorianChronology8.months();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2000, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2000) + "'", int2 == (-2000));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.roundHalfEven((long) 57600000);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 57600000L + "'", long49 == 57600000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendPattern("70");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfMonth();
        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int int11 = localDate7.compareTo(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundHalfCeilingCopy();
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withYear(292279001);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279001 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        int int8 = property5.getMinimumValue();
        java.util.Locale locale9 = null;
        int int10 = property5.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "70" + "'", str7.equals("70"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsShortText(readablePartial6, 58946008, locale8);
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 58944326);
        java.lang.String str12 = delegatedDateTimeField4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "58946008" + "'", str9.equals("58946008"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[yearOfEra]" + "'", str12.equals("DateTimeField[yearOfEra]"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withDayOfWeek(58939619);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58939619 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundHalfCeilingCopy();
        org.joda.time.Interval interval5 = localDate4.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime6 = localDate4.toDateTimeAtMidnight();
        int int7 = dateTime6.getYearOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        try {
            long long52 = zeroIsMaxDateTimeField47.set(0L, "PST");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 58937835, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology2.seconds();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        long long8 = offsetDateTimeField3.roundCeiling((long) 'a');
        java.lang.String str9 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600000L + "'", long8 == 3600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hourOfDay" + "'", str9.equals("hourOfDay"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 31536000000L + "'", long0 == 31536000000L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(52L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969-12-31");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(3600000L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property3 = localDate1.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 0, 0, 0, 2, 58944987);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944987 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 292279001);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.String str3 = dateTimeFormatter1.print((long) 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T000002Z" + "'", str3.equals("T000002Z"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears((int) ' ');
        boolean boolean10 = dateTime8.isEqual(3599999L);
        org.joda.time.LocalDate localDate11 = dateTime8.toLocalDate();
        int int12 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField9 = gregorianChronology8.months();
        org.joda.time.Chronology chronology10 = gregorianChronology8.withUTC();
        try {
            long long15 = gregorianChronology8.getDateTimeMillis((int) (byte) 10, 166, 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-25200000) + "'", int5 == (-25200000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long8 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getName(3600000L, locale11);
//        int int14 = dateTimeZone1.getOffsetFromLocal(31536000000L);
//        long long18 = dateTimeZone1.convertLocalToUTC((long) 1970, false, (long) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-25200000) + "'", int5 == (-25200000));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28801970L + "'", long18 == 28801970L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate1.getFields();
        int int7 = localDate1.getYearOfEra();
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusYears((int) ' ');
        int int14 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime11);
        long long17 = dateTimeZone10.adjustOffset(0L, false);
        org.joda.time.DateTime dateTime18 = localDate1.toDateTime(localTime8, dateTimeZone10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-25200000) + "'", int14 == (-25200000));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28798081L) + "'", long6 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (-28798062L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28798062L) + "'", long2 == (-28798062L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfSecond(6, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        try {
            long long11 = julianChronology0.getDateTimeMillis(2, 6, 0, 8, 2000, (int) (short) 0, (-58942414));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(0L, (long) 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        int[] intArray3 = partial0.getValues();
        int[] intArray4 = partial0.getValues();
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfMinute((-58942414), 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        int int49 = zeroIsMaxDateTimeField47.getMinimumValue((long) 62566122);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate4 = localDate1.minusWeeks((int) ' ');
        int int5 = localDate4.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendPattern("70");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendMillisOfDay((-28798030));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        int int10 = delegatedDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        int int5 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(58944326, 0, 0, 166, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime0.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            boolean boolean7 = yearMonthDay5.isAfter(readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        int int2 = dateTime0.getYearOfCentury();
//        int int3 = dateTime0.getHourOfDay();
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate6 = localDate4.plusWeeks(57600001);
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks((int) (byte) -1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.withFieldAdded(durationFieldType4, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial3 = partial0.plus(readablePeriod2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.withFieldAddWrapped(durationFieldType4, 292278969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(partial3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.yearOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology2);
        int[] intArray6 = localDate5.getValues();
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
//        org.joda.time.DurationField durationField3 = gJChronology1.millis();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getCenturyOfEra();
//        int int8 = dateTime6.getDayOfYear();
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime6.toYearMonthDay();
//        boolean boolean10 = localDate4.equals((java.lang.Object) dateTime6);
//        int int11 = dateTime6.getYear();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(31536000000L, (long) 58942414);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 535L + "'", long2 == 535L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
//        java.lang.String str11 = dateTime9.toString("58944080");
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((-1));
//        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime27 = dateTime25.plusYears((int) ' ');
//        int int28 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        long long31 = dateTimeZone24.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.clockhourOfHalfday();
//        java.lang.String str34 = gregorianChronology32.toString();
//        int int35 = gregorianChronology32.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime9.toMutableDateTime((org.joda.time.Chronology) gregorianChronology32);
//        int int38 = mutableDateTime37.getDayOfWeek();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62570091 + "'", int2 == 62570091);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-25200000) + "'", int28 == (-25200000));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str34.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("1978");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1978\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((long) (-1));
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = offsetDateTimeField3.getAsText(readablePartial6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 2019);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        java.lang.Number number9 = illegalFieldValueException2.getUpperBound();
        java.lang.String str10 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str11 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfSecond(6, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("58946008", "", false, 292278969, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 16, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-84L) + "'", long2 == (-84L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 31536000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2724499533240000000L + "'", long1 == 2724499533240000000L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.lang.String str3 = dateTimeZone1.getShortName((long) 292279001);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((-1));
        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime18);
        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.plusYears((int) ' ');
        int int28 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime25);
        long long31 = dateTimeZone24.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.clockhourOfHalfday();
        java.lang.String str34 = gregorianChronology32.toString();
        int int35 = gregorianChronology32.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime9.toMutableDateTime((org.joda.time.Chronology) gregorianChronology32);
        java.util.GregorianCalendar gregorianCalendar38 = dateTime9.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str34.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(gregorianCalendar38);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean9 = iSOChronology7.equals((java.lang.Object) "58939886");
        org.joda.time.Chronology chronology10 = iSOChronology7.withUTC();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(2002, 62570091, 1978, 58939619, (int) (byte) 0, 1969, (int) (short) 1, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58939619 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add(0L, (long) 10);
        boolean boolean18 = offsetDateTimeField3.isLeap(2440587L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("58944080", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("58944696", (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate1.getFields();
        java.util.Date date7 = localDate1.toDate();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.fromDateFields(date7);
        boolean boolean10 = localDate8.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
//        org.joda.time.LocalDate localDate12 = property11.withMaximumValue();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate12, locale13);
//        int int17 = delegatedDateTimeField4.getDifference((long) 28800000, (long) 292278993);
//        int int19 = delegatedDateTimeField4.get((long) 70);
//        long long21 = delegatedDateTimeField4.roundCeiling((long) 9);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight25 = localDate23.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = dateTimeZone27.getShortName(1L, locale29);
//        org.joda.time.DateTime dateTime31 = localDate23.toDateTimeAtStartOfDay(dateTimeZone27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter32.withZoneUTC();
//        boolean boolean34 = localDate23.equals((java.lang.Object) dateTimeFormatter32);
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.yearOfEra();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology37);
//        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology37);
//        int[] intArray41 = localDate40.getValues();
//        try {
//            int[] intArray43 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localDate23, (int) (byte) -1, intArray41, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "292278969" + "'", str14.equals("292278969"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31536000000L + "'", long21 == 31536000000L);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateMidnight25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(intArray41);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.hourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
        org.joda.time.DurationField durationField51 = delegatedDateTimeField50.getDurationField();
        int int53 = delegatedDateTimeField50.getLeapAmount((long) 58940097);
        org.joda.time.Partial partial54 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = partial54.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray56 = partial54.getFieldTypes();
        int[] intArray57 = partial54.getValues();
        int[] intArray58 = new int[] {};
        int int59 = delegatedDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) partial54, intArray58);
        java.util.Locale locale60 = null;
        try {
            java.lang.String str61 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) partial54, locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292278993 + "'", int59 == 292278993);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtCurrentTime();
        boolean boolean8 = dateTime6.isAfter((-28799968L));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.seconds();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((int) ' ');
//        int int10 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        long long13 = dateTimeZone6.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone6.getName(3600000L, locale16);
//        org.joda.time.DateTime dateTime18 = localDate4.toDateTimeAtMidnight(dateTimeZone6);
//        org.joda.time.DateTime.Property property19 = dateTime18.year();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.plus((long) 166);
        boolean boolean3 = instant2.isBeforeNow();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long13 = cachedDateTimeZone11.convertUTCToLocal(0L);
        boolean boolean15 = cachedDateTimeZone11.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(315532800000L, chronology1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        int int2 = dateTimeFormatter1.getDefaultYear();
        boolean boolean3 = dateTimeFormatter1.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("20");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime0.toGregorianCalendar();
        org.joda.time.Instant instant5 = dateTime0.toInstant();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getCenturyOfEra();
        int int2 = dateTime0.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime0.toYearMonthDay();
        long long4 = dateTime0.getMillis();
        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(58944579);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(62566122);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsShortText(readablePartial6, 58946008, locale8);
        boolean boolean10 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "58946008" + "'", str9.equals("58946008"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        int int11 = delegatedDateTimeField4.getMaximumValue((long) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292278993 + "'", int11 == 292278993);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        int int49 = zeroIsMaxDateTimeField47.getMaximumValue((long) 'a');
        try {
            long long52 = zeroIsMaxDateTimeField47.set((long) 1969, (-2000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2000 for yearOfEra must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 86400000 + "'", int49 == 86400000);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.Instant instant3 = instant1.withMillis((long) 58944987);
        org.joda.time.Instant instant5 = instant3.withMillis(3599999L);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.halfdayOfDay();
        java.lang.Object obj2 = null;
        boolean boolean3 = copticChronology0.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.plus((long) 20);
        boolean boolean7 = copticChronology0.equals((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate5 = localDate3.withYearOfCentury((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(2724499533240000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2724499533240000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime0.withMinuteOfHour(6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.minutes();
        org.joda.time.DurationField durationField5 = gJChronology1.weeks();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime1.minusWeeks(58944326);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property11.withMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate12, locale13);
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField4.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "292278969" + "'", str14.equals("292278969"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime6.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.plus((long) 166);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant2.withDurationAdded(readableDuration3, 58942414);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant8 = instant2.withDurationAdded(readableDuration6, (int) '4');
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfSecond(6, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMinuteOfHour(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property6 = localDate4.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long55 = zeroIsMaxDateTimeField47.getDifferenceAsLong(1844724137788L, (long) (short) 100);
        int int57 = zeroIsMaxDateTimeField47.getMaximumValue((long) 1970);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField47.getLeapDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1844724137688L + "'", long55 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 86400000 + "'", int57 == 86400000);
        org.junit.Assert.assertNull(durationField58);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfMonth();
        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfEra();
        int int11 = localDate7.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfMonth();
        org.joda.time.LocalDate localDate4 = property2.addToCopy(166);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.yearOfEra();
        org.joda.time.DurationField durationField11 = gJChronology9.millis();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology9.era();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology9.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        long long18 = dateTimeZone1.getMillisKeepLocal(dateTimeZone15, (long) ' ');
        long long21 = dateTimeZone15.convertLocalToUTC((long) (-28798030), true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28799968L) + "'", long18 == (-28799968L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28798030L) + "'", long21 == (-28798030L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add((long) 16, 2L);
        long long18 = offsetDateTimeField3.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 63072000016L + "'", long16 == 63072000016L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        int int8 = property7.getMinimumValueOverall();
        org.joda.time.DateTime dateTime10 = property7.setCopy((int) (short) 100);
        java.util.Locale locale12 = null;
        org.joda.time.DateTime dateTime13 = property7.setCopy("20", locale12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.plusYears((int) ' ');
        int int19 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime16);
        long long21 = dateTimeZone15.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime23 = dateTime13.withZone(dateTimeZone15);
        java.lang.String str24 = dateTimeZone15.getID();
        org.joda.time.Interval interval25 = localDate4.toInterval(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28799999L) + "'", long21 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval25);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        java.lang.String str2 = partial0.toStringList();
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("America/Los_Angeles", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        long long51 = zeroIsMaxDateTimeField47.roundHalfCeiling((long) (-10));
        long long54 = zeroIsMaxDateTimeField47.set((long) 57602019, "58941222");
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-10L) + "'", long51 == (-10L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 87741222L + "'", long54 == 87741222L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(57600001, (-10));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long18 = dateTimeZone14.getMillisKeepLocal(dateTimeZone16, (long) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter12.withZone(dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0, dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder10, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28798081L) + "'", long18 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(gJChronology20);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime0.withMillis((long) 58939619);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withZoneUTC();
        int int11 = dateTimeFormatter10.getDefaultYear();
        java.lang.String str12 = dateTime8.toString(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2000 + "'", int11 == 2000);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "T162219Z" + "'", str12.equals("T162219Z"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTime();
        int int39 = dateTime37.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime37.plus(readableDuration41);
        org.joda.time.DateTime.Property property43 = dateTime37.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 8);
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property50 = localDate49.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate52 = localDate49.plus(readablePeriod51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate52, 20, locale54);
        long long57 = offsetDateTimeField47.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField47.getType();
        int int59 = dateTime37.get(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType58, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType58);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder0.appendYearOfCentury(16, 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertNotNull(dateMidnight40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2001, 57600001, 86400000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57602001 + "'", int3 == 57602001);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        long long7 = delegatedDateTimeField4.roundHalfEven((long) 1969);
        int int9 = delegatedDateTimeField4.getMinimumValue((long) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime0.withMillis((long) 58939619);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getLeapAmount((long) (-25200000));
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField13.getAsText((long) (-10), locale17);
        int int19 = dateTime8.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
        boolean boolean20 = dateTime8.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        long long11 = offsetDateTimeField3.roundHalfCeiling((long) 1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField3.getAsShortText(17, locale13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17" + "'", str14.equals("17"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        boolean boolean13 = cachedDateTimeZone8.isStandardOffset((long) 2000);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate4 = localDate1.plus(readablePeriod3);
        int int5 = localDate1.getYearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, (-58942414), (int) 'a', 0, 20, 0, 58946008, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58946008 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
//        org.joda.time.DurationField durationField3 = gJChronology1.millis();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone7.getShortName((long) 1970, locale10);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfMinute((-1), 58938682);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTime();
        int int39 = dateTime37.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime37.plus(readableDuration41);
        org.joda.time.DateTime.Property property43 = dateTime37.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 8);
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property50 = localDate49.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate52 = localDate49.plus(readablePeriod51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate52, 20, locale54);
        long long57 = offsetDateTimeField47.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField47.getType();
        int int59 = dateTime37.get(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType58, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType58);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder67.appendTwoDigitWeekyear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertNotNull(dateMidnight40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.minuteOfHour();
        try {
            long long18 = gregorianChronology9.getDateTimeMillis(58942414, (-58942414), 86400000, 12, 12, 0, 86400000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePeriod2, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "T162219Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime.Property property3 = dateTime0.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(0L);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.Partial partial10 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = partial10.getFormatter();
        int[] intArray12 = partial10.getValues();
        try {
            int[] intArray14 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDateTime8, 9, intArray12, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.Instant instant3 = instant1.withMillis((long) 58944987);
        org.joda.time.MutableDateTime mutableDateTime4 = instant1.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertNull(durationFieldType10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, 3599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(57602001, 58944326, 57600000, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = dateTime9.minusSeconds(2002);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime9.withFieldAdded(durationFieldType13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
//        java.util.Locale locale6 = null;
//        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
//        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
//        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
//        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
//        int int26 = localDate22.getYearOfCentury();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
//        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
//        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
//        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
//        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
//        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
//        long long55 = zeroIsMaxDateTimeField47.getDifferenceAsLong(1844724137788L, (long) (short) 100);
//        int int57 = zeroIsMaxDateTimeField47.getMaximumValue((long) 1970);
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property60 = localDate59.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight61 = localDate59.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeUtils.getZone(dateTimeZone62);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = dateTimeZone63.getShortName(1L, locale65);
//        org.joda.time.DateTime dateTime67 = localDate59.toDateTimeAtStartOfDay(dateTimeZone63);
//        org.joda.time.DateTime dateTime68 = localDate59.toDateTimeAtStartOfDay();
//        int int69 = zeroIsMaxDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate59);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1844724137688L + "'", long55 == 1844724137688L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 86400000 + "'", int57 == 86400000);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateMidnight61);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "PST" + "'", str66.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 86400000 + "'", int69 == 86400000);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime4 = localDate3.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours(62566122);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        long long19 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField20 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 57602, 62566122);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 62566122");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            long long6 = julianChronology0.getDateTimeMillis((int) (byte) 100, 0, (-10), 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        java.lang.String str3 = partial0.toString("08");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.String str5 = partial0.toString(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08" + "'", str3.equals("08"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "��:��:��.000" + "'", str5.equals("��:��:��.000"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property1.getAsText(locale3);
        org.joda.time.DurationField durationField5 = property1.getLeapDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "57602019" + "'", str4.equals("57602019"));
        org.junit.Assert.assertNull(durationField5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readablePeriod2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withFieldAdded(durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 0, 17, 86400000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [17,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        java.util.Locale locale3 = null;
        int int4 = property1.getMaximumShortTextLength(locale3);
        java.lang.String str5 = property1.getAsShortText();
        org.joda.time.DateTime dateTime6 = property1.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        java.util.Date date9 = dateTime8.toDate();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra(62570091);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62570091 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57602019" + "'", str5.equals("57602019"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 8);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate9.plus(readablePeriod11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate12, 20, locale14);
        long long17 = offsetDateTimeField7.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField7.getType();
        int int19 = localDate3.indexOf(dateTimeFieldType18);
        org.joda.time.DateTime dateTime20 = localDate3.toDateTimeAtMidnight();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20" + "'", str15.equals("20"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        try {
            long long38 = unsupportedDateTimeField36.roundCeiling((long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long13 = cachedDateTimeZone11.previousTransition(1560640937788L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560640937788L + "'", long13 == 1560640937788L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(46, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add((long) 16, 2L);
        long long18 = offsetDateTimeField3.roundFloor((long) (byte) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 63072000016L + "'", long16 == 63072000016L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology2.seconds();
        org.joda.time.DurationField durationField4 = copticChronology2.halfdays();
        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number10 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(durationFieldType11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime6 = localDate4.toDateTimeAtMidnight();
        int int7 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        try {
            long long13 = julianChronology0.getDateTimeMillis(292279001, 19, 17, 57600000, 58946632, 1978, 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        try {
            int int38 = unsupportedDateTimeField36.getMaximumValue((long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        try {
            long long9 = gJChronology1.getDateTimeMillis((-1), 0, 17, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int9 = fixedDateTimeZone7.getOffsetFromLocal((long) 58940097);
        java.util.TimeZone timeZone10 = fixedDateTimeZone7.toTimeZone();
        org.joda.time.Chronology chronology11 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 58940097 + "'", int9 == 58940097);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(3);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(1L, locale3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
//        int int7 = property6.get();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
//        int int10 = property6.compareTo((org.joda.time.ReadablePartial) localDateTime9);
//        org.joda.time.DateTime dateTime11 = property6.roundCeilingCopy();
//        java.lang.String str13 = dateTime11.toString("58941222");
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57602019 + "'", int7 == 57602019);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "58941222" + "'", str13.equals("58941222"));
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate5 = localDate3.plusWeeks(15);
        try {
            org.joda.time.LocalDate localDate7 = localDate3.withCenturyOfEra(58946632);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58946632 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        long long12 = delegatedDateTimeField4.getDifferenceAsLong((long) '4', (long) (short) 1);
        long long14 = delegatedDateTimeField4.remainder((long) 70);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.yearOfEra();
        org.joda.time.DurationField durationField18 = gJChronology16.millis();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTime dateTime20 = localDate19.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property21 = localDate19.weekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.LocalDate localDate29 = localDate26.plus(readablePeriod28);
        int[] intArray31 = copticChronology24.get((org.joda.time.ReadablePartial) localDate29, (long) 12);
        try {
            int[] intArray33 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localDate19, 58946632, intArray31, 58946008);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58946632");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 70L + "'", long14 == 70L);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.monthOfYear();
        org.joda.time.DurationField durationField6 = gJChronology1.centuries();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        long long4 = dateTime3.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((int) ' ');
        int int16 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime13);
        long long18 = dateTimeZone12.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        boolean boolean20 = cachedDateTimeZone8.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        org.joda.time.Instant instant23 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.Instant instant25 = instant23.withMillis((long) 58944987);
        int int26 = cachedDateTimeZone21.getOffset((org.joda.time.ReadableInstant) instant25);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28799999L) + "'", long18 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight7 = localDate5.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = localDate5.get(dateTimeFieldType22);
        org.joda.time.LocalDate localDate25 = localDate5.plusDays(0);
        int int26 = localDate5.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2001 + "'", int23 == 2001);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime0.toYearMonthDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(19, 2, 3, 6, 28800000, 292279001);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        try {
            long long38 = unsupportedDateTimeField36.remainder((long) 58940097);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DurationField durationField2 = gJChronology0.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.tTime();
        boolean boolean4 = gJChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.minusWeeks((-1));
        long long9 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate7, (long) 2);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = localDate11.toDateTime(localTime13, dateTimeZone14);
        org.joda.time.DateTimeField[] dateTimeFieldArray16 = localDate11.getFields();
        java.util.Date date17 = localDate11.toDate();
        long long19 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate11, (long) 57600000);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        int int22 = dateTime20.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight23 = dateTime20.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.plus(readableDuration24);
        org.joda.time.DateTime.Property property26 = dateTime20.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = dateTime20.get(dateTimeFieldType41);
        org.joda.time.LocalDate.Property property43 = localDate11.property(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 518400002L + "'", long9 == 518400002L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28800000L) + "'", long19 == (-28800000L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1969 + "'", int42 == 1969);
        org.junit.Assert.assertNotNull(property43);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 21, 86400000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = partial1.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        int[] intArray4 = partial1.getValues();
        boolean boolean5 = partial0.isBefore((org.joda.time.ReadablePartial) partial1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.Partial partial8 = partial1.withPeriodAdded(readablePeriod6, 2000);
        org.joda.time.Chronology chronology9 = partial8.getChronology();
        org.junit.Assert.assertNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
//        java.util.Locale locale6 = null;
//        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
//        int int13 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        long long15 = dateTimeZone9.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime17 = dateTime7.withZone(dateTimeZone9);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone9.getName((long) 28800000, locale19);
//        long long23 = dateTimeZone9.adjustOffset((long) 58944987, false);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28799999L) + "'", long15 == (-28799999L));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 58944987L + "'", long23 == 58944987L);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        int int10 = delegatedDateTimeField7.getLeapAmount((long) 58940097);
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = partial11.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = partial11.getFieldTypes();
        int[] intArray14 = partial11.getValues();
        int[] intArray15 = new int[] {};
        int int16 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) partial11, intArray15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.halfdayOfDay();
        org.joda.time.Partial partial20 = new org.joda.time.Partial(dateTimeFieldTypeArray2, intArray15, (org.joda.time.Chronology) copticChronology18);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType22 = partial20.getFieldType(292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 292278993");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292278993 + "'", int16 == 292278993);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        int int10 = dateTime8.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readableDuration12);
        org.joda.time.DateTime.Property property14 = dateTime8.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate20.plus(readablePeriod22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate23, 20, locale25);
        long long28 = offsetDateTimeField18.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField18.getType();
        int int30 = dateTime8.get(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType29, 1970, 1969);
        boolean boolean35 = localDate1.isSupported(dateTimeFieldType29);
        org.joda.time.LocalDate.Property property36 = localDate1.yearOfEra();
        org.joda.time.LocalDate localDate37 = property36.withMinimumValue();
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property40 = localDate39.dayOfMonth();
        org.joda.time.LocalDate localDate41 = property40.roundHalfEvenCopy();
        boolean boolean42 = localDate37.isEqual((org.joda.time.ReadablePartial) localDate41);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate40 = localDate38.withCenturyOfEra(15);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.hourOfDay();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44, dateTimeFieldType45);
        org.joda.time.DurationField durationField47 = delegatedDateTimeField46.getDurationField();
        int int49 = delegatedDateTimeField46.getLeapAmount((long) 58940097);
        org.joda.time.Partial partial50 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = partial50.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray52 = partial50.getFieldTypes();
        int[] intArray53 = partial50.getValues();
        int[] intArray54 = new int[] {};
        int int55 = delegatedDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) partial50, intArray54);
        try {
            int[] intArray57 = unsupportedDateTimeField36.add((org.joda.time.ReadablePartial) localDate38, 58940097, intArray54, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 292278993 + "'", int55 == 292278993);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) ' ');
        int int12 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime9);
        long long15 = dateTimeZone8.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.clockhourOfHalfday();
        java.lang.String str18 = gregorianChronology16.toString();
        int int19 = gregorianChronology16.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(58940097, 2000, 365, 1, 4, 58944579, (int) (byte) -1, (org.joda.time.Chronology) gregorianChronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944579 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField5 = gJChronology1.minutes();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks(1978);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withEra(19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 0);
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimePrinter11);
        boolean boolean13 = dateTimeFormatterBuilder4.canBuildParser();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) ' ');
        boolean boolean18 = dateTime16.isEqual(3599999L);
        org.joda.time.LocalDate localDate19 = dateTime16.toLocalDate();
        org.joda.time.DateTime dateTime20 = localDate19.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight21 = localDate19.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 8);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.LocalDate localDate30 = localDate27.plus(readablePeriod29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) localDate30, 20, locale32);
        long long35 = offsetDateTimeField25.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField25.getType();
        int int37 = localDate19.get(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType36, 46, 17);
        boolean boolean41 = localDate2.isSupported(dateTimeFieldType36);
        boolean boolean42 = localDate0.isEqual((org.joda.time.ReadablePartial) localDate2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20" + "'", str33.equals("20"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2001 + "'", int37 == 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(2002);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType28, (int) (short) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType28);
        java.lang.String str33 = delegatedDateTimeField32.getName();
        java.util.Locale locale36 = null;
        try {
            long long37 = delegatedDateTimeField32.set((long) 4, "PST", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "yearOfEra" + "'", str33.equals("yearOfEra"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = partial0.getFormatter();
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeFormatter2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(57600001, (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DurationField durationField3 = gJChronology0.months();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        boolean boolean6 = delegatedDateTimeField4.isLeap(3600000L);
        boolean boolean7 = delegatedDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add(0L, (long) 10);
        int int19 = offsetDateTimeField3.getDifference(10L, 2440587L);
        long long21 = offsetDateTimeField3.roundHalfCeiling((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1978, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 1978");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear(3);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("dayOfMonth", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        int int9 = delegatedDateTimeField4.getDifference((long) 6, (long) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) ' ');
        int int12 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime9);
        long long15 = dateTimeZone8.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.clockhourOfHalfday();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(58936847, 62566122, 15, 57602001, 9, 1978, 28800000, (org.joda.time.Chronology) gregorianChronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57602001 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property1.roundFloorCopy();
        int int8 = property1.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        int int13 = dateTime11.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight14 = dateTime11.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
        org.joda.time.DateTime.Property property17 = dateTime11.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        int int33 = dateTime11.get(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType32, 1970, 1969);
        boolean boolean38 = localDate4.isSupported(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType32, 57600001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTime(chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        int int13 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime5.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology15 = dateTime14.getChronology();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        org.joda.time.Partial partial37 = new org.joda.time.Partial();
        org.joda.time.Partial partial38 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = partial38.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray40 = partial38.getFieldTypes();
        int[] intArray41 = partial38.getValues();
        boolean boolean42 = partial37.isBefore((org.joda.time.ReadablePartial) partial38);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.Partial partial45 = partial38.withPeriodAdded(readablePeriod43, 2000);
        java.lang.String str46 = partial38.toStringList();
        try {
            int int47 = unsupportedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) partial38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(partial45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "[]" + "'", str46.equals("[]"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        long long12 = delegatedDateTimeField4.getDifferenceAsLong((long) '4', (long) (short) 1);
        long long14 = delegatedDateTimeField4.roundCeiling(315532800000L);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.LocalTime localTime18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = localDate16.toDateTime(localTime18, dateTimeZone19);
        org.joda.time.DateTimeField[] dateTimeFieldArray21 = localDate16.getFields();
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate16, 2002, locale23);
        int int26 = delegatedDateTimeField4.getLeapAmount((long) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 315532800000L + "'", long14 == 315532800000L);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFieldArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2002" + "'", str24.equals("2002"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long14 = dateTimeZone10.getMillisKeepLocal(dateTimeZone12, (long) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter8.withZone(dateTimeZone12);
        java.lang.String str16 = dateTime7.toString(dateTimeFormatter8);
        java.lang.StringBuffer stringBuffer17 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.yearOfEra();
        org.joda.time.DurationField durationField21 = gJChronology19.millis();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfMonth();
        org.joda.time.LocalDate localDate24 = property23.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.DurationField durationField28 = gJChronology26.millis();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.LocalDate localDate31 = localDate29.plusWeeks(57600001);
        boolean boolean32 = localDate24.isEqual((org.joda.time.ReadablePartial) localDate31);
        try {
            dateTimeFormatter8.printTo(stringBuffer17, (org.joda.time.ReadablePartial) localDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28798081L) + "'", long14 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "00520103T170002.019-0752" + "'", str16.equals("00520103T170002.019-0752"));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        try {
            int int37 = unsupportedDateTimeField36.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add((long) 16, 2L);
        long long18 = offsetDateTimeField3.remainder((long) 21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 63072000016L + "'", long16 == 63072000016L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 21L + "'", long18 == 21L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getCenturyOfEra();
        int int2 = dateTime0.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime0.toYearMonthDay();
        long long4 = dateTime0.getMillis();
        org.joda.time.LocalDate localDate5 = dateTime0.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime0.plusYears(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.yearOfEra();
        org.joda.time.DurationField durationField6 = gJChronology4.millis();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime8 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property9 = localDate7.weekyear();
        org.joda.time.LocalDate.Property property10 = localDate7.centuryOfEra();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
        boolean boolean9 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property10 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property11 = dateTime3.yearOfEra();
        int int12 = dateTime3.getYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.millisOfSecond();
        org.joda.time.DurationField durationField6 = gJChronology1.weekyears();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("69", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(15);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear(0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        int int11 = offsetDateTimeField3.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) iSOChronology0);
        java.util.Date date4 = localDate3.toDate();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58944696");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"58944696\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"58944696\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName(0L, locale2);
//        long long5 = dateTimeZone0.convertUTCToLocal((-28800000L));
//        long long7 = dateTimeZone0.convertUTCToLocal((long) 12);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-57600000L) + "'", long5 == (-57600000L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799988L) + "'", long7 == (-28799988L));
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int7 = delegatedDateTimeField4.getDifference(28801970L, 57600000L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.hourOfDay();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.Chronology) iSOChronology8);
        int int12 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28798030) + "'", int7 == (-28798030));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58944696");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        int int5 = dateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2002 + "'", int5 == 2002);
    }
}

