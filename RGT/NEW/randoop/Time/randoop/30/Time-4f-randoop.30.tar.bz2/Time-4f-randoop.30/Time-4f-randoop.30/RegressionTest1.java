import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
//        org.joda.time.LocalDate localDate12 = property11.roundFloorCopy();
//        org.joda.time.LocalDate localDate14 = localDate12.plusWeeks(15);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.LocalDate localDate16 = localDate12.minus(readablePeriod15);
//        boolean boolean17 = gregorianChronology8.equals((java.lang.Object) readablePeriod15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-53998081L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.LocalDate localDate5 = localDate2.plus(readablePeriod4);
        java.util.Date date6 = localDate5.toDate();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate9 = localDate5.withYearOfCentury(2);
        try {
            org.joda.time.LocalDate localDate11 = localDate9.withDayOfYear(292278969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278969 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970W013" + "'", str7.equals("1970W013"));
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        int int19 = offsetDateTimeField3.getMinimumValue(315532800000L);
        long long22 = offsetDateTimeField3.set((long) (byte) 10, "57602019");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1817681729040000010L + "'", long22 == 1817681729040000010L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) ' ');
//        int int7 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = dateTime4.plusMonths((int) (byte) -1);
//        int int10 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTime4);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths(2019);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
//        int int7 = dateTime5.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
//        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
//        int int27 = dateTime5.get(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime38 = dateTime37.toDateTime();
//        int int39 = dateTime37.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime37.plus(readableDuration41);
//        org.joda.time.DateTime.Property property43 = dateTime37.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 8);
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property50 = localDate49.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.LocalDate localDate52 = localDate49.plus(readablePeriod51);
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate52, 20, locale54);
//        long long57 = offsetDateTimeField47.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField47.getType();
//        int int59 = dateTime37.get(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType58, 1970, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType58);
//        boolean boolean65 = dateTimeFormatterBuilder64.canBuildPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = partial1.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        int[] intArray4 = partial1.getValues();
        boolean boolean5 = partial0.isBefore((org.joda.time.ReadablePartial) partial1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.Partial partial8 = partial1.withPeriodAdded(readablePeriod6, 2000);
        java.lang.String str9 = partial1.toStringList();
        try {
            int int11 = partial1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.monthOfYear();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology$ImpreciseCutoverField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withDayOfWeek(58944326);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944326 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate5 = localDate3.plusWeeks(15);
        try {
            org.joda.time.Instant instant6 = new org.joda.time.Instant((java.lang.Object) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey(0L);
        boolean boolean11 = cachedDateTimeZone8.isFixed();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        boolean boolean51 = zeroIsMaxDateTimeField47.isLeap((long) 2051);
        long long54 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 69);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-28798012L) + "'", long54 == (-28798012L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 15, 58938682, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        try {
            long long8 = delegatedDateTimeField4.set((-53998081L), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant2 = instant0.plus((long) 166);
//        org.joda.time.Instant instant4 = instant0.plus((long) 2019);
//        org.joda.time.Instant instant6 = instant0.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime7.minusDays(58938682);
//        int int11 = dateTime7.getMillisOfSecond();
//        boolean boolean12 = instant0.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int7 = delegatedDateTimeField4.getDifference(28801970L, 57600000L);
        long long9 = delegatedDateTimeField4.roundCeiling(10L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 57602);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28798030) + "'", int7 == (-28798030));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        org.joda.time.DateTime dateTime6 = property1.withMinimumValue();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
//        int int13 = dateTime11.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight14 = dateTime11.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime11.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
//        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
//        int int33 = dateTime11.get(dateTimeFieldType32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType32, 1970, 1969);
//        boolean boolean38 = localDate4.isSupported(dateTimeFieldType32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType32, 57600001);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime42 = dateTime41.toDateTime();
//        int int43 = dateTime41.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight44 = dateTime41.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime41.plus(readableDuration45);
//        org.joda.time.DateTime.Property property47 = dateTime41.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 8);
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property54 = localDate53.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod55 = null;
//        org.joda.time.LocalDate localDate56 = localDate53.plus(readablePeriod55);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) localDate56, 20, locale58);
//        long long61 = offsetDateTimeField51.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField51.getType();
//        int int63 = dateTime41.get(dateTimeFieldType62);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray64 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType32, dateTimeFieldType62 };
//        org.joda.time.Partial partial65 = new org.joda.time.Partial();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = partial65.getFormatter();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray67 = partial65.getFieldTypes();
//        int[] intArray68 = partial65.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField71 = iSOChronology69.dayOfMonth();
//        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property74 = localDate73.dayOfWeek();
//        org.joda.time.LocalDate localDate76 = localDate73.minusWeeks((-1));
//        long long78 = iSOChronology69.set((org.joda.time.ReadablePartial) localDate76, (long) 2);
//        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property81 = localDate80.centuryOfEra();
//        org.joda.time.LocalTime localTime82 = null;
//        org.joda.time.DateTimeZone dateTimeZone83 = null;
//        org.joda.time.DateTime dateTime84 = localDate80.toDateTime(localTime82, dateTimeZone83);
//        org.joda.time.DateTimeField[] dateTimeFieldArray85 = localDate80.getFields();
//        java.util.Date date86 = localDate80.toDate();
//        long long88 = iSOChronology69.set((org.joda.time.ReadablePartial) localDate80, (long) 57600000);
//        try {
//            org.joda.time.Partial partial89 = new org.joda.time.Partial(dateTimeFieldTypeArray64, intArray68, (org.joda.time.Chronology) iSOChronology69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "20" + "'", str59.equals("20"));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1969 + "'", int63 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray64);
//        org.junit.Assert.assertNull(dateTimeFormatter66);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray67);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 518400002L + "'", long78 == 518400002L);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray85);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-28800000L) + "'", long88 == (-28800000L));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-28798030));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.year();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate6 = localDate4.plusWeeks(57600001);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate11 = localDate8.minusWeeks((int) ' ');
        int int12 = localDate8.getWeekyear();
        int int13 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateMidnight dateMidnight14 = localDate8.toDateMidnight();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateMidnight14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 58940097);
        int int8 = fixedDateTimeZone4.getOffset((long) '#');
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        int int11 = fixedDateTimeZone4.getStandardOffset((long) 166);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58940097 + "'", int6 == 58940097);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 58940097 + "'", int8 == 58940097);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1978);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfWeek((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusWeeks(0);
//        org.joda.time.DateTime dateTime8 = dateTime2.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
//        java.util.Locale locale6 = null;
//        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
//        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
//        int int9 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57602 + "'", int9 == 57602);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, 16);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute(28800000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((int) (byte) -1);
        java.io.Writer writer5 = null;
        try {
            dateTimeFormatter4.printTo(writer5, (long) 166);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate3.plus(readablePeriod5);
        int[] intArray8 = copticChronology1.get((org.joda.time.ReadablePartial) localDate6, (long) 12);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property11.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = localDate12.plusWeeks(15);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate12.minus(readablePeriod15);
        long long18 = copticChronology1.set((org.joda.time.ReadablePartial) localDate16, (long) 19);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 6743775600019L + "'", long18 == 6743775600019L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(2051, 2002, 9, 0, 69, 2, 57600001, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
//        int int7 = dateTime5.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
//        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
//        int int27 = dateTime5.get(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter36 = dateTimeFormatterBuilder33.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendHourOfDay(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimePrinter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate.Property property3 = localDate1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.LocalDate localDate6 = property3.setCopy("58946008");
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.LocalDate localDate5 = localDate2.plus(readablePeriod4);
//        java.util.Date date6 = localDate5.toDate();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.yearOfEra();
//        org.joda.time.DurationField durationField11 = gJChronology9.millis();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.LocalDate.Property property13 = localDate12.dayOfMonth();
//        org.joda.time.LocalDate localDate15 = localDate12.minusDays(2002);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.LocalDate localDate17 = localDate12.minus(readablePeriod16);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfWeek();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime27 = dateTime26.toDateTime();
//        int int28 = dateTime26.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight29 = dateTime26.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime26.plus(readableDuration30);
//        org.joda.time.DateTime.Property property32 = dateTime26.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property39 = localDate38.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.LocalDate localDate41 = localDate38.plus(readablePeriod40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate41, 20, locale43);
//        long long46 = offsetDateTimeField36.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField36.getType();
//        int int48 = dateTime26.get(dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder21.appendSignedDecimal(dateTimeFieldType47, 1970, 1969);
//        boolean boolean53 = localDate19.isSupported(dateTimeFieldType47);
//        boolean boolean54 = localDate17.isSupported(dateTimeFieldType47);
//        boolean boolean55 = localDate5.isSupported(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970W013" + "'", str7.equals("1970W013"));
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "20" + "'", str44.equals("20"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        long long47 = dividedDateTimeField45.remainder(1844724137688L);
        int int50 = dividedDateTimeField45.getDifference((long) 2, (long) 58944579);
        int int51 = dividedDateTimeField45.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1844724137688L + "'", long47 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate5 = localDate3.plusWeeks(15);
        org.joda.time.LocalTime localTime6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long12 = dateTimeZone8.getMillisKeepLocal(dateTimeZone10, (long) 2019);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTime(localTime6, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.DateTime dateTime16 = dateTime13.withZoneRetainFields(dateTimeZone15);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28798081L) + "'", long12 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        org.joda.time.DateTime dateTime10 = localDate1.toDateTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) ' ');
//        int int17 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        long long19 = dateTimeZone13.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.DateTime dateTime20 = localDate1.toDateTime(localTime11, dateTimeZone13);
//        int int21 = localDate1.getDayOfYear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28799999L) + "'", long19 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        int int6 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime2.withMinuteOfHour(31);
//        int int9 = dateTime8.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        long long51 = zeroIsMaxDateTimeField47.roundHalfCeiling((long) (-10));
        java.util.Locale locale52 = null;
        int int53 = zeroIsMaxDateTimeField47.getMaximumTextLength(locale52);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-10L) + "'", long51 == (-10L));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 8 + "'", int53 == 8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate6 = property5.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.LocalDate localDate13 = localDate11.plusWeeks(57600001);
        boolean boolean14 = localDate6.isEqual((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.LocalDate localDate16 = localDate6.plusDays(0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, 1844724137788L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1844724137788L) + "'", long2 == (-1844724137788L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(212199573600001L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long8 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime11, dateTimeZone12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate9.getFields();
        int int15 = localDate9.getYearOfEra();
        int int16 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray19 = null;
        try {
            int[] intArray21 = delegatedDateTimeField4.addWrapPartial(readablePartial17, (-28798030), intArray19, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.append(dateTimePrinter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatter28.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder22.append(dateTimePrinter29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter29, dateTimeParser32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimePrinter29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
//        int int2 = dateTime0.getMonthOfYear();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMinutes(70);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime0.withZoneRetainFields(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property1.getAsText(locale3);
//        org.joda.time.DateTime dateTime5 = property1.roundHalfEvenCopy();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime5.withDate(57602, 1105894, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1105894 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "57602019" + "'", str4.equals("57602019"));
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.yearOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long10 = cachedDateTimeZone8.nextTransition((long) (-2000));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2000L) + "'", long10 == (-2000L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.minusWeeks((-1));
        int int8 = localDate4.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 8);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate14.plus(readablePeriod16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate17, 20, locale19);
        long long22 = offsetDateTimeField12.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField12.getType();
        boolean boolean24 = localDate4.isSupported(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType23, (int) (short) 10);
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20" + "'", str20.equals("20"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("58944080");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.plusMonths(58942414);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(70);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-1844724137788L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        long long43 = unsupportedDateTimeField36.add(518400002L, 58944579);
        try {
            long long46 = unsupportedDateTimeField36.set(518400002L, "1970W013");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2546406331200002L + "'", long43 == 2546406331200002L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        try {
            long long54 = skipDateTimeField52.roundHalfEven((long) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [9,292279001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("58944696", (java.lang.Number) (-84L), (java.lang.Number) (byte) 1, (java.lang.Number) 2000);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) 2019);
        long long8 = dateTimeZone1.adjustOffset((long) (byte) 1, true);
        long long11 = dateTimeZone1.adjustOffset((long) 999, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28798081L) + "'", long5 == (-28798081L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 999L + "'", long11 == 999L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate3 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        long long43 = unsupportedDateTimeField36.add(518400002L, 58944579);
        java.util.Locale locale44 = null;
        try {
            int int45 = unsupportedDateTimeField36.getMaximumTextLength(locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2546406331200002L + "'", long43 == 2546406331200002L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime8 = property6.setCopy(0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        long long47 = dividedDateTimeField45.remainder(1844724137688L);
        try {
            long long50 = dividedDateTimeField45.add((long) (-28798030), 2002);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1823027121 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1844724137688L + "'", long47 == 1844724137688L);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
//        int int4 = dateTime0.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((int) (byte) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 58940097);
        int int13 = fixedDateTimeZone9.getOffset((long) '#');
        boolean boolean14 = fixedDateTimeZone9.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 58940097 + "'", int11 == 58940097);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 58940097 + "'", int13 == 58940097);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long13 = cachedDateTimeZone11.convertUTCToLocal(0L);
        int int15 = cachedDateTimeZone11.getOffsetFromLocal((long) 58944326);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate16 = localDate13.minusWeeks((-1));
        int int17 = localDate13.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        boolean boolean33 = localDate13.isSupported(dateTimeFieldType32);
        boolean boolean34 = dateTime11.isSupported(dateTimeFieldType32);
        org.joda.time.DateTime.Property property35 = dateTime0.property(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(property35);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField9 = gregorianChronology8.months();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        long long47 = dividedDateTimeField45.remainder(1844724137688L);
        int int50 = dividedDateTimeField45.getDifference((long) 2, (long) 58944579);
        try {
            long long53 = dividedDateTimeField45.add(0L, (-28798030));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 690663346 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1844724137688L + "'", long47 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
//        boolean boolean3 = dateTime0.isEqual(0L);
//        int int4 = dateTime0.getWeekyear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
//        org.joda.time.DateTime dateTime10 = dateTime0.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        int int12 = fixedDateTimeZone9.getOffsetFromLocal(28801970L);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58940097 + "'", int12 == 58940097);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 58940097);
        int int8 = fixedDateTimeZone4.getOffset((long) '#');
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        try {
            org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 58944326);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58944326");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58940097 + "'", int6 == 58940097);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 58940097 + "'", int8 == 58940097);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        int int49 = zeroIsMaxDateTimeField47.getMaximumValue((long) 'a');
        long long51 = zeroIsMaxDateTimeField47.roundHalfEven((long) 58944326);
        int int53 = zeroIsMaxDateTimeField47.getMaximumValue((long) 999);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 86400000 + "'", int49 == 86400000);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 58944326L + "'", long51 == 58944326L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 86400000 + "'", int53 == 86400000);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime3 = property1.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        int int10 = dateTime8.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.plus(readableDuration12);
//        org.joda.time.DateTime.Property property14 = dateTime8.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.LocalDate localDate23 = localDate20.plus(readablePeriod22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate23, 20, locale25);
//        long long28 = offsetDateTimeField18.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField18.getType();
//        int int30 = dateTime8.get(dateTimeFieldType29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType29, 1970, 1969);
//        boolean boolean35 = localDate1.isSupported(dateTimeFieldType29);
//        try {
//            org.joda.time.LocalDate localDate37 = localDate1.withDayOfYear((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.DateTime dateTime11 = property1.addWrapFieldToCopy((-2000));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(1L, locale3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
//        int int2 = dateTime0.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(58944987);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944987 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        org.joda.time.DateTime dateTime10 = localDate1.toDateTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) ' ');
//        int int17 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        long long19 = dateTimeZone13.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.DateTime dateTime20 = localDate1.toDateTime(localTime11, dateTimeZone13);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight24 = localDate22.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getShortName(1L, locale28);
//        org.joda.time.DateTime dateTime30 = localDate22.toDateTimeAtStartOfDay(dateTimeZone26);
//        long long32 = dateTimeZone13.getMillisKeepLocal(dateTimeZone26, (long) 28800000);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int34 = dateTime33.getDayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime36 = dateTime33.withDayOfWeek((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28799999L) + "'", long19 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28800000L + "'", long32 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withMinuteOfHour(8);
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        org.joda.time.DateTime dateTime7 = property1.setCopy("2002");
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DurationField durationField41 = unsupportedDateTimeField36.getRangeDurationField();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField36.getLeapDurationField();
        java.util.Locale locale45 = null;
        try {
            long long46 = unsupportedDateTimeField36.set((long) (-58942414), "20", locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertNull(durationField42);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationField durationField4 = iSOChronology0.seconds();
        java.lang.String str5 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder((-1L));
        int int51 = zeroIsMaxDateTimeField47.getMinimumValue((long) 15);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime.Property property2 = dateTime0.millisOfSecond();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(16, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        int int53 = dividedDateTimeField46.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime0.toGregorianCalendar();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.LocalDate localDate8 = localDate5.withFieldAdded(durationFieldType6, 292278969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale9 = null;
        long long10 = offsetDateTimeField3.set((-28798081L), "08", locale9);
        long long13 = offsetDateTimeField3.add((long) (short) 1, 58944326);
        org.joda.time.DurationField durationField14 = offsetDateTimeField3.getRangeDurationField();
        try {
            long long17 = offsetDateTimeField3.set(70L, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [-1,22]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-53998081L) + "'", long10 == (-53998081L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 212199573600001L + "'", long13 == 212199573600001L);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(58938682);
        dateTimeFormatterBuilder10.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
//        java.lang.String str11 = dateTime9.toString("58944080");
//        org.joda.time.DateTime.Property property12 = dateTime9.era();
//        java.lang.String str13 = property12.getName();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57602019 + "'", int2 == 57602019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "era" + "'", str13.equals("era"));
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
//        int int7 = dateTime5.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
//        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
//        int int27 = dateTime5.get(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendHourOfDay(21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder0.appendClockhourOfDay(4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        int int10 = dateTime8.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.plus(readableDuration12);
//        org.joda.time.DateTime.Property property14 = dateTime8.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.LocalDate localDate23 = localDate20.plus(readablePeriod22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate23, 20, locale25);
//        long long28 = offsetDateTimeField18.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField18.getType();
//        int int30 = dateTime8.get(dateTimeFieldType29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType29, 1970, 1969);
//        boolean boolean35 = localDate1.isSupported(dateTimeFieldType29);
//        org.joda.time.LocalDate.Property property36 = localDate1.yearOfEra();
//        org.joda.time.LocalDate localDate37 = property36.withMinimumValue();
//        org.joda.time.DurationField durationField38 = property36.getLeapDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNull(durationField38);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(100L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfDay();
        int int3 = property2.getMinimumValueOverall();
        org.joda.time.DateTime dateTime5 = property2.setCopy((int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property2.setCopy("20", locale7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusYears((int) ' ');
        int int14 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime11);
        long long16 = dateTimeZone10.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.withZone(dateTimeZone10);
        java.lang.String str19 = dateTimeZone10.getID();
        org.joda.time.Chronology chronology20 = gJChronology0.withZone(dateTimeZone10);
        java.lang.String str21 = dateTimeZone10.getID();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28799999L) + "'", long16 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "America/Los_Angeles" + "'", str21.equals("America/Los_Angeles"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property1.roundFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks(10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        long long7 = delegatedDateTimeField4.roundHalfEven((long) 1969);
        long long9 = delegatedDateTimeField4.roundCeiling((long) 31);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        int int12 = property11.getMinimumValueOverall();
        org.joda.time.DateTime dateTime14 = property11.setCopy((int) (short) 100);
        org.joda.time.Interval interval15 = property11.toInterval();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property11.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31536000000L + "'", long9 == 31536000000L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight7 = localDate5.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = localDate5.get(dateTimeFieldType22);
        org.joda.time.LocalDate localDate25 = localDate5.plusDays(0);
        org.joda.time.LocalDate localDate27 = localDate5.withWeekOfWeekyear(15);
        org.joda.time.LocalDate.Property property28 = localDate5.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2001 + "'", int23 == 2001);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfSecond(6, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.yearOfEra();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology3.era();
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology3.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int12 = cachedDateTimeZone10.getStandardOffset((long) 69);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.plusYears((int) ' ');
        int int18 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime15);
        long long20 = dateTimeZone14.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        boolean boolean22 = cachedDateTimeZone10.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.DateTime dateTime23 = dateTime1.toDateTime(dateTimeZone14);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-28799999L) + "'", long20 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.LocalDate localDate11 = localDate9.plusWeeks(57600001);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate16 = localDate13.minusWeeks((int) ' ');
        int int17 = localDate13.getWeekyear();
        int int18 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        int int26 = dateTime24.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight27 = dateTime24.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime24.plus(readableDuration28);
        org.joda.time.DateTime.Property property30 = dateTime24.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 8);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property37 = localDate36.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate39 = localDate36.plus(readablePeriod38);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) localDate39, 20, locale41);
        long long44 = offsetDateTimeField34.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField34.getType();
        int int46 = dateTime24.get(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder23.appendShortText(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder19.appendSignedDecimal(dateTimeFieldType45, 1970, 1969);
        int int51 = localDate13.get(dateTimeFieldType45);
        boolean boolean52 = localDate4.isSupported(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "20" + "'", str42.equals("20"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1969 + "'", int51 == 1969);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(87741222L, locale11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMaximumValue();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        org.joda.time.LocalDate localDate8 = localDate5.minusWeeks((-1));
        int int9 = localDate5.getYearOfCentury();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        int int13 = property12.getMinimumValueOverall();
        org.joda.time.DateTime dateTime15 = property12.setCopy((int) (short) 100);
        java.util.Locale locale17 = null;
        org.joda.time.DateTime dateTime18 = property12.setCopy("20", locale17);
        org.joda.time.DateTime dateTime19 = property12.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField20 = property12.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime31 = dateTime29.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property34 = localDate33.dayOfWeek();
        org.joda.time.LocalDate localDate36 = localDate33.minusWeeks((-1));
        int int37 = localDate33.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 8);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property44 = localDate43.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.LocalDate localDate46 = localDate43.plus(readablePeriod45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) localDate46, 20, locale48);
        long long51 = offsetDateTimeField41.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField41.getType();
        boolean boolean53 = localDate33.isSupported(dateTimeFieldType52);
        boolean boolean54 = dateTime31.isSupported(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder23.appendDecimal(dateTimeFieldType52, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField58 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType52);
        int int59 = localDate5.get(dateTimeFieldType52);
        org.joda.time.DurationField durationField60 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 69 + "'", int37 == 69);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "20" + "'", str49.equals("20"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(57600001, (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMinuteOfHour(58936847);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long7 = fixedDateTimeZone4.previousTransition(2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        try {
            long long39 = unsupportedDateTimeField36.roundHalfFloor((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundHalfCeilingCopy();
        java.util.Locale locale6 = null;
        org.joda.time.LocalDate localDate7 = property2.setCopy("1969", locale6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        java.lang.String str42 = unsupportedDateTimeField36.getName();
        try {
            int int44 = unsupportedDateTimeField36.getLeapAmount(70L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "yearOfEra" + "'", str42.equals("yearOfEra"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour(8);
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        long long7 = delegatedDateTimeField4.roundHalfEven((long) 1969);
        long long9 = delegatedDateTimeField4.remainder((long) 1978);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1978L + "'", long9 == 1978L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        long long55 = remainderDateTimeField53.roundHalfEven((long) (-58942414));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime7 = dateTime5.plusYears((int) ' ');
        int int8 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime5);
        long long11 = dateTimeZone4.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        try {
            org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(58938682, (-2000), 2, (org.joda.time.Chronology) gregorianChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("58941222");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        long long20 = offsetDateTimeField3.set((long) (-28800000), 58937835);
        long long22 = offsetDateTimeField3.roundFloor((long) '4');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1859836041907200000L + "'", long20 == 1859836041907200000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        int int3 = dateTime1.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime1.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = dateTime1.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType22);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.DurationField durationField28 = gJChronology26.millis();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology26.era();
        org.joda.time.DurationField durationField32 = gJChronology26.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField32);
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField33.getAsText(0L, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks(1978);
        try {
            java.lang.String str9 = dateTime0.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMaximumValue();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        org.joda.time.LocalDate localDate8 = localDate5.minusWeeks((-1));
        int int9 = localDate5.getYearOfCentury();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = localDate5.isSupported(durationFieldType11);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((-1));
        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime18);
        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        try {
            org.joda.time.DateTime dateTime26 = dateTime9.withDate(58940097, (-58942414), 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -58942414 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMillisOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfCentury(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long54 = zeroIsMaxDateTimeField47.roundHalfEven(2440587L);
        int int57 = zeroIsMaxDateTimeField47.getDifference((long) 365, (long) 62570091);
        int int58 = zeroIsMaxDateTimeField47.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2440587L + "'", long54 == 2440587L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-62569726) + "'", int57 == (-62569726));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 86400000 + "'", int58 == 86400000);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 1970, 3);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1967L + "'", long3 == 1967L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        long long8 = offsetDateTimeField3.roundCeiling((long) 'a');
        boolean boolean10 = offsetDateTimeField3.isLeap((-28799968L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600000L + "'", long8 == 3600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTime();
        int int39 = dateTime37.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight40 = dateTime37.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime37.plus(readableDuration41);
        org.joda.time.DateTime.Property property43 = dateTime37.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 8);
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property50 = localDate49.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate52 = localDate49.plus(readablePeriod51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate52, 20, locale54);
        long long57 = offsetDateTimeField47.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField47.getType();
        int int59 = dateTime37.get(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType58, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType58);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder64.appendFractionOfDay(0, (-28798030));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertNotNull(dateMidnight40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((-1));
        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime18);
        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime24 = dateTime9.plusHours(2001);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        long long21 = offsetDateTimeField3.roundCeiling((long) 58936847);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime24 = dateTime22.plusYears((int) ' ');
        boolean boolean26 = dateTime24.isEqual(3599999L);
        org.joda.time.LocalDate localDate27 = dateTime24.toLocalDate();
        org.joda.time.DateTime dateTime28 = localDate27.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight29 = localDate27.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.hourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.yearOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.hourOfDay();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
        org.joda.time.ReadablePartial readablePartial40 = null;
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField38.getAsShortText(readablePartial40, 58946008, locale42);
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology31, (org.joda.time.DateTimeField) delegatedDateTimeField38, 0);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime48 = dateTime46.plusYears((int) ' ');
        boolean boolean50 = dateTime48.isEqual(3599999L);
        org.joda.time.LocalDate localDate51 = dateTime48.toLocalDate();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property54 = localDate53.dayOfMonth();
        boolean boolean55 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate53);
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime57 = dateTime56.toDateTime();
        org.joda.time.DateTime dateTime59 = dateTime56.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime60 = localDate53.toDateTime((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology63 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology62);
        org.joda.time.DateTimeZone dateTimeZone64 = gJChronology62.getZone();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology62.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField65);
        int int69 = delegatedDateTimeField66.getDifference(28801970L, 57600000L);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate73 = localDate71.withCenturyOfEra(15);
        org.joda.time.chrono.GJChronology gJChronology75 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField76 = gJChronology75.yearOfEra();
        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology75);
        org.joda.time.LocalDate localDate78 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology75);
        int[] intArray79 = localDate78.getValues();
        int int80 = delegatedDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) localDate71, intArray79);
        int[] intArray82 = delegatedDateTimeField38.addWrapPartial((org.joda.time.ReadablePartial) localDate53, 0, intArray79, 58936847);
        try {
            int[] intArray84 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDate27, (int) (short) -1, intArray79, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31536000000L + "'", long21 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "58946008" + "'", str43.equals("58946008"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-28798030) + "'", int69 == (-28798030));
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(gJChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(intArray82);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra(69);
        org.joda.time.DateTime dateTime14 = dateTime10.minusYears(20);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) (short) 0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.joda.time.DurationField durationField4 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        java.util.Locale locale51 = null;
        java.lang.String str52 = zeroIsMaxDateTimeField47.getAsText((long) 58946008, locale51);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "30146008" + "'", str52.equals("30146008"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long54 = zeroIsMaxDateTimeField47.roundHalfEven(2440587L);
        long long57 = zeroIsMaxDateTimeField47.add((-28798062L), (-28798081L));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2440587L + "'", long54 == 2440587L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-57596143L) + "'", long57 == (-57596143L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        int int12 = dateTime10.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight13 = dateTime10.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime10.hourOfDay();
        int int17 = property9.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate11.plus(readablePeriod13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, 20, locale16);
        long long19 = offsetDateTimeField9.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        int int21 = localDate5.indexOf(dateTimeFieldType20);
        org.joda.time.LocalDate localDate23 = localDate1.withField(dateTimeFieldType20, 70);
        org.joda.time.LocalDate localDate25 = localDate23.minusMonths(62570091);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate27 = localDate23.plus(readablePeriod26);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long12 = cachedDateTimeZone8.convertLocalToUTC(0L, true, (-28799999L));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime1.minusWeeks(58944326);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long55 = zeroIsMaxDateTimeField47.getDifferenceAsLong((long) 57600000, 100L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 57599900L + "'", long55 == 57599900L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfDay(16, 58944326);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeek(57600011);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(copticChronology3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property6 = localDate4.weekyear();
        int int7 = property6.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder((-1L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime60 = dateTime58.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property63 = localDate62.dayOfWeek();
        org.joda.time.LocalDate localDate65 = localDate62.minusWeeks((-1));
        int int66 = localDate62.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField68 = gJChronology67.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField68, 8);
        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property73 = localDate72.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod74 = null;
        org.joda.time.LocalDate localDate75 = localDate72.plus(readablePeriod74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField70.getAsShortText((org.joda.time.ReadablePartial) localDate75, 20, locale77);
        long long80 = offsetDateTimeField70.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = offsetDateTimeField70.getType();
        boolean boolean82 = localDate62.isSupported(dateTimeFieldType81);
        boolean boolean83 = dateTime60.isSupported(dateTimeFieldType81);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder52.appendDecimal(dateTimeFieldType81, 58946008, 58938682);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField47, dateTimeFieldType81, 58938682);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 69 + "'", int66 == 69);
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "20" + "'", str78.equals("20"));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        int int55 = remainderDateTimeField53.get((long) 57600001);
        long long57 = remainderDateTimeField53.remainder((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1978 + "'", int55 == 1978);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2000L + "'", long57 == 2000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((-25200000));
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(86400000);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) '#', (int) (byte) 0, 57602, 0, (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57602 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) (-25200000));
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField6.getAsText((long) (-10), locale10);
        long long14 = delegatedDateTimeField6.getDifferenceAsLong((long) '4', (long) (short) 1);
        long long16 = delegatedDateTimeField6.roundCeiling(315532800000L);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        org.joda.time.LocalTime localTime20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = localDate18.toDateTime(localTime20, dateTimeZone21);
        org.joda.time.DateTimeField[] dateTimeFieldArray23 = localDate18.getFields();
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDate18, 2002, locale25);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFieldArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2002" + "'", str26.equals("2002"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 58940097 + "'", int7 == 58940097);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int7 = delegatedDateTimeField4.getDifference(28801970L, 57600000L);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsShortText(19, locale9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28798030) + "'", int7 == (-28798030));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime0.hourOfDay();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int int8 = property6.compareTo(readablePartial7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate6 = property5.roundFloorCopy();
        boolean boolean7 = property5.isLeap();
        org.joda.time.LocalDate localDate9 = property5.setCopy(3);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property5.getAsText(locale10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        long long12 = delegatedDateTimeField4.getDifferenceAsLong((long) '4', (long) (short) 1);
        long long14 = delegatedDateTimeField4.roundCeiling(315532800000L);
        java.lang.String str15 = delegatedDateTimeField4.getName();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 315532800000L + "'", long14 == 315532800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "yearOfEra" + "'", str15.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("era");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"era\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        long long7 = fixedDateTimeZone5.nextTransition((-57600000L));
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property39 = localDate38.centuryOfEra();
        org.joda.time.Partial partial40 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate38);
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = unsupportedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate38, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNotNull(property39);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = unsupportedDateTimeField36.getAsText((-2699186673600000L), locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType28, (int) (short) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType28);
        long long34 = delegatedDateTimeField4.roundFloor((long) 100);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long54 = zeroIsMaxDateTimeField47.roundHalfCeiling((long) ' ');
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 32L + "'", long54 == 32L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        int int5 = offsetDateTimeField3.getLeapAmount((long) 10);
        java.lang.String str7 = offsetDateTimeField3.getAsText((long) (short) 10);
        org.joda.time.Partial partial8 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = partial8.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = partial8.getFieldTypes();
        int[] intArray11 = partial8.getValues();
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) partial8, 0, locale13);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1978" + "'", str7.equals("1978"));
        org.junit.Assert.assertNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        long long55 = remainderDateTimeField53.roundFloor((long) 28800000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        boolean boolean6 = dateTime4.isEqual(3599999L);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        boolean boolean8 = property1.equals((java.lang.Object) dateTime4);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate7 = localDate4.minusYears(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        int int10 = property9.getMinimumValueOverall();
        org.joda.time.DateTime dateTime12 = property9.setCopy((int) (short) 100);
        java.util.Locale locale14 = null;
        org.joda.time.DateTime dateTime15 = property9.setCopy("20", locale14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusYears((int) ' ');
        int int21 = dateTimeZone17.getOffset((org.joda.time.ReadableInstant) dateTime18);
        long long23 = dateTimeZone17.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTime dateTime25 = dateTime15.withZone(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology26.getZone();
        long long29 = dateTimeZone17.getMillisKeepLocal(dateTimeZone27, 3600000L);
        org.joda.time.DateTime dateTime30 = localDate4.toDateTimeAtCurrentTime(dateTimeZone27);
        int int31 = dateTime30.getYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28799999L) + "'", long23 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3600000L + "'", long29 == 3600000L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField7.getAsShortText(readablePartial9, 58946008, locale11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField7, 0);
        int int16 = skipDateTimeField14.get((long) 58942414);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property19.roundFloorCopy();
        org.joda.time.LocalDate localDate22 = localDate20.plusWeeks(15);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate20, locale23);
        long long27 = skipDateTimeField14.set(0L, 292278993);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "58946008" + "'", str12.equals("58946008"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1900" + "'", str24.equals("1900"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223371985593600000L + "'", long27 == 9223371985593600000L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfMonth();
        org.joda.time.LocalDate localDate4 = property2.addToCopy(166);
        org.joda.time.LocalDate localDate5 = property2.withMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays(58938682);
        org.joda.time.DateTime.Property property4 = dateTime0.year();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) (-1), number2, (java.lang.Number) (-25200000));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        int int49 = zeroIsMaxDateTimeField47.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DurationField durationField3 = property1.getDurationField();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property5.addWrapFieldToCopy(58936847);
        int int9 = property1.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, 166);
//        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear(16);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DurationField durationField7 = gJChronology1.weeks();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        int int3 = dateTime1.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime1.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = dateTime1.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType22);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.DurationField durationField28 = gJChronology26.millis();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology26.era();
        org.joda.time.DurationField durationField32 = gJChronology26.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField32);
        java.util.Locale locale36 = null;
        try {
            long long37 = unsupportedDateTimeField33.set((long) (short) -1, "", locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = localDate5.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight7 = localDate5.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = localDate5.get(dateTimeFieldType22);
        org.joda.time.LocalDate localDate25 = localDate5.plusDays(0);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime28 = localDate27.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate30 = localDate27.minusWeeks((int) ' ');
        int int31 = localDate5.compareTo((org.joda.time.ReadablePartial) localDate27);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2001 + "'", int23 == 2001);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int7 = delegatedDateTimeField4.getDifference(28801970L, 57600000L);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate11 = localDate9.withCenturyOfEra(15);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.yearOfEra();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology13);
        int[] intArray17 = localDate16.getValues();
        int int18 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate9, intArray17);
        long long20 = delegatedDateTimeField4.roundCeiling(518400002L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28798030) + "'", int7 == (-28798030));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 518400002L + "'", long20 == 518400002L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long54 = zeroIsMaxDateTimeField47.roundHalfEven(2440587L);
        int int57 = zeroIsMaxDateTimeField47.getDifference((long) 365, (long) 62570091);
        long long59 = zeroIsMaxDateTimeField47.roundCeiling(10L);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.yearOfEra();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology61);
        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology61);
        int[] intArray65 = localDate64.getValues();
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime67 = dateTime66.toDateTime();
        int int68 = dateTime66.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight69 = dateTime66.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.DateTime dateTime71 = dateTime66.plus(readableDuration70);
        org.joda.time.DateTime.Property property72 = dateTime66.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField74 = gJChronology73.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, 8);
        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property79 = localDate78.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod80 = null;
        org.joda.time.LocalDate localDate81 = localDate78.plus(readablePeriod80);
        java.util.Locale locale83 = null;
        java.lang.String str84 = offsetDateTimeField76.getAsShortText((org.joda.time.ReadablePartial) localDate81, 20, locale83);
        long long86 = offsetDateTimeField76.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = offsetDateTimeField76.getType();
        int int88 = dateTime66.get(dateTimeFieldType87);
        boolean boolean89 = localDate64.isSupported(dateTimeFieldType87);
        int[] intArray90 = null;
        int int91 = zeroIsMaxDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDate64, intArray90);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2440587L + "'", long54 == 2440587L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-62569726) + "'", int57 == (-62569726));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 12 + "'", int68 == 12);
        org.junit.Assert.assertNotNull(dateMidnight69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(localDate81);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "20" + "'", str84.equals("20"));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1969 + "'", int88 == 1969);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property6 = localDate4.weekyear();
        org.joda.time.LocalDate.Property property7 = localDate4.centuryOfEra();
        org.joda.time.LocalDate.Property property8 = localDate4.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        java.lang.String str8 = dateTime6.toString("58941222");
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        boolean boolean11 = dateTime6.isAfter((-53998081L));
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime6.withFieldAdded(durationFieldType12, 2001);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "58941222" + "'", str8.equals("58941222"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        int int29 = localDate13.indexOf(dateTimeFieldType28);
        int[] intArray30 = localDate13.getValues();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.yearOfEra();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology33);
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology33);
        int[] intArray37 = localDate36.getValues();
        try {
            int[] intArray39 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate13, (int) (short) 10, intArray37, 58939619);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        boolean boolean14 = dateTime12.isEqual(3599999L);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime16 = localDate15.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        int int33 = localDate15.get(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType32, 46, 17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder37.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter44 = dateTimeFormatter43.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder37.append(dateTimePrinter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder46.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter53 = dateTimeFormatter52.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder46.append(dateTimePrinter53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatter55.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter53, dateTimeParser56);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter44, dateTimeParser56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder36.append(dateTimePrinter44);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap60 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendTimeZoneName(strMap60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2001 + "'", int33 == 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimePrinter44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimePrinter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(strMap60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.String str3 = instant1.toString(dateTimeFormatter2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-83564-03-06T12:00:00" + "'", str3.equals("-83564-03-06T12:00:00"));
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28799948L) + "'", long3 == (-28799948L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = buddhistChronology0.add(readablePeriod1, (long) 1978, 12);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, (long) 2019);
        int int12 = dateTimeZone6.getOffsetFromLocal(3599999L);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        boolean boolean16 = buddhistChronology0.equals((java.lang.Object) gJChronology14);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        int int22 = offsetDateTimeField20.getLeapAmount((long) 10);
        java.lang.String str24 = offsetDateTimeField20.getAsText((long) (short) 10);
        boolean boolean25 = buddhistChronology0.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1978L + "'", long4 == 1978L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28798081L) + "'", long10 == (-28798081L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1978" + "'", str24.equals("1978"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        int int49 = zeroIsMaxDateTimeField47.getMaximumValue((long) 'a');
        long long51 = zeroIsMaxDateTimeField47.roundHalfEven((long) 58944326);
        int int53 = zeroIsMaxDateTimeField47.getMinimumValue((long) 3);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 86400000 + "'", int49 == 86400000);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 58944326L + "'", long51 == 58944326L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendMonthOfYear(17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeek(70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16) + "'", int1 == (-16));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 3, (-28798012L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28798009L) + "'", long2 == (-28798009L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField18 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNull(durationField18);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
//        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
//        int int13 = localDate9.getYearOfCentury();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
//        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
//        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
//        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
//        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
//        boolean boolean37 = unsupportedDateTimeField36.isSupported();
//        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property43 = localDate42.centuryOfEra();
//        org.joda.time.LocalTime localTime44 = null;
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = localDate42.toDateTime(localTime44, dateTimeZone45);
//        org.joda.time.DateTimeField[] dateTimeFieldArray47 = localDate42.getFields();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dateTimeZone49.getShortName(1L, locale51);
//        org.joda.time.DateTime dateTime53 = localDate42.toDateTimeAtCurrentTime(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone55);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property59 = localDate58.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod60 = null;
//        org.joda.time.LocalDate localDate61 = localDate58.plus(readablePeriod60);
//        int[] intArray63 = copticChronology56.get((org.joda.time.ReadablePartial) localDate61, (long) 12);
//        try {
//            int[] intArray65 = unsupportedDateTimeField36.addWrapField((org.joda.time.ReadablePartial) localDate42, (-16), intArray63, (-16));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PST" + "'", str52.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(copticChronology56);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(intArray63);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) ' ');
        int int7 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime4);
        long long10 = dateTimeZone3.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone3);
        java.util.Locale locale13 = dateTimeFormatter12.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(locale13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.withFields((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) ' ');
        int int12 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime9);
        long long15 = dateTimeZone8.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.clockhourOfHalfday();
        java.lang.String str18 = gregorianChronology16.toString();
        int int19 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime20 = dateTime0.withChronology((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTime dateTime21 = dateTime20.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter2, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add(0L, (long) 10);
        int int18 = offsetDateTimeField3.getMaximumValue((long) 1970);
        long long21 = offsetDateTimeField3.set((long) 292279001, 57600011);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292279001 + "'", int18 == 292279001);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1817618362967479001L + "'", long21 == 1817618362967479001L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[centuryOfEra]" + "'", str4.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate.Property property3 = localDate1.yearOfEra();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        int int11 = dateTime9.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight12 = dateTime9.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 8);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property22 = localDate21.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate21.plus(readablePeriod23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDate24, 20, locale26);
        long long29 = offsetDateTimeField19.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField19.getType();
        int int31 = dateTime9.get(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType30, 1970, 1969);
        boolean boolean36 = property3.equals((java.lang.Object) dateTimeFieldType30);
        org.joda.time.DurationField durationField37 = property3.getRangeDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, 62570091);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.minusWeeks((-1));
        int int8 = localDate4.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 8);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate14.plus(readablePeriod16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate17, 20, locale19);
        long long22 = offsetDateTimeField12.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField12.getType();
        boolean boolean24 = localDate4.isSupported(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType23, (int) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 57602019, "1969-12-31T16:00:02.019-08:00");
        java.lang.Number number30 = illegalFieldValueException29.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20" + "'", str20.equals("20"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        int int55 = remainderDateTimeField53.get((long) 57600001);
        long long57 = remainderDateTimeField53.roundHalfEven((long) 69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1978 + "'", int55 == 1978);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withMonthOfYear(15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        boolean boolean14 = dateTime12.isEqual(3599999L);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime16 = localDate15.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        int int33 = localDate15.get(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType32, 46, 17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder37.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter44 = dateTimeFormatter43.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder37.append(dateTimePrinter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder46.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter53 = dateTimeFormatter52.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder46.append(dateTimePrinter53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatter55.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter53, dateTimeParser56);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter44, dateTimeParser56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder36.append(dateTimePrinter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder36.appendSecondOfDay(1105894);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2001 + "'", int33 == 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimePrinter44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimePrinter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = property8.getDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        int int53 = skipDateTimeField52.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        org.joda.time.DateTime dateTime10 = localDate1.toDateTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusYears((int) ' ');
//        int int17 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        long long19 = dateTimeZone13.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.DateTime dateTime20 = localDate1.toDateTime(localTime11, dateTimeZone13);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
//        int int23 = dateTime21.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight24 = dateTime21.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime21.plus(readableDuration25);
//        boolean boolean27 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime26);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28799999L) + "'", long19 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.yearOfEra();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology38);
        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology38);
        int[] intArray42 = localDate41.getValues();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime44 = dateTime43.toDateTime();
        int int45 = dateTime43.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight46 = dateTime43.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.DateTime dateTime48 = dateTime43.plus(readableDuration47);
        org.joda.time.DateTime.Property property49 = dateTime43.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 8);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property56 = localDate55.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.LocalDate localDate58 = localDate55.plus(readablePeriod57);
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField53.getAsShortText((org.joda.time.ReadablePartial) localDate58, 20, locale60);
        long long63 = offsetDateTimeField53.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField53.getType();
        int int65 = dateTime43.get(dateTimeFieldType64);
        boolean boolean66 = localDate41.isSupported(dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder36.appendText(dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder67.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = dateTimeFormatterBuilder67.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(dateMidnight46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "20" + "'", str61.equals("20"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1969 + "'", int65 == 1969);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusDays((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, dateTimeZone1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(57602);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = property1.withMaximumValue();
        java.lang.String str10 = property1.getAsString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "57600100" + "'", str10.equals("57600100"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime7 = property5.setCopy("19");
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(86400000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 62566122);
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.nextTransition((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.halfdays();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.Instant instant3 = instant1.withMillis((long) 28800000);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("58944080", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("00520103T170002.019-0752", 365);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder11.writeTo("T162219Z", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(57600001, 960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendDayOfWeek(58939619);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra(58946008, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((-25200000));
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 0);
        long long14 = dateTime11.getMillis();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-795297357158822000L) + "'", long14 == (-795297357158822000L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        boolean boolean51 = zeroIsMaxDateTimeField47.isLeap((long) 2051);
        boolean boolean53 = zeroIsMaxDateTimeField47.isLeap(100L);
        java.lang.String str54 = zeroIsMaxDateTimeField47.getName();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "yearOfEra" + "'", str54.equals("yearOfEra"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, chronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        int int4 = property3.getMinimumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.setCopy((int) (short) 100);
        java.util.Locale locale8 = null;
        org.joda.time.DateTime dateTime9 = property3.setCopy("20", locale8);
        org.joda.time.DateTime dateTime10 = property3.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField11 = property3.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        org.joda.time.LocalDate localDate27 = localDate24.minusWeeks((-1));
        int int28 = localDate24.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 8);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.LocalDate localDate37 = localDate34.plus(readablePeriod36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate37, 20, locale39);
        long long42 = offsetDateTimeField32.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField32.getType();
        boolean boolean44 = localDate24.isSupported(dateTimeFieldType43);
        boolean boolean45 = dateTime22.isSupported(dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType43, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType43);
        long long51 = zeroIsMaxDateTimeField49.remainder(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField49, 57602001);
        long long55 = zeroIsMaxDateTimeField49.roundFloor((long) 58940097);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 69 + "'", int28 == 69);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58940097L + "'", long55 == 58940097L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        org.joda.time.Instant instant6 = instant4.minus((long) 58942414);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("58941222");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property11.withMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate12, locale13);
        int int17 = delegatedDateTimeField4.getDifference((long) 28800000, (long) 292278993);
        int int19 = delegatedDateTimeField4.get((long) 70);
        long long21 = delegatedDateTimeField4.roundCeiling((long) 9);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.DurationField durationField25 = gJChronology23.millis();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology23);
        org.joda.time.LocalDate.Property property27 = localDate26.dayOfMonth();
        org.joda.time.LocalDate localDate29 = localDate26.minusDays(2002);
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate26, locale30);
        org.joda.time.LocalDate localDate33 = localDate26.plusWeeks(19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "292278969" + "'", str14.equals("292278969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31536000000L + "'", long21 == 31536000000L);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertNotNull(localDate33);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTime(chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        int int13 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime5.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) 999, 0);
        try {
            org.joda.time.DateTime dateTime19 = dateTime14.withSecondOfMinute(58944579);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944579 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMillisOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendSecondOfDay(58937835);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-8643597981L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440487.4583567013d + "'", double1 == 2440487.4583567013d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter36 = dateTimeFormatterBuilder33.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear(62566122, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimePrinter36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate5 = property2.setCopy(1978);
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.LocalDate localDate9 = property2.setCopy("GregorianChronology[America/Los_Angeles]", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime11, dateTimeZone12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate9.getFields();
        int int15 = localDate9.getYearOfEra();
        int int16 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate localDate18 = localDate9.plusDays(21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfHalfday();
        java.lang.String str11 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.Chronology chronology16 = gregorianChronology9.withZone(dateTimeZone13);
        try {
            org.joda.time.Instant instant17 = new org.joda.time.Instant((java.lang.Object) dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        long long47 = dividedDateTimeField45.remainder(1844724137688L);
        try {
            long long49 = dividedDateTimeField45.roundFloor((long) 57602);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [9,292279001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1844724137688L + "'", long47 == 1844724137688L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfHalfday();
        java.lang.String str11 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.Chronology chronology16 = gregorianChronology9.withZone(dateTimeZone13);
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        int int10 = dateTime8.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readableDuration12);
        org.joda.time.DateTime.Property property14 = dateTime8.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate20.plus(readablePeriod22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate23, 20, locale25);
        long long28 = offsetDateTimeField18.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField18.getType();
        int int30 = dateTime8.get(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType29, 1970, 1969);
        boolean boolean35 = localDate1.isSupported(dateTimeFieldType29);
        org.joda.time.LocalDate.Property property36 = localDate1.yearOfEra();
        org.joda.time.LocalDate localDate37 = property36.withMinimumValue();
        org.joda.time.LocalDate localDate39 = localDate37.withDayOfMonth(9);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        boolean boolean41 = unsupportedDateTimeField36.isSupported();
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = buddhistChronology0.add(readablePeriod1, (long) 1978, 12);
        try {
            long long12 = buddhistChronology0.getDateTimeMillis((int) 'a', (int) ' ', 12, 58937835, 62566122, 57600001, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1978L + "'", long4 == 1978L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 1);
        long long3 = dateTimeZone1.convertUTCToLocal((-1L));
        long long5 = dateTimeZone1.convertUTCToLocal((long) 292278969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3599999L + "'", long3 == 3599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 295878969L + "'", long5 == 295878969L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        org.joda.time.Partial partial10 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = partial10.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = partial10.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.Partial partial14 = partial10.without(dateTimeFieldType13);
        org.joda.time.Chronology chronology15 = partial10.getChronology();
        java.util.Locale locale17 = null;
        java.lang.String str18 = partial10.toString("58939886", locale17);
        int int19 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) partial10);
        int int20 = partial10.size();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "58939886" + "'", str18.equals("58939886"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 22 + "'", int19 == 22);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("58944080", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("��:��:��.000", 46, 292278993, (-1), 'a', 0, 58940097, 0, false, 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZone(dateTimeZone5);
        java.util.TimeZone timeZone7 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("58944080", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("00520103T170002.019-0752", 365);
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("58946632", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 58938682);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4881435364800000L + "'", long1 == 4881435364800000L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 58946008);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.yearOfEra();
        org.joda.time.DurationField durationField4 = gJChronology2.millis();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology2.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getStandardOffset((long) 69);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfEra(62566122);
        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19700101" + "'", str15.equals("19700101"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(21, 1969, 292278993);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 292277046 + "'", int3 == 292277046);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        try {
            long long10 = julianChronology0.getDateTimeMillis(17, (-10), 365, (int) (short) 1, (int) '4', (int) (short) 0, 2051);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2051 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
        int int10 = delegatedDateTimeField4.getMinimumValue(0L);
        long long13 = delegatedDateTimeField4.set((-53998081L), "1970");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31482001919L + "'", long13 == 31482001919L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 8);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate9.plus(readablePeriod11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate12, 20, locale14);
        long long17 = offsetDateTimeField7.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField7.getType();
        int int19 = localDate3.indexOf(dateTimeFieldType18);
        int[] intArray20 = localDate3.getValues();
        org.joda.time.LocalDate localDate22 = localDate3.plusWeeks(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20" + "'", str15.equals("20"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks(1978);
        org.joda.time.DateTime dateTime9 = dateTime0.withHourOfDay(17);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.minusWeeks((-1));
        long long9 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate7, (long) 2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = localDate7.toString("70", locale11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        int int14 = dateTime13.getCenturyOfEra();
        int int15 = dateTime13.getDayOfYear();
        int int16 = dateTime13.getDayOfMonth();
        boolean boolean18 = dateTime13.isAfter((long) 166);
        boolean boolean19 = localDate7.equals((java.lang.Object) boolean18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 518400002L + "'", long9 == 518400002L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "70" + "'", str12.equals("70"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(copticChronology4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime11, dateTimeZone12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate9.getFields();
        int int15 = localDate9.getYearOfEra();
        int int16 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property17 = localDate9.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.yearOfEra();
        org.joda.time.DurationField durationField51 = gJChronology49.millis();
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology49);
        org.joda.time.LocalDate.Property property53 = localDate52.dayOfMonth();
        org.joda.time.LocalDate localDate54 = property53.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.yearOfEra();
        org.joda.time.DurationField durationField58 = gJChronology56.millis();
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology56);
        org.joda.time.LocalDate localDate61 = localDate59.plusWeeks(57600001);
        boolean boolean62 = localDate54.isEqual((org.joda.time.ReadablePartial) localDate61);
        int int63 = localDate61.getYearOfEra();
        java.util.Locale locale65 = null;
        java.lang.String str66 = zeroIsMaxDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDate61, 17, locale65);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1105894 + "'", int63 == 1105894);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "17" + "'", str66.equals("17"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendMonthOfYear((-62569726));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears((int) ' ');
        boolean boolean4 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        int int8 = property5.getMinimumValue();
        boolean boolean9 = property5.isLeap();
        int int10 = property5.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(58944326);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendClockhourOfHalfday(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.appendMinuteOfDay(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder31.appendTwoDigitYear((int) (byte) 10, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.yearOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate11.plus(readablePeriod13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, 20, locale16);
        long long19 = offsetDateTimeField9.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        int int21 = localDate5.indexOf(dateTimeFieldType20);
        org.joda.time.LocalDate localDate23 = localDate1.withField(dateTimeFieldType20, 70);
        java.util.Locale locale25 = null;
        java.lang.String str26 = localDate23.toString("20", locale25);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray27 = localDate23.getFieldTypes();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        int int10 = delegatedDateTimeField7.getLeapAmount((long) 58940097);
        java.util.Locale locale11 = null;
        int int12 = delegatedDateTimeField7.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField7.getLeapDurationField();
        long long15 = delegatedDateTimeField7.roundCeiling((-57600000L));
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        int int51 = zeroIsMaxDateTimeField47.getMinimumValue((-28799999L));
        int int52 = zeroIsMaxDateTimeField47.getMaximumValue();
        boolean boolean53 = zeroIsMaxDateTimeField47.isSupported();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 86400000 + "'", int52 == 86400000);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-28798030), 12, 2000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 701 + "'", int3 == 701);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours(3);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField36.getAsShortText(readablePartial37, 17, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str10 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        int int6 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime2.withMinuteOfHour(31);
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(0);
        org.joda.time.DateTime dateTime11 = dateTime10.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate6 = property5.roundFloorCopy();
        boolean boolean7 = property5.isLeap();
        org.joda.time.LocalDate localDate8 = property5.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
//        org.joda.time.DurationField durationField3 = gJChronology1.millis();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 58946008, locale7);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName(1L, locale9);
//        org.joda.time.DateTime dateTime11 = localDate3.toDateTimeAtStartOfDay(dateTimeZone7);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(0L, dateTimeZone7);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, dateTimeZone7);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        int int55 = remainderDateTimeField53.get((long) 57600001);
        long long57 = remainderDateTimeField53.roundHalfEven(0L);
        int int58 = remainderDateTimeField53.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1978 + "'", int55 == 1978);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 28799999 + "'", int58 == 28799999);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(6743775600019L, chronology1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        long long16 = offsetDateTimeField3.add(0L, (long) 10);
        int int18 = offsetDateTimeField3.getMaximumValue((long) 1970);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField3.getMaximumShortTextLength(locale19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 315532800000L + "'", long16 == 315532800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292279001 + "'", int18 == 292279001);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        long long5 = offsetDateTimeField3.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = offsetDateTimeField3.getAsShortText(readablePartial6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(999, (-28800000), 58944579, 16, 365, 57602001, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        int int3 = dateTime1.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime1.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate13.plus(readablePeriod15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate16, 20, locale18);
        long long21 = offsetDateTimeField11.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField11.getType();
        int int23 = dateTime1.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType22);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.DurationField durationField28 = gJChronology26.millis();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology26.era();
        org.joda.time.DurationField durationField32 = gJChronology26.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField32);
        try {
            long long36 = unsupportedDateTimeField33.set(10L, "(\"org.joda.time.JodaTimePermission\" \"58944696\")");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
//        boolean boolean5 = fixedDateTimeZone4.isFixed();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight9 = localDate7.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getShortName(1L, locale13);
//        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime16 = localDate7.toDateTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime22 = dateTime20.plusYears((int) ' ');
//        int int23 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        long long25 = dateTimeZone19.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.DateTime dateTime26 = localDate7.toDateTime(localTime17, dateTimeZone19);
//        boolean boolean27 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone19);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 28800000, 57602019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57602019");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-28799999L) + "'", long25 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 58940097);
        long long8 = fixedDateTimeZone4.previousTransition((-28799988L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58940097 + "'", int6 == 58940097);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799988L) + "'", long8 == (-28799988L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = julianChronology0.add(readablePeriod4, (long) 57602019, 3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 57602019L + "'", long7 == 57602019L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException6.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = illegalFieldValueException6.getDateTimeFieldType();
        java.lang.Number number11 = illegalFieldValueException6.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(dateTimeFieldType9);
        org.junit.Assert.assertNull(dateTimeFieldType10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getCenturyOfEra();
        int int2 = dateTime0.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime0.toYearMonthDay();
        long long4 = dateTime0.getMillis();
        org.joda.time.LocalDate localDate5 = dateTime0.toLocalDate();
        int int6 = localDate5.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        long long14 = delegatedDateTimeField4.add((-28798030L), 8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 252432001970L + "'", long14 == 252432001970L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
//        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
//        long long8 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getName(3600000L, locale11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime dateTime14 = dateTime13.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        int int47 = dividedDateTimeField45.get((long) 1978);
        long long50 = dividedDateTimeField45.addWrapField((long) (-62569726), (int) '4');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 7270721740737430274L + "'", long50 == 7270721740737430274L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "17");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        java.lang.String str3 = partial2.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[]" + "'", str3.equals("[]"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        int int55 = remainderDateTimeField53.get((long) 57600001);
        long long57 = remainderDateTimeField53.roundHalfEven(0L);
        long long60 = remainderDateTimeField53.set((long) 4, 57602);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1978 + "'", int55 == 1978);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1755323913600004L + "'", long60 == 1755323913600004L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMillisOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.append(dateTimePrinter16, dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.append(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.getDateTime();
        java.lang.String str7 = property1.getAsShortText();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "57600100" + "'", str7.equals("57600100"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58940097, 'a', 2019, 1978, 10, false, 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover((-28800000), ' ', 20, 6, 62566122, false, 58940097);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 58944326);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number9 = illegalFieldValueException8.getLowerBound();
        java.lang.String str10 = illegalFieldValueException8.getIllegalValueAsString();
        java.lang.Number number11 = illegalFieldValueException8.getUpperBound();
        java.lang.String str12 = illegalFieldValueException8.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("��:��:��.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��:��:��.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfDay((int) (short) 100);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType28, (int) (short) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType28);
        org.joda.time.DateTimeField dateTimeField33 = delegatedDateTimeField32.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        try {
            long long44 = unsupportedDateTimeField36.set(1L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58944696");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"58944696\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"58944696\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58944696" + "'", str3.equals("58944696"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime4);
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        int int7 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.dayOfWeek();
        org.joda.time.LocalDate localDate15 = localDate12.minusWeeks((-1));
        int int16 = localDate12.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 8);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate22.plus(readablePeriod24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 20, locale27);
        long long30 = offsetDateTimeField20.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField20.getType();
        boolean boolean32 = localDate12.isSupported(dateTimeFieldType31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType31, 58946008, 58938682);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.yearOfEra();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology38);
        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology38);
        int[] intArray42 = localDate41.getValues();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime44 = dateTime43.toDateTime();
        int int45 = dateTime43.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight46 = dateTime43.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.DateTime dateTime48 = dateTime43.plus(readableDuration47);
        org.joda.time.DateTime.Property property49 = dateTime43.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 8);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property56 = localDate55.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.LocalDate localDate58 = localDate55.plus(readablePeriod57);
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField53.getAsShortText((org.joda.time.ReadablePartial) localDate58, 20, locale60);
        long long63 = offsetDateTimeField53.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField53.getType();
        int int65 = dateTime43.get(dateTimeFieldType64);
        boolean boolean66 = localDate41.isSupported(dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder36.appendText(dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder67.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder67.appendClockhourOfDay(57600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(dateMidnight46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "20" + "'", str61.equals("20"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1969 + "'", int65 == 1969);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.Interval interval8 = property1.toInterval();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology2.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy(2000);
        org.joda.time.LocalDate localDate5 = property2.withMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(chronology7);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime.Property property3 = dateTime0.weekOfWeekyear();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("58944080", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58944080 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long55 = zeroIsMaxDateTimeField47.getDifferenceAsLong(1844724137788L, (long) (short) 100);
        try {
            long long58 = zeroIsMaxDateTimeField47.set((-2699186673600000L), (-58942414));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -58942414 for yearOfEra must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1844724137688L + "'", long55 == 1844724137688L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        boolean boolean42 = unsupportedDateTimeField36.isSupported();
        try {
            int int43 = unsupportedDateTimeField36.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long51 = zeroIsMaxDateTimeField47.roundHalfCeiling((long) 19);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.hourOfDay();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.dayOfMonth();
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property57 = localDate56.dayOfWeek();
        org.joda.time.LocalDate localDate59 = localDate56.minusWeeks((-1));
        long long61 = iSOChronology52.set((org.joda.time.ReadablePartial) localDate59, (long) 2);
        java.util.Locale locale63 = null;
        java.lang.String str64 = zeroIsMaxDateTimeField47.getAsText((org.joda.time.ReadablePartial) localDate59, (int) (short) 100, locale63);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 19L + "'", long51 == 19L);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 518400002L + "'", long61 == 518400002L);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "100" + "'", str64.equals("100"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long7 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, (long) 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 0, dateTimeZone5);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType12 = localDate10.getFieldType(46);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 46");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28798081L) + "'", long7 == (-28798081L));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFractionOfMinute((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        int int4 = property3.getMinimumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.setCopy((int) (short) 100);
        java.util.Locale locale8 = null;
        org.joda.time.DateTime dateTime9 = property3.setCopy("20", locale8);
        org.joda.time.DateTime dateTime10 = property3.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField11 = property3.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        org.joda.time.LocalDate localDate27 = localDate24.minusWeeks((-1));
        int int28 = localDate24.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 8);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.LocalDate localDate37 = localDate34.plus(readablePeriod36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate37, 20, locale39);
        long long42 = offsetDateTimeField32.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField32.getType();
        boolean boolean44 = localDate24.isSupported(dateTimeFieldType43);
        boolean boolean45 = dateTime22.isSupported(dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType43, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType43);
        long long51 = zeroIsMaxDateTimeField49.remainder(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField49, 57602001);
        org.joda.time.DateTimeField dateTimeField54 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 69 + "'", int28 == 69);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField54);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        org.joda.time.DurationField durationField50 = zeroIsMaxDateTimeField47.getLeapDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(durationField50);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.minusWeeks((-1));
        long long9 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate7, (long) 2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 518400002L + "'", long9 == 518400002L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = dateTime4.getClass();
        org.joda.time.DateTime dateTime9 = dateTime4.plusMonths(10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours(58938682);
        org.joda.time.DateTime.Property property12 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        int int10 = property9.getMinimumValueOverall();
        org.joda.time.DateTime dateTime12 = property9.setCopy((int) (short) 100);
        java.util.Locale locale14 = null;
        org.joda.time.DateTime dateTime15 = property9.setCopy("20", locale14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusYears((int) ' ');
        int int21 = dateTimeZone17.getOffset((org.joda.time.ReadableInstant) dateTime18);
        long long23 = dateTimeZone17.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTime dateTime25 = dateTime15.withZone(dateTimeZone17);
        java.lang.String str26 = dateTimeZone17.getID();
        org.joda.time.Chronology chronology27 = gJChronology7.withZone(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((int) '#', 16, 46, 1970, 292278969, (-28800000), 0, chronology27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28799999L) + "'", long23 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "America/Los_Angeles" + "'", str26.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(1);
        java.util.Date date6 = dateTime5.toDate();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks((int) ' ');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((-1));
        boolean boolean9 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property10 = dateTime3.millisOfDay();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime3.toCalendar(locale11);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(calendar12);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate1.withYearOfEra((int) (short) 1);
//        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        java.lang.String str19 = offsetDateTimeField3.getAsShortText((-53998081L));
        long long21 = offsetDateTimeField3.remainder(0L);
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField3.getMaximumShortTextLength(locale22);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1977" + "'", str19.equals("1977"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-1));
        org.joda.time.TimeOfDay timeOfDay2 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(timeOfDay2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField9 = gregorianChronology8.months();
        long long14 = gregorianChronology8.getDateTimeMillis(57602, 4, 6, 2001);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology8.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799999L) + "'", long7 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1755584607602001L + "'", long14 == 1755584607602001L);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate4 = localDate1.minusWeeks((-1));
        int int5 = localDate1.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate11.plus(readablePeriod13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, 20, locale16);
        long long19 = offsetDateTimeField9.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        boolean boolean21 = localDate1.isSupported(dateTimeFieldType20);
        org.joda.time.LocalDate localDate23 = localDate1.withYear(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        int int5 = dateTime3.getYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.get();
//        int int3 = property1.getLeapAmount();
//        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusSeconds(2002);
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getShortName(1L, locale17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
//        int int21 = property20.get();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int int24 = property20.compareTo((org.joda.time.ReadablePartial) localDateTime23);
//        org.joda.time.DateTime dateTime25 = property20.roundCeilingCopy();
//        java.lang.String str27 = dateTime25.toString("58941222");
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime13.toMutableDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600100 + "'", int21 == 57600100);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "58941222" + "'", str27.equals("58941222"));
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "57600001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField3.getMaximumShortTextLength(locale16);
        int int19 = offsetDateTimeField3.get(0L);
        long long21 = offsetDateTimeField3.roundHalfCeiling((long) 57600001);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1978 + "'", int19 == 1978);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        boolean boolean5 = dateTime3.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property24.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 8);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate31.plus(readablePeriod33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDate34, 20, locale36);
        long long39 = offsetDateTimeField29.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField29.getType();
        int int41 = localDate25.indexOf(dateTimeFieldType40);
        org.joda.time.LocalDate localDate43 = localDate21.withField(dateTimeFieldType40, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType40, 28800000);
        long long47 = dividedDateTimeField45.remainder(1844724137688L);
        try {
            long long49 = dividedDateTimeField45.roundFloor((long) 57602019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [9,292279001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1844724137688L + "'", long47 == 1844724137688L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfHalfday();
        java.lang.String str11 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.Chronology chronology16 = gregorianChronology9.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology9.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, 535L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 534L + "'", long2 == 534L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("20", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 8);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate6.plus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate9, 20, locale11);
        int int14 = offsetDateTimeField4.get(0L);
        long long16 = offsetDateTimeField4.roundCeiling(0L);
        int int18 = offsetDateTimeField4.getMinimumValue(100L);
        int int20 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate26 = property25.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        int int42 = localDate26.indexOf(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate22.withField(dateTimeFieldType41, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, 28800000);
        long long48 = dividedDateTimeField46.remainder(1844724137688L);
        int int51 = dividedDateTimeField46.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) dividedDateTimeField46);
        int int53 = dividedDateTimeField46.getDivisor();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime61 = dateTime59.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property64 = localDate63.dayOfWeek();
        org.joda.time.LocalDate localDate66 = localDate63.minusWeeks((-1));
        int int67 = localDate63.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField69 = gJChronology68.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 8);
        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property74 = localDate73.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod75 = null;
        org.joda.time.LocalDate localDate76 = localDate73.plus(readablePeriod75);
        java.util.Locale locale78 = null;
        java.lang.String str79 = offsetDateTimeField71.getAsShortText((org.joda.time.ReadablePartial) localDate76, 20, locale78);
        long long81 = offsetDateTimeField71.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = offsetDateTimeField71.getType();
        boolean boolean83 = localDate63.isSupported(dateTimeFieldType82);
        boolean boolean84 = dateTime61.isSupported(dateTimeFieldType82);
        org.joda.time.DateTimeZone dateTimeZone86 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology87 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone86);
        org.joda.time.DurationField durationField88 = copticChronology87.seconds();
        org.joda.time.DurationField durationField89 = copticChronology87.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField90 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType82, durationField89);
        boolean boolean91 = unsupportedDateTimeField90.isSupported();
        long long94 = unsupportedDateTimeField90.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType95 = unsupportedDateTimeField90.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField96 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46, dateTimeFieldType95);
        long long99 = remainderDateTimeField96.addWrapField((long) 8, 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "20" + "'", str12.equals("20"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1978 + "'", int14 == 1978);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1844724137688L + "'", long48 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 28800000 + "'", int53 == 28800000);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 69 + "'", int67 == 69);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(localDate76);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "20" + "'", str79.equals("20"));
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(dateTimeZone86);
        org.junit.Assert.assertNotNull(copticChronology87);
        org.junit.Assert.assertNotNull(durationField88);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-1L) + "'", long94 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType95);
        org.junit.Assert.assertTrue("'" + long99 + "' != '" + 252460800008L + "'", long99 == 252460800008L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        java.util.Locale locale9 = null;
        long long10 = offsetDateTimeField3.set((-28798081L), "08", locale9);
        long long13 = offsetDateTimeField3.add((long) (short) 1, 58944326);
        boolean boolean15 = offsetDateTimeField3.isLeap((long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-53998081L) + "'", long10 == (-53998081L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 212199573600001L + "'", long13 == 212199573600001L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.Interval interval3 = property1.toInterval();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(interval3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("30146008", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"30146008/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime3, dateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate1.getFields();
        java.util.Date date7 = localDate1.toDate();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.fromDateFields(date7);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.fromDateFields(date7);
        int int10 = localDate9.getDayOfMonth();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = dateTime9.minusSeconds(2002);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        long long55 = zeroIsMaxDateTimeField47.getDifferenceAsLong(1844724137788L, (long) (short) 100);
        java.lang.String str57 = zeroIsMaxDateTimeField47.getAsShortText((long) 58946008);
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.yearOfEra();
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology59);
        org.joda.time.LocalDate localDate62 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology59);
        int[] intArray63 = localDate62.getValues();
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime65 = dateTime64.toDateTime();
        int int66 = dateTime64.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight67 = dateTime64.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration68 = null;
        org.joda.time.DateTime dateTime69 = dateTime64.plus(readableDuration68);
        org.joda.time.DateTime.Property property70 = dateTime64.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, 8);
        org.joda.time.LocalDate localDate76 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property77 = localDate76.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.LocalDate localDate79 = localDate76.plus(readablePeriod78);
        java.util.Locale locale81 = null;
        java.lang.String str82 = offsetDateTimeField74.getAsShortText((org.joda.time.ReadablePartial) localDate79, 20, locale81);
        long long84 = offsetDateTimeField74.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType85 = offsetDateTimeField74.getType();
        int int86 = dateTime64.get(dateTimeFieldType85);
        boolean boolean87 = localDate62.isSupported(dateTimeFieldType85);
        org.joda.time.chrono.GJChronology gJChronology90 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField91 = gJChronology90.yearOfEra();
        org.joda.time.DateTime dateTime92 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology90);
        org.joda.time.LocalDate localDate93 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology90);
        int[] intArray94 = localDate93.getValues();
        int[] intArray96 = zeroIsMaxDateTimeField47.addWrapField((org.joda.time.ReadablePartial) localDate62, (int) (byte) 1, intArray94, 0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1844724137688L + "'", long55 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "30146008" + "'", str57.equals("30146008"));
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
        org.junit.Assert.assertNotNull(dateMidnight67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "20" + "'", str82.equals("20"));
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1969 + "'", int86 == 1969);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(gJChronology90);
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertNotNull(localDate93);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfMonth();
        org.joda.time.LocalDate localDate3 = property2.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate5 = property2.addWrapFieldToCopy(9);
        org.joda.time.LocalDate localDate6 = property2.roundHalfCeilingCopy();
        int int7 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology38);
        org.joda.time.DateTimeZone dateTimeZone40 = gJChronology38.getZone();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology38.millisOfSecond();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((-28798130L), (org.joda.time.Chronology) gJChronology38);
        org.joda.time.Partial partial43 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = partial43.getFormatter();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.Partial partial46 = partial43.plus(readablePeriod45);
        int[] intArray48 = gJChronology38.get((org.joda.time.ReadablePartial) partial43, 0L);
        int[] intArray53 = new int[] { 58939619, 58944326, '#', 57600011 };
        try {
            int int54 = unsupportedDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) partial43, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(partial46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate4 = localDate1.minusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Interval interval6 = localDate4.toInterval(dateTimeZone5);
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(readableInterval7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
        boolean boolean4 = dateTime2.isEqual(3599999L);
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.plusYears((int) ' ');
        int int11 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone7.convertUTCToLocal((long) (byte) 1);
        org.joda.time.DateTime dateTime14 = localDate5.toDateTimeAtStartOfDay(dateTimeZone7);
        int int15 = dateTime14.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28799999L) + "'", long13 == (-28799999L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfWeek();
        org.joda.time.LocalDate localDate22 = localDate19.minusWeeks((-1));
        int int23 = localDate19.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 8);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate29.plus(readablePeriod31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDate32, 20, locale34);
        long long37 = offsetDateTimeField27.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        boolean boolean39 = localDate19.isSupported(dateTimeFieldType38);
        boolean boolean40 = dateTime17.isSupported(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone42);
        org.joda.time.DurationField durationField44 = copticChronology43.seconds();
        org.joda.time.DurationField durationField45 = copticChronology43.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField45);
        boolean boolean47 = unsupportedDateTimeField46.isSupported();
        long long50 = unsupportedDateTimeField46.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = unsupportedDateTimeField46.getType();
        java.lang.String str52 = unsupportedDateTimeField46.getName();
        org.joda.time.DurationField durationField53 = unsupportedDateTimeField46.getLeapDurationField();
        org.joda.time.DurationField durationField54 = unsupportedDateTimeField46.getDurationField();
        boolean boolean55 = property1.equals((java.lang.Object) durationField54);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "20" + "'", str35.equals("20"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "yearOfEra" + "'", str52.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        long long7 = gJChronology0.getDateTimeMillis(9223371985593600010L, (int) (byte) 0, 2, 4, 6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223371985593724006L + "'", long7 == 9223371985593724006L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter2, dateTimeParser4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfYear(21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfMonth();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        int int7 = dateTime6.getCenturyOfEra();
        int int8 = dateTime6.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime6.toYearMonthDay();
        boolean boolean10 = localDate4.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis((-62569726));
        org.joda.time.DateTime dateTime14 = dateTime6.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        int int4 = property3.getMinimumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.setCopy((int) (short) 100);
        java.util.Locale locale8 = null;
        org.joda.time.DateTime dateTime9 = property3.setCopy("20", locale8);
        org.joda.time.DateTime dateTime10 = property3.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField11 = property3.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        org.joda.time.LocalDate localDate27 = localDate24.minusWeeks((-1));
        int int28 = localDate24.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 8);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.LocalDate localDate37 = localDate34.plus(readablePeriod36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate37, 20, locale39);
        long long42 = offsetDateTimeField32.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField32.getType();
        boolean boolean44 = localDate24.isSupported(dateTimeFieldType43);
        boolean boolean45 = dateTime22.isSupported(dateTimeFieldType43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType43, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType43);
        long long51 = zeroIsMaxDateTimeField49.remainder(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField49, 57602001);
        int int55 = skipUndoDateTimeField53.get(1817681729040000010L);
        java.util.Locale locale56 = null;
        int int57 = skipUndoDateTimeField53.getMaximumTextLength(locale56);
        int int59 = skipUndoDateTimeField53.get((long) (-1));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 69 + "'", int28 == 69);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 57600011 + "'", int55 == 57600011);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 57600000 + "'", int59 == 57600000);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.withMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-2699186673600000L));
        org.joda.time.Instant instant3 = instant1.withMillis((long) 58944987);
        org.joda.time.MutableDateTime mutableDateTime4 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1978);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFractionOfHour(58944579, 12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime16 = dateTime11.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) '4');
        boolean boolean19 = gregorianChronology9.equals((java.lang.Object) dateTime16);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology9.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime4 = localDate3.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay(160);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getDurationField();
        java.lang.String str19 = offsetDateTimeField3.getAsShortText((-53998081L));
        long long21 = offsetDateTimeField3.remainder(0L);
        long long24 = offsetDateTimeField3.add((-28798130L), 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1977" + "'", str19.equals("1977"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28798130L) + "'", long24 == (-28798130L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        boolean boolean14 = dateTime12.isEqual(3599999L);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime16 = localDate15.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        int int33 = localDate15.get(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType32, 46, 17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder37.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter44 = dateTimeFormatter43.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder37.append(dateTimePrinter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder46.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter53 = dateTimeFormatter52.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder46.append(dateTimePrinter53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatter55.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter53, dateTimeParser56);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter44, dateTimeParser56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder36.append(dateTimePrinter44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder36.appendFractionOfSecond(10, (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2001 + "'", int33 == 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimePrinter44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimePrinter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        long long15 = offsetDateTimeField3.roundCeiling(0L);
        int int17 = offsetDateTimeField3.getMinimumValue(100L);
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        long long21 = offsetDateTimeField3.roundCeiling((long) 58936847);
        org.joda.time.DateTimeField dateTimeField22 = offsetDateTimeField3.getWrappedField();
        long long24 = offsetDateTimeField3.roundFloor((long) 70);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31536000000L + "'", long21 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField36.getRangeDurationField();
        java.util.Locale locale44 = null;
        try {
            java.lang.String str45 = unsupportedDateTimeField36.getAsShortText(534L, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNull(durationField42);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long13 = cachedDateTimeZone11.convertUTCToLocal(0L);
        java.lang.String str15 = cachedDateTimeZone11.getNameKey(315532800000L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfMinute(58944579, 9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology0.getZone();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(localDate7);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusYears((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.yearOfEra();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology7);
//        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusYears((int) ' ');
//        int int16 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        long long19 = dateTimeZone12.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone12.getName(3600000L, locale22);
//        org.joda.time.DateTime dateTime24 = localDate10.toDateTimeAtMidnight(dateTimeZone12);
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime26 = dateTime4.toDateTime(dateTimeZone12);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, 2440587L, (-16));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -16");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField36.getRangeDurationField();
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property45 = localDate44.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime52 = dateTime51.toDateTime();
        int int53 = dateTime51.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight54 = dateTime51.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.DateTime dateTime56 = dateTime51.plus(readableDuration55);
        org.joda.time.DateTime.Property property57 = dateTime51.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, 8);
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property64 = localDate63.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.LocalDate localDate66 = localDate63.plus(readablePeriod65);
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField61.getAsShortText((org.joda.time.ReadablePartial) localDate66, 20, locale68);
        long long71 = offsetDateTimeField61.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField61.getType();
        int int73 = dateTime51.get(dateTimeFieldType72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder50.appendShortText(dateTimeFieldType72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder46.appendSignedDecimal(dateTimeFieldType72, 1970, 1969);
        boolean boolean78 = localDate44.isSupported(dateTimeFieldType72);
        java.util.Locale locale79 = null;
        try {
            java.lang.String str80 = unsupportedDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate44, locale79);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertNotNull(dateMidnight54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "20" + "'", str69.equals("20"));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1969 + "'", int73 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField3.getType();
        long long17 = offsetDateTimeField3.add((long) '4', 0L);
        long long19 = offsetDateTimeField3.roundHalfFloor((long) 58936847);
        long long21 = offsetDateTimeField3.roundHalfCeiling((long) (byte) -1);
        int int23 = offsetDateTimeField3.getLeapAmount(0L);
        java.lang.String str24 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "yearOfEra" + "'", str24.equals("yearOfEra"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.LocalDate localDate6 = localDate4.plusWeeks(57600001);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate11 = localDate8.minusWeeks((int) ' ');
        int int12 = localDate8.getWeekyear();
        int int13 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = localDate4.isSupported(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.year();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField8 = gJChronology1.millis();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 8);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property16 = localDate15.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate15.plus(readablePeriod17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDate18, 20, locale20);
        int int23 = offsetDateTimeField13.get(0L);
        long long25 = offsetDateTimeField13.roundCeiling(0L);
        int int27 = offsetDateTimeField13.getMinimumValue(100L);
        int int29 = offsetDateTimeField13.getLeapAmount((long) (short) 1);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate35 = property34.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 8);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property42 = localDate41.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.LocalDate localDate44 = localDate41.plus(readablePeriod43);
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) localDate44, 20, locale46);
        long long49 = offsetDateTimeField39.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = offsetDateTimeField39.getType();
        int int51 = localDate35.indexOf(dateTimeFieldType50);
        org.joda.time.LocalDate localDate53 = localDate31.withField(dateTimeFieldType50, 70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType50, 28800000);
        long long57 = dividedDateTimeField55.remainder(1844724137688L);
        int int60 = dividedDateTimeField55.getDifference((long) 2, (long) 58944579);
        org.joda.time.field.SkipDateTimeField skipDateTimeField61 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) dividedDateTimeField55);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField55);
        org.joda.time.field.SkipDateTimeField skipDateTimeField64 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) dividedDateTimeField55, 2019);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20" + "'", str21.equals("20"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1978 + "'", int23 == 1978);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "20" + "'", str47.equals("20"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1844724137688L + "'", long57 == 1844724137688L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.plusYears((int) ' ');
//        int int10 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        long long13 = dateTimeZone6.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone6.getName(3600000L, locale16);
//        org.joda.time.DateTime dateTime18 = localDate4.toDateTimeAtMidnight(dateTimeZone6);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
//        org.joda.time.LocalDate.Property property22 = localDate20.yearOfEra();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendYearOfCentury(0, 58937835);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        int int30 = dateTime28.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight31 = dateTime28.toDateMidnight();
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime28.plus(readableDuration32);
//        org.joda.time.DateTime.Property property34 = dateTime28.hourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 8);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property41 = localDate40.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.LocalDate localDate43 = localDate40.plus(readablePeriod42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate43, 20, locale45);
//        long long48 = offsetDateTimeField38.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = offsetDateTimeField38.getType();
//        int int50 = dateTime28.get(dateTimeFieldType49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder27.appendShortText(dateTimeFieldType49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType49, 1970, 1969);
//        boolean boolean55 = property22.equals((java.lang.Object) dateTimeFieldType49);
//        org.joda.time.LocalDate.Property property56 = localDate4.property(dateTimeFieldType49);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, "58946008");
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(property56);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight3 = localDate1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName(1L, locale7);
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtStartOfDay(dateTimeZone5);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTime9.toString("58941222", locale11);
//        org.joda.time.DateTime dateTime14 = dateTime9.withYear(58944326);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "58941222" + "'", str12.equals("58941222"));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMillisOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.append(dateTimeParser15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter17.withLocale(locale19);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.append(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        int int2 = property1.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
//        java.util.Locale locale6 = null;
//        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
//        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
//        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
//        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
//        int int26 = localDate22.getYearOfCentury();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
//        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
//        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
//        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
//        long long49 = zeroIsMaxDateTimeField47.remainder((-1L));
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property52 = localDate51.centuryOfEra();
//        org.joda.time.DateMidnight dateMidnight53 = localDate51.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = dateTimeZone55.getShortName(1L, locale57);
//        org.joda.time.DateTime dateTime59 = localDate51.toDateTimeAtStartOfDay(dateTimeZone55);
//        org.joda.time.DateTime dateTime60 = localDate51.toDateTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime61 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeUtils.getZone(dateTimeZone62);
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime66 = dateTime64.plusYears((int) ' ');
//        int int67 = dateTimeZone63.getOffset((org.joda.time.ReadableInstant) dateTime64);
//        long long69 = dateTimeZone63.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.DateTime dateTime70 = localDate51.toDateTime(localTime61, dateTimeZone63);
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.chrono.CopticChronology copticChronology72 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone71);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property75 = localDate74.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod76 = null;
//        org.joda.time.LocalDate localDate77 = localDate74.plus(readablePeriod76);
//        int[] intArray79 = copticChronology72.get((org.joda.time.ReadablePartial) localDate77, (long) 12);
//        int int80 = zeroIsMaxDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray79);
//        int int81 = zeroIsMaxDateTimeField47.getMaximumValue();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateMidnight53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "PST" + "'", str58.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-28800000) + "'", int67 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-28799999L) + "'", long69 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(copticChronology72);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 86400000 + "'", int81 == 86400000);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField36.getType();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField36.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField45 = gJChronology44.weeks();
        boolean boolean46 = julianChronology43.equals((java.lang.Object) gJChronology44);
        org.joda.time.DateTimeZone dateTimeZone47 = julianChronology43.getZone();
        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology43.getZone();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        long long54 = dateTimeZone50.getMillisKeepLocal(dateTimeZone52, (long) 2019);
        org.joda.time.Chronology chronology55 = julianChronology43.withZone(dateTimeZone52);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(chronology55);
        try {
            int int57 = unsupportedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-28798081L) + "'", long54 == (-28798081L));
        org.junit.Assert.assertNotNull(chronology55);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) ' ');
        int int15 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime12);
        long long17 = dateTimeZone11.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField19 = gregorianChronology18.months();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property30 = localDate29.dayOfWeek();
        org.joda.time.LocalDate localDate32 = localDate29.minusWeeks((-1));
        int int33 = localDate29.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 8);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property40 = localDate39.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate42 = localDate39.plus(readablePeriod41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) localDate42, 20, locale44);
        long long47 = offsetDateTimeField37.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField37.getType();
        boolean boolean49 = localDate29.isSupported(dateTimeFieldType48);
        boolean boolean50 = dateTime27.isSupported(dateTimeFieldType48);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        org.joda.time.DurationField durationField54 = copticChronology53.seconds();
        org.joda.time.DurationField durationField55 = copticChronology53.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField55);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, durationField19, dateTimeFieldType48, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28799999L) + "'", long17 == (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 69 + "'", int33 == 69);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "20" + "'", str45.equals("20"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial0.without(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate8 = property7.withMaximumValue();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.dayOfWeek();
        org.joda.time.LocalDate localDate13 = localDate10.minusWeeks((-1));
        int int14 = localDate10.getYearOfCentury();
        int int15 = property7.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime20 = property17.setCopy((int) (short) 100);
        java.util.Locale locale22 = null;
        org.joda.time.DateTime dateTime23 = property17.setCopy("20", locale22);
        org.joda.time.DateTime dateTime24 = property17.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField25 = property17.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property39 = localDate38.dayOfWeek();
        org.joda.time.LocalDate localDate41 = localDate38.minusWeeks((-1));
        int int42 = localDate38.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 8);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property49 = localDate48.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.LocalDate localDate51 = localDate48.plus(readablePeriod50);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField46.getAsShortText((org.joda.time.ReadablePartial) localDate51, 20, locale53);
        long long56 = offsetDateTimeField46.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField46.getType();
        boolean boolean58 = localDate38.isSupported(dateTimeFieldType57);
        boolean boolean59 = dateTime36.isSupported(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder28.appendDecimal(dateTimeFieldType57, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField63 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType57);
        int int64 = localDate10.get(dateTimeFieldType57);
        try {
            int int65 = partial0.get(dateTimeFieldType57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 69 + "'", int42 == 69);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "20" + "'", str54.equals("20"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText((long) (-1), locale7);
        int int9 = delegatedDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(166);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-166) + "'", int1 == (-166));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withMinuteOfHour(8);
        org.joda.time.DateTime dateTime9 = dateTime4.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour(9);
        org.joda.time.DateTime.Property property12 = dateTime9.secondOfMinute();
        boolean boolean13 = julianChronology0.equals((java.lang.Object) dateTime9);
        java.lang.String str14 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str14.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        int int7 = dateTime5.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight8 = dateTime5.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime5.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate17.plus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate20, 20, locale22);
        long long25 = offsetDateTimeField15.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField15.getType();
        int int27 = dateTime5.get(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType26, 1970, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendClockhourOfHalfday(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.appendMinuteOfDay(58940097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendSecondOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate5 = property2.setCopy(1978);
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        org.joda.time.LocalDate.Property property7 = localDate6.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long52 = zeroIsMaxDateTimeField47.addWrapField((-28798081L), 19);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property54 = dateTime53.millisOfDay();
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property57 = localDate56.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight58 = localDate56.toDateMidnight();
        org.joda.time.DateTime dateTime59 = dateTime53.withFields((org.joda.time.ReadablePartial) localDate56);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.yearOfEra();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology61);
        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology61);
        int[] intArray65 = localDate64.getValues();
        int int66 = zeroIsMaxDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate56, intArray65);
        int int68 = zeroIsMaxDateTimeField47.getMinimumValue((long) 19);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-28798062L) + "'", long52 == (-28798062L));
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateMidnight58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 86400000 + "'", int66 == 86400000);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        java.util.Locale locale3 = null;
        int int4 = property1.getMaximumShortTextLength(locale3);
        java.lang.String str5 = property1.getAsShortText();
        org.joda.time.DateTime dateTime6 = property1.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600100" + "'", str5.equals("57600100"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate3 = property2.roundFloorCopy();
        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) ' ');
        boolean boolean14 = dateTime12.isEqual(3599999L);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime16 = localDate15.toDateTimeAtCurrentTime();
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property24 = localDate23.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate23.plus(readablePeriod25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate26, 20, locale28);
        long long31 = offsetDateTimeField21.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField21.getType();
        int int33 = localDate15.get(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType32, 46, 17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendYearOfCentury(292279001, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder0.appendMinuteOfHour(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendMonthOfYear(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime46 = dateTime45.toDateTime();
        int int47 = dateTime45.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight48 = dateTime45.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime50 = dateTime45.plus(readableDuration49);
        org.joda.time.DateTime.Property property51 = dateTime45.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology52.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 8);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property58 = localDate57.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.LocalDate localDate60 = localDate57.plus(readablePeriod59);
        java.util.Locale locale62 = null;
        java.lang.String str63 = offsetDateTimeField55.getAsShortText((org.joda.time.ReadablePartial) localDate60, 20, locale62);
        long long65 = offsetDateTimeField55.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField55.getType();
        int int67 = dateTime45.get(dateTimeFieldType66);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder44.appendShortText(dateTimeFieldType66);
        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = gJChronology70.yearOfEra();
        org.joda.time.DurationField durationField72 = gJChronology70.millis();
        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology70);
        org.joda.time.DateTimeZone dateTimeZone74 = gJChronology70.getZone();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology70.era();
        org.joda.time.DurationField durationField76 = gJChronology70.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField77 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField76);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder41.appendDecimal(dateTimeFieldType66, 3, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2001 + "'", int33 == 2001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
        org.junit.Assert.assertNotNull(dateMidnight48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "20" + "'", str63.equals("20"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1969 + "'", int67 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(gJChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        org.joda.time.Partial partial5 = new org.joda.time.Partial(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        boolean boolean49 = zeroIsMaxDateTimeField47.isLeap(0L);
        long long51 = zeroIsMaxDateTimeField47.roundHalfCeiling((long) 19);
        long long54 = zeroIsMaxDateTimeField47.add((long) ' ', 1978);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 19L + "'", long51 == 19L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2010L + "'", long54 == 2010L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate11.plus(readablePeriod13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate14, 20, locale16);
        long long19 = offsetDateTimeField9.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField9.getType();
        int int21 = localDate5.indexOf(dateTimeFieldType20);
        org.joda.time.LocalDate localDate23 = localDate1.withField(dateTimeFieldType20, 70);
        java.util.Locale locale25 = null;
        java.lang.String str26 = localDate23.toString("20", locale25);
        org.joda.time.LocalDate localDate28 = localDate23.plusWeeks((int) (short) 100);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertNotNull(localDate28);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DateTime.Property property12 = dateTime9.era();
        try {
            org.joda.time.DateTime dateTime14 = property12.addToCopy(701);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        int int10 = copticChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        long long17 = fixedDateTimeZone15.nextTransition((-57600000L));
        org.joda.time.Chronology chronology18 = copticChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-57600000L) + "'", long17 == (-57600000L));
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        int int5 = offsetDateTimeField3.getLeapAmount((long) 10);
        java.lang.String str7 = offsetDateTimeField3.getAsText((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean11 = iSOChronology9.equals((java.lang.Object) "58939886");
        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((-10L), (org.joda.time.Chronology) iSOChronology9);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate13, locale14);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1978" + "'", str7.equals("1978"));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime4 = property1.setCopy((int) (short) 100);
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property1.setCopy("20", locale6);
        org.joda.time.DateTime dateTime8 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField9 = property1.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate22.minusWeeks((-1));
        int int26 = localDate22.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 8);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate32.plus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, 20, locale37);
        long long40 = offsetDateTimeField30.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField30.getType();
        boolean boolean42 = localDate22.isSupported(dateTimeFieldType41);
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType41, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType41);
        long long49 = zeroIsMaxDateTimeField47.remainder(0L);
        boolean boolean51 = zeroIsMaxDateTimeField47.isLeap((long) 2051);
        try {
            long long54 = zeroIsMaxDateTimeField47.set(0L, "[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 69 + "'", int26 == 69);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "20" + "'", str38.equals("20"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        org.junit.Assert.assertNotNull(partial2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate.Property property3 = localDate1.yearOfEra();
        int int4 = localDate1.size();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusDays(58944987);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5092846876800100L + "'", long4 == 5092846876800100L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(58944987);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMillisOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DurationField durationField41 = unsupportedDateTimeField36.getRangeDurationField();
        try {
            int int43 = unsupportedDateTimeField36.getMaximumValue(63072000016L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNull(durationField41);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        try {
            org.joda.time.DateTime dateTime6 = dateTime0.withCenturyOfEra((-166));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -166 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test419");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime7 = dateTime5.plusYears((int) ' ');
//        int int8 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        long long11 = dateTimeZone4.adjustOffset(0L, false);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone4.getName(3600000L, locale14);
//        boolean boolean16 = localDate1.equals((java.lang.Object) locale14);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 8);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate5.plus(readablePeriod7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDate8, 20, locale10);
        int int13 = offsetDateTimeField3.get(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((-10), locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField3.getLeapDurationField();
        long long19 = offsetDateTimeField3.roundHalfCeiling(31482001919L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1978 + "'", int13 == 1978);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-10" + "'", str16.equals("-10"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000000L + "'", long19 == 31536000000L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property1.getAsText(locale3);
        org.joda.time.DateTime dateTime5 = property1.roundHalfEvenCopy();
        java.lang.String str6 = property1.getAsString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "57600100" + "'", str4.equals("57600100"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "57600100" + "'", str6.equals("57600100"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField36.getAsShortText(readablePartial38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        int int7 = delegatedDateTimeField4.getLeapAmount((long) 58940097);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime11, dateTimeZone12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate9.getFields();
        int int15 = localDate9.getYearOfEra();
        int int16 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate localDate18 = localDate9.withCenturyOfEra(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField7.getAsShortText(readablePartial9, 58946008, locale11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField7, 0);
        int int16 = skipDateTimeField14.get((long) 58942414);
        long long19 = skipDateTimeField14.set(1817681729040000010L, 292278993);
        int int20 = skipDateTimeField14.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "58946008" + "'", str12.equals("58946008"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223371985593600010L + "'", long19 == 9223371985593600010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(58936847, 15, 0, 58940097, (int) (short) 1, 1, 2002);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58940097 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField7.getAsShortText(readablePartial9, 58946008, locale11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField7, 0);
        int int16 = skipDateTimeField14.get((long) (short) 100);
        java.util.Locale locale17 = null;
        int int18 = skipDateTimeField14.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "58946008" + "'", str12.equals("58946008"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        java.lang.String str3 = property2.getAsText();
        try {
            org.joda.time.LocalDate localDate5 = property2.setCopy("(\"org.joda.time.JodaTimePermission\" \"58944696\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"58944696\")\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property43 = localDate42.centuryOfEra();
        org.joda.time.LocalTime localTime44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = localDate42.toDateTime(localTime44, dateTimeZone45);
        int int47 = localDate42.getCenturyOfEra();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime49 = dateTime48.toDateTime();
        org.joda.time.DateTime dateTime51 = dateTime48.plusDays(58944987);
        java.util.GregorianCalendar gregorianCalendar52 = dateTime48.toGregorianCalendar();
        org.joda.time.LocalDate localDate53 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar52);
        org.joda.time.LocalDate localDate54 = localDate42.withFields((org.joda.time.ReadablePartial) localDate53);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone55);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property59 = localDate58.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.LocalDate localDate61 = localDate58.plus(readablePeriod60);
        int[] intArray63 = copticChronology56.get((org.joda.time.ReadablePartial) localDate61, (long) 12);
        try {
            int int64 = unsupportedDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) localDate54, intArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 19 + "'", int47 == 19);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(gregorianCalendar52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(copticChronology56);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfHalfday();
        java.lang.String str11 = gregorianChronology9.toString();
        int int12 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.Chronology chronology18 = gregorianChronology9.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("58944696", "1978", 58940097, 69);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long7 = fixedDateTimeZone4.nextTransition(2019L);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate12 = localDate9.minusWeeks((-1));
        int int13 = localDate9.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate19.plus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate22, 20, locale24);
        long long27 = offsetDateTimeField17.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField17.getType();
        boolean boolean29 = localDate9.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime7.isSupported(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = copticChronology33.seconds();
        org.joda.time.DurationField durationField35 = copticChronology33.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        boolean boolean37 = unsupportedDateTimeField36.isSupported();
        long long40 = unsupportedDateTimeField36.getDifferenceAsLong((long) 12, (long) 58942414);
        org.joda.time.DurationField durationField41 = unsupportedDateTimeField36.getRangeDurationField();
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.yearOfEra();
        org.joda.time.DurationField durationField45 = gJChronology43.millis();
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology43);
        org.joda.time.DateMidnight dateMidnight47 = localDate46.toDateMidnight();
        org.joda.time.Partial partial48 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate46);
        try {
            int int49 = unsupportedDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) partial48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateMidnight47);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        int int10 = dateTime8.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readableDuration12);
        org.joda.time.DateTime.Property property14 = dateTime8.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate20.plus(readablePeriod22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate23, 20, locale25);
        long long28 = offsetDateTimeField18.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField18.getType();
        int int30 = dateTime8.get(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType29, 1970, 1969);
        boolean boolean35 = localDate1.isSupported(dateTimeFieldType29);
        org.joda.time.LocalDate.Property property36 = localDate1.yearOfEra();
        org.joda.time.LocalDate localDate37 = property36.withMinimumValue();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfDay();
        org.joda.time.DurationField durationField40 = property39.getRangeDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = property39.getAsText(locale41);
        org.joda.time.DateTime dateTime43 = property39.roundHalfEvenCopy();
        int int44 = property36.getDifference((org.joda.time.ReadableInstant) dateTime43);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "57600100" + "'", str42.equals("57600100"));
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears((int) ' ');
        int int5 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime2);
        long long8 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial3.getFieldTypes();
        int[] intArray6 = partial3.getValues();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.millisOfSecond();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-28798130L), (org.joda.time.Chronology) gJChronology8);
        org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldTypeArray2, intArray6, (org.joda.time.Chronology) gJChronology8);
        org.junit.Assert.assertNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount((long) (-25200000));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((long) (-10), locale8);
        long long12 = delegatedDateTimeField4.getDifferenceAsLong((long) '4', (long) (short) 1);
        long long14 = delegatedDateTimeField4.roundCeiling(315532800000L);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.LocalDate localDate18 = property17.roundFloorCopy();
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(15);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate18.minus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate18, (int) (short) 1, locale24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 315532800000L + "'", long14 == 315532800000L);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20");
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.yearOfEra();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 58937835, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfMonth();
        org.joda.time.LocalDate localDate8 = property7.roundFloorCopy();
        boolean boolean9 = property7.isLeap();
        org.joda.time.LocalDate localDate11 = property7.setCopy(3);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((-25200000));
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property14 = dateTime11.secondOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.withWeekyear((int) (byte) 1);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime0.year();
        java.lang.String str7 = property6.getName();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "year" + "'", str7.equals("year"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        int int2 = property1.get();
        int int3 = property1.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property1.addToCopy(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        java.lang.String str11 = dateTime9.toString("58944080");
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withFieldAdded(durationFieldType12, 57602);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600100 + "'", int2 == 57600100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58944080" + "'", str11.equals("58944080"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury(0, 58937835);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfDay(16, 58944326);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfDay(46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology2.seconds();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight7 = localDate5.toDateMidnight();
        boolean boolean8 = copticChronology2.equals((java.lang.Object) dateMidnight7);
        try {
            long long13 = copticChronology2.getDateTimeMillis(58946008, (int) '4', (int) (byte) 1, 58946008);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) (short) 0, (long) 4);
        long long8 = offsetDateTimeField3.roundCeiling((long) 'a');
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        int int15 = property14.getMinimumValueOverall();
        org.joda.time.DateTime dateTime17 = property14.setCopy((int) (short) 100);
        java.util.Locale locale19 = null;
        org.joda.time.DateTime dateTime20 = property14.setCopy("20", locale19);
        org.joda.time.DateTime dateTime21 = property14.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField22 = property14.getField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((int) '#', (int) (byte) 10, 20, 0, (int) (short) 10);
        org.joda.time.DateTime dateTime33 = dateTime31.withMinuteOfHour(0);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property36 = localDate35.dayOfWeek();
        org.joda.time.LocalDate localDate38 = localDate35.minusWeeks((-1));
        int int39 = localDate35.getYearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 8);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property46 = localDate45.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.LocalDate localDate48 = localDate45.plus(readablePeriod47);
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) localDate48, 20, locale50);
        long long53 = offsetDateTimeField43.roundHalfEven((long) 58942414);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField43.getType();
        boolean boolean55 = localDate35.isSupported(dateTimeFieldType54);
        boolean boolean56 = dateTime33.isSupported(dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder25.appendDecimal(dateTimeFieldType54, 58946008, 58938682);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField60 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField22, dateTimeFieldType54);
        boolean boolean62 = zeroIsMaxDateTimeField60.isLeap(0L);
        long long65 = zeroIsMaxDateTimeField60.addWrapField((-28798081L), 19);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property67 = dateTime66.millisOfDay();
        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property70 = localDate69.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight71 = localDate69.toDateMidnight();
        org.joda.time.DateTime dateTime72 = dateTime66.withFields((org.joda.time.ReadablePartial) localDate69);
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.yearOfEra();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) 8, (org.joda.time.Chronology) gJChronology74);
        org.joda.time.LocalDate localDate77 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology74);
        int[] intArray78 = localDate77.getValues();
        int int79 = zeroIsMaxDateTimeField60.getMaximumValue((org.joda.time.ReadablePartial) localDate69, intArray78);
        int[] intArray81 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) localDate10, 292278993, intArray78, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600000L + "'", long8 == 3600000L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "20" + "'", str51.equals("20"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-28798062L) + "'", long65 == (-28798062L));
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateMidnight71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 86400000 + "'", int79 == 86400000);
        org.junit.Assert.assertNotNull(intArray81);
    }
}

