import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        org.joda.time.DurationField durationField44 = offsetDateTimeField38.getRangeDurationField();
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField38.getAsShortText((int) (short) 1, locale46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, 100);
        try {
            long long52 = offsetDateTimeField49.add((long) 65, (long) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 111 for millisOfSecond must be in the range [200,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        long long7 = copticChronology3.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = copticChronology3.eras();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField16 = copticChronology11.eras();
        org.joda.time.MonthDay monthDay17 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) copticChronology11);
        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
        java.util.Locale locale19 = null;
        int int20 = property18.getMaximumTextLength(locale19);
        org.joda.time.MonthDay monthDay21 = property18.getMonthDay();
        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
        try {
            java.lang.String str23 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        int int18 = skipDateTimeField17.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField17.getType();
        int int21 = skipDateTimeField17.get((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        long long27 = copticChronology23.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField28 = copticChronology23.eras();
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology23);
        org.joda.time.MonthDay monthDay31 = monthDay29.minusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField46 = copticChronology41.eras();
        org.joda.time.MonthDay monthDay47 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) copticChronology41);
        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
        java.util.Locale locale49 = null;
        int int50 = property48.getMaximumTextLength(locale49);
        org.joda.time.MonthDay monthDay51 = property48.getMonthDay();
        boolean boolean52 = monthDay29.isEqual((org.joda.time.ReadablePartial) monthDay51);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone54 = gJChronology53.getZone();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone55);
        long long60 = copticChronology56.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField61 = copticChronology56.eras();
        org.joda.time.MonthDay monthDay62 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology56);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone63);
        long long68 = copticChronology64.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField69 = copticChronology64.eras();
        org.joda.time.MonthDay monthDay70 = monthDay62.withChronologyRetainFields((org.joda.time.Chronology) copticChronology64);
        int int71 = monthDay62.getMonthOfYear();
        int[] intArray73 = gJChronology53.get((org.joda.time.ReadablePartial) monthDay62, (long) (short) 100);
        int int74 = skipDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay51, intArray73);
        long long77 = skipDateTimeField17.set(0L, 999);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 999 + "'", int21 == 999);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(copticChronology56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(copticChronology64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 999 + "'", int74 == 999);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 999L + "'", long77 == 999L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        int int42 = offsetDateTimeField38.getMaximumValue((long) 100);
        java.lang.String str43 = offsetDateTimeField38.getName();
        try {
            long long46 = offsetDateTimeField38.set(0L, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for millisOfSecond must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "millisOfSecond" + "'", str43.equals("millisOfSecond"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        java.util.Locale locale42 = null;
        java.lang.String str43 = property41.getAsShortText(locale42);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1965" + "'", str43.equals("1965"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        java.lang.String str36 = property35.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "millisOfSecond" + "'", str36.equals("millisOfSecond"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-1440000000));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        long long73 = unsupportedDateTimeField70.getDifferenceAsLong((long) 52, (long) 6);
        long long76 = unsupportedDateTimeField70.add((long) 12, (int) (short) 100);
        try {
            long long78 = unsupportedDateTimeField70.roundHalfCeiling(57542400L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 8640000012L + "'", long76 == 8640000012L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DurationField durationField7 = copticChronology1.eras();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = copticChronology1.get(readablePeriod8, (long) 49166778);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("24", "ISOChronology[UTC]");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        long long7 = copticChronology3.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = copticChronology3.eras();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField16 = copticChronology11.eras();
        org.joda.time.MonthDay monthDay17 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) copticChronology11);
        int int18 = monthDay9.getMonthOfYear();
        int[] intArray20 = gJChronology0.get((org.joda.time.ReadablePartial) monthDay9, (long) (short) 100);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        java.lang.String str22 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str22.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        try {
            int int72 = unsupportedDateTimeField70.get(28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendLiteral("10");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendWeekOfWeekyear(49156);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 49119);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime2.withWeekyear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        java.lang.String str3 = dateTime2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str3.equals("1969-12-31T16:00:00.010-08:00"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        try {
            org.joda.time.MonthDay monthDay3 = monthDay1.minusDays(49154);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        long long44 = offsetDateTimeField38.roundHalfFloor(53L);
        long long46 = offsetDateTimeField38.roundHalfCeiling((long) 0);
        org.joda.time.DurationField durationField47 = offsetDateTimeField38.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-14400000L) + "'", long44 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.lang.String str71 = unsupportedDateTimeField70.getName();
        try {
            int int73 = unsupportedDateTimeField70.getLeapAmount((long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfSecond" + "'", str71.equals("millisOfSecond"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        long long73 = unsupportedDateTimeField70.getDifferenceAsLong((long) 52, (long) 6);
        java.util.Locale locale76 = null;
        try {
            long long77 = unsupportedDateTimeField70.set(0L, "LimitChronology[CopticChronology[America/Los_Angeles], NoLimit, NoLimit]", locale76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        long long5 = buddhistChronology0.add((-136771199990L), 0L, 0);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-136771199990L) + "'", long5 == (-136771199990L));
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology14, readableDateTime15, readableDateTime16);
        org.joda.time.DurationField durationField18 = limitChronology17.weekyears();
        org.joda.time.DateTimeField dateTimeField19 = limitChronology17.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10, dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMonths((int) '4');
        org.joda.time.DateTime dateTime26 = dateTime24.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar27 = dateTime24.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        long long33 = copticChronology29.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField34 = copticChronology29.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = copticChronology29.withZone(dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone37);
        long long42 = copticChronology38.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField43 = copticChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology36, dateTimeField43, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = skipDateTimeField45.getType();
        org.joda.time.DateTime.Property property47 = dateTime24.property(dateTimeFieldType46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType46, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType46);
        int int53 = dateTime7.get(dateTimeFieldType46);
        org.joda.time.DateTime dateTime55 = dateTime7.minusWeeks(57600010);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime55);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int14 = fixedDateTimeZone12.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int17 = cachedDateTimeZone15.getOffset(28799001L);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone15.getUncachedZone();
        long long20 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (long) 2019);
        long long22 = fixedDateTimeZone4.previousTransition((long) 57600010);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 57600010L + "'", long22 == 57600010L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        int int42 = property41.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 57600);
        int int12 = fixedDateTimeZone4.getOffset((long) 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTime dateTime29 = dateTime4.plusSeconds((int) (short) -1);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.DateTime dateTime31 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.DateTime dateTime33 = dateTime31.plusMonths((int) (short) 10);
        int int34 = dateTime31.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 10, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.minusMonths((int) '4');
        boolean boolean47 = dateTime39.isBefore((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 10, dateTimeZone49);
        org.joda.time.DateTime dateTime52 = dateTime50.minusMonths((int) '4');
        org.joda.time.DateTime dateTime54 = dateTime52.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar55 = dateTime52.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone56);
        long long61 = copticChronology57.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField62 = copticChronology57.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.Chronology chronology64 = copticChronology57.withZone(dateTimeZone63);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone65);
        long long70 = copticChronology66.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField71 = copticChronology66.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField(chronology64, dateTimeField71, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = skipDateTimeField73.getType();
        org.joda.time.DateTime.Property property75 = dateTime52.property(dateTimeFieldType74);
        int int76 = dateTime39.get(dateTimeFieldType74);
        org.joda.time.DateTime dateTime78 = dateTime31.withField(dateTimeFieldType74, 9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(gregorianCalendar55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(copticChronology66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
        org.junit.Assert.assertNotNull(dateTime78);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        long long19 = skipDateTimeField17.roundCeiling((long) 2000);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2000L + "'", long19 == 2000L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        long long73 = unsupportedDateTimeField70.getDifferenceAsLong((long) 52, (long) 6);
        try {
            long long75 = unsupportedDateTimeField70.roundFloor((long) 49153);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 1);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.DateTime dateTime40 = dateTime4.plusDays(3);
        try {
            org.joda.time.DateTime dateTime42 = dateTime4.withCenturyOfEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTime dateTime29 = dateTime4.plusSeconds((int) (short) -1);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.DateTime dateTime31 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.DateTime dateTime33 = dateTime31.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property34 = dateTime33.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        long long44 = offsetDateTimeField38.roundHalfFloor((-989L));
        int int46 = offsetDateTimeField38.getLeapAmount((long) 77939);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-14400000L) + "'", long44 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1965-08-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1965-08-31\" is malformed at \"-08-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean11 = fixedDateTimeZone10.isFixed();
        long long14 = fixedDateTimeZone10.convertLocalToUTC(28800000L, true);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) ' ', 24, 99, 24, 52, 57600010, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799001L + "'", long14 == 28799001L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        long long73 = unsupportedDateTimeField70.getDifferenceAsLong((long) 52, (long) 6);
        try {
            int int75 = unsupportedDateTimeField70.getMinimumValue((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsShortText(locale8);
        org.joda.time.DateTime dateTime10 = property6.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Dec" + "'", str9.equals("Dec"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime20 = dateTime16.withYear(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology2.add(readablePeriod5, (-124271280421990L), 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-124271280421990L) + "'", long8 == (-124271280421990L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        java.lang.Class<?> wildcardClass5 = copticChronology1.getClass();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime9, readableDateTime10);
        org.joda.time.DurationField durationField12 = limitChronology11.weekyears();
        org.joda.time.DateTimeField dateTimeField13 = limitChronology11.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = limitChronology11.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology6, dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(limitChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        org.joda.time.DateTimeField dateTimeField19 = property16.getField();
        try {
            org.joda.time.MonthDay monthDay21 = property16.setCopy("2019");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.clockhourOfDay();
        org.joda.time.Chronology chronology5 = julianChronology3.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours(65);
        int int9 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1965 + "'", int9 == 1965);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.Chronology chronology6 = limitChronology4.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = julianChronology3.get(readablePeriod4, 52L, (-136771200989L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertNotNull(julianChronology3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        java.util.Date date19 = dateTime16.toDate();
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.fromDateFields(date19);
        org.joda.time.MonthDay monthDay22 = monthDay20.plusMonths((int) (byte) 0);
        int int23 = monthDay20.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        int int12 = dateTime9.getSecondOfDay();
        boolean boolean13 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime9);
        int int14 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime.Property property15 = dateTime4.weekyear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsShortText(locale16);
        int int18 = property15.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1965" + "'", str17.equals("1965"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (-14400000L), (java.lang.Number) 52);
        illegalFieldValueException4.prependMessage("UTC");
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra((int) (byte) 10, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay(2019, 49154);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        try {
            long long33 = limitChronology4.getDateTimeMillis(49166778, 12, 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        org.joda.time.MonthDay monthDay19 = property16.getMonthDay();
        java.lang.String str20 = property16.getAsString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6" + "'", str20.equals("6"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        java.lang.String str39 = offsetDateTimeField38.toString();
        long long41 = offsetDateTimeField38.roundHalfCeiling(1L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField38.getAsText(2019, locale43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = offsetDateTimeField38.getAsText(readablePartial45, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str39.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        java.lang.String str39 = offsetDateTimeField38.toString();
        java.lang.String str41 = offsetDateTimeField38.getAsShortText((long) 100);
        boolean boolean43 = offsetDateTimeField38.isLeap((long) 49154);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str39.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "11" + "'", str41.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            long long9 = julianChronology0.getDateTimeMillis(49119, 49159, 0, 31, (-1), 49156, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = property6.getDifference((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime15.toString();
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime21 = dateTime15.withEarlierOffsetAtOverlap();
        long long22 = dateTime21.getMillis();
        org.joda.time.DateTime dateTime24 = dateTime21.plusMillis(99);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField30 = copticChronology25.eras();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = monthDay31.withChronologyRetainFields((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone41);
        long long46 = copticChronology42.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField47 = copticChronology42.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.Chronology chronology49 = copticChronology42.withZone(dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone50);
        long long55 = copticChronology51.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField56 = copticChronology51.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField(chronology49, dateTimeField56, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = skipDateTimeField58.getType();
        java.util.Locale locale61 = null;
        java.lang.String str62 = skipDateTimeField58.getAsText(10, locale61);
        java.lang.String str63 = skipDateTimeField58.getName();
        java.lang.String str64 = skipDateTimeField58.getName();
        java.lang.String str65 = skipDateTimeField58.getName();
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipDateTimeField58.getAsText(1L, locale67);
        org.joda.time.MonthDay monthDay69 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone71 = gJChronology70.getZone();
        org.joda.time.DateTimeZone dateTimeZone72 = null;
        org.joda.time.chrono.CopticChronology copticChronology73 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone72);
        long long77 = copticChronology73.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField78 = copticChronology73.eras();
        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology73);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.CopticChronology copticChronology81 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone80);
        long long85 = copticChronology81.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField86 = copticChronology81.eras();
        org.joda.time.MonthDay monthDay87 = monthDay79.withChronologyRetainFields((org.joda.time.Chronology) copticChronology81);
        int int88 = monthDay79.getMonthOfYear();
        int[] intArray90 = gJChronology70.get((org.joda.time.ReadablePartial) monthDay79, (long) (short) 100);
        int int91 = skipDateTimeField58.getMaximumValue((org.joda.time.ReadablePartial) monthDay69, intArray90);
        int[] intArray93 = skipDateTimeField17.addWrapPartial((org.joda.time.ReadablePartial) monthDay39, 11, intArray90, 0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10" + "'", str62.equals("10"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "millisOfSecond" + "'", str63.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "millisOfSecond" + "'", str64.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "millisOfSecond" + "'", str65.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1" + "'", str68.equals("1"));
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(gJChronology70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(copticChronology73);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(copticChronology81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 4 + "'", int88 == 4);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 999 + "'", int91 == 999);
        org.junit.Assert.assertNotNull(intArray93);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone35);
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology36, readableDateTime37, readableDateTime38);
        org.joda.time.DurationField durationField40 = limitChronology39.weekyears();
        org.joda.time.DateTimeField dateTimeField41 = limitChronology39.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 10, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.minusMonths((int) '4');
        org.joda.time.DateTime dateTime48 = dateTime46.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar49 = dateTime46.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone50);
        long long55 = copticChronology51.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField56 = copticChronology51.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.Chronology chronology58 = copticChronology51.withZone(dateTimeZone57);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone59);
        long long64 = copticChronology60.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField65 = copticChronology60.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField67 = new org.joda.time.field.SkipDateTimeField(chronology58, dateTimeField65, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = skipDateTimeField67.getType();
        org.joda.time.DateTime.Property property69 = dateTime46.property(dateTimeFieldType68);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, dateTimeFieldType68, (int) (byte) 10, (int) (byte) 100, (-1));
        int int74 = offsetDateTimeField73.getMaximumValue();
        java.lang.String str75 = offsetDateTimeField73.getName();
        org.joda.time.DurationField durationField76 = offsetDateTimeField73.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField77 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField76);
        org.joda.time.DateTime dateTime79 = dateTime2.withField(dateTimeFieldType33, 100);
        org.joda.time.ReadableInstant readableInstant80 = null;
        boolean boolean81 = dateTime79.isAfter(readableInstant80);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(gregorianCalendar49);
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(copticChronology60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "millisOfSecond" + "'", str75.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField77);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "millisOfSecond");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "LimitChronology[CopticChronology[America/Los_Angeles], NoLimit, NoLimit]", "Coordinated Universal Time");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfYear(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone41);
        long long46 = copticChronology42.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField47 = copticChronology42.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology42.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone49);
        long long54 = copticChronology50.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField55 = copticChronology50.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.Chronology chronology57 = copticChronology50.withZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone58);
        long long63 = copticChronology59.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField64 = copticChronology59.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField(chronology57, dateTimeField64, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipDateTimeField66.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, dateTimeFieldType67, (int) '#', 1, 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType67);
        int int75 = offsetDateTimeField38.getDifference((long) 647, (-136771200989L));
        java.util.Locale locale76 = null;
        int int77 = offsetDateTimeField38.getMaximumShortTextLength(locale76);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3165 + "'", int75 == 3165);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime9, readableDateTime10);
        org.joda.time.DurationField durationField12 = limitChronology11.weekyears();
        org.joda.time.DateTimeField dateTimeField13 = limitChronology11.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 10, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar21 = dateTime18.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        long long27 = copticChronology23.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology23.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology23.withZone(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone31);
        long long36 = copticChronology32.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField37 = copticChronology32.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField(chronology30, dateTimeField37, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipDateTimeField39.getType();
        org.joda.time.DateTime.Property property41 = dateTime18.property(dateTimeFieldType40);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType40, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder6.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendTwoDigitYear(1965);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(limitChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        int int43 = offsetDateTimeField38.getMaximumValue();
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField38.getAsShortText((int) (short) 100, locale45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField38.getAsShortText(3, locale48);
        long long51 = offsetDateTimeField38.roundHalfFloor(8640000012L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "100" + "'", str46.equals("100"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "3" + "'", str49.equals("3"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 8625600000L + "'", long51 == 8625600000L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) '4');
        int int11 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime13 = dateTime8.plusYears((int) (byte) -1);
        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfHour();
        org.joda.time.DurationField durationField15 = property14.getDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime4.getWeekyear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra(49156);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1965 + "'", int5 == 1965);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfDay((int) (byte) 0);
        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
        java.lang.String str12 = property11.getAsText();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1965" + "'", str12.equals("1965"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        try {
            int int73 = unsupportedDateTimeField70.get(32L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.String str2 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str2.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DurationField durationField7 = copticChronology1.eras();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.year();
        org.joda.time.Chronology chronology9 = copticChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology10.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18);
        long long23 = copticChronology19.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField24 = copticChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField(chronology17, dateTimeField24, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField26.getType();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField26.getAsText(10, locale29);
        java.lang.String str31 = skipDateTimeField26.getName();
        int int32 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField26);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField26.getType();
        int int36 = skipDateTimeField26.getDifference((long) 10, 100L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfSecond" + "'", str31.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-90) + "'", int36 == (-90));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField3 = buddhistChronology0.eras();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 12);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime9, readableDateTime10);
        org.joda.time.DurationField durationField12 = limitChronology11.weekyears();
        org.joda.time.DateTimeField dateTimeField13 = limitChronology11.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 10, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths((int) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar21 = dateTime18.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        long long27 = copticChronology23.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology23.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology23.withZone(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone31);
        long long36 = copticChronology32.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField37 = copticChronology32.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField(chronology30, dateTimeField37, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipDateTimeField39.getType();
        org.joda.time.DateTime.Property property41 = dateTime18.property(dateTimeFieldType40);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType40, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType40);
        org.joda.time.format.DateTimePrinter dateTimePrinter47 = dateTimeFormatterBuilder6.toPrinter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap48 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(limitChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimePrinter47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        long long41 = offsetDateTimeField38.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
        try {
            long long45 = offsetDateTimeField38.addWrapField((long) (short) 1, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        int int44 = offsetDateTimeField38.getLeapAmount((long) 1);
        java.util.Locale locale45 = null;
        int int46 = offsetDateTimeField38.getMaximumShortTextLength(locale45);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        long long44 = offsetDateTimeField38.roundHalfFloor(53L);
        int int46 = offsetDateTimeField38.get((long) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) 10, dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime54.minusMonths((int) '4');
        int int57 = dateTime54.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property58 = dateTime54.monthOfYear();
        org.joda.time.DateTime dateTime59 = property58.getDateTime();
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime62 = dateTime59.minusYears(0);
        org.joda.time.LocalDateTime localDateTime63 = dateTime62.toLocalDateTime();
        boolean boolean64 = fixedDateTimeZone51.isLocalDateTimeGap(localDateTime63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDateTime63, (int) '#', locale66);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-14400000L) + "'", long44 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "35" + "'", str67.equals("35"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        int int18 = skipDateTimeField17.getMaximumValue();
        long long20 = skipDateTimeField17.roundCeiling((long) (short) 100);
        java.util.Locale locale23 = null;
        long long24 = skipDateTimeField17.set((long) 0, "100", locale23);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime2.millisOfDay();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.util.Locale locale71 = null;
        try {
            int int72 = unsupportedDateTimeField70.getMaximumTextLength(locale71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean6 = dateTimeZone0.isStandardOffset(10L);
        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int14 = fixedDateTimeZone12.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int17 = cachedDateTimeZone15.getOffset(28799001L);
        long long19 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (-136771199990L));
        long long22 = dateTimeZone0.convertLocalToUTC((long) (byte) 1, false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136771200989L) + "'", long19 == (-136771200989L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        long long41 = offsetDateTimeField38.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
        java.lang.String str44 = offsetDateTimeField38.getAsText(35L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "11" + "'", str44.equals("11"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeField dateTimeField5 = limitChronology4.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = limitChronology4.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = copticChronology0.add(readablePeriod3, (long) 49154, 49159);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.weekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 49154L + "'", long6 == 49154L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DurationField durationField10 = limitChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = limitChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology21.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, dateTimeField35, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTime.Property property39 = dateTime16.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType38, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 0, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendHourOfDay(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
        int int4 = dateTime2.getYear();
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) '#');
        org.joda.time.Instant instant8 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.era();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean6 = dateTimeZone0.isStandardOffset(10L);
        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long11 = dateTimeZone8.convertLocalToUTC((-136771199990L), true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-136771199990L) + "'", long11 == (-136771199990L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        boolean boolean72 = unsupportedDateTimeField70.isLenient();
        java.util.Locale locale74 = null;
        try {
            java.lang.String str75 = unsupportedDateTimeField70.getAsText((-27L), locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 24, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        org.joda.time.MonthDay monthDay19 = property16.getMonthDay();
        org.joda.time.MonthDay monthDay20 = property16.getMonthDay();
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = monthDay20.toString("JulianChronology[UTC]", locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        long long6 = copticChronology2.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.millisOfSecond();
        org.joda.time.DurationField durationField8 = copticChronology2.eras();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(100L, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.MonthDay monthDay9 = monthDay7.minusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField16 = copticChronology11.eras();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18);
        long long23 = copticChronology19.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField24 = copticChronology19.eras();
        org.joda.time.MonthDay monthDay25 = monthDay17.withChronologyRetainFields((org.joda.time.Chronology) copticChronology19);
        org.joda.time.MonthDay.Property property26 = monthDay25.dayOfMonth();
        java.util.Locale locale27 = null;
        int int28 = property26.getMaximumTextLength(locale27);
        org.joda.time.MonthDay monthDay29 = property26.getMonthDay();
        boolean boolean30 = monthDay7.isEqual((org.joda.time.ReadablePartial) monthDay29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.minus(readablePeriod31);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(monthDay32);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.setCopy(49153);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(49166778);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        java.lang.String str39 = offsetDateTimeField38.toString();
        int int41 = offsetDateTimeField38.getLeapAmount((-901L));
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str39.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatterBuilder10.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology11.getZone();
        org.joda.time.Chronology chronology17 = gregorianChronology2.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean8 = fixedDateTimeZone7.isFixed();
        int int10 = fixedDateTimeZone7.getOffset((long) 57649);
        boolean boolean11 = fixedDateTimeZone7.isFixed();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) chronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.MonthDay monthDay9 = monthDay7.minusMonths((int) (short) 1);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.lang.String str71 = unsupportedDateTimeField70.getName();
        java.util.Locale locale72 = null;
        try {
            int int73 = unsupportedDateTimeField70.getMaximumTextLength(locale72);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfSecond" + "'", str71.equals("millisOfSecond"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        long long6 = copticChronology2.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime13.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 10, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar22 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        long long28 = copticChronology24.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField29 = copticChronology24.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology24.withZone(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField(chronology31, dateTimeField38, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField40.getType();
        org.joda.time.DateTime.Property property42 = dateTime19.property(dateTimeFieldType41);
        int int43 = dateTime13.get(dateTimeFieldType41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType41, (int) ' ');
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType41, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1965 + "'", int14 == 1965);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianCalendar22);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add(0L, (int) ' ');
        int int34 = skipUndoDateTimeField28.getDifference((long) 11, 8L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        int int7 = copticChronology1.getMinimumDaysInFirstWeek();
        java.lang.String str8 = copticChronology1.toString();
        try {
            long long13 = copticChronology1.getDateTimeMillis((int) (byte) 100, (-1440000000), 2000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1440000000 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str8.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        try {
            java.lang.String str72 = unsupportedDateTimeField70.getAsText(9990L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DurationField durationField18 = skipDateTimeField17.getLeapDurationField();
        java.lang.String str20 = skipDateTimeField17.getAsShortText((long) 57600010);
        int int22 = skipDateTimeField17.getLeapAmount((long) (byte) 0);
        org.joda.time.DurationField durationField23 = skipDateTimeField17.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray26 = null;
        try {
            int[] intArray28 = skipDateTimeField17.addWrapPartial(readablePartial24, 0, intArray26, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTimeZoneOffset("Property[monthOfYear]", false, 49119, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DurationField durationField18 = skipDateTimeField17.getLeapDurationField();
        long long20 = skipDateTimeField17.roundFloor(35100L);
        int int21 = skipDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35100L + "'", long20 == 35100L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.era();
        org.joda.time.DateTime.Property property6 = dateTime2.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        java.util.Date date16 = dateTime13.toDate();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField23 = copticChronology18.eras();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology18);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone25);
        long long30 = copticChronology26.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField31 = copticChronology26.eras();
        org.joda.time.MonthDay monthDay32 = monthDay24.withChronologyRetainFields((org.joda.time.Chronology) copticChronology26);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 10, dateTimeZone34);
        org.joda.time.DateTime dateTime37 = dateTime35.minusMonths((int) '4');
        org.joda.time.DateTime dateTime39 = dateTime37.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar40 = dateTime37.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone41);
        long long46 = copticChronology42.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField47 = copticChronology42.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.Chronology chronology49 = copticChronology42.withZone(dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone50);
        long long55 = copticChronology51.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField56 = copticChronology51.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField(chronology49, dateTimeField56, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = skipDateTimeField58.getType();
        org.joda.time.DateTime.Property property60 = dateTime37.property(dateTimeFieldType59);
        boolean boolean61 = monthDay32.isSupported(dateTimeFieldType59);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone62);
        long long67 = copticChronology63.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField68 = copticChronology63.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.Chronology chronology70 = copticChronology63.withZone(dateTimeZone69);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.CopticChronology copticChronology72 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone71);
        long long76 = copticChronology72.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField77 = copticChronology72.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField79 = new org.joda.time.field.SkipDateTimeField(chronology70, dateTimeField77, (int) (byte) 100);
        org.joda.time.MonthDay monthDay80 = monthDay32.withChronologyRetainFields(chronology70);
        org.joda.time.DateTime dateTime81 = dateTime13.withFields((org.joda.time.ReadablePartial) monthDay80);
        try {
            int int82 = property6.compareTo((org.joda.time.ReadablePartial) monthDay80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gregorianCalendar40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(copticChronology72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(dateTime81);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.clockhourOfHalfday();
        long long10 = limitChronology4.add(3500L, 35L, 1969);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 72415L + "'", long10 == 72415L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        java.lang.String str39 = offsetDateTimeField38.toString();
        long long41 = offsetDateTimeField38.roundHalfCeiling(1L);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField38.getAsText(2019, locale43);
        long long46 = offsetDateTimeField38.roundFloor((long) (byte) 1);
        long long48 = offsetDateTimeField38.roundHalfFloor((long) 1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str39.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-14400000L) + "'", long48 == (-14400000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        long long8 = fixedDateTimeZone4.previousTransition((long) (byte) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.previousTransition((long) (short) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        long long18 = copticChronology14.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology14.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology14.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        long long27 = copticChronology23.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField(chronology21, dateTimeField28, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField30.getType();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsText(10, locale33);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        int int40 = dateTime37.getWeekOfWeekyear();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime37.toYearMonthDay();
        int int42 = skipDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay41);
        long long44 = buddhistChronology12.set((org.joda.time.ReadablePartial) yearMonthDay41, 8640000012L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10" + "'", str34.equals("10"));
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 999 + "'", int42 == 999);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-17134761599988L) + "'", long44 == (-17134761599988L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
        org.joda.time.MonthDay monthDay20 = property16.setCopy("10");
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 10, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMonths((int) '4');
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar28 = dateTime25.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.Chronology chronology37 = copticChronology30.withZone(dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38);
        long long43 = copticChronology39.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField44 = copticChronology39.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField(chronology37, dateTimeField44, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField46.getType();
        org.joda.time.DateTime.Property property48 = dateTime25.property(dateTimeFieldType47);
        org.joda.time.DateTime dateTime50 = dateTime25.plusSeconds((int) (short) -1);
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now();
        org.joda.time.DateTime dateTime52 = dateTime25.withFields((org.joda.time.ReadablePartial) monthDay51);
        org.joda.time.MutableDateTime mutableDateTime53 = dateTime52.toMutableDateTimeISO();
        int int54 = property16.compareTo((org.joda.time.ReadableInstant) dateTime52);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianCalendar28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str1 = monthDay0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str3 = monthDay0.toString(dateTimeFormatter2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int10 = fixedDateTimeZone8.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int13 = fixedDateTimeZone8.getOffset((long) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int15 = dateTimeFormatter2.getDefaultYear();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--12-15" + "'", str1.equals("--12-15"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����-W��-�" + "'", str3.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2000 + "'", int15 == 2000);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2019, 77939, (int) (byte) 100, (-90), 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -90 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        org.joda.time.DurationField durationField41 = offsetDateTimeField38.getRangeDurationField();
        int int43 = offsetDateTimeField38.getLeapAmount((long) (short) 100);
        int int44 = offsetDateTimeField38.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-9552L), (org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        boolean boolean12 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTime4);
        int int14 = dateTime4.getMinuteOfDay();
        org.joda.time.DateTime dateTime16 = dateTime4.withMillisOfDay(49161);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 960 + "'", int14 == 960);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
        java.util.Locale locale19 = null;
        int int20 = property16.getMaximumTextLength(locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property16.getFieldType();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.centuryOfEra();
        long long7 = gJChronology2.add(0L, (long) 999, 57600);
        try {
            org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(292278993, (int) (byte) 1, (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 57542400L + "'", long7 == 57542400L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int9 = fixedDateTimeZone7.getOffset((-1L));
        long long11 = fixedDateTimeZone7.previousTransition((long) (byte) 10);
        java.util.TimeZone timeZone12 = fixedDateTimeZone7.toTimeZone();
        org.joda.time.Chronology chronology13 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str14 = fixedDateTimeZone7.toString();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfSecond" + "'", str14.equals("millisOfSecond"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        org.joda.time.DurationField durationField44 = offsetDateTimeField38.getRangeDurationField();
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField38.getAsShortText((int) (short) 1, locale46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, 100);
        int int51 = offsetDateTimeField38.getMinimumValue((long) 57600);
        int int53 = offsetDateTimeField38.getMaximumValue(14L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DurationField durationField18 = skipDateTimeField17.getLeapDurationField();
        java.lang.String str20 = skipDateTimeField17.getAsShortText((long) 57600010);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipDateTimeField17.getAsShortText((long) (-1440000000), locale22);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        int int42 = property41.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        int int40 = offsetDateTimeField38.getOffset();
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((long) 6);
        java.lang.String str43 = offsetDateTimeField38.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "11" + "'", str42.equals("11"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str43.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(49119, 57600010, 57600010, 49156, 1965, 4, 49161);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49156 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        org.joda.time.DurationField durationField24 = skipDateTimeField17.getLeapDurationField();
        int int26 = skipDateTimeField17.get((long) (byte) 100);
        org.joda.time.DurationField durationField27 = skipDateTimeField17.getLeapDurationField();
        long long29 = skipDateTimeField17.remainder(2073649157L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendLiteral("10");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder10.appendWeekyear(0, 8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("--04-06", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"--04-06/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        java.lang.String str42 = property41.getAsText();
        org.joda.time.DateTime dateTime43 = property41.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1965" + "'", str42.equals("1965"));
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) '4');
        int int11 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime4.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(77939, 647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78586 + "'", int2 == 78586);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.era();
        org.joda.time.DateTime.Property property6 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        long long8 = fixedDateTimeZone4.previousTransition((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar16 = dateTime13.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = copticChronology18.withZone(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        long long31 = copticChronology27.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField32 = copticChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology25, dateTimeField32, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField34.getType();
        org.joda.time.DateTime.Property property36 = dateTime13.property(dateTimeFieldType35);
        org.joda.time.DateTime dateTime38 = dateTime13.plusSeconds((int) (short) -1);
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now();
        org.joda.time.DateTime dateTime40 = dateTime13.withFields((org.joda.time.ReadablePartial) monthDay39);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime40.toMutableDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.DateTime dateTime45 = dateTime40.withDurationAdded(readableDuration43, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(0);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        int int5 = dateTime3.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTime dateTime29 = dateTime4.plusSeconds((int) (short) -1);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.DateTime dateTime31 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.DateTime dateTime33 = dateTime31.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime35 = dateTime31.plusSeconds(6);
        org.joda.time.DateTime.Property property36 = dateTime31.dayOfWeek();
        org.joda.time.DurationField durationField37 = property36.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNull(durationField37);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        java.lang.String str39 = offsetDateTimeField38.toString();
        long long41 = offsetDateTimeField38.roundHalfCeiling(1L);
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField38.getMaximumShortTextLength(locale42);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str39.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("3");
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime43 = dateTime4.plusHours(0);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = dateTime4.toString("����-W��-�", locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime13.getWeekyear();
        boolean boolean16 = dateTime13.equals((java.lang.Object) "millisOfSecond");
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, (org.joda.time.ReadableDateTime) dateTime13, readableDateTime17);
        try {
            long long26 = limitChronology18.getDateTimeMillis((int) ' ', 52, 186, (int) (short) -1, 0, (-90), 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1965 + "'", int14 == 1965);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime20 = dateTime16.minus((long) 49128);
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology23 = dateTimeFormatter22.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gregorianChronology24);
        boolean boolean27 = gregorianChronology24.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.Chronology chronology29 = gregorianChronology24.withZone(dateTimeZone28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology24.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone38 = copticChronology33.getZone();
        org.joda.time.Chronology chronology39 = gregorianChronology24.withZone(dateTimeZone38);
        org.joda.time.DateTime dateTime40 = dateTime20.toDateTime(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNull(chronology23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology2.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DurationField durationField28 = property27.getDurationField();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime dateTime31 = property27.setCopy(0);
        int int32 = dateTime31.getWeekyear();
        org.joda.time.DateTime dateTime34 = dateTime31.minusMillis((-28799001));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1965 + "'", int32 == 1965);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DurationField durationField6 = limitChronology4.days();
        org.joda.time.DateTime dateTime7 = limitChronology4.getUpperLimit();
        try {
            long long13 = limitChronology4.getDateTimeMillis((long) (short) -1, 57649, 6, 11, 65);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57649 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNull(dateTime7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) 52L, (java.lang.Number) (-124271280421990L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        long long41 = offsetDateTimeField38.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 10, dateTimeZone44);
        org.joda.time.DateTime dateTime47 = dateTime45.minusMonths((int) '4');
        org.joda.time.DateTime dateTime49 = dateTime47.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.DateTime dateTime51 = dateTime49.plus(readableDuration50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.Chronology chronology60 = copticChronology53.withZone(dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone61);
        long long66 = copticChronology62.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField67 = copticChronology62.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField69 = new org.joda.time.field.SkipDateTimeField(chronology60, dateTimeField67, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = skipDateTimeField69.getType();
        java.util.Locale locale72 = null;
        java.lang.String str73 = skipDateTimeField69.getAsText(10, locale72);
        java.lang.String str74 = skipDateTimeField69.getName();
        int int75 = dateTime51.get((org.joda.time.DateTimeField) skipDateTimeField69);
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = skipDateTimeField69.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType76);
        try {
            long long80 = offsetDateTimeField38.add((long) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for millisOfSecond must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400000L) + "'", long41 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "10" + "'", str73.equals("10"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "millisOfSecond" + "'", str74.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 9 + "'", int75 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str1 = monthDay0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str3 = monthDay0.toString(dateTimeFormatter2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int10 = fixedDateTimeZone8.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int13 = fixedDateTimeZone8.getOffset((long) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.Appendable appendable15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        try {
            dateTimeFormatter14.printTo(appendable15, readableInstant16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--12-15" + "'", str1.equals("--12-15"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����-W��-�" + "'", str3.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        boolean boolean72 = unsupportedDateTimeField70.isLenient();
        long long75 = unsupportedDateTimeField70.add((long) 49157, 24);
        try {
            int int77 = unsupportedDateTimeField70.getMaximumValue((long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2073649157L + "'", long75 == 2073649157L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(186, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(49128);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) '4');
        int int11 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology13, readableDateTime14, readableDateTime15);
        org.joda.time.DurationField durationField17 = limitChronology16.weekyears();
        org.joda.time.DateTimeField dateTimeField18 = limitChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 10, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMonths((int) '4');
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar26 = dateTime23.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone27);
        long long32 = copticChronology28.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField33 = copticChronology28.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.Chronology chronology35 = copticChronology28.withZone(dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone36);
        long long41 = copticChronology37.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField42 = copticChronology37.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField(chronology35, dateTimeField42, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipDateTimeField44.getType();
        org.joda.time.DateTime.Property property46 = dateTime23.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType45, (int) (byte) 10, (int) (byte) 100, (-1));
        int int51 = offsetDateTimeField50.getMaximumValue();
        java.lang.String str52 = offsetDateTimeField50.getName();
        long long54 = offsetDateTimeField50.roundHalfEven((long) 10);
        int int55 = offsetDateTimeField50.getMaximumValue();
        int int56 = dateTime4.get((org.joda.time.DateTimeField) offsetDateTimeField50);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "millisOfSecond" + "'", str52.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-14400000L) + "'", long54 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.dayOfWeek();
        int int42 = dateTime4.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 2073649157L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        int int45 = offsetDateTimeField38.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = limitChronology5.weekyears();
        org.joda.time.DurationField durationField7 = limitChronology5.days();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) -1, (org.joda.time.Chronology) limitChronology5);
        org.joda.time.DurationField durationField9 = limitChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology5.weekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone41);
        long long46 = copticChronology42.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField47 = copticChronology42.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology42.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone49);
        long long54 = copticChronology50.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField55 = copticChronology50.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.Chronology chronology57 = copticChronology50.withZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone58);
        long long63 = copticChronology59.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField64 = copticChronology59.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField(chronology57, dateTimeField64, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipDateTimeField66.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, dateTimeFieldType67, (int) '#', 1, 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType67);
        boolean boolean73 = offsetDateTimeField38.isSupported();
        org.joda.time.DurationField durationField74 = offsetDateTimeField38.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNull(durationField74);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        boolean boolean9 = dateTimeZone7.isStandardOffset(3500L);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(999, 57600010, 57600010, 65, 999, (int) (byte) 10, 10, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 65 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean6 = dateTimeZone0.isStandardOffset(10L);
        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int14 = fixedDateTimeZone12.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int17 = cachedDateTimeZone15.getOffset(28799001L);
        long long19 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (-136771199990L));
        long long22 = cachedDateTimeZone15.convertLocalToUTC((long) '4', false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136771200989L) + "'", long19 == (-136771200989L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-947L) + "'", long22 == (-947L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        java.lang.String str22 = skipDateTimeField17.getName();
        java.lang.String str23 = skipDateTimeField17.getName();
        java.lang.String str24 = skipDateTimeField17.getName();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField17.getAsText(1L, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology29.getZone();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone31);
        long long36 = copticChronology32.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField37 = copticChronology32.eras();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology32);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.CopticChronology copticChronology40 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone39);
        long long44 = copticChronology40.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField45 = copticChronology40.eras();
        org.joda.time.MonthDay monthDay46 = monthDay38.withChronologyRetainFields((org.joda.time.Chronology) copticChronology40);
        int int47 = monthDay38.getMonthOfYear();
        int[] intArray49 = gJChronology29.get((org.joda.time.ReadablePartial) monthDay38, (long) (short) 100);
        int int50 = skipDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay28, intArray49);
        int int52 = skipDateTimeField17.getLeapAmount((long) 10);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "millisOfSecond" + "'", str22.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "millisOfSecond" + "'", str23.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "millisOfSecond" + "'", str24.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(copticChronology40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        boolean boolean5 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        long long11 = copticChronology7.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology7.getZone();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime21, readableDateTime22);
        org.joda.time.DurationField durationField24 = limitChronology23.weekyears();
        org.joda.time.DateTimeField dateTimeField25 = limitChronology23.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 10, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) '4');
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar33 = dateTime30.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        long long39 = copticChronology35.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField40 = copticChronology35.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.Chronology chronology42 = copticChronology35.withZone(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField(chronology42, dateTimeField49, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = skipDateTimeField51.getType();
        org.joda.time.DateTime.Property property53 = dateTime30.property(dateTimeFieldType52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType52, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType52);
        int int59 = dateTime13.get(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType52, 11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 12, "1965-06-15T16:00:00.010-07:00");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(gregorianCalendar33);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.plus(readablePeriod2);
        java.lang.String str5 = monthDay3.toString("3");
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3" + "'", str5.equals("3"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = limitChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology5.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar15 = dateTime12.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
        long long21 = copticChronology17.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology17.withZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone25);
        long long30 = copticChronology26.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology26.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField(chronology24, dateTimeField31, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField33.getType();
        org.joda.time.DateTime.Property property35 = dateTime12.property(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType34, (int) (byte) 10, (int) (byte) 100, (-1));
        int int40 = offsetDateTimeField39.getMaximumValue();
        java.lang.String str41 = offsetDateTimeField39.getName();
        org.joda.time.DurationField durationField42 = offsetDateTimeField39.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField39.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "millisOfSecond" + "'", str41.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        int int22 = skipDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
        java.lang.String str19 = property16.getAsString();
        java.lang.String str20 = property16.getAsString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone21);
        long long26 = copticChronology22.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField27 = copticChronology22.eras();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology22);
        boolean boolean30 = monthDay28.equals((java.lang.Object) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay33 = monthDay28.withPeriodAdded(readablePeriod31, (int) (short) 1);
        int int34 = property16.compareTo((org.joda.time.ReadablePartial) monthDay28);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "6" + "'", str19.equals("6"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6" + "'", str20.equals("6"));
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (-14400000L), (java.lang.Number) 52);
        illegalFieldValueException4.prependMessage("UTC");
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 52 + "'", number7.equals(52));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 52 + "'", number8.equals(52));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add(0L, (int) ' ');
        int int33 = skipUndoDateTimeField28.get((long) 49157);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 157 + "'", int33 == 157);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime7.minusYears(0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(1965);
        int int13 = dateTime12.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 58 + "'", int13 == 58);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.lang.String str71 = unsupportedDateTimeField70.getName();
        org.joda.time.DurationField durationField72 = unsupportedDateTimeField70.getLeapDurationField();
        try {
            long long75 = unsupportedDateTimeField70.set((long) (short) 100, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfSecond" + "'", str71.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField72);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((long) 12, 70, 292278993, 0, (-28799001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withZoneRetainFields(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.secondOfMinute();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((long) (short) 10, (org.joda.time.Chronology) copticChronology21);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology30.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone37);
        long long42 = copticChronology38.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField43 = copticChronology38.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.Chronology chronology45 = copticChronology38.withZone(dateTimeZone44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone46);
        long long51 = copticChronology47.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField52 = copticChronology47.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField(chronology45, dateTimeField52, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType55, (int) '#', 1, 100);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.CopticChronology copticChronology61 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone60);
        long long65 = copticChronology61.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField66 = copticChronology61.eras();
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology61);
        boolean boolean69 = monthDay67.equals((java.lang.Object) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone72 = gJChronology71.getZone();
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.chrono.CopticChronology copticChronology74 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone73);
        long long78 = copticChronology74.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField79 = copticChronology74.eras();
        org.joda.time.MonthDay monthDay80 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology74);
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.chrono.CopticChronology copticChronology82 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone81);
        long long86 = copticChronology82.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField87 = copticChronology82.eras();
        org.joda.time.MonthDay monthDay88 = monthDay80.withChronologyRetainFields((org.joda.time.Chronology) copticChronology82);
        int int89 = monthDay80.getMonthOfYear();
        int[] intArray91 = gJChronology71.get((org.joda.time.ReadablePartial) monthDay80, (long) (short) 100);
        int[] intArray93 = offsetDateTimeField59.addWrapField((org.joda.time.ReadablePartial) monthDay67, (int) (byte) 0, intArray91, (int) '4');
        try {
            int[] intArray95 = skipDateTimeField17.addWrapPartial((org.joda.time.ReadablePartial) monthDay27, 2019, intArray91, 49154);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(copticChronology61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertNotNull(copticChronology74);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertNotNull(copticChronology82);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
        org.junit.Assert.assertNotNull(durationField87);
        org.junit.Assert.assertNotNull(monthDay88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 4 + "'", int89 == 4);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray93);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology11.getZone();
        org.joda.time.Chronology chronology17 = gregorianChronology2.withZone(dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        int int19 = gJChronology18.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) '4');
        int int8 = dateTime7.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar16 = dateTime13.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = copticChronology18.withZone(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        long long31 = copticChronology27.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField32 = copticChronology27.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology25, dateTimeField32, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField34.getType();
        org.joda.time.DateTime.Property property36 = dateTime13.property(dateTimeFieldType35);
        int int37 = dateTime7.get(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType35, (int) (byte) 10, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendClockhourOfDay((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap44 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendTimeZoneShortName(strMap44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendMillisOfDay((int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = dateTimeFormatterBuilder47.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatter49.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder40.append(dateTimePrinter48, dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTwoDigitWeekyear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendClockhourOfDay((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap57 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder56.appendTimeZoneShortName(strMap57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMillisOfDay((int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter61 = dateTimeFormatterBuilder60.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder53.append(dateTimePrinter61);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap63 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder53.appendTimeZoneName(strMap63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1965 + "'", int8 == 1965);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimePrinter48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimePrinter61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        int int36 = property35.getLeapAmount();
        int int37 = property35.getMaximumValue();
        org.joda.time.DateTime dateTime39 = property35.setCopy(9);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((long) 49166778, 9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime20 = dateTime16.minus((long) 49128);
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology24.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        long long31 = copticChronology27.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField32 = copticChronology27.eras();
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology27);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        long long39 = copticChronology35.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField40 = copticChronology35.eras();
        org.joda.time.MonthDay monthDay41 = monthDay33.withChronologyRetainFields((org.joda.time.Chronology) copticChronology35);
        int int42 = monthDay33.getMonthOfYear();
        int[] intArray44 = gJChronology24.get((org.joda.time.ReadablePartial) monthDay33, (long) (short) 100);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology24);
        org.joda.time.DateTime dateTime46 = dateTime23.withChronology(chronology45);
        try {
            org.joda.time.DateTime dateTime48 = dateTime46.withDayOfWeek(78586);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78586 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTime46);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = property6.getDifference((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime15.toString();
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime21 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime15.toDateTimeISO();
        org.joda.time.DateTime dateTime25 = dateTime15.withDurationAdded(52L, (int) (short) 100);
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
        int int27 = property26.get();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 69 + "'", int27 == 69);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime20 = dateTime16.minus((long) 49128);
        org.joda.time.DateTime dateTime23 = dateTime16.withDurationAdded((long) 10, 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        int int20 = dateTime16.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 0);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        java.lang.String str22 = skipDateTimeField17.getName();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 10, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusMonths((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime27.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readableDuration30);
        java.util.Date date32 = dateTime29.toDate();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.fromDateFields(date32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology36.getZone();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38);
        long long43 = copticChronology39.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField44 = copticChronology39.eras();
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology39);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone46);
        long long51 = copticChronology47.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField52 = copticChronology47.eras();
        org.joda.time.MonthDay monthDay53 = monthDay45.withChronologyRetainFields((org.joda.time.Chronology) copticChronology47);
        int int54 = monthDay45.getMonthOfYear();
        int[] intArray56 = gJChronology36.get((org.joda.time.ReadablePartial) monthDay45, (long) (short) 100);
        int int57 = skipDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay35, intArray56);
        org.joda.time.DateTimeField[] dateTimeFieldArray58 = monthDay35.getFields();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "millisOfSecond" + "'", str22.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 999 + "'", int57 == 999);
        org.junit.Assert.assertNotNull(dateTimeFieldArray58);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (short) 100);
        org.joda.time.Instant instant6 = instant3.withDurationAdded(3500L, (int) (byte) 10);
        org.joda.time.Instant instant7 = instant6.toInstant();
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 31, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTime((org.joda.time.Chronology) copticChronology9);
        try {
            long long15 = copticChronology9.getDateTimeMillis((int) (byte) 10, (int) (byte) 0, 186, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        long long6 = copticChronology2.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.secondOfMinute();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (short) 10, (org.joda.time.Chronology) copticChronology2);
        try {
            org.joda.time.MonthDay monthDay10 = monthDay8.withMonthOfYear(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("965", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"965\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone42);
        long long47 = copticChronology43.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField48 = copticChronology43.eras();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology43);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone50);
        long long55 = copticChronology51.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField56 = copticChronology51.eras();
        org.joda.time.MonthDay monthDay57 = monthDay49.withChronologyRetainFields((org.joda.time.Chronology) copticChronology51);
        int int58 = monthDay57.getDayOfMonth();
        int[] intArray60 = null;
        try {
            int[] intArray62 = offsetDateTimeField38.add((org.joda.time.ReadablePartial) monthDay57, 52, intArray60, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay11.plus(readablePeriod12);
        int int14 = property6.compareTo((org.joda.time.ReadablePartial) monthDay13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 49157);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = gregorianChronology2.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        long long45 = offsetDateTimeField38.roundHalfEven((long) 100);
        int int46 = offsetDateTimeField38.getOffset();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-14400000L) + "'", long45 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis(77939);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("10");
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfDay((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        long long16 = copticChronology12.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology12.getZone();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTime6, dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "2019");
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (-14400000L), (java.lang.Number) 52);
        illegalFieldValueException7.prependMessage("UTC");
        java.lang.Number number10 = illegalFieldValueException7.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 52 + "'", number10.equals(52));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add((long) (short) -1, (long) 65);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField46 = copticChronology41.eras();
        org.joda.time.MonthDay monthDay47 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) copticChronology41);
        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
        java.util.Locale locale49 = null;
        int int50 = property48.getMaximumTextLength(locale49);
        org.joda.time.MonthDay monthDay51 = property48.getMonthDay();
        org.joda.time.MonthDay monthDay52 = property48.getMonthDay();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone55 = gJChronology54.getZone();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone56);
        long long61 = copticChronology57.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField62 = copticChronology57.eras();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology57);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.CopticChronology copticChronology65 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone64);
        long long69 = copticChronology65.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField70 = copticChronology65.eras();
        org.joda.time.MonthDay monthDay71 = monthDay63.withChronologyRetainFields((org.joda.time.Chronology) copticChronology65);
        int int72 = monthDay63.getMonthOfYear();
        int[] intArray74 = gJChronology54.get((org.joda.time.ReadablePartial) monthDay63, (long) (short) 100);
        int[] intArray76 = skipUndoDateTimeField28.addWrapPartial((org.joda.time.ReadablePartial) monthDay52, 0, intArray74, 49154);
        java.lang.String str78 = skipUndoDateTimeField28.getAsText(8625600000L);
        java.lang.String str79 = skipUndoDateTimeField28.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 64L + "'", long31 == 64L);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(copticChronology65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "0" + "'", str78.equals("0"));
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str79.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        org.joda.time.DurationField durationField72 = unsupportedDateTimeField70.getDurationField();
        try {
            long long74 = unsupportedDateTimeField70.roundHalfEven((long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertNotNull(durationField72);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology20 = dateTimeFormatter19.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gregorianChronology21);
        boolean boolean24 = gregorianChronology21.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone35 = copticChronology30.getZone();
        org.joda.time.Chronology chronology36 = gregorianChronology21.withZone(dateTimeZone35);
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime16.toMutableDateTime((org.joda.time.Chronology) gJChronology37);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(chronology20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.lang.String str71 = unsupportedDateTimeField70.getName();
        try {
            long long73 = unsupportedDateTimeField70.roundFloor((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfSecond" + "'", str71.equals("millisOfSecond"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime4.getWeekyear();
        boolean boolean7 = dateTime4.equals((java.lang.Object) "millisOfSecond");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        long long12 = dateTimeZone8.convertLocalToUTC((long) 31, false, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = dateTime4.withZone(dateTimeZone14);
        long long16 = dateTime4.getMillis();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1965 + "'", int5 == 1965);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31L + "'", long12 == 31L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-136774799990L) + "'", long16 == (-136774799990L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(448);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DurationField durationField10 = limitChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = limitChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology21.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, dateTimeField35, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTime.Property property39 = dateTime16.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType38, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendClockhourOfDay((int) '4');
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 10, dateTimeZone52);
        org.joda.time.DateTime dateTime55 = dateTime53.minusMonths((int) '4');
        int int56 = dateTime55.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 10, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.minusMonths((int) '4');
        org.joda.time.DateTime dateTime63 = dateTime61.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar64 = dateTime61.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone65);
        long long70 = copticChronology66.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField71 = copticChronology66.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone72 = null;
        org.joda.time.Chronology chronology73 = copticChronology66.withZone(dateTimeZone72);
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.chrono.CopticChronology copticChronology75 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone74);
        long long79 = copticChronology75.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField80 = copticChronology75.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField82 = new org.joda.time.field.SkipDateTimeField(chronology73, dateTimeField80, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = skipDateTimeField82.getType();
        org.joda.time.DateTime.Property property84 = dateTime61.property(dateTimeFieldType83);
        int int85 = dateTime55.get(dateTimeFieldType83);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder48.appendDecimal(dateTimeFieldType83, (int) (byte) 10, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder45.appendFixedSignedDecimal(dateTimeFieldType83, 186);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1965 + "'", int56 == 1965);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(gregorianCalendar64);
        org.junit.Assert.assertNotNull(copticChronology66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(copticChronology75);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
        org.junit.Assert.assertNotNull(property84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 10 + "'", int85 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        java.util.Locale locale29 = null;
        int int30 = skipUndoDateTimeField28.getMaximumShortTextLength(locale29);
        int int32 = skipUndoDateTimeField28.getMaximumValue((-27L));
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 999 + "'", int32 == 999);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        int int8 = dateTime4.getSecondOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField8 = copticChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime dateTime9 = dateTime4.withYear(0);
        org.joda.time.DateTime dateTime11 = dateTime4.withWeekyear(186);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        java.lang.String str6 = dateTime4.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTime dateTime16 = dateTime11.plusDays(49153);
        int int17 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1965-08-31T16:00:00.010-07:00" + "'", str6.equals("1965-08-31T16:00:00.010-07:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        try {
            long long9 = durationField6.subtract((long) 1965, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.CopticChronology copticChronology40 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone39);
        org.joda.time.ReadableDateTime readableDateTime41 = null;
        org.joda.time.ReadableDateTime readableDateTime42 = null;
        org.joda.time.chrono.LimitChronology limitChronology43 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology40, readableDateTime41, readableDateTime42);
        org.joda.time.DurationField durationField44 = limitChronology43.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField44);
        try {
            int int47 = unsupportedDateTimeField45.getMinimumValue((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(copticChronology40);
        org.junit.Assert.assertNotNull(limitChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.era();
        org.joda.time.DateTime.Property property6 = dateTime2.weekyear();
        java.lang.String str7 = property6.toString();
        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[weekyear]" + "'", str7.equals("Property[weekyear]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        java.lang.String str1 = monthDay0.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.String str3 = monthDay0.toString(dateTimeFormatter2);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
//        int int10 = fixedDateTimeZone8.getOffset((-1L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        int int13 = fixedDateTimeZone8.getOffset((long) (short) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--06-15" + "'", str1.equals("--06-15"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����-W��-�" + "'", str3.equals("����-W��-�"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        org.joda.time.DurationField durationField24 = skipDateTimeField17.getLeapDurationField();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone27);
        long long32 = copticChronology28.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField33 = copticChronology28.eras();
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology28);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone35);
        long long40 = copticChronology36.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField41 = copticChronology36.eras();
        org.joda.time.MonthDay monthDay42 = monthDay34.withChronologyRetainFields((org.joda.time.Chronology) copticChronology36);
        int int43 = monthDay34.getMonthOfYear();
        int[] intArray45 = gJChronology25.get((org.joda.time.ReadablePartial) monthDay34, (long) (short) 100);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay34, 12, locale47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay34.plus(readablePeriod49);
        org.joda.time.MonthDay.Property property51 = monthDay34.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "12" + "'", str48.equals("12"));
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(property51);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.era();
        org.joda.time.DateTime.Property property6 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime8 = dateTime2.withMillis((long) 647);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DurationField durationField10 = limitChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = limitChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology21.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, dateTimeField35, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTime.Property property39 = dateTime16.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType38, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone45);
        long long50 = copticChronology46.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField51 = copticChronology46.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField52 = copticChronology46.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology46.centuryOfEra();
        org.joda.time.DurationField durationField54 = copticChronology46.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField54);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) 10, dateTimeZone57);
        org.joda.time.DateTime dateTime60 = dateTime58.minusMonths((int) '4');
        org.joda.time.DateTime dateTime62 = dateTime60.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.DateTime dateTime64 = dateTime62.plus(readableDuration63);
        java.util.Date date65 = dateTime62.toDate();
        org.joda.time.MonthDay monthDay66 = org.joda.time.MonthDay.fromDateFields(date65);
        org.joda.time.ReadablePeriod readablePeriod67 = null;
        org.joda.time.MonthDay monthDay68 = monthDay66.plus(readablePeriod67);
        int[] intArray74 = new int[] { 49166778, (byte) -1, 57600010, (-1440000000) };
        try {
            int[] intArray76 = unsupportedDateTimeField55.add((org.joda.time.ReadablePartial) monthDay66, (int) (short) 0, intArray74, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(intArray74);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime13.getWeekyear();
        boolean boolean16 = dateTime13.equals((java.lang.Object) "millisOfSecond");
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, (org.joda.time.ReadableDateTime) dateTime13, readableDateTime17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.minus(readableDuration19);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1965 + "'", int14 == 1965);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        int int24 = skipDateTimeField17.getMaximumValue();
        java.lang.String str25 = skipDateTimeField17.toString();
        boolean boolean26 = skipDateTimeField17.isLenient();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str25.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
//        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
//        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
//        int int24 = skipDateTimeField17.getMaximumValue();
//        java.lang.String str25 = skipDateTimeField17.toString();
//        long long28 = skipDateTimeField17.addWrapField((long) (-1), (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
//        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField35 = copticChronology30.eras();
//        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology30);
//        boolean boolean38 = monthDay36.equals((java.lang.Object) (short) 0);
//        java.lang.String str39 = monthDay36.toString();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField46 = copticChronology41.eras();
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology41);
//        boolean boolean48 = monthDay36.isBefore((org.joda.time.ReadablePartial) monthDay47);
//        java.util.Locale locale49 = null;
//        try {
//            java.lang.String str50 = skipDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay36, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str25.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-901L) + "'", long28 == (-901L));
//        org.junit.Assert.assertNotNull(copticChronology30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "--10-08" + "'", str39.equals("--10-08"));
//        org.junit.Assert.assertNotNull(copticChronology41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        long long11 = dateTimeZone7.convertLocalToUTC((long) 31, false, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(49157, 186, 57600010, 49156, (int) (short) -1, 49156, 2019, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49156 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31L + "'", long11 == 31L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        java.util.Locale locale19 = null;
        int int20 = property16.getMaximumTextLength(locale19);
        java.util.Locale locale21 = null;
        int int22 = property16.getMaximumTextLength(locale21);
        java.lang.String str23 = property16.toString();
        java.lang.String str24 = property16.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[dayOfMonth]" + "'", str23.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(31, (int) (short) 1, (int) (short) 0, 0, 4, 2000, 49159);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendLiteral("10");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendPattern("10");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder10.appendFractionOfDay(1965, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        long long8 = fixedDateTimeZone4.convertUTCToLocal((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1099L + "'", long8 == 1099L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.centuryOfEra();
        try {
            long long13 = copticChronology1.getDateTimeMillis(157, (int) (byte) 0, 15, 157);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
        int int4 = dateTime2.getYear();
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.plusYears(57600010);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDate(31, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfYear();
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((-1));
        int int17 = dateTime16.getDayOfMonth();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, readableDateTime9, (org.joda.time.ReadableDateTime) dateTime16);
        java.lang.String str19 = limitChronology18.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LimitChronology[GregorianChronology[UTC], NoLimit, 1965-08-31T17:00:00.010-07:00]" + "'", str19.equals("LimitChronology[GregorianChronology[UTC], NoLimit, 1965-08-31T17:00:00.010-07:00]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
//        boolean boolean5 = dateTimeFormatterBuilder3.canBuildPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        long long11 = copticChronology7.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology7.getZone();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendClockhourOfDay((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendClockhourOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime21, readableDateTime22);
//        org.joda.time.DurationField durationField24 = limitChronology23.weekyears();
//        org.joda.time.DateTimeField dateTimeField25 = limitChronology23.halfdayOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 10, dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) '4');
//        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((-1));
//        java.util.GregorianCalendar gregorianCalendar33 = dateTime30.toGregorianCalendar();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        long long39 = copticChronology35.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField40 = copticChronology35.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.Chronology chronology42 = copticChronology35.withZone(dateTimeZone41);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
//        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField(chronology42, dateTimeField49, (int) (byte) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = skipDateTimeField51.getType();
//        org.joda.time.DateTime.Property property53 = dateTime30.property(dateTimeFieldType52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType52, (int) (byte) 10, (int) (byte) 100, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType52);
//        int int59 = dateTime13.get(dateTimeFieldType52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType52, 11);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone62);
//        long long67 = copticChronology63.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField68 = copticChronology63.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField69 = copticChronology63.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField70 = copticChronology63.centuryOfEra();
//        org.joda.time.DurationField durationField71 = copticChronology63.minutes();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField72 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(limitChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gregorianCalendar33);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 52 + "'", int59 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField72);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        int int6 = dateTime2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset(28799001L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(copticChronology12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        org.joda.time.DurationField durationField44 = offsetDateTimeField38.getRangeDurationField();
        java.util.Locale locale45 = null;
        int int46 = offsetDateTimeField38.getMaximumShortTextLength(locale45);
        boolean boolean48 = offsetDateTimeField38.isLeap((-27L));
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        boolean boolean72 = unsupportedDateTimeField70.isLenient();
        long long75 = unsupportedDateTimeField70.add((long) 49157, 24);
        org.joda.time.MonthDay monthDay76 = org.joda.time.MonthDay.now();
        boolean boolean78 = monthDay76.equals((java.lang.Object) (byte) 100);
        org.joda.time.LocalDate localDate80 = monthDay76.toLocalDate((-1));
        try {
            int int81 = unsupportedDateTimeField70.getMaximumValue((org.joda.time.ReadablePartial) monthDay76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2073649157L + "'", long75 == 2073649157L);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(localDate80);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = property41.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean6 = dateTimeZone0.isStandardOffset(10L);
        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int14 = fixedDateTimeZone12.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int17 = cachedDateTimeZone15.getOffset(28799001L);
        long long19 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (-136771199990L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        boolean boolean22 = cachedDateTimeZone15.equals((java.lang.Object) dateTimeFormatterBuilder20);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136771200989L) + "'", long19 == (-136771200989L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gregorianChronology23);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long10 = julianChronology0.getDateTimeMillis(6, (int) (short) 1, (int) (byte) 0, (int) (byte) 0, 4, 65, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 65 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 49156, 999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50155L + "'", long2 == 50155L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long42 = offsetDateTimeField38.roundHalfEven((long) 10);
        long long44 = offsetDateTimeField38.roundHalfFloor(53L);
        long long46 = offsetDateTimeField38.roundHalfCeiling((long) 0);
        java.lang.String str47 = offsetDateTimeField38.toString();
        try {
            int int49 = offsetDateTimeField38.get((-124271280421990L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-14400000L) + "'", long44 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str47.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.lang.String str8 = property6.getAsString();
        org.joda.time.DateTime dateTime9 = property6.getDateTime();
        int int10 = property6.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12" + "'", str8.equals("12"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 100);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(3500L, (int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMinuteOfHour(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        long long18 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime20 = dateTime16.minus((long) 49128);
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology24.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        long long31 = copticChronology27.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField32 = copticChronology27.eras();
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology27);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        long long39 = copticChronology35.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField40 = copticChronology35.eras();
        org.joda.time.MonthDay monthDay41 = monthDay33.withChronologyRetainFields((org.joda.time.Chronology) copticChronology35);
        int int42 = monthDay33.getMonthOfYear();
        int[] intArray44 = gJChronology24.get((org.joda.time.ReadablePartial) monthDay33, (long) (short) 100);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology24);
        org.joda.time.DateTime dateTime46 = dateTime23.withChronology(chronology45);
        org.joda.time.DateTime dateTime48 = dateTime46.plusHours(100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        long long6 = copticChronology2.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = copticChronology2.withZone(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withChronology(chronology9);
        java.lang.Appendable appendable11 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 10, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMonths((int) '4');
        boolean boolean24 = dateTime16.isBefore((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) dateTime16);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime25.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime27 = dateTime25.toDateTime();
        try {
            dateTimeFormatter10.printTo(appendable11, (org.joda.time.ReadableInstant) dateTime25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add(0L, (int) ' ');
        java.lang.String str33 = skipUndoDateTimeField28.getAsShortText(1L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = buddhistChronology0.eras();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.clockhourOfHalfday();
        try {
            long long10 = gJChronology0.getDateTimeMillis(49128, 58, 77939, 69, 15, (int) (short) 10, 57649);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        java.util.Locale locale19 = null;
        int int20 = property16.getMaximumTextLength(locale19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone21);
        long long26 = copticChronology22.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = copticChronology22.getZone();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime28.toMutableDateTime();
        org.joda.time.DateTime dateTime30 = dateTime28.withEarlierOffsetAtOverlap();
        int int31 = property16.compareTo((org.joda.time.ReadableInstant) dateTime28);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = property6.getDifference((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime15.toString();
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime21 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.DateTime.Property property23 = dateTime21.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        long long12 = copticChronology8.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField13 = copticChronology8.eras();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField21 = copticChronology16.eras();
        org.joda.time.MonthDay monthDay22 = monthDay14.withChronologyRetainFields((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        long long28 = copticChronology24.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField29 = copticChronology24.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology24.withZone(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField(chronology31, dateTimeField38, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField40.getType();
        boolean boolean42 = monthDay22.isSupported(dateTimeFieldType41);
        org.joda.time.DateTime dateTime44 = dateTime4.withField(dateTimeFieldType41, (int) (short) 10);
        org.joda.time.DateTime dateTime46 = dateTime4.withYearOfCentury(0);
        boolean boolean48 = dateTime46.isAfter((long) 49119);
        org.joda.time.DateTime dateTime50 = dateTime46.minusYears(49157);
        boolean boolean52 = dateTime46.isAfter((long) (-10));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "millisOfSecond");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "hi!", "GregorianChronology[UTC]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "6", "100");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(24, 0, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withTime(57649, 49166778, 11, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57649 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        boolean boolean72 = unsupportedDateTimeField70.isLenient();
        java.lang.String str73 = unsupportedDateTimeField70.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "UnsupportedDateTimeField" + "'", str73.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add((long) (short) -1, (long) 65);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField46 = copticChronology41.eras();
        org.joda.time.MonthDay monthDay47 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) copticChronology41);
        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
        java.util.Locale locale49 = null;
        int int50 = property48.getMaximumTextLength(locale49);
        org.joda.time.MonthDay monthDay51 = property48.getMonthDay();
        org.joda.time.MonthDay monthDay52 = property48.getMonthDay();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone55 = gJChronology54.getZone();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone56);
        long long61 = copticChronology57.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField62 = copticChronology57.eras();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology57);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.CopticChronology copticChronology65 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone64);
        long long69 = copticChronology65.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField70 = copticChronology65.eras();
        org.joda.time.MonthDay monthDay71 = monthDay63.withChronologyRetainFields((org.joda.time.Chronology) copticChronology65);
        int int72 = monthDay63.getMonthOfYear();
        int[] intArray74 = gJChronology54.get((org.joda.time.ReadablePartial) monthDay63, (long) (short) 100);
        int[] intArray76 = skipUndoDateTimeField28.addWrapPartial((org.joda.time.ReadablePartial) monthDay52, 0, intArray74, 49154);
        java.util.Locale locale78 = null;
        java.lang.String str79 = skipUndoDateTimeField28.getAsText((-1440000000), locale78);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 64L + "'", long31 == 64L);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(copticChronology65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "-1440000000" + "'", str79.equals("-1440000000"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long7 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendLiteral("10");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendDayOfYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(copticChronology8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        java.lang.String str7 = gregorianChronology5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("-1440000000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1440000000\" is malformed at \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        int int24 = skipDateTimeField17.getMaximumValue();
        java.lang.String str25 = skipDateTimeField17.toString();
        int int26 = skipDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str25.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime4.withPeriodAdded(readablePeriod36, 999);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime4.minus(readablePeriod39);
        org.joda.time.DateTime.Property property41 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime43 = dateTime4.plusHours(0);
        org.joda.time.DateTime dateTime45 = dateTime43.withYearOfEra(647);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfDay(49119);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekyear(1, 647);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean10 = fixedDateTimeZone8.equals((java.lang.Object) dateTimeFormatter9);
        boolean boolean11 = fixedDateTimeZone8.isFixed();
        int int13 = fixedDateTimeZone8.getOffset(53L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone8.getShortName(0L, locale15);
        org.joda.time.Chronology chronology17 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str18 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.999" + "'", str16.equals("+00:00:00.999"));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JulianChronology[UTC]" + "'", str18.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        long long43 = offsetDateTimeField38.getDifferenceAsLong((long) 6, (long) 2000);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) 10, dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.minusMonths((int) '4');
        org.joda.time.DateTime dateTime50 = dateTime48.withDayOfYear((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.DateTime dateTime52 = dateTime50.plus(readableDuration51);
        java.util.Date date53 = dateTime50.toDate();
        org.joda.time.MonthDay monthDay54 = org.joda.time.MonthDay.fromDateFields(date53);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.MonthDay monthDay56 = monthDay54.plus(readablePeriod55);
        int[] intArray62 = new int[] { 24, (byte) 0, 8, 77939 };
        try {
            int[] intArray64 = offsetDateTimeField38.addWrapField((org.joda.time.ReadablePartial) monthDay54, (-28799001), intArray62, 49128);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28799001");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(intArray62);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        java.lang.String str71 = unsupportedDateTimeField70.getName();
        org.joda.time.DurationField durationField72 = unsupportedDateTimeField70.getLeapDurationField();
        try {
            int int73 = unsupportedDateTimeField70.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfSecond" + "'", str71.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField72);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        long long7 = copticChronology3.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = copticChronology3.eras();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField16 = copticChronology11.eras();
        org.joda.time.MonthDay monthDay17 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) copticChronology11);
        int int18 = monthDay9.getMonthOfYear();
        int[] intArray20 = gJChronology0.get((org.joda.time.ReadablePartial) monthDay9, (long) (short) 100);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        long long26 = dateTimeZone22.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean28 = dateTimeZone22.isStandardOffset(10L);
        java.util.TimeZone timeZone29 = dateTimeZone22.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int36 = fixedDateTimeZone34.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        int int39 = cachedDateTimeZone37.getOffset(28799001L);
        long long41 = dateTimeZone22.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone37, (-136771199990L));
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone37);
        try {
            long long48 = zonedChronology42.getDateTimeMillis((long) 3, 77939, (-10), 1969, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 77939 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31L + "'", long26 == 31L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 999 + "'", int36 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 999 + "'", int39 == 999);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-136771200989L) + "'", long41 == (-136771200989L));
        org.junit.Assert.assertNotNull(zonedChronology42);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 100);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(3500L, (int) (byte) 10);
        org.joda.time.Instant instant6 = instant4.withMillis((long) 49166778);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField4, 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.MonthDay monthDay9 = monthDay7.minusMonths((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = monthDay9.getFieldTypes();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
        long long21 = copticChronology17.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology17.withZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone25);
        long long30 = copticChronology26.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology26.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField(chronology24, dateTimeField31, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField33.getType();
        boolean boolean35 = monthDay15.isSupported(dateTimeFieldType34);
        try {
            int int37 = monthDay15.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        java.lang.String str1 = monthDay0.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.String str3 = monthDay0.toString(dateTimeFormatter2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths((int) '4');
//        int int9 = dateTime6.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property10 = dateTime6.monthOfYear();
//        org.joda.time.DateTime dateTime11 = property10.getDateTime();
//        org.joda.time.DateTime dateTime12 = property10.withMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((int) '4');
//        int int18 = dateTime15.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property19 = dateTime15.monthOfYear();
//        org.joda.time.DateTime dateTime20 = property19.getDateTime();
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
//        long long22 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        java.util.Date date23 = dateTime20.toDate();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.fromDateFields(date23);
//        org.joda.time.MonthDay monthDay26 = monthDay24.plusMonths((int) (byte) 0);
//        int int27 = monthDay24.size();
//        boolean boolean28 = monthDay0.isBefore((org.joda.time.ReadablePartial) monthDay24);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--06-15" + "'", str1.equals("--06-15"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����-W��-�" + "'", str3.equals("����-W��-�"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DurationField durationField10 = limitChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = limitChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology21.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, dateTimeField35, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTime.Property property39 = dateTime16.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType38, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone45);
        long long50 = copticChronology46.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField51 = copticChronology46.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField52 = copticChronology46.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology46.centuryOfEra();
        org.joda.time.DurationField durationField54 = copticChronology46.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField54);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay((long) (short) -1, chronology57);
        org.joda.time.Instant instant60 = new org.joda.time.Instant((long) (short) 100);
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.Instant instant63 = instant60.withDurationAdded(readableDuration61, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology64 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField65 = buddhistChronology64.hourOfHalfday();
        org.joda.time.DurationField durationField66 = buddhistChronology64.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone71 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int73 = fixedDateTimeZone71.getOffset((-1L));
        long long75 = fixedDateTimeZone71.previousTransition((long) (byte) 10);
        java.util.TimeZone timeZone76 = fixedDateTimeZone71.toTimeZone();
        org.joda.time.Chronology chronology77 = buddhistChronology64.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone71);
        org.joda.time.DateTime dateTime78 = instant63.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone71);
        org.joda.time.DateTime dateTime79 = monthDay58.toDateTime((org.joda.time.ReadableInstant) dateTime78);
        java.util.Locale locale81 = null;
        try {
            java.lang.String str82 = unsupportedDateTimeField55.getAsShortText((org.joda.time.ReadablePartial) monthDay58, 1969, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertNotNull(instant63);
        org.junit.Assert.assertNotNull(buddhistChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 999 + "'", int73 == 999);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(chronology77);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime79);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        int int18 = skipDateTimeField17.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField17.getType();
        int int21 = skipDateTimeField17.get((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        long long27 = copticChronology23.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField28 = copticChronology23.eras();
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology23);
        org.joda.time.MonthDay monthDay31 = monthDay29.minusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField46 = copticChronology41.eras();
        org.joda.time.MonthDay monthDay47 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) copticChronology41);
        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
        java.util.Locale locale49 = null;
        int int50 = property48.getMaximumTextLength(locale49);
        org.joda.time.MonthDay monthDay51 = property48.getMonthDay();
        boolean boolean52 = monthDay29.isEqual((org.joda.time.ReadablePartial) monthDay51);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone54 = gJChronology53.getZone();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone55);
        long long60 = copticChronology56.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField61 = copticChronology56.eras();
        org.joda.time.MonthDay monthDay62 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology56);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone63);
        long long68 = copticChronology64.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField69 = copticChronology64.eras();
        org.joda.time.MonthDay monthDay70 = monthDay62.withChronologyRetainFields((org.joda.time.Chronology) copticChronology64);
        int int71 = monthDay62.getMonthOfYear();
        int[] intArray73 = gJChronology53.get((org.joda.time.ReadablePartial) monthDay62, (long) (short) 100);
        int int74 = skipDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay51, intArray73);
        try {
            long long77 = skipDateTimeField17.set((long) (short) 10, "1965");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1965 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 999 + "'", int21 == 999);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(copticChronology56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(copticChronology64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 999 + "'", int74 == 999);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (short) 100);
        org.joda.time.Instant instant7 = dateTime4.toInstant();
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        org.joda.time.DurationField durationField44 = offsetDateTimeField38.getRangeDurationField();
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField38.getAsShortText((int) (short) 1, locale46);
        long long49 = offsetDateTimeField38.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-14400000L) + "'", long49 == (-14400000L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsShortText(locale8);
        org.joda.time.DateTime dateTime11 = property6.addToCopy(12);
        org.joda.time.DateTime dateTime12 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Dec" + "'", str9.equals("Dec"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField17.getAsText((-14400000L), locale19);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime4.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar13 = dateTime10.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = copticChronology15.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        long long28 = copticChronology24.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField29 = copticChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField(chronology22, dateTimeField29, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField31.getType();
        org.joda.time.DateTime.Property property33 = dateTime10.property(dateTimeFieldType32);
        int int34 = dateTime4.get(dateTimeFieldType32);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1965 + "'", int5 == 1965);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getOffset(53L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName(0L, locale11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 1L, 49153);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 49153");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.999" + "'", str12.equals("+00:00:00.999"));
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsText(10, locale20);
        long long23 = skipDateTimeField17.roundHalfCeiling(0L);
        int int24 = skipDateTimeField17.getMaximumValue();
        java.lang.String str25 = skipDateTimeField17.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField17.getType();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str25.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        long long7 = copticChronology3.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField8 = copticChronology3.eras();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField16 = copticChronology11.eras();
        org.joda.time.MonthDay monthDay17 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) copticChronology11);
        int int18 = monthDay9.getMonthOfYear();
        int[] intArray20 = gJChronology0.get((org.joda.time.ReadablePartial) monthDay9, (long) (short) 100);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        long long26 = dateTimeZone22.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean28 = dateTimeZone22.isStandardOffset(10L);
        java.util.TimeZone timeZone29 = dateTimeZone22.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int36 = fixedDateTimeZone34.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        int int39 = cachedDateTimeZone37.getOffset(28799001L);
        long long41 = dateTimeZone22.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone37, (-136771199990L));
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone43 = zonedChronology42.getZone();
        org.joda.time.DateTimeZone dateTimeZone44 = zonedChronology42.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31L + "'", long26 == 31L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 999 + "'", int36 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 999 + "'", int39 == 999);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-136771200989L) + "'", long41 == (-136771200989L));
        org.junit.Assert.assertNotNull(zonedChronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withEra(11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getOffset(53L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName(0L, locale11);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.999" + "'", str12.equals("+00:00:00.999"));
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        int int36 = property35.getLeapAmount();
        int int37 = property35.getMaximumValue();
        org.joda.time.DateTime dateTime39 = property35.setCopy(9);
        org.joda.time.Instant instant40 = dateTime39.toInstant();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology42 = dateTimeFormatter41.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter41.withChronology((org.joda.time.Chronology) gregorianChronology43);
        java.lang.String str45 = instant40.toString(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(instant40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNull(chronology42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "11:00:00 PM" + "'", str45.equals("11:00:00 PM"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 9, (java.lang.Number) (-989L), (java.lang.Number) (-10));
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        boolean boolean45 = offsetDateTimeField38.isLeap(1L);
        try {
            long long48 = offsetDateTimeField38.set((long) 52, "12");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for millisOfSecond must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        long long10 = copticChronology6.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology6.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField20, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField22.getType();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText(10, locale25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) -1);
        long long31 = skipUndoDateTimeField28.add((long) (short) -1, (long) 65);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField38 = copticChronology33.eras();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        long long45 = copticChronology41.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField46 = copticChronology41.eras();
        org.joda.time.MonthDay monthDay47 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) copticChronology41);
        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
        java.util.Locale locale49 = null;
        int int50 = property48.getMaximumTextLength(locale49);
        org.joda.time.MonthDay monthDay51 = property48.getMonthDay();
        org.joda.time.MonthDay monthDay52 = property48.getMonthDay();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone55 = gJChronology54.getZone();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone56);
        long long61 = copticChronology57.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField62 = copticChronology57.eras();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology57);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.CopticChronology copticChronology65 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone64);
        long long69 = copticChronology65.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField70 = copticChronology65.eras();
        org.joda.time.MonthDay monthDay71 = monthDay63.withChronologyRetainFields((org.joda.time.Chronology) copticChronology65);
        int int72 = monthDay63.getMonthOfYear();
        int[] intArray74 = gJChronology54.get((org.joda.time.ReadablePartial) monthDay63, (long) (short) 100);
        int[] intArray76 = skipUndoDateTimeField28.addWrapPartial((org.joda.time.ReadablePartial) monthDay52, 0, intArray74, 49154);
        java.lang.String str78 = skipUndoDateTimeField28.getAsText(8625600000L);
        org.joda.time.MonthDay monthDay80 = new org.joda.time.MonthDay((long) (short) -1);
        int int81 = skipUndoDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) monthDay80);
        long long84 = skipUndoDateTimeField28.getDifferenceAsLong((long) 1969, (long) 9);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 64L + "'", long31 == 64L);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(copticChronology65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "0" + "'", str78.equals("0"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1960L + "'", long84 == 1960L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DurationField durationField6 = limitChronology4.days();
        org.joda.time.DateTime dateTime7 = limitChronology4.getUpperLimit();
        org.joda.time.DurationField durationField8 = limitChronology4.hours();
        try {
            long long13 = limitChronology4.getDateTimeMillis(49156, (int) (byte) 100, (-90), 49161);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.era();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("11");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"11\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        long long45 = offsetDateTimeField38.roundHalfEven((long) 100);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology46.era();
        org.joda.time.DateTimeField dateTimeField49 = gJChronology46.era();
        try {
            org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) 100, (org.joda.time.Chronology) gJChronology46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-14400000L) + "'", long45 == (-14400000L));
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        long long16 = copticChronology12.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField17 = copticChronology12.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = copticChronology12.withZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField(chronology19, dateTimeField26, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipDateTimeField28.getType();
        org.joda.time.DateTime.Property property30 = dateTime7.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime7.plusSeconds((int) (short) -1);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType26, (int) '#', 1, 100);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone31);
        long long36 = copticChronology32.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField37 = copticChronology32.eras();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology32);
        boolean boolean40 = monthDay38.equals((java.lang.Object) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone43 = gJChronology42.getZone();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone44);
        long long49 = copticChronology45.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField50 = copticChronology45.eras();
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology45);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField58 = copticChronology53.eras();
        org.joda.time.MonthDay monthDay59 = monthDay51.withChronologyRetainFields((org.joda.time.Chronology) copticChronology53);
        int int60 = monthDay51.getMonthOfYear();
        int[] intArray62 = gJChronology42.get((org.joda.time.ReadablePartial) monthDay51, (long) (short) 100);
        int[] intArray64 = offsetDateTimeField30.addWrapField((org.joda.time.ReadablePartial) monthDay38, (int) (byte) 0, intArray62, (int) '4');
        int int66 = monthDay38.getValue(0);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone67);
        long long72 = copticChronology68.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField73 = copticChronology68.eras();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology68);
        boolean boolean75 = monthDay38.isBefore((org.joda.time.ReadablePartial) monthDay74);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
        org.junit.Assert.assertNotNull(copticChronology68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean5 = gregorianChronology2.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology2);
        int int9 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "1");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        java.lang.String str8 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        int int41 = offsetDateTimeField38.getLeapAmount((long) 1969);
        long long43 = offsetDateTimeField38.roundCeiling((long) (short) 100);
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField38.getAsShortText(1, locale45);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = property6.getDifference((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime15.toString();
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime21 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        java.util.Locale locale23 = null;
        java.lang.String str24 = property22.getAsShortText(locale23);
        long long25 = property22.remainder();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31507200010L + "'", long25 == 31507200010L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 12);
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField6 = copticChronology1.eras();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField14 = copticChronology9.eras();
//        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
//        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
//        java.util.Locale locale17 = null;
//        int int18 = property16.getMaximumTextLength(locale17);
//        org.joda.time.MonthDay monthDay19 = property16.getMonthDay();
//        org.joda.time.MonthDay monthDay20 = property16.getMonthDay();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property16.getAsText(locale21);
//        java.lang.String str23 = property16.toString();
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "8" + "'", str22.equals("8"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[dayOfMonth]" + "'", str23.equals("Property[dayOfMonth]"));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) '4');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = property6.getDifference((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime15.toString();
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime21 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime15.toDateTimeISO();
        org.joda.time.DateTime dateTime25 = dateTime15.withDurationAdded(52L, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime25.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField17.getAsShortText(100L, locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField17.getMaximumTextLength(locale21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField17.getAsShortText(0, locale24);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = copticChronology1.eras();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = copticChronology9.eras();
        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
        int[] intArray19 = monthDay18.getValues();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay18.withPeriodAdded(readablePeriod20, 3165);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime4.getWeekyear();
        boolean boolean7 = dateTime4.equals((java.lang.Object) "millisOfSecond");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        long long12 = dateTimeZone8.convertLocalToUTC((long) 31, false, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = dateTime4.withZone(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1965 + "'", int5 == 1965);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31L + "'", long12 == 31L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod3, 8625600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(647, 15, 70, 57600, 99, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
//        boolean boolean12 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
//        long long19 = copticChronology15.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology15.getZone();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        int int22 = dateTime21.getSecondOfMinute();
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime21);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43 + "'", int22 == 43);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        int int9 = dateTime7.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology11, readableDateTime12, readableDateTime13);
        org.joda.time.DurationField durationField15 = limitChronology14.weekyears();
        org.joda.time.DateTimeField dateTimeField16 = limitChronology14.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMonths((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar24 = dateTime21.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone25);
        long long30 = copticChronology26.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology26.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.Chronology chronology33 = copticChronology26.withZone(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        long long39 = copticChronology35.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField40 = copticChronology35.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField(chronology33, dateTimeField40, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipDateTimeField42.getType();
        org.joda.time.DateTime.Property property44 = dateTime21.property(dateTimeFieldType43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType43, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean49 = offsetDateTimeField48.isLenient();
        long long51 = offsetDateTimeField48.roundHalfEven((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField48.getType();
        org.joda.time.DateTime dateTime54 = dateTime7.withField(dateTimeFieldType52, 70);
        org.joda.time.DateTime.Property property55 = dateTime7.weekOfWeekyear();
        int int56 = property55.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianCalendar24);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-14400000L) + "'", long51 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 53 + "'", int56 == 53);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        long long73 = unsupportedDateTimeField70.getDifferenceAsLong((long) 52, (long) 6);
        org.joda.time.DurationField durationField74 = unsupportedDateTimeField70.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertNull(durationField74);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.lang.Object obj8 = null;
        boolean boolean9 = property6.equals(obj8);
        int int10 = property6.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-901L));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = limitChronology5.weekyears();
        org.joda.time.DurationField durationField7 = limitChronology5.days();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) -1, (org.joda.time.Chronology) limitChronology5);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) '4');
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMonths((int) '4');
        int int22 = dateTime19.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property23 = dateTime19.monthOfYear();
        org.joda.time.DateTime dateTime24 = property23.getDateTime();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property15.getDifference((org.joda.time.ReadableInstant) dateTime24);
        java.lang.String str27 = dateTime24.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 10, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths((int) '4');
        org.joda.time.DateTime dateTime34 = dateTime32.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar35 = dateTime32.toGregorianCalendar();
        org.joda.time.DateTime dateTime37 = dateTime32.plusDays(49153);
        boolean boolean38 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDateTime readableDateTime39 = null;
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology5, (org.joda.time.ReadableDateTime) dateTime24, readableDateTime39);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str27.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianCalendar35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(limitChronology40);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfMonth();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 3, 0, (-28799001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for dayOfMonth must be in the range [0,-28799001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField6 = copticChronology1.eras();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField14 = copticChronology9.eras();
//        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
//        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
//        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
//        java.util.Locale locale19 = null;
//        int int20 = property16.getMaximumTextLength(locale19);
//        int int21 = property16.getMinimumValue();
//        int int22 = property16.get();
//        org.joda.time.MonthDay monthDay24 = property16.setCopy(9);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
//        org.junit.Assert.assertNotNull(monthDay24);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField6 = copticChronology1.eras();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField14 = copticChronology9.eras();
//        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
//        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
//        org.joda.time.MonthDay monthDay18 = property16.addToCopy((int) (short) 1);
//        java.lang.String str19 = property16.getAsString();
//        java.lang.String str20 = property16.getAsString();
//        int int21 = property16.getMinimumValue();
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "8" + "'", str19.equals("8"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "8" + "'", str20.equals("8"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType26, (int) '#', 1, 100);
        int int32 = offsetDateTimeField30.getLeapAmount(1L);
        java.lang.String str33 = offsetDateTimeField30.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str33.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DurationField durationField10 = limitChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = limitChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        long long25 = copticChronology21.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology21.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone29);
        long long34 = copticChronology30.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology30.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology28, dateTimeField35, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField37.getType();
        org.joda.time.DateTime.Property property39 = dateTime16.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType38, (int) (byte) 10, (int) (byte) 100, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder0.appendDayOfYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder0.appendClockhourOfDay(31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatterBuilder48.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYear(24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int6 = fixedDateTimeZone4.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime7.minusYears(0);
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        int int12 = dateTime10.getDayOfWeek();
        org.joda.time.DateTime dateTime14 = dateTime10.minusSeconds(9);
        org.joda.time.DateTime.Property property15 = dateTime10.minuteOfDay();
        java.lang.String str16 = property15.getAsText();
        int int17 = property15.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "960" + "'", str16.equals("960"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1439 + "'", int17 == 1439);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        java.lang.String str41 = offsetDateTimeField38.getAsText((long) 'a');
        boolean boolean42 = offsetDateTimeField38.isSupported();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "11" + "'", str41.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime7.minusYears(0);
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        int int12 = dateTime10.getDayOfWeek();
        org.joda.time.DateTime dateTime14 = dateTime10.minusSeconds(9);
        org.joda.time.DateTime.Property property15 = dateTime10.minuteOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField6 = copticChronology1.eras();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
//        boolean boolean9 = monthDay7.equals((java.lang.Object) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay7.withPeriodAdded(readablePeriod10, (int) (short) 1);
//        java.lang.String str14 = monthDay7.toString("35");
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology15.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
//        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField23 = copticChronology18.eras();
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology18);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone25);
//        long long30 = copticChronology26.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField31 = copticChronology26.eras();
//        org.joda.time.MonthDay monthDay32 = monthDay24.withChronologyRetainFields((org.joda.time.Chronology) copticChronology26);
//        int int33 = monthDay24.getMonthOfYear();
//        int[] intArray35 = gJChronology15.get((org.joda.time.ReadablePartial) monthDay24, (long) (short) 100);
//        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology15);
//        java.lang.String str37 = gJChronology15.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str41 = dateTimeZone39.getName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter38.withZone(dateTimeZone39);
//        boolean boolean43 = gJChronology15.equals((java.lang.Object) dateTimeFormatter38);
//        org.joda.time.MonthDay monthDay44 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) gJChronology15);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "35" + "'", str14.equals("35"));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(copticChronology26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str37.equals("GJChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(monthDay44);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra((int) (byte) 10, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFractionOfSecond((int) (short) 1, (int) ' ');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendMonthOfYear(448);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = gregorianChronology2.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronolgy();
        boolean boolean7 = gregorianChronology2.equals((java.lang.Object) chronology6);
        java.lang.String str8 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
//        long long14 = copticChronology10.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology10.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField15, (int) (byte) 100);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = skipDateTimeField17.getAsShortText(100L, locale19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone21);
//        long long26 = copticChronology22.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField27 = copticChronology22.eras();
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology22);
//        boolean boolean30 = monthDay28.equals((java.lang.Object) (short) 0);
//        java.lang.String str31 = monthDay28.toString();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
//        long long37 = copticChronology33.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField38 = copticChronology33.eras();
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology33);
//        boolean boolean40 = monthDay28.isBefore((org.joda.time.ReadablePartial) monthDay39);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology41.getZone();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
//        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField49 = copticChronology44.eras();
//        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology44);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone51);
//        long long56 = copticChronology52.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField57 = copticChronology52.eras();
//        org.joda.time.MonthDay monthDay58 = monthDay50.withChronologyRetainFields((org.joda.time.Chronology) copticChronology52);
//        int int59 = monthDay50.getMonthOfYear();
//        int[] intArray61 = gJChronology41.get((org.joda.time.ReadablePartial) monthDay50, (long) (short) 100);
//        int int62 = skipDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray61);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "--10-08" + "'", str31.equals("--10-08"));
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(copticChronology52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 999 + "'", int62 == 999);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField8 = copticChronology1.centuries();
        org.joda.time.Chronology chronology9 = copticChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        long long15 = copticChronology11.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology11.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology11.withZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
        long long24 = copticChronology20.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology20.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField25, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipDateTimeField27.getType();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField27.getAsText(10, locale30);
        java.lang.String str32 = skipDateTimeField27.getName();
        java.lang.String str33 = skipDateTimeField27.getName();
        java.lang.String str34 = skipDateTimeField27.getName();
        boolean boolean36 = skipDateTimeField27.isLeap((long) 1965);
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, (org.joda.time.DateTimeField) skipDateTimeField27, (-1));
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10" + "'", str31.equals("10"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "millisOfSecond" + "'", str32.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfSecond" + "'", str33.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "millisOfSecond" + "'", str34.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = limitChronology5.weekyears();
        org.joda.time.DurationField durationField7 = limitChronology5.days();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) -1, (org.joda.time.Chronology) limitChronology5);
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay8.getFields();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.minus(readablePeriod10);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology2.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "millisOfSecond");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "hi!", "GregorianChronology[UTC]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime dateTime9 = dateTime4.withYear(0);
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = property10.addToCopy((int) (byte) 0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusDays((int) (byte) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean21 = fixedDateTimeZone19.equals((java.lang.Object) dateTimeFormatter20);
        java.lang.String str22 = dateTime14.toString(dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology24, readableDateTime25, readableDateTime26);
        boolean boolean29 = limitChronology27.equals((java.lang.Object) 10L);
        org.joda.time.DateTimeField dateTimeField30 = limitChronology27.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 10, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.minusMonths((int) '4');
        int int36 = dateTime33.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property37 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = property37.getDateTime();
        org.joda.time.DateTime dateTime39 = property37.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 10, dateTimeZone41);
        org.joda.time.DateTime dateTime44 = dateTime42.minusMonths((int) '4');
        int int45 = dateTime42.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property46 = dateTime42.monthOfYear();
        org.joda.time.DateTime dateTime47 = property46.getDateTime();
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime47);
        long long49 = property37.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime47);
        java.util.Date date50 = dateTime47.toDate();
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.fromDateFields(date50);
        org.joda.time.MonthDay monthDay53 = monthDay51.plusMonths((int) (byte) 0);
        int[] intArray55 = limitChronology27.get((org.joda.time.ReadablePartial) monthDay51, 52L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) limitChronology27);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1965-W35-2" + "'", str22.equals("1965-W35-2"));
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "1");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("CopticChronology[America/Los_Angeles]", "+00:00:00.999", 69, 157);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) 31, false, (long) (short) 10);
        boolean boolean6 = dateTimeZone0.isStandardOffset(10L);
        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        int int14 = fixedDateTimeZone12.getOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int17 = cachedDateTimeZone15.getOffset(28799001L);
        long long19 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (-136771199990L));
        java.lang.String str21 = cachedDateTimeZone15.getNameKey((long) 31);
        int int23 = cachedDateTimeZone15.getStandardOffset((long) 2000);
        int int25 = cachedDateTimeZone15.getOffset((long) 49166778);
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 31L + "'", long4 == 31L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136771200989L) + "'", long19 == (-136771200989L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
        org.junit.Assert.assertNotNull(monthDay26);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.secondOfMinute();
        org.joda.time.Chronology chronology9 = copticChronology1.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("965");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra(448, 448);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.convertLocalToUTC(28800000L, true);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799001L + "'", long8 == 28799001L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("millisOfSecond", "", 999, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.Chronology chronology7 = dateTimeFormatter5.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(chronology7);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        long long5 = copticChronology1.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField6 = copticChronology1.eras();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology1);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
//        org.joda.time.DurationField durationField14 = copticChronology9.eras();
//        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
//        org.joda.time.MonthDay.Property property16 = monthDay15.dayOfMonth();
//        java.util.Locale locale17 = null;
//        int int18 = property16.getMaximumTextLength(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        java.util.Locale locale21 = null;
//        int int22 = property16.getMaximumTextLength(locale21);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property16.getAsShortText(locale23);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "8" + "'", str20.equals("8"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "8" + "'", str24.equals("8"));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DurationField durationField33 = limitChronology32.weekyears();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar42 = dateTime39.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone43);
        long long48 = copticChronology44.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology44.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology44.withZone(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone52);
        long long57 = copticChronology53.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField58 = copticChronology53.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField(chronology51, dateTimeField58, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipDateTimeField60.getType();
        org.joda.time.DateTime.Property property62 = dateTime39.property(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType61, (int) (byte) 10, (int) (byte) 100, (-1));
        int int67 = offsetDateTimeField66.getMaximumValue();
        java.lang.String str68 = offsetDateTimeField66.getName();
        org.joda.time.DurationField durationField69 = offsetDateTimeField66.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField70 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField69);
        org.joda.time.DurationField durationField71 = unsupportedDateTimeField70.getRangeDurationField();
        boolean boolean72 = unsupportedDateTimeField70.isLenient();
        java.lang.String str73 = unsupportedDateTimeField70.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "millisOfSecond" + "'", str68.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField70);
        org.junit.Assert.assertNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "millisOfSecond" + "'", str73.equals("millisOfSecond"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.DateTime.Property property35 = dateTime4.property(dateTimeFieldType33);
        try {
            org.joda.time.DateTime dateTime37 = dateTime4.withHourOfDay(1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime11.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        long long20 = copticChronology16.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology16.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        long long29 = copticChronology25.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField(chronology23, dateTimeField30, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField32.getType();
        org.joda.time.DateTime.Property property34 = dateTime11.property(dateTimeFieldType33);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType33, (int) (byte) 10, (int) (byte) 100, (-1));
        int int39 = offsetDateTimeField38.getMaximumValue();
        java.lang.String str40 = offsetDateTimeField38.getName();
        org.joda.time.DurationField durationField41 = offsetDateTimeField38.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField38.getType();
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField38.getAsText(18, locale44);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "millisOfSecond" + "'", str40.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "18" + "'", str45.equals("18"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-28799001), 1969, (int) (byte) 10, (int) (byte) 1, 0, 49128);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49128 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((-1));
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        long long13 = copticChronology9.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology9.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        long long22 = copticChronology18.add(0L, (long) (short) 0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField23, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.DateTime.Property property27 = dateTime4.property(dateTimeFieldType26);
        org.joda.time.DateTime dateTime29 = dateTime4.plusSeconds((int) (short) -1);
        java.util.GregorianCalendar gregorianCalendar30 = dateTime4.toGregorianCalendar();
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property32 = dateTime4.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianCalendar30);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertNotNull(property32);
    }
}

