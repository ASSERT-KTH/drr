import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test001");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str6 = cachedDateTimeZone4.getName((long) ' ');
//        java.lang.String str8 = cachedDateTimeZone4.getName(1560366408091L);
//        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone4.getUncachedZone();
//        java.lang.Class<?> wildcardClass10 = cachedDateTimeZone4.getClass();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.Instant instant15 = instant12.withDurationAdded(readableDuration13, 0);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = instant15.toDateTime(chronology16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeZone dateTimeZone20 = mutableDateTime19.getZone();
//        org.joda.time.DateTime dateTime21 = dateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime17.secondOfMinute();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        int int26 = dateTimeZone24.getOffset(readableInstant25);
//        org.joda.time.DateTime dateTime27 = dateTime17.withZone(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime17.minuteOfHour();
//        int int29 = dateTime17.getMinuteOfDay();
//        boolean boolean30 = cachedDateTimeZone4.equals((java.lang.Object) dateTime17);
//        org.joda.time.DateTime dateTime31 = dateTime17.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        int int16 = offsetDateTimeField11.getMaximumValue();
        try {
            long long19 = offsetDateTimeField11.set(1560366409391L, "DateTimeField[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[dayOfWeek]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(21807275L, 2052L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 44748528300");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(2019, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfDay();
        int int10 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime6.minusMinutes(21797041);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime15 = dateTime6.plus(0L);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.Instant instant3 = instant1.withMillis((long) '#');
        org.joda.time.DateTime dateTime4 = instant1.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTime();
        boolean boolean7 = instant1.isAfter(0L);
        org.joda.time.Instant instant8 = instant1.toInstant();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "1970-01-01T00:00:00.000Z");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        try {
            long long50 = dividedDateTimeField48.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [7,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.weekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfMinute();
        org.joda.time.LocalDate localDate13 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime6.withEra((int) (short) 1);
        int int16 = dateTime15.getMonthOfYear();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        java.util.Locale locale6 = null;
//        int int7 = property3.getMaximumTextLength(locale6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        boolean boolean9 = property3.equals((java.lang.Object) dateTimeFormatter8);
//        java.lang.Class<?> wildcardClass10 = dateTimeFormatter8.getClass();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.clockhourOfDay();
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) wildcardClass10, (org.joda.time.Chronology) julianChronology11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Class");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(2019, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek(277);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology3, locale6, (java.lang.Integer) 20);
        java.util.Locale locale9 = dateTimeParserBucket8.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology1, locale9, (java.lang.Integer) 1, 0);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket12.getChronology();
        boolean boolean15 = dateTimeParserBucket12.restoreState((java.lang.Object) 1560344606976L);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        boolean boolean6 = dateTime4.isBefore(1560344603175L);
        org.joda.time.DateTime dateTime8 = dateTime4.minusWeeks(68);
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds(9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.Object obj12 = null;
        boolean boolean13 = iSOChronology11.equals(obj12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime15.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        boolean boolean19 = cachedDateTimeZone18.isFixed();
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.Chronology chronology21 = iSOChronology11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.joda.time.DateTime dateTime22 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        java.lang.Object obj5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj5);
//        long long7 = mutableDateTime6.getMillis();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime9.getZone();
//        mutableDateTime6.setZone(dateTimeZone10);
//        try {
//            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(100, 1, 7, 783, 0, dateTimeZone10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 783 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder4.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimePrinter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendClockhourOfDay(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        dateTimeParserBucket6.setOffset(446);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("3", (java.lang.Number) 21794864L, (java.lang.Number) (-1), (java.lang.Number) 21796908L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 21794864L + "'", number5.equals(21794864L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 21806404);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "", (int) '#', (-1));
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffset(86400000L);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int49 = dividedDateTimeField48.getDivisor();
        int int50 = dividedDateTimeField48.getDivisor();
        java.lang.String str51 = dividedDateTimeField48.toString();
        int int53 = dividedDateTimeField48.get(21809251L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 18059 + "'", int49 == 18059);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 18059 + "'", int50 == 18059);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str51.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        int int6 = mutableDateTime5.getMillisOfDay();
//        boolean boolean8 = mutableDateTime5.isEqual(21798203L);
//        mutableDateTime5.setYear(163);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int49 = dividedDateTimeField48.getDivisor();
        int int50 = dividedDateTimeField48.getDivisor();
        long long53 = dividedDateTimeField48.getDifferenceAsLong(1560344606277L, 21811925L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 18059 + "'", int49 == 18059);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 18059 + "'", int50 == 18059);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundFloor(1560344662498L);
        java.lang.String str7 = delegatedDateTimeField4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546214400000L + "'", long6 == 1546214400000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str7.equals("DateTimeField[weekyearOfCentury]"));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundFloor();
//        java.lang.String str6 = property3.getAsShortText();
//        org.joda.time.MutableDateTime mutableDateTime8 = property3.add(31);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.centuryOfEra();
//        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundFloor();
//        try {
//            org.joda.time.Instant instant11 = new org.joda.time.Instant((java.lang.Object) property9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thu" + "'", str6.equals("Thu"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (long) 68, (int) 'a');
        org.joda.time.DurationField durationField5 = gJChronology0.hours();
        try {
            long long10 = gJChronology0.getDateTimeMillis((int) '4', 486, 1970, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 486 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 68L + "'", long4 == 68L);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        int int16 = offsetDateTimeField11.getMaximumValue();
        try {
            long long19 = offsetDateTimeField11.set((long) 277, "61710-09-21T13:03:31.356Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"61710-09-21T13:03:31.356Z\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology3, locale6, (java.lang.Integer) 20);
        java.util.Locale locale9 = dateTimeParserBucket8.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology1, locale9, (java.lang.Integer) 1, 0);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket12.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology18);
        long long23 = gregorianChronology18.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField24, 19);
        java.lang.String str27 = skipDateTimeField26.toString();
        long long30 = skipDateTimeField26.add(1L, 762970915);
        org.joda.time.Instant instant32 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Instant instant35 = instant32.withDurationAdded(readableDuration33, 0);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.DateTime dateTime37 = instant35.toDateTime(chronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime42 = dateTime37.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property43 = dateTime37.secondOfMinute();
        org.joda.time.LocalDate localDate44 = dateTime37.toLocalDate();
        int int45 = skipDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate44);
        int int47 = skipDateTimeField26.get(1560344606277L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, (org.joda.time.DateTimeField) skipDateTimeField26);
        java.lang.String str50 = skipUndoDateTimeField48.getAsShortText(1560344596908L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48);
        int int53 = skipUndoDateTimeField48.getMaximumValue(777600000L);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560344592765L + "'", long23 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str27.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 762970916L + "'", long30 == 762970916L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 277 + "'", int47 == 277);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "908" + "'", str50.equals("908"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 999 + "'", int53 == 999);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        boolean boolean10 = offsetDateTimeField4.isLeap(1560344599169L);
        int int12 = offsetDateTimeField4.getLeapAmount((long) 97);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (long) 68, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        long long12 = cachedDateTimeZone9.nextTransition((long) 16);
        long long16 = cachedDateTimeZone9.convertLocalToUTC((long) 21804658, false, 1560344606427L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 68L + "'", long4 == 68L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 16L + "'", long12 == 16L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21804658L + "'", long16 == 21804658L);
        org.junit.Assert.assertNotNull(buddhistChronology17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) 'a');
        org.joda.time.Instant instant5 = instant3.withMillis((long) '#');
        org.joda.time.DateTime dateTime6 = instant3.toDateTimeISO();
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateMidnight dateMidnight8 = dateTime6.toDateMidnight();
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "713");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test040");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.weekyear();
//        boolean boolean4 = mutableDateTime1.isAfter(1L);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add(21802794L);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        long long8 = dateTimeParserBucket6.computeMillis(true);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology13);
        long long18 = gregorianChronology13.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField19, 19);
        org.joda.time.DurationField durationField22 = skipDateTimeField21.getDurationField();
        boolean boolean23 = dateTimeParserBucket6.restoreState((java.lang.Object) skipDateTimeField21);
        long long26 = skipDateTimeField21.set(10L, 999);
        int int28 = skipDateTimeField21.get(21807446L);
        long long30 = skipDateTimeField21.remainder(21797819L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292278993L) + "'", long8 == (-292278993L));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560344592765L + "'", long18 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 999L + "'", long26 == 999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 446 + "'", int28 == 446);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560344662498L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560344662498");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '4', (int) (byte) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(21804809L);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str10 = fixedDateTimeZone4.getShortName(1560344607088L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.052" + "'", str10.equals("+00:00:00.052"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long16 = skipDateTimeField12.add(1L, 762970915);
        boolean boolean17 = skipDateTimeField12.isSupported();
        boolean boolean18 = skipDateTimeField12.isSupported();
        long long21 = skipDateTimeField12.add(1560344599917L, 68);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 762970916L + "'", long16 == 762970916L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560344599985L + "'", long21 == 1560344599985L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        int int9 = cachedDateTimeZone7.getOffset(21798106L);
        int int11 = cachedDateTimeZone7.getOffset((long) 446);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        int int13 = skipDateTimeField12.getMaximumValue();
        int int15 = skipDateTimeField12.getMaximumValue((long) 999);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = iSOChronology1.add(readablePeriod2, 21807088L, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.centuryOfEra();
//        org.joda.time.DurationField durationField10 = gregorianChronology7.weeks();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField11);
//        java.lang.Object obj13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(obj13);
//        long long15 = mutableDateTime14.getMillis();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.dayOfWeek();
//        long long17 = property16.remainder();
//        org.joda.time.MutableDateTime mutableDateTime18 = property16.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.getMutableDateTime();
//        int int20 = mutableDateTime19.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.weeks();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology25);
//        long long30 = gregorianChronology25.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology25.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField31, 19);
//        java.lang.String str34 = skipDateTimeField33.toString();
//        long long37 = skipDateTimeField33.add(1L, 762970915);
//        org.joda.time.Instant instant39 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration40 = null;
//        org.joda.time.Instant instant42 = instant39.withDurationAdded(readableDuration40, 0);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.DateTime dateTime44 = instant42.toDateTime(chronology43);
//        org.joda.time.DateTime dateTime46 = dateTime44.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime49 = dateTime44.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property50 = dateTime44.secondOfMinute();
//        org.joda.time.LocalDate localDate51 = dateTime44.toLocalDate();
//        int int52 = skipDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
//        java.lang.String str53 = skipDateTimeField33.toString();
//        org.joda.time.Instant instant55 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration56 = null;
//        org.joda.time.Instant instant58 = instant55.withDurationAdded(readableDuration56, 0);
//        org.joda.time.Chronology chronology59 = null;
//        org.joda.time.DateTime dateTime60 = instant58.toDateTime(chronology59);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology61);
//        org.joda.time.DateTimeZone dateTimeZone63 = mutableDateTime62.getZone();
//        org.joda.time.DateTime dateTime64 = dateTime60.toDateTime(dateTimeZone63);
//        org.joda.time.DateTime.Property property65 = dateTime60.centuryOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property65.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, dateTimeFieldType66, 52);
//        int int69 = mutableDateTime19.get(dateTimeFieldType66);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, (java.lang.Number) 21796615L, (java.lang.Number) 21802794L, (java.lang.Number) 21802344L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType66, 21809251);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField76 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 21807088L + "'", long5 == 21807088L);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560344592765L + "'", long30 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str34.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 762970916L + "'", long37 == 762970916L);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 999 + "'", int52 == 999);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str53.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(instant58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 19 + "'", int69 == 19);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.year();
        org.joda.time.DurationField durationField5 = gregorianChronology1.centuries();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider7 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider7);
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider7.getName(locale9, "Wed", "Wed");
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str15 = buddhistChronology14.toString();
        org.joda.time.Chronology chronology16 = buddhistChronology14.withUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = buddhistChronology14.withZone(dateTimeZone17);
        java.lang.String str19 = buddhistChronology14.toString();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField24 = gJChronology23.years();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.dayOfYear();
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology23, locale26, (java.lang.Integer) 20);
        java.util.Locale locale29 = dateTimeParserBucket28.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology21, locale29, (java.lang.Integer) 1, 0);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) buddhistChronology14, locale29);
        java.lang.String str36 = defaultNameProvider7.getName(locale29, "GJChronology[UTC]", "0");
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket(43608534L, (org.joda.time.Chronology) gregorianChronology1, locale29, (java.lang.Integer) 13, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[UTC]" + "'", str15.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DurationField durationField3 = gJChronology1.weekyears();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.joda.time.DurationField durationField5 = gJChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        org.joda.time.DurationField durationField49 = dividedDateTimeField48.getDurationField();
        try {
            long long52 = dividedDateTimeField48.set((long) 960, (-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for centuryOfEra must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(durationField49);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int50 = dividedDateTimeField48.get(35L);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField52 = gregorianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology55);
        long long60 = gregorianChronology55.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology55.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology51, dateTimeField61, 19);
        java.lang.String str64 = skipDateTimeField63.toString();
        long long67 = skipDateTimeField63.add(1L, 762970915);
        org.joda.time.Instant instant69 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.Instant instant72 = instant69.withDurationAdded(readableDuration70, 0);
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.DateTime dateTime74 = instant72.toDateTime(chronology73);
        org.joda.time.DateTime dateTime76 = dateTime74.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime79 = dateTime74.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property80 = dateTime74.secondOfMinute();
        org.joda.time.LocalDate localDate81 = dateTime74.toLocalDate();
        int int82 = skipDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) localDate81);
        java.lang.String str83 = skipDateTimeField63.toString();
        org.joda.time.Instant instant85 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration86 = null;
        org.joda.time.Instant instant88 = instant85.withDurationAdded(readableDuration86, 0);
        org.joda.time.Chronology chronology89 = null;
        org.joda.time.DateTime dateTime90 = instant88.toDateTime(chronology89);
        org.joda.time.chrono.GregorianChronology gregorianChronology91 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime92 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology91);
        org.joda.time.DateTimeZone dateTimeZone93 = mutableDateTime92.getZone();
        org.joda.time.DateTime dateTime94 = dateTime90.toDateTime(dateTimeZone93);
        org.joda.time.DateTime.Property property95 = dateTime90.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType96 = property95.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField98 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField63, dateTimeFieldType96, 52);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField99 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField48, dateTimeFieldType96);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344592765L + "'", long60 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str64.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 762970916L + "'", long67 == 762970916L);
        org.junit.Assert.assertNotNull(instant72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertNotNull(localDate81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 999 + "'", int82 == 999);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str83.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(instant88);
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertNotNull(gregorianChronology91);
        org.junit.Assert.assertNotNull(dateTimeZone93);
        org.junit.Assert.assertNotNull(dateTime94);
        org.junit.Assert.assertNotNull(property95);
        org.junit.Assert.assertNotNull(dateTimeFieldType96);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.weekyear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendYearOfCentury(16, 31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int50 = dividedDateTimeField48.get(35L);
        org.joda.time.DurationField durationField51 = dividedDateTimeField48.getRangeDurationField();
        int int52 = dividedDateTimeField48.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long16 = skipDateTimeField12.add(1L, 762970915);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant21 = instant18.withDurationAdded(readableDuration19, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = instant21.toDateTime(chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime28 = dateTime23.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property29 = dateTime23.secondOfMinute();
        org.joda.time.LocalDate localDate30 = dateTime23.toLocalDate();
        int int31 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField33 = gregorianChronology32.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 6);
        org.joda.time.Instant instant38 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.Instant instant41 = instant38.withDurationAdded(readableDuration39, 0);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.DateTime dateTime43 = instant41.toDateTime(chronology42);
        org.joda.time.DateTime dateTime45 = dateTime43.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime48 = dateTime43.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property49 = dateTime43.secondOfMinute();
        org.joda.time.LocalDate localDate50 = dateTime43.toLocalDate();
        int int51 = offsetDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate50);
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate50, 0, locale53);
        long long57 = skipDateTimeField12.addWrapField((long) 'a', 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 762970916L + "'", long16 == 762970916L);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 999 + "'", int31 == 999);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(instant41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 13 + "'", int51 == 13);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0" + "'", str54.equals("0"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 97L + "'", long57 == 97L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 21794864 for 3 must be in the range [-1,21796908]", "32", (int) (byte) -1, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: Value 21794864 for 3 must be in the range [-1,21796908]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        org.joda.time.DurationField durationField14 = skipDateTimeField12.getDurationField();
        org.joda.time.DurationField durationField15 = skipDateTimeField12.getDurationField();
        long long18 = skipDateTimeField12.getDifferenceAsLong((long) 97, (-263478993L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 263479090L + "'", long18 == 263479090L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("3", (java.lang.Number) 21794864L, (java.lang.Number) (-1), (java.lang.Number) 21796908L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "21794864" + "'", str5.equals("21794864"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 21796908L + "'", number6.equals(21796908L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 21794864L + "'", number7.equals(21794864L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        mutableDateTime3.addMonths((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.dayOfYear();
        java.lang.Class<?> wildcardClass7 = property6.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("3", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("", 0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder6.toDateTimeZone("T060321.361-0700", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder6.setFixedSavings("(\"org.joda.time.JodaTimePermission\" \"T060320.098-0700\")", 365);
        java.io.OutputStream outputStream14 = null;
        try {
            dateTimeZoneBuilder12.writeTo("T060326.192-0700", outputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long16 = skipDateTimeField12.add(1L, 762970915);
        boolean boolean17 = skipDateTimeField12.isSupported();
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField12.getWrappedField();
        int int20 = skipDateTimeField12.get(21799446L);
        int int22 = skipDateTimeField12.get(1560344607687L);
        long long25 = skipDateTimeField12.getDifferenceAsLong(1560344661356L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 762970916L + "'", long16 == 762970916L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 446 + "'", int20 == 446);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 687 + "'", int22 == 687);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560344661356L + "'", long25 == 1560344661356L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfHour(68);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime4.withYear(16);
        org.joda.time.DateTime dateTime11 = dateTime4.minusWeeks(960);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.hourOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfCeilingCopy();
//        java.lang.Object obj9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(obj9);
//        long long11 = mutableDateTime10.getMillis();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.dayOfWeek();
//        long long13 = property12.remainder();
//        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfCeiling();
//        int int15 = mutableDateTime14.getMillisOfDay();
//        org.joda.time.Chronology chronology16 = mutableDateTime14.getChronology();
//        boolean boolean17 = property7.equals((java.lang.Object) chronology16);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        long long8 = dateTimeParserBucket6.computeMillis(true);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology13);
        long long18 = gregorianChronology13.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField19, 19);
        org.joda.time.DurationField durationField22 = skipDateTimeField21.getDurationField();
        boolean boolean23 = dateTimeParserBucket6.restoreState((java.lang.Object) skipDateTimeField21);
        org.joda.time.tz.Provider provider24 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider24);
        boolean boolean26 = dateTimeParserBucket6.restoreState((java.lang.Object) provider24);
        dateTimeParserBucket6.setOffset((java.lang.Integer) 13);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292278993L) + "'", long8 == (-292278993L));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560344592765L + "'", long18 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(provider24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("3", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("", 0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder6.toDateTimeZone("T060321.361-0700", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder6.setFixedSavings("88", 21806);
        java.io.OutputStream outputStream14 = null;
        try {
            dateTimeZoneBuilder12.writeTo("713", outputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long16 = skipDateTimeField12.add(1L, 762970915);
        boolean boolean17 = skipDateTimeField12.isSupported();
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField12.getWrappedField();
        long long20 = skipDateTimeField12.roundCeiling(1560344611789L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 762970916L + "'", long16 == 762970916L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560344611789L + "'", long20 == 1560344611789L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        long long8 = offsetDateTimeField4.roundHalfFloor((long) 3);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.hourOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plus(1560344592765L);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(2000);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("32", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        org.joda.time.Instant instant6 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 0);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = instant9.toDateTime(chronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property17 = dateTime11.secondOfMinute();
        org.joda.time.LocalDate localDate18 = dateTime11.toLocalDate();
        int int19 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        int int21 = offsetDateTimeField4.getMinimumValue((long) 21809251);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.years();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.dayOfYear();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology24, locale27, (java.lang.Integer) 20);
        long long31 = dateTimeParserBucket29.computeMillis(true);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField33 = gregorianChronology32.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology36);
        long long41 = gregorianChronology36.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology32, dateTimeField42, 19);
        org.joda.time.DurationField durationField45 = skipDateTimeField44.getDurationField();
        boolean boolean46 = dateTimeParserBucket29.restoreState((java.lang.Object) skipDateTimeField44);
        long long49 = skipDateTimeField44.set(10L, 999);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider52 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider52);
        java.util.Locale locale54 = null;
        java.lang.String str57 = defaultNameProvider52.getName(locale54, "Wed", "Wed");
        org.joda.time.chrono.BuddhistChronology buddhistChronology59 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str60 = buddhistChronology59.toString();
        org.joda.time.Chronology chronology61 = buddhistChronology59.withUTC();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.Chronology chronology63 = buddhistChronology59.withZone(dateTimeZone62);
        java.lang.String str64 = buddhistChronology59.toString();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField69 = gJChronology68.years();
        org.joda.time.DateTimeField dateTimeField70 = gJChronology68.dayOfYear();
        java.util.Locale locale71 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology68, locale71, (java.lang.Integer) 20);
        java.util.Locale locale74 = dateTimeParserBucket73.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology66, locale74, (java.lang.Integer) 1, 0);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket78 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) buddhistChronology59, locale74);
        java.lang.String str81 = defaultNameProvider52.getName(locale74, "GJChronology[UTC]", "0");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = dateTimeFormatter51.withLocale(locale74);
        java.lang.String str83 = skipDateTimeField44.getAsShortText(52, locale74);
        java.text.DateFormatSymbols dateFormatSymbols84 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale74);
        java.lang.String str85 = offsetDateTimeField4.getAsShortText(356, locale74);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-292278993L) + "'", long31 == (-292278993L));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560344592765L + "'", long41 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 999L + "'", long49 == 999L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(buddhistChronology59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "BuddhistChronology[UTC]" + "'", str60.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "BuddhistChronology[UTC]" + "'", str64.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(locale74);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "52" + "'", str83.equals("52"));
        org.junit.Assert.assertNotNull(dateFormatSymbols84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "356" + "'", str85.equals("356"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        mutableDateTime1.addYears(10);
        mutableDateTime1.setYear((int) (byte) 100);
        org.joda.time.DateTime dateTime6 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, 1976);
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T13:03:21.543Z");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendYear((int) (short) 100, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendTimeZoneOffset("T060321.361-0700", false, (int) (byte) 100, 21806);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendSignedDecimal(dateTimeFieldType18, 16, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.weekyear();
//        boolean boolean4 = mutableDateTime1.isAfter(1L);
//        mutableDateTime1.addMonths(6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.Instant instant16 = instant13.withDurationAdded(readableDuration14, 0);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.DateTime dateTime18 = instant16.toDateTime(chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime23 = dateTime18.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property24 = dateTime18.secondOfMinute();
//        org.joda.time.LocalDate localDate25 = dateTime18.toLocalDate();
//        int int26 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField32 = gJChronology31.years();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.dayOfYear();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology31, locale34, (java.lang.Integer) 20);
//        java.util.Locale locale37 = dateTimeParserBucket36.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology29, locale37, (java.lang.Integer) 1, 0);
//        java.lang.String str41 = offsetDateTimeField11.getAsText(68, locale37);
//        long long44 = offsetDateTimeField11.add(1560344663261L, (long) 2000);
//        try {
//            mutableDateTime1.setRounding((org.joda.time.DateTimeField) offsetDateTimeField11, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 10");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(locale37);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "68" + "'", str41.equals("68"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1733144663261L + "'", long44 == 1733144663261L);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-10));
//        boolean boolean9 = offsetDateTimeField7.isLeap(21798193L);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField7.getDurationField();
//        long long12 = offsetDateTimeField7.roundHalfCeiling(1560344607088L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7);
//        int int16 = offsetDateTimeField7.getDifference(1560344593147L, 1560344607275L);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.DateTime dateTime25 = dateTime22.toDateTime(dateTimeZone24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.dayOfWeek();
//        org.joda.time.DateTime dateTime30 = dateTime25.toDateTime((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTime dateTime32 = dateTime25.withYear(2);
//        org.joda.time.ReadablePeriod readablePeriod33 = null;
//        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, 1969);
//        org.joda.time.DateTime dateTime36 = dateTime32.toDateTimeISO();
//        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology39);
//        long long44 = gregorianChronology39.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology39.millisOfSecond();
//        org.joda.time.DurationField durationField46 = gregorianChronology39.weekyears();
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        long long50 = gregorianChronology39.add(readablePeriod47, (long) 31, 10);
//        java.lang.Object obj51 = null;
//        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime(obj51);
//        long long53 = mutableDateTime52.getMillis();
//        org.joda.time.MutableDateTime.Property property54 = mutableDateTime52.dayOfWeek();
//        long long55 = property54.remainder();
//        org.joda.time.MutableDateTime mutableDateTime56 = property54.roundFloor();
//        java.lang.String str57 = property54.getAsShortText();
//        org.joda.time.Instant instant59 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration60 = null;
//        org.joda.time.Instant instant62 = instant59.withDurationAdded(readableDuration60, 0);
//        org.joda.time.Chronology chronology63 = null;
//        org.joda.time.DateTime dateTime64 = instant62.toDateTime(chronology63);
//        org.joda.time.DateTime dateTime66 = dateTime64.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime.Property property67 = dateTime64.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone69 = gregorianChronology68.getZone();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime72 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology71);
//        org.joda.time.DateTimeZone dateTimeZone73 = mutableDateTime72.getZone();
//        org.joda.time.Chronology chronology74 = gregorianChronology68.withZone(dateTimeZone73);
//        java.lang.String str75 = dateTimeZone73.getID();
//        org.joda.time.DateTime dateTime76 = dateTime64.withZone(dateTimeZone73);
//        int int77 = property54.compareTo((org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.DateTime.Property property78 = dateTime64.millisOfSecond();
//        int int79 = dateTime64.getDayOfYear();
//        org.joda.time.LocalDate localDate80 = dateTime64.toLocalDate();
//        int[] intArray82 = gregorianChronology39.get((org.joda.time.ReadablePartial) localDate80, 1560344599446L);
//        try {
//            int[] intArray84 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) localTime37, 6, intArray82, 1976);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560384000000L + "'", long12 == 1560384000000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localTime37);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560344592765L + "'", long44 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 31L + "'", long50 == 31L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Thu" + "'", str57.equals("Thu"));
//        org.junit.Assert.assertNotNull(instant62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(chronology74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "UTC" + "'", str75.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertNotNull(localDate80);
//        org.junit.Assert.assertNotNull(intArray82);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        mutableDateTime1.addYears(10);
        mutableDateTime1.addWeeks((int) '4');
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.weekyear();
        java.lang.Object obj7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj7);
        mutableDateTime8.addYears((int) (byte) 1);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime1.setMillis((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("0");
        mutableDateTime1.setMillis((org.joda.time.ReadableInstant) instant14);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime14 = dateTime7.withYear(2);
        org.joda.time.DateTime.Property property15 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime17 = property15.addToCopy(9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 59, 35, 356, 25200, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 356 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) gJChronology2);
        try {
            long long11 = gJChronology2.getDateTimeMillis(277, 960, 832, (int) (byte) 100, 446, 10, 1976);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(21799169L);
        mutableDateTime1.setMillisOfDay(0);
        int int4 = mutableDateTime1.getMinuteOfDay();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) instant5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = gregorianChronology6.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        long long15 = gregorianChronology10.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField16, 19);
//        java.lang.String str19 = skipDateTimeField18.toString();
//        int int20 = skipDateTimeField18.getMinimumValue();
//        long long22 = skipDateTimeField18.roundHalfFloor(1L);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.years();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfYear();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology25, locale28, (java.lang.Integer) 20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField32 = gregorianChronology31.weeks();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 6);
//        boolean boolean36 = dateTimeParserBucket30.restoreState((java.lang.Object) offsetDateTimeField35);
//        long long39 = offsetDateTimeField35.add(21802794L, 1);
//        long long42 = offsetDateTimeField35.add(1560366408091L, 0);
//        int int44 = offsetDateTimeField35.getMaximumValue(21809800L);
//        long long46 = offsetDateTimeField35.roundHalfCeiling(26915155L);
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField52 = gJChronology51.years();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.dayOfYear();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology51, locale54, (java.lang.Integer) 20);
//        java.util.Locale locale57 = dateTimeParserBucket56.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology49, locale57, (java.lang.Integer) 1, 0);
//        java.lang.String str61 = offsetDateTimeField35.getAsShortText((int) '#', locale57);
//        java.lang.String str62 = skipDateTimeField18.getAsShortText(2, locale57);
//        java.lang.String str63 = dateTimeZone4.getShortName(26915155L, locale57);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology64 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560344592765L + "'", long15 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str19.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 108202794L + "'", long39 == 108202794L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560366408091L + "'", long42 == 1560366408091L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 13 + "'", int44 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "35" + "'", str61.equals("35"));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2" + "'", str62.equals("2"));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "UTC" + "'", str63.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology64);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", 365, 1);
        java.lang.String str7 = fixedDateTimeZone5.getShortName(1560344604658L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int9 = dateTime8.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.365" + "'", str7.equals("+00:00:00.365"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(21799169L);
        try {
            mutableDateTime1.setDayOfWeek(23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime14 = dateTime7.withYear(2);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 1969);
        org.joda.time.DateTime dateTime22 = dateTime14.withTime(16, (int) (byte) 1, (int) (short) 0, 31);
        org.joda.time.Instant instant24 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.Instant instant27 = instant24.withDurationAdded(readableDuration25, 0);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = instant27.toDateTime(chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.hourOfDay();
        org.joda.time.DateTime dateTime31 = property30.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime39 = dateTime36.toDateTime(dateTimeZone38);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.dayOfWeek();
        org.joda.time.DateTime dateTime44 = dateTime39.toDateTime((org.joda.time.Chronology) gregorianChronology40);
        org.joda.time.DateTime dateTime46 = dateTime39.withYear(2);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, 1969);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = dateTime46.withChronology((org.joda.time.Chronology) gregorianChronology50);
        boolean boolean52 = dateTime31.isAfter((org.joda.time.ReadableInstant) dateTime51);
        int int53 = dateTime22.compareTo((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime55 = dateTime22.plusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(dateTime55);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.minusHours(10);
        org.joda.time.DateTime dateTime13 = dateTime6.minusDays(9);
        org.joda.time.DateTime dateTime16 = dateTime6.withDurationAdded((long) (-1), (int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfWeek(7);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        long long14 = offsetDateTimeField4.roundHalfCeiling((long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) mutableDateTime0);
//        java.lang.Object obj2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj2);
//        long long4 = mutableDateTime3.getMillis();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime3.dayOfWeek();
//        long long6 = property5.remainder();
//        int int7 = property5.get();
//        org.joda.time.DurationField durationField8 = property5.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property5.getFieldType();
//        int int10 = instant1.get(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.yearOfEra();
        java.lang.Object obj5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj5);
        mutableDateTime6.addYears((int) (byte) 1);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime1.setChronology(chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.yearOfEra();
        mutableDateTime1.setMillisOfSecond(687);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1L, 1560344597041L, 25200);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 1, (org.joda.time.Chronology) gregorianChronology4);
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 39320683845433201L + "'", long9 == 39320683845433201L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime4.withYear(16);
        org.joda.time.DateTime.Property property10 = dateTime4.era();
        org.joda.time.DateTime dateTime12 = dateTime4.minus(43609391L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundFloor();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
//        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
//        boolean boolean8 = instant7.isBeforeNow();
//        java.lang.Object obj9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(obj9);
//        long long11 = mutableDateTime10.getMillis();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.dayOfWeek();
//        long long13 = property12.remainder();
//        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime15 = property12.getMutableDateTime();
//        int int16 = mutableDateTime15.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = gregorianChronology17.weeks();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology21);
//        long long26 = gregorianChronology21.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology21.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField27, 19);
//        java.lang.String str30 = skipDateTimeField29.toString();
//        long long33 = skipDateTimeField29.add(1L, 762970915);
//        org.joda.time.Instant instant35 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration36 = null;
//        org.joda.time.Instant instant38 = instant35.withDurationAdded(readableDuration36, 0);
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.DateTime dateTime40 = instant38.toDateTime(chronology39);
//        org.joda.time.DateTime dateTime42 = dateTime40.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime45 = dateTime40.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property46 = dateTime40.secondOfMinute();
//        org.joda.time.LocalDate localDate47 = dateTime40.toLocalDate();
//        int int48 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate47);
//        java.lang.String str49 = skipDateTimeField29.toString();
//        org.joda.time.Instant instant51 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration52 = null;
//        org.joda.time.Instant instant54 = instant51.withDurationAdded(readableDuration52, 0);
//        org.joda.time.Chronology chronology55 = null;
//        org.joda.time.DateTime dateTime56 = instant54.toDateTime(chronology55);
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime58 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology57);
//        org.joda.time.DateTimeZone dateTimeZone59 = mutableDateTime58.getZone();
//        org.joda.time.DateTime dateTime60 = dateTime56.toDateTime(dateTimeZone59);
//        org.joda.time.DateTime.Property property61 = dateTime56.centuryOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField29, dateTimeFieldType62, 52);
//        int int65 = mutableDateTime15.get(dateTimeFieldType62);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 21796615L, (java.lang.Number) 21802794L, (java.lang.Number) 21802344L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "AD");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 1560344599169L, "32");
//        int int75 = instant7.get(dateTimeFieldType62);
//        org.joda.time.Chronology chronology76 = instant7.getChronology();
//        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField78 = gregorianChronology77.weeks();
//        org.joda.time.DateTimeField dateTimeField79 = gregorianChronology77.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 6);
//        int int83 = offsetDateTimeField81.getLeapAmount(1560344602794L);
//        int int85 = offsetDateTimeField81.getLeapAmount(1560344602184L);
//        int int86 = instant7.get((org.joda.time.DateTimeField) offsetDateTimeField81);
//        org.joda.time.chrono.GregorianChronology gregorianChronology87 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime88 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology87);
//        org.joda.time.DateTimeZone dateTimeZone89 = mutableDateTime88.getZone();
//        org.joda.time.DateTime dateTime90 = new org.joda.time.DateTime(dateTimeZone89);
//        org.joda.time.LocalDate localDate91 = dateTime90.toLocalDate();
//        int[] intArray95 = new int[] { 21806404, 100 };
//        try {
//            int[] intArray97 = offsetDateTimeField81.addWrapField((org.joda.time.ReadablePartial) localDate91, (int) (short) 1, intArray95, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560344592765L + "'", long26 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str30.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 762970916L + "'", long33 == 762970916L);
//        org.junit.Assert.assertNotNull(instant38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 999 + "'", int48 == 999);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str49.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(instant54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 19 + "'", int65 == 19);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 19 + "'", int75 == 19);
//        org.junit.Assert.assertNotNull(chronology76);
//        org.junit.Assert.assertNotNull(gregorianChronology77);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 10 + "'", int86 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology87);
//        org.junit.Assert.assertNotNull(dateTimeZone89);
//        org.junit.Assert.assertNotNull(localDate91);
//        org.junit.Assert.assertNotNull(intArray95);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
        org.joda.time.Instant instant10 = instant4.withDurationAdded(0L, (int) (short) 10);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant11.withDurationAdded(readableDuration12, 21809251);
        org.joda.time.DateTime dateTime15 = instant11.toDateTime();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("UTC", "", (int) '#', (-1));
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.clockhourOfDay();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(21799446L);
        mutableDateTime1.setMillis((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime4.getZone();
//        mutableDateTime1.setZone(dateTimeZone5);
//        boolean boolean8 = mutableDateTime1.isEqual(21794864L);
//        java.util.Locale locale9 = null;
//        java.util.Calendar calendar10 = mutableDateTime1.toCalendar(locale9);
//        mutableDateTime1.addWeeks((-10));
//        try {
//            mutableDateTime1.setTime(18059, 1969, 2, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18059 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(calendar10);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1560344599985L, "ISOChronology[UTC]");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology3, locale6, (java.lang.Integer) 20);
        java.util.Locale locale9 = dateTimeParserBucket8.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology1, locale9, (java.lang.Integer) 1, 0);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket12.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology18);
        long long23 = gregorianChronology18.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField24, 19);
        java.lang.String str27 = skipDateTimeField26.toString();
        long long30 = skipDateTimeField26.add(1L, 762970915);
        org.joda.time.Instant instant32 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Instant instant35 = instant32.withDurationAdded(readableDuration33, 0);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.DateTime dateTime37 = instant35.toDateTime(chronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime42 = dateTime37.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property43 = dateTime37.secondOfMinute();
        org.joda.time.LocalDate localDate44 = dateTime37.toLocalDate();
        int int45 = skipDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate44);
        int int47 = skipDateTimeField26.get(1560344606277L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, (org.joda.time.DateTimeField) skipDateTimeField26);
        int int50 = skipUndoDateTimeField48.get(43607095L);
        int int51 = skipUndoDateTimeField48.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560344592765L + "'", long23 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str27.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 762970916L + "'", long30 == 762970916L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 277 + "'", int47 == 277);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 95 + "'", int50 == 95);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = mutableDateTime5.getZone();
        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.year();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(1560344661694L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1560344594181L, (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology7);
//        long long12 = gregorianChronology7.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DurationField durationField14 = gregorianChronology7.weekyears();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        long long18 = gregorianChronology7.add(readablePeriod15, (long) 31, 10);
//        java.lang.Object obj19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(obj19);
//        long long21 = mutableDateTime20.getMillis();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime20.dayOfWeek();
//        long long23 = property22.remainder();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.roundFloor();
//        java.lang.String str25 = property22.getAsShortText();
//        org.joda.time.Instant instant27 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.Instant instant30 = instant27.withDurationAdded(readableDuration28, 0);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = instant30.toDateTime(chronology31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime.Property property35 = dateTime32.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone37 = gregorianChronology36.getZone();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeZone dateTimeZone41 = mutableDateTime40.getZone();
//        org.joda.time.Chronology chronology42 = gregorianChronology36.withZone(dateTimeZone41);
//        java.lang.String str43 = dateTimeZone41.getID();
//        org.joda.time.DateTime dateTime44 = dateTime32.withZone(dateTimeZone41);
//        int int45 = property22.compareTo((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property46 = dateTime32.millisOfSecond();
//        int int47 = dateTime32.getDayOfYear();
//        org.joda.time.LocalDate localDate48 = dateTime32.toLocalDate();
//        int[] intArray50 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDate48, 1560344599446L);
//        int[] intArray53 = new int[] { (byte) 1, (byte) 1 };
//        try {
//            gregorianChronology2.validate((org.joda.time.ReadablePartial) localDate48, intArray53);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560344592765L + "'", long12 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 31L + "'", long18 == 31L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Thu" + "'", str25.equals("Thu"));
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray53);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundFloor();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime7 = property3.set("2019");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime14 = dateTime7.withYear(2);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 1969);
        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(0);
        org.joda.time.DateTime dateTime21 = dateTime14.withMillisOfSecond((int) (byte) 1);
        org.joda.time.Chronology chronology22 = dateTime21.getChronology();
        try {
            org.joda.time.DateTime dateTime24 = dateTime21.withSecondOfMinute(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        long long18 = offsetDateTimeField11.add(1560366408091L, 0);
        long long20 = offsetDateTimeField11.roundHalfEven(475002278834720L);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology25);
        long long30 = gregorianChronology25.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField31, 19);
        java.lang.String str34 = skipDateTimeField33.toString();
        long long37 = skipDateTimeField33.add(1L, 762970915);
        org.joda.time.Instant instant39 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Instant instant42 = instant39.withDurationAdded(readableDuration40, 0);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = instant42.toDateTime(chronology43);
        org.joda.time.DateTime dateTime46 = dateTime44.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime44.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property50 = dateTime44.secondOfMinute();
        org.joda.time.LocalDate localDate51 = dateTime44.toLocalDate();
        int int52 = skipDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        java.lang.String str53 = skipDateTimeField33.toString();
        org.joda.time.Instant instant55 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.Instant instant58 = instant55.withDurationAdded(readableDuration56, 0);
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.DateTime dateTime60 = instant58.toDateTime(chronology59);
        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology61);
        org.joda.time.DateTimeZone dateTimeZone63 = mutableDateTime62.getZone();
        org.joda.time.DateTime dateTime64 = dateTime60.toDateTime(dateTimeZone63);
        org.joda.time.DateTime.Property property65 = dateTime60.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property65.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, dateTimeFieldType66, 52);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField69 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560366408091L + "'", long18 == 1560366408091L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 475002316800000L + "'", long20 == 475002316800000L);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560344592765L + "'", long30 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str34.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 762970916L + "'", long37 == 762970916L);
        org.junit.Assert.assertNotNull(instant42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 999 + "'", int52 == 999);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str53.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(instant58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gregorianChronology61);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long16 = skipDateTimeField12.add(1L, 762970915);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant21 = instant18.withDurationAdded(readableDuration19, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = instant21.toDateTime(chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime28 = dateTime23.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property29 = dateTime23.secondOfMinute();
        org.joda.time.LocalDate localDate30 = dateTime23.toLocalDate();
        int int31 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField36 = gJChronology35.years();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology35.dayOfYear();
        java.util.Locale locale38 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology35, locale38, (java.lang.Integer) 20);
        java.util.Locale locale41 = dateTimeParserBucket40.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology33, locale41, (java.lang.Integer) 1, 0);
        java.text.DateFormatSymbols dateFormatSymbols45 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale41);
        int int46 = skipDateTimeField12.getMaximumTextLength(locale41);
        int int48 = skipDateTimeField12.get(1560344604486L);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale50 = null;
        try {
            java.lang.String str51 = skipDateTimeField12.getAsText(readablePartial49, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 762970916L + "'", long16 == 762970916L);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 999 + "'", int31 == 999);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertNotNull(dateFormatSymbols45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 486 + "'", int48 == 486);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime(dateTimeZone9);
        long long12 = dateTimeZone9.convertUTCToLocal(1560344603175L);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560344603175L + "'", long12 == 1560344603175L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.getMutableDateTime();
//        int int7 = mutableDateTime6.getEra();
//        mutableDateTime6.setDayOfYear((int) ' ');
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        mutableDateTime6.add(readableDuration10, 2000);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DurationField durationField14 = property12.getLeapDurationField();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology3, locale6, (java.lang.Integer) 20);
        java.util.Locale locale9 = dateTimeParserBucket8.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology1, locale9, (java.lang.Integer) 1, 0);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket12.getChronology();
        boolean boolean15 = dateTimeParserBucket12.restoreState((java.lang.Object) 20);
        java.lang.Integer int16 = dateTimeParserBucket12.getPivotYear();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16.equals(1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendYearOfCentury(832, 365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test121");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-10));
//        boolean boolean9 = offsetDateTimeField7.isLeap(21798193L);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField7.getDurationField();
//        long long12 = offsetDateTimeField7.roundHalfCeiling(1560344607088L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.weeks();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 6);
//        org.joda.time.Instant instant20 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.Instant instant23 = instant20.withDurationAdded(readableDuration21, 0);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = instant23.toDateTime(chronology24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime25.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property31 = dateTime25.secondOfMinute();
//        org.joda.time.LocalDate localDate32 = dateTime25.toLocalDate();
//        int int33 = offsetDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider35 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider35);
//        java.util.Locale locale37 = null;
//        java.lang.String str40 = defaultNameProvider35.getName(locale37, "Wed", "Wed");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.String str43 = buddhistChronology42.toString();
//        org.joda.time.Chronology chronology44 = buddhistChronology42.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.Chronology chronology46 = buddhistChronology42.withZone(dateTimeZone45);
//        java.lang.String str47 = buddhistChronology42.toString();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField52 = gJChronology51.years();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.dayOfYear();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology51, locale54, (java.lang.Integer) 20);
//        java.util.Locale locale57 = dateTimeParserBucket56.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology49, locale57, (java.lang.Integer) 1, 0);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) buddhistChronology42, locale57);
//        java.lang.String str64 = defaultNameProvider35.getName(locale57, "GJChronology[UTC]", "0");
//        org.joda.time.Chronology chronology66 = null;
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField69 = gJChronology68.years();
//        org.joda.time.DateTimeField dateTimeField70 = gJChronology68.dayOfYear();
//        java.util.Locale locale71 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology68, locale71, (java.lang.Integer) 20);
//        java.util.Locale locale74 = dateTimeParserBucket73.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology66, locale74, (java.lang.Integer) 1, 0);
//        java.lang.String str80 = defaultNameProvider35.getShortName(locale74, "millisOfSecond", "AD");
//        java.lang.String str81 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate32, (int) ' ', locale74);
//        int int82 = offsetDateTimeField7.getOffset();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560384000000L + "'", long12 == 1560384000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(instant23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BuddhistChronology[UTC]" + "'", str43.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "BuddhistChronology[UTC]" + "'", str47.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertNull(str64);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(locale74);
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "32" + "'", str81.equals("32"));
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-10) + "'", int82 == (-10));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-12T14:40:31.356Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T14:40:31.356Z' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
        org.joda.time.Instant instant10 = instant4.withDurationAdded(0L, (int) (short) 10);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant11.withDurationAdded(readableDuration12, 21809251);
        org.joda.time.DateTime dateTime15 = instant11.toDateTime();
        long long16 = instant11.getMillis();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
        mutableDateTime1.setMillis(21794831L);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology6);
        boolean boolean8 = mutableDateTime1.equals((java.lang.Object) mutableDateTime7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = mutableDateTime1.toDateTime(chronology9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime((org.joda.time.Chronology) julianChronology11);
        try {
            long long17 = julianChronology11.getDateTimeMillis(31, 365, 19, 446);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendSecondOfMinute((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendMonthOfYearText();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder5.append(dateTimePrinter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendSecondOfMinute((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder32.appendMonthOfYearText();
        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatterBuilder37.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder25.append(dateTimePrinter38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder25.appendYearOfCentury((int) (byte) 10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder42.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter50 = dateTimeFormatterBuilder46.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatterBuilder46.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder42.appendOptional(dateTimeParser51);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder5.append(dateTimeParser51);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendSecondOfMinute(446);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder53.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap58 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendTimeZoneShortName(strMap58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral("Wed");
        boolean boolean62 = dateTimeFormatterBuilder59.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder59.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatter64.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder59.append(dateTimePrinter65);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap68 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendTimeZoneShortName(strMap68);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder69.appendLiteral("Wed");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder69.appendFractionOfDay(2019, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser76 = dateTimeFormatter75.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder74.append(dateTimeParser76);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder78.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder78.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter82 = dateTimeFormatterBuilder78.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter83 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser84 = dateTimeFormatter83.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter82, dateTimeParser84);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray86 = new org.joda.time.format.DateTimeParser[] { dateTimeParser76, dateTimeParser84 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder56.append(dateTimePrinter65, dateTimeParserArray86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimePrinter38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimePrinter50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatter75);
        org.junit.Assert.assertNotNull(dateTimeParser76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimePrinter82);
        org.junit.Assert.assertNotNull(dateTimeFormatter83);
        org.junit.Assert.assertNotNull(dateTimeParser84);
        org.junit.Assert.assertNotNull(dateTimeParserArray86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test126");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
//        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
//        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField12.getWrappedField();
//        org.joda.time.DurationField durationField14 = skipDateTimeField12.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 6);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField19.getAsShortText((long) 20, locale21);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField27 = gJChronology26.years();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.dayOfYear();
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology26, locale29, (java.lang.Integer) 20);
//        java.util.Locale locale32 = dateTimeParserBucket31.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology24, locale32, (java.lang.Integer) 1, 0);
//        int int36 = offsetDateTimeField19.getMaximumShortTextLength(locale32);
//        int int37 = skipDateTimeField12.getMaximumTextLength(locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology38);
//        org.joda.time.DateTimeZone dateTimeZone40 = mutableDateTime39.getZone();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime44 = dateTime41.withCenturyOfEra((int) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay45 = dateTime41.toTimeOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime48 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology47);
//        long long52 = gregorianChronology47.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology47.millisOfSecond();
//        org.joda.time.DurationField durationField54 = gregorianChronology47.weekyears();
//        org.joda.time.ReadablePeriod readablePeriod55 = null;
//        long long58 = gregorianChronology47.add(readablePeriod55, (long) 31, 10);
//        java.lang.Object obj59 = null;
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime(obj59);
//        long long61 = mutableDateTime60.getMillis();
//        org.joda.time.MutableDateTime.Property property62 = mutableDateTime60.dayOfWeek();
//        long long63 = property62.remainder();
//        org.joda.time.MutableDateTime mutableDateTime64 = property62.roundFloor();
//        java.lang.String str65 = property62.getAsShortText();
//        org.joda.time.Instant instant67 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration68 = null;
//        org.joda.time.Instant instant70 = instant67.withDurationAdded(readableDuration68, 0);
//        org.joda.time.Chronology chronology71 = null;
//        org.joda.time.DateTime dateTime72 = instant70.toDateTime(chronology71);
//        org.joda.time.DateTime dateTime74 = dateTime72.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime.Property property75 = dateTime72.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone77 = gregorianChronology76.getZone();
//        org.joda.time.DateTimeField dateTimeField78 = gregorianChronology76.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology79);
//        org.joda.time.DateTimeZone dateTimeZone81 = mutableDateTime80.getZone();
//        org.joda.time.Chronology chronology82 = gregorianChronology76.withZone(dateTimeZone81);
//        java.lang.String str83 = dateTimeZone81.getID();
//        org.joda.time.DateTime dateTime84 = dateTime72.withZone(dateTimeZone81);
//        int int85 = property62.compareTo((org.joda.time.ReadableInstant) dateTime72);
//        org.joda.time.DateTime.Property property86 = dateTime72.millisOfSecond();
//        int int87 = dateTime72.getDayOfYear();
//        org.joda.time.LocalDate localDate88 = dateTime72.toLocalDate();
//        int[] intArray90 = gregorianChronology47.get((org.joda.time.ReadablePartial) localDate88, 1560344599446L);
//        try {
//            int[] intArray92 = skipDateTimeField12.add((org.joda.time.ReadablePartial) timeOfDay45, 16, intArray90, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNull(durationField14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10" + "'", str22.equals("10"));
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(locale32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(timeOfDay45);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560344592765L + "'", long52 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 31L + "'", long58 == 31L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Thu" + "'", str65.equals("Thu"));
//        org.junit.Assert.assertNotNull(instant70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(gregorianChronology76);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(gregorianChronology79);
//        org.junit.Assert.assertNotNull(dateTimeZone81);
//        org.junit.Assert.assertNotNull(chronology82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "UTC" + "'", str83.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
//        org.junit.Assert.assertNotNull(property86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertNotNull(intArray90);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        long long4 = dateTimeZone1.adjustOffset(43607095L, true);
        boolean boolean6 = dateTimeZone1.isStandardOffset(2440588L);
        long long8 = dateTimeZone1.convertUTCToLocal(1560344610399L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43607095L + "'", long4 == 43607095L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560344610409L + "'", long8 == 1560344610409L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(1560344599169L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        int int16 = offsetDateTimeField11.getMaximumValue();
        int int18 = offsetDateTimeField11.getLeapAmount(1560344594181L);
        long long20 = offsetDateTimeField11.roundCeiling(47061356L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
//        mutableDateTime1.setMillis(21794831L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology6);
//        boolean boolean8 = mutableDateTime1.equals((java.lang.Object) mutableDateTime7);
//        int int9 = mutableDateTime7.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime12 = property10.add(21799446L);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test131");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.years();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime6.getZone();
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone7);
//        java.lang.String str9 = dateTimeZone7.getID();
//        org.joda.time.Chronology chronology10 = gJChronology0.withZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        long long12 = dateTime11.getMillis();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = iSOChronology0.add(readablePeriod1, 21807088L, (int) (short) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        boolean boolean6 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter5);
//        boolean boolean7 = dateTimeFormatter5.isParser();
//        java.lang.StringBuffer stringBuffer8 = null;
//        java.lang.Object obj9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(obj9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.weekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTimeZone dateTimeZone17 = mutableDateTime16.getZone();
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withZone(dateTimeZone17);
//        java.lang.String str19 = dateTimeZone17.getID();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((-1));
//        java.lang.Object obj23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj23);
//        long long25 = mutableDateTime24.getMillis();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime24.dayOfWeek();
//        long long27 = property26.remainder();
//        org.joda.time.MutableDateTime mutableDateTime28 = property26.roundFloor();
//        java.lang.String str29 = property26.getAsShortText();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime.Property property39 = dateTime36.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology43);
//        org.joda.time.DateTimeZone dateTimeZone45 = mutableDateTime44.getZone();
//        org.joda.time.Chronology chronology46 = gregorianChronology40.withZone(dateTimeZone45);
//        java.lang.String str47 = dateTimeZone45.getID();
//        org.joda.time.DateTime dateTime48 = dateTime36.withZone(dateTimeZone45);
//        int int49 = property26.compareTo((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime.Property property50 = dateTime36.millisOfSecond();
//        int int51 = dateTime36.getDayOfYear();
//        org.joda.time.LocalDate localDate52 = dateTime36.toLocalDate();
//        org.joda.time.DateTime dateTime53 = dateTime20.withFields((org.joda.time.ReadablePartial) localDate52);
//        int int54 = property11.compareTo((org.joda.time.ReadablePartial) localDate52);
//        try {
//            dateTimeFormatter5.printTo(stringBuffer8, (org.joda.time.ReadablePartial) localDate52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 21807088L + "'", long4 == 21807088L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Thu" + "'", str29.equals("Thu"));
//        org.junit.Assert.assertNotNull(instant34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        int int6 = mutableDateTime5.getMillisOfDay();
//        mutableDateTime5.setYear(3);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.centuryOfEra();
//        org.joda.time.DurationField durationField10 = property9.getRangeDurationField();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        long long15 = property14.remainder();
//        org.joda.time.MutableDateTime mutableDateTime16 = property14.roundHalfCeiling();
//        int int17 = mutableDateTime16.getMillisOfDay();
//        mutableDateTime16.setYear(3);
//        boolean boolean20 = property9.equals((java.lang.Object) 3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.halfdays();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekyear(18059);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTimeISO();
        java.lang.Object obj13 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", 365, 1);
        int int20 = fixedDateTimeZone18.getOffsetFromLocal(1560344594181L);
        int int22 = fixedDateTimeZone18.getStandardOffset((-210866760000000L));
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj13, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        java.util.Set<java.lang.String> strSet8 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean9 = iSOChronology7.equals((java.lang.Object) strSet8);
        org.joda.time.DurationField durationField10 = iSOChronology7.minutes();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant12.withDurationAdded(readableDuration13, 0);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = instant15.toDateTime(chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property23 = dateTime17.secondOfMinute();
        org.joda.time.LocalDate localDate24 = dateTime17.toLocalDate();
        int[] intArray26 = iSOChronology7.get((org.joda.time.ReadablePartial) localDate24, 21802794L);
        int[] intArray28 = null;
        try {
            int[] intArray30 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate24, 100, intArray28, 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for dayOfWeek must be in the range [7,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("org.joda.time.IllegalFieldValueException: Value 0 for 3 must be in the range [100,1560344597539]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        long long18 = offsetDateTimeField11.add(1560366408091L, 0);
        int int20 = offsetDateTimeField11.getMaximumValue(21809800L);
        long long22 = offsetDateTimeField11.roundHalfCeiling(26915155L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField11.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560366408091L + "'", long18 == 1560366408091L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(durationField23);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        int int5 = property3.get();
//        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
//        int int7 = property3.getMinimumValue();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = property3.set("");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.getID();
        org.joda.time.Chronology chronology10 = gJChronology0.withZone(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.secondOfDay();
        org.joda.time.Instant instant13 = gJChronology11.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(instant13);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str6 = cachedDateTimeZone4.getName((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(21799169L);
        mutableDateTime3.setTime((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.minuteOfDay();
        mutableDateTime3.add(762970916L);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime3.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        long long18 = offsetDateTimeField11.add(1560366408091L, 0);
        int int20 = offsetDateTimeField11.getMaximumValue(21809800L);
        long long22 = offsetDateTimeField11.roundHalfCeiling(26915155L);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField28 = gJChronology27.years();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.dayOfYear();
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology27, locale30, (java.lang.Integer) 20);
        java.util.Locale locale33 = dateTimeParserBucket32.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology25, locale33, (java.lang.Integer) 1, 0);
        java.lang.String str37 = offsetDateTimeField11.getAsShortText((int) '#', locale33);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider39 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider39);
        java.util.Locale locale41 = null;
        java.lang.String str44 = defaultNameProvider39.getName(locale41, "Wed", "Wed");
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str47 = buddhistChronology46.toString();
        org.joda.time.Chronology chronology48 = buddhistChronology46.withUTC();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.Chronology chronology50 = buddhistChronology46.withZone(dateTimeZone49);
        java.lang.String str51 = buddhistChronology46.toString();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField56 = gJChronology55.years();
        org.joda.time.DateTimeField dateTimeField57 = gJChronology55.dayOfYear();
        java.util.Locale locale58 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology55, locale58, (java.lang.Integer) 20);
        java.util.Locale locale61 = dateTimeParserBucket60.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology53, locale61, (java.lang.Integer) 1, 0);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) buddhistChronology46, locale61);
        java.lang.String str68 = defaultNameProvider39.getName(locale61, "GJChronology[UTC]", "0");
        org.joda.time.Chronology chronology70 = null;
        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField73 = gJChronology72.years();
        org.joda.time.DateTimeField dateTimeField74 = gJChronology72.dayOfYear();
        java.util.Locale locale75 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology72, locale75, (java.lang.Integer) 20);
        java.util.Locale locale78 = dateTimeParserBucket77.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket81 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology70, locale78, (java.lang.Integer) 1, 0);
        java.lang.String str84 = defaultNameProvider39.getShortName(locale78, "millisOfSecond", "AD");
        java.lang.String str85 = offsetDateTimeField11.getAsShortText(1, locale78);
        java.lang.String str87 = offsetDateTimeField11.getAsShortText(475329659486864L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560366408091L + "'", long18 == 1560366408091L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "35" + "'", str37.equals("35"));
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "BuddhistChronology[UTC]" + "'", str47.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "BuddhistChronology[UTC]" + "'", str51.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(gJChronology72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(locale78);
        org.junit.Assert.assertNull(str84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "1" + "'", str85.equals("1"));
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "7" + "'", str87.equals("7"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("3", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder6.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for 3 must be in the range [100,1560344597539]", 31);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder6.setFixedSavings("Thursday", 277);
        java.io.OutputStream outputStream14 = null;
        try {
            dateTimeZoneBuilder6.writeTo("1", outputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (-10));
//        boolean boolean9 = offsetDateTimeField7.isLeap(21798193L);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField7.getDurationField();
//        long long12 = offsetDateTimeField7.roundHalfCeiling(1560344607088L);
//        try {
//            long long15 = offsetDateTimeField7.set(9223372036854775807L, 18059);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18059 for dayOfMonth must be in the range [-9,21]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560384000000L + "'", long12 == 1560384000000L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant4.minus(readableDuration8);
        org.joda.time.DateTime dateTime10 = instant9.toDateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.withDurationAdded(readableDuration12, 21806);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
//        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology7);
//        long long12 = gregorianChronology7.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DurationField durationField14 = gregorianChronology7.weekyears();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        long long18 = gregorianChronology7.add(readablePeriod15, (long) 31, 10);
//        java.lang.Object obj19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(obj19);
//        long long21 = mutableDateTime20.getMillis();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime20.dayOfWeek();
//        long long23 = property22.remainder();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.roundFloor();
//        java.lang.String str25 = property22.getAsShortText();
//        org.joda.time.Instant instant27 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.Instant instant30 = instant27.withDurationAdded(readableDuration28, 0);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = instant30.toDateTime(chronology31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime.Property property35 = dateTime32.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone37 = gregorianChronology36.getZone();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeZone dateTimeZone41 = mutableDateTime40.getZone();
//        org.joda.time.Chronology chronology42 = gregorianChronology36.withZone(dateTimeZone41);
//        java.lang.String str43 = dateTimeZone41.getID();
//        org.joda.time.DateTime dateTime44 = dateTime32.withZone(dateTimeZone41);
//        int int45 = property22.compareTo((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property46 = dateTime32.millisOfSecond();
//        int int47 = dateTime32.getDayOfYear();
//        org.joda.time.LocalDate localDate48 = dateTime32.toLocalDate();
//        int[] intArray50 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDate48, 1560344599446L);
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.util.Set<java.lang.String> strSet53 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean54 = iSOChronology52.equals((java.lang.Object) strSet53);
//        org.joda.time.DurationField durationField55 = iSOChronology52.minutes();
//        org.joda.time.Instant instant57 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration58 = null;
//        org.joda.time.Instant instant60 = instant57.withDurationAdded(readableDuration58, 0);
//        org.joda.time.Chronology chronology61 = null;
//        org.joda.time.DateTime dateTime62 = instant60.toDateTime(chronology61);
//        org.joda.time.DateTime dateTime64 = dateTime62.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime67 = dateTime62.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property68 = dateTime62.secondOfMinute();
//        org.joda.time.LocalDate localDate69 = dateTime62.toLocalDate();
//        int[] intArray71 = iSOChronology52.get((org.joda.time.ReadablePartial) localDate69, 21802794L);
//        try {
//            int[] intArray73 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate48, 59, intArray71, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560344592765L + "'", long12 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 31L + "'", long18 == 31L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Thu" + "'", str25.equals("Thu"));
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(strSet53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(instant60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(intArray71);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter3.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendSecondOfMinute((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendMonthOfYearText();
        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatterBuilder26.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.append(dateTimePrinter27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder38.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder41.appendSecondOfMinute((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendMonthOfYearText();
        org.joda.time.format.DateTimePrinter dateTimePrinter47 = dateTimeFormatterBuilder46.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder34.append(dateTimePrinter47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder34.appendYearOfCentury((int) (byte) 10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder51.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder55.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder55.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter59 = dateTimeFormatterBuilder55.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser60 = dateTimeFormatterBuilder55.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder51.appendOptional(dateTimeParser60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder14.append(dateTimeParser60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter64 = dateTimeFormatter63.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder65.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder65.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter69 = dateTimeFormatterBuilder65.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatter70.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter69, dateTimeParser71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder14.append(dateTimePrinter64, dateTimeParser71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder74.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder74.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter78 = dateTimeFormatterBuilder74.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder74.appendClockhourOfDay(2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser82 = dateTimeFormatter81.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder74.append(dateTimeParser82);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder8.append(dateTimePrinter64, dateTimeParser82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimePrinter27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimePrinter47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimePrinter59);
        org.junit.Assert.assertNotNull(dateTimeParser60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimePrinter64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimePrinter69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimePrinter78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
        org.junit.Assert.assertNotNull(dateTimeFormatter81);
        org.junit.Assert.assertNotNull(dateTimeParser82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (long) 68, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 68L + "'", long4 == 68L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.util.Set<java.lang.String> strSet1 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) strSet1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", 365, 1);
        java.lang.String str7 = fixedDateTimeZone5.getShortName(1560344604658L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant13 = instant10.withDurationAdded(readableDuration11, 0);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = instant13.toDateTime(chronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTimeZone dateTimeZone18 = mutableDateTime17.getZone();
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime15.secondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadableInstant readableInstant23 = null;
        int int24 = dateTimeZone22.getOffset(readableInstant23);
        org.joda.time.DateTime dateTime25 = dateTime15.withZone(dateTimeZone22);
        boolean boolean26 = fixedDateTimeZone5.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime.Property property27 = dateTime15.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime29 = property27.addToCopy(1560344598701L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1560344598701 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.365" + "'", str7.equals("+00:00:00.365"));
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gJChronology7.add(readablePeriod8, (long) 68, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = mutableDateTime13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.Chronology chronology17 = gJChronology7.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        long long19 = cachedDateTimeZone16.nextTransition((long) 16);
        long long23 = cachedDateTimeZone16.convertLocalToUTC((long) 21804658, false, 1560344606427L);
        java.lang.String str25 = cachedDateTimeZone16.getNameKey(21807687L);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(95, 3, (int) '4', (-1), 292278993, (int) 'a', 25200, (org.joda.time.DateTimeZone) cachedDateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 68L + "'", long11 == 68L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 16L + "'", long19 == 16L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 21804658L + "'", long23 == 21804658L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendWeekOfWeekyear(21806);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap20 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTimeZoneName(strMap20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder24.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatterBuilder24.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder23.appendOptional(dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder8.append(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test157");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("T060321.361-0700");
//        java.lang.Object obj2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj2);
//        long long4 = mutableDateTime3.getMillis();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime3.dayOfWeek();
//        long long6 = property5.remainder();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfCeiling();
//        int int8 = mutableDateTime7.getMillisOfDay();
//        boolean boolean10 = mutableDateTime7.isEqual(21798203L);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.hourOfDay();
//        int int12 = mutableDateTime7.getYearOfEra();
//        jodaTimePermission1.checkGuard((java.lang.Object) int12);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 163);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000018864d + "'", double1 == 2440587.5000018864d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField12.getWrappedField();
        long long16 = skipDateTimeField12.add(1560366407535L, 1560344601791L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField12.getAsShortText(762970915, locale18);
        org.joda.time.DurationField durationField20 = skipDateTimeField12.getDurationField();
        long long23 = durationField20.subtract(21797041L, 21809800L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3120711009326L + "'", long16 == 3120711009326L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "762970915" + "'", str19.equals("762970915"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-12759L) + "'", long23 == (-12759L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
        org.joda.time.Instant instant10 = instant4.withDurationAdded(0L, (int) (short) 10);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant11.withDurationAdded(readableDuration12, 21809251);
        org.joda.time.DateTime dateTime15 = instant11.toDateTime();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology21);
        long long26 = gregorianChronology21.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology21.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField27, 19);
        java.lang.String str30 = skipDateTimeField29.toString();
        org.joda.time.DurationField durationField31 = skipDateTimeField29.getDurationField();
        org.joda.time.Instant instant33 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.Instant instant36 = instant33.withDurationAdded(readableDuration34, 0);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = instant36.toDateTime(chronology37);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = mutableDateTime40.getZone();
        org.joda.time.DateTime dateTime42 = dateTime38.toDateTime(dateTimeZone41);
        org.joda.time.DateTime.Property property43 = dateTime38.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField29, dateTimeFieldType44, 21797041, 4, 446);
        int int49 = dateTime16.get(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560344592765L + "'", long26 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str30.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(instant36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 19 + "'", int49 == 19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("35", (java.lang.Number) 1560344602344L, (java.lang.Number) 23, (java.lang.Number) 39320683845433201L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        mutableDateTime1.addYears(10);
        mutableDateTime1.addWeeks((int) '4');
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfYear();
        org.joda.time.DateTime dateTime7 = mutableDateTime1.toDateTimeISO();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, 9);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours(6);
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test165");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
//        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField4.getMaximumTextLength(locale7);
//        long long10 = offsetDateTimeField4.remainder((-475329659484845L));
//        boolean boolean12 = offsetDateTimeField4.isLeap((long) 4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTimeZone dateTimeZone15 = mutableDateTime14.getZone();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.withCenturyOfEra((int) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime16.toTimeOfDay();
//        java.lang.Object obj22 = null;
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime(obj22);
//        long long24 = mutableDateTime23.getMillis();
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime23.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime23.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField27 = property26.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (-10));
//        int int31 = offsetDateTimeField29.getLeapAmount(999L);
//        org.joda.time.Instant instant33 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.Instant instant35 = instant33.withMillis((long) '#');
//        org.joda.time.DateTime dateTime36 = instant33.toDateTimeISO();
//        int int37 = dateTime36.getCenturyOfEra();
//        org.joda.time.DateMidnight dateMidnight38 = dateTime36.toDateMidnight();
//        org.joda.time.LocalDate localDate39 = dateTime36.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.util.Set<java.lang.String> strSet42 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean43 = iSOChronology41.equals((java.lang.Object) strSet42);
//        org.joda.time.DurationField durationField44 = iSOChronology41.minutes();
//        org.joda.time.Instant instant46 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration47 = null;
//        org.joda.time.Instant instant49 = instant46.withDurationAdded(readableDuration47, 0);
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.DateTime dateTime51 = instant49.toDateTime(chronology50);
//        org.joda.time.DateTime dateTime53 = dateTime51.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime56 = dateTime51.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property57 = dateTime51.secondOfMinute();
//        org.joda.time.LocalDate localDate58 = dateTime51.toLocalDate();
//        int[] intArray60 = iSOChronology41.get((org.joda.time.ReadablePartial) localDate58, 21802794L);
//        int[] intArray62 = offsetDateTimeField29.addWrapPartial((org.joda.time.ReadablePartial) localDate39, 0, intArray60, (int) (short) 10);
//        try {
//            int[] intArray64 = offsetDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay20, 783, intArray60, 21);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 783");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26915155L + "'", long10 == 26915155L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 19 + "'", int37 == 19);
//        org.junit.Assert.assertNotNull(dateMidnight38);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertNotNull(strSet42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(instant49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertNotNull(intArray62);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("3", (int) (byte) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(70, 'a', 0, 0, 3, true, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.Instant instant3 = instant1.withMillis((long) '#');
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            int int5 = instant3.get(dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, 21807088L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.centuryOfEra();
        org.joda.time.DurationField durationField9 = gregorianChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField10);
        int int13 = skipUndoDateTimeField11.get(1560344611925L);
        int int15 = skipUndoDateTimeField11.get((long) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 21807088L + "'", long4 == 21807088L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        long long10 = gregorianChronology5.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology5.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField11, 19);
        org.joda.time.DateTimeField dateTimeField14 = skipDateTimeField13.getWrappedField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField14, (int) (byte) 100);
        long long19 = skipDateTimeField16.add(0L, (int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344592765L + "'", long10 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("T130331.408Z");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.yearOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.year();
        java.lang.String str6 = property5.toString();
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("T060321.361-0700", "", 100, (int) (short) 100);
        java.lang.String str6 = fixedDateTimeZone4.getShortName(1560344608088L);
        try {
            org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 23");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 97, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        org.joda.time.DurationField durationField14 = skipDateTimeField12.getDurationField();
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = instant19.toDateTime(chronology20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = mutableDateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime(dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime21.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType27, 21797041, 4, 446);
        long long33 = offsetDateTimeField31.roundHalfCeiling(21797041L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 21797041L + "'", long33 == 21797041L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime13 = dateTime10.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime10.withYear(16);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder16.setFixedSavings("3", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder19.setFixedSavings("", 0);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeZoneBuilder22.toDateTimeZone("T060321.361-0700", false);
        org.joda.time.DateTime dateTime26 = dateTime10.toDateTime(dateTimeZone25);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) (byte) 10, (int) ' ', 2, (int) (byte) 0, 21806, 687, dateTimeZone25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21806 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        org.joda.time.DurationField durationField14 = skipDateTimeField12.getDurationField();
        long long16 = skipDateTimeField12.remainder(2440588L);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField12, 783, (int) (short) 1, 2019);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 365, 1);
        java.lang.String str6 = fixedDateTimeZone4.getShortName(1560344604658L);
        long long10 = fixedDateTimeZone4.convertLocalToUTC(21809279L, false, (long) 783);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.365" + "'", str6.equals("+00:00:00.365"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 21808914L + "'", long10 == 21808914L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.dayOfYear();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology3, locale6, (java.lang.Integer) 20);
        java.util.Locale locale9 = dateTimeParserBucket8.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology1, locale9, (java.lang.Integer) 1, 0);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket12.getChronology();
        java.lang.Integer int14 = dateTimeParserBucket12.getOffsetInteger();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNull(int14);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 31);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        boolean boolean17 = property15.isLeap();
//        org.joda.time.DurationField durationField18 = property15.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.weeks();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology24);
//        long long29 = gregorianChronology24.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology24.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField30, 19);
//        org.joda.time.DurationField durationField33 = skipDateTimeField32.getDurationField();
//        long long35 = skipDateTimeField32.roundHalfCeiling(762970916L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField37 = gregorianChronology36.weeks();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.halfdayOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology40);
//        long long45 = gregorianChronology40.add(1560344592817L, (long) (byte) -1, (int) '4');
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology40.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology36, dateTimeField46, 19);
//        java.lang.String str49 = skipDateTimeField48.toString();
//        long long52 = skipDateTimeField48.add(1L, 762970915);
//        org.joda.time.Instant instant54 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration55 = null;
//        org.joda.time.Instant instant57 = instant54.withDurationAdded(readableDuration55, 0);
//        org.joda.time.Chronology chronology58 = null;
//        org.joda.time.DateTime dateTime59 = instant57.toDateTime(chronology58);
//        org.joda.time.DateTime dateTime61 = dateTime59.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime64 = dateTime59.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property65 = dateTime59.secondOfMinute();
//        org.joda.time.LocalDate localDate66 = dateTime59.toLocalDate();
//        int int67 = skipDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDate66);
//        int[] intArray68 = null;
//        int int69 = skipDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) localDate66, intArray68);
//        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField73 = gJChronology72.years();
//        org.joda.time.DateTimeField dateTimeField74 = gJChronology72.dayOfYear();
//        java.util.Locale locale75 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology72, locale75, (java.lang.Integer) 20);
//        java.util.Locale locale78 = dateTimeParserBucket77.getLocale();
//        try {
//            java.lang.String str79 = unsupportedDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate66, 0, locale78);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560344592765L + "'", long29 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 762970916L + "'", long35 == 762970916L);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560344592765L + "'", long45 == 1560344592765L);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str49.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 762970916L + "'", long52 == 762970916L);
//        org.junit.Assert.assertNotNull(instant57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 999 + "'", int67 == 999);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(gJChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(locale78);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 31);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        boolean boolean17 = property15.isLeap();
//        org.joda.time.DurationField durationField18 = property15.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
//        org.joda.time.DurationField durationField20 = unsupportedDateTimeField19.getDurationField();
//        try {
//            long long22 = unsupportedDateTimeField19.roundFloor(21794181L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField3 = gJChronology0.halfdays();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        org.joda.time.Instant instant6 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 0);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = instant9.toDateTime(chronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property17 = dateTime11.secondOfMinute();
        org.joda.time.LocalDate localDate18 = dateTime11.toLocalDate();
        int int19 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.years();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.dayOfYear();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology24, locale27, (java.lang.Integer) 20);
        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology22, locale30, (java.lang.Integer) 1, 0);
        java.lang.String str34 = offsetDateTimeField4.getAsText(68, locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField37 = gregorianChronology36.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology40);
        long long45 = gregorianChronology40.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology36, dateTimeField46, 19);
        java.lang.String str49 = skipDateTimeField48.toString();
        long long52 = skipDateTimeField48.add(1L, 762970915);
        org.joda.time.Instant instant54 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.Instant instant57 = instant54.withDurationAdded(readableDuration55, 0);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.DateTime dateTime59 = instant57.toDateTime(chronology58);
        org.joda.time.DateTime dateTime61 = dateTime59.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime64 = dateTime59.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property65 = dateTime59.secondOfMinute();
        org.joda.time.LocalDate localDate66 = dateTime59.toLocalDate();
        int int67 = skipDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDate66);
        org.joda.time.Chronology chronology69 = null;
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField72 = gJChronology71.years();
        org.joda.time.DateTimeField dateTimeField73 = gJChronology71.dayOfYear();
        java.util.Locale locale74 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket76 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology71, locale74, (java.lang.Integer) 20);
        java.util.Locale locale77 = dateTimeParserBucket76.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology69, locale77, (java.lang.Integer) 1, 0);
        java.text.DateFormatSymbols dateFormatSymbols81 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale77);
        int int82 = skipDateTimeField48.getMaximumTextLength(locale77);
        java.lang.String str83 = offsetDateTimeField4.getAsShortText((-10), locale77);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "68" + "'", str34.equals("68"));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560344592765L + "'", long45 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str49.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 762970916L + "'", long52 == 762970916L);
        org.junit.Assert.assertNotNull(instant57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 999 + "'", int67 == 999);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(locale77);
        org.junit.Assert.assertNotNull(dateFormatSymbols81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "-10" + "'", str83.equals("-10"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        long long8 = dateTimeParserBucket6.computeMillis(true);
        long long11 = dateTimeParserBucket6.computeMillis(true, "857");
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292278993L) + "'", long8 == (-292278993L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-292278993L) + "'", long11 == (-292278993L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField3 = gJChronology2.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime8.getZone();
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone9);
        java.lang.String str11 = dateTimeZone9.getID();
        org.joda.time.Chronology chronology12 = gJChronology2.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 6);
        org.joda.time.Instant instant19 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.Instant instant22 = instant19.withDurationAdded(readableDuration20, 0);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = instant22.toDateTime(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime24.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property30 = dateTime24.secondOfMinute();
        org.joda.time.LocalDate localDate31 = dateTime24.toLocalDate();
        int int32 = offsetDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField38 = gJChronology37.years();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.dayOfYear();
        java.util.Locale locale40 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology37, locale40, (java.lang.Integer) 20);
        java.util.Locale locale43 = dateTimeParserBucket42.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology35, locale43, (java.lang.Integer) 1, 0);
        java.lang.String str47 = offsetDateTimeField17.getAsText(68, locale43);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket49 = new org.joda.time.format.DateTimeParserBucket(97L, (org.joda.time.Chronology) gJChronology2, locale43, (java.lang.Integer) 783);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        java.lang.Appendable appendable51 = null;
        try {
            dateTimeFormatter50.printTo(appendable51, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(locale43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "68" + "'", str47.equals("68"));
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test186");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        int int5 = property3.get();
//        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfCeiling();
//        org.joda.time.DurationField durationField8 = property3.getDurationField();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime6.secondOfMinute();
        boolean boolean13 = dateTime6.isEqual(0L);
        int int14 = dateTime6.getEra();
        org.joda.time.DateTime dateTime16 = dateTime6.minus((long) (short) -1);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMinutes(21806);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", 365, 1);
        int int10 = fixedDateTimeZone8.getOffsetFromLocal(1560344594181L);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "(\"org.joda.time.JodaTimePermission\" \"T060321.361-0700\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test190");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 31);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        boolean boolean17 = property15.isLeap();
//        org.joda.time.DurationField durationField18 = property15.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
//        long long22 = unsupportedDateTimeField19.add((long) 7, (long) 23);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60393600007L + "'", long22 == 60393600007L);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        java.lang.String str2 = dateTimeFormatter0.print(3120711009326L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Nov 21, 2068" + "'", str2.equals("Nov 21, 2068"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (long) 68, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = mutableDateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        long long12 = cachedDateTimeZone9.nextTransition((long) 16);
        long long16 = cachedDateTimeZone9.convertLocalToUTC((long) 21804658, false, 1560344606427L);
        long long20 = cachedDateTimeZone9.convertLocalToUTC((long) 21809251, true, (long) 20);
        java.lang.String str21 = cachedDateTimeZone9.getID();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 68L + "'", long4 == 68L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 16L + "'", long12 == 16L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21804658L + "'", long16 == 21804658L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 21809251L + "'", long20 == 21809251L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = iSOChronology0.equals(obj1);
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = iSOChronology0.get(readablePeriod4, 21802794L, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test194");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gJChronology1.years();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
//        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
//        long long15 = offsetDateTimeField11.add(21802794L, 1);
//        long long18 = offsetDateTimeField11.add(1560366408091L, 0);
//        long long21 = offsetDateTimeField11.add(1560344606222L, 70);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField25 = gJChronology24.years();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.dayOfYear();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology24, locale27, (java.lang.Integer) 20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = gregorianChronology30.weeks();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 6);
//        boolean boolean35 = dateTimeParserBucket29.restoreState((java.lang.Object) offsetDateTimeField34);
//        long long38 = offsetDateTimeField34.add(21802794L, 1);
//        int int39 = offsetDateTimeField34.getMaximumValue();
//        java.lang.Object obj41 = null;
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime(obj41);
//        long long43 = mutableDateTime42.getMillis();
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime42.dayOfWeek();
//        long long45 = property44.remainder();
//        long long46 = property44.remainder();
//        java.lang.Object obj47 = null;
//        org.joda.time.MutableDateTime mutableDateTime48 = new org.joda.time.MutableDateTime(obj47);
//        long long49 = mutableDateTime48.getMillis();
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime48.dayOfWeek();
//        long long51 = property50.remainder();
//        org.joda.time.MutableDateTime mutableDateTime52 = property50.roundHalfCeiling();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField55 = gJChronology54.years();
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology54.dayOfYear();
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology54, locale57, (java.lang.Integer) 20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField61 = gregorianChronology60.weeks();
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology60.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, 6);
//        boolean boolean65 = dateTimeParserBucket59.restoreState((java.lang.Object) offsetDateTimeField64);
//        long long68 = offsetDateTimeField64.add(21802794L, 1);
//        long long71 = offsetDateTimeField64.add(1560366408091L, 0);
//        int int73 = offsetDateTimeField64.getMaximumValue(21809800L);
//        long long75 = offsetDateTimeField64.roundHalfCeiling(26915155L);
//        org.joda.time.Chronology chronology78 = null;
//        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField81 = gJChronology80.years();
//        org.joda.time.DateTimeField dateTimeField82 = gJChronology80.dayOfYear();
//        java.util.Locale locale83 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket85 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology80, locale83, (java.lang.Integer) 20);
//        java.util.Locale locale86 = dateTimeParserBucket85.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket89 = new org.joda.time.format.DateTimeParserBucket(1560344606427L, chronology78, locale86, (java.lang.Integer) 1, 0);
//        java.lang.String str90 = offsetDateTimeField64.getAsShortText((int) '#', locale86);
//        java.lang.String str91 = property50.getAsShortText(locale86);
//        int int92 = property44.getMaximumTextLength(locale86);
//        java.lang.String str93 = offsetDateTimeField34.getAsText((int) (byte) 1, locale86);
//        java.lang.String str94 = offsetDateTimeField11.getAsShortText((long) (short) 10, locale86);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560366408091L + "'", long18 == 1560366408091L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1566392606222L + "'", long21 == 1566392606222L);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 108202794L + "'", long38 == 108202794L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 13 + "'", int39 == 13);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 108202794L + "'", long68 == 108202794L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560366408091L + "'", long71 == 1560366408091L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology80);
//        org.junit.Assert.assertNotNull(durationField81);
//        org.junit.Assert.assertNotNull(dateTimeField82);
//        org.junit.Assert.assertNotNull(locale86);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "35" + "'", str90.equals("35"));
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "Thu" + "'", str91.equals("Thu"));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 9 + "'", int92 == 9);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "1" + "'", str93.equals("1"));
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "10" + "'", str94.equals("10"));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.years();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.dayOfYear();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(21806404, 2, 13, 1970, (int) (short) 0, 2, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test196");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.yearOfEra();
//        java.lang.Object obj5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj5);
//        mutableDateTime6.addYears((int) (byte) 1);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime6);
//        mutableDateTime1.setChronology(chronology9);
//        mutableDateTime1.addMinutes((int) 'a');
//        java.lang.String str13 = mutableDateTime1.toString();
//        mutableDateTime1.setSecondOfMinute((int) '#');
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970-01-01T01:37:00.000Z" + "'", str13.equals("1970-01-01T01:37:00.000Z"));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 0, (int) (short) 0);
        boolean boolean9 = instant4.isEqual((long) 292278993);
        org.joda.time.DateTime dateTime10 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear(68);
        long long14 = dateTime13.getMillis();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5833941907L + "'", long14 == 5833941907L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        long long10 = dateTimeZone7.convertLocalToUTC(5833941907L, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 5833941907L + "'", long10 == 5833941907L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        java.lang.String str13 = skipDateTimeField12.toString();
        org.joda.time.DurationField durationField14 = skipDateTimeField12.getDurationField();
        long long16 = skipDateTimeField12.remainder(2440588L);
        org.joda.time.DurationField durationField17 = skipDateTimeField12.getDurationField();
        java.lang.String str19 = skipDateTimeField12.getAsText((long) 163);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str13.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "163" + "'", str19.equals("163"));
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test202");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 31);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        boolean boolean17 = property15.isLeap();
//        org.joda.time.DurationField durationField18 = property15.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
//        org.joda.time.DurationField durationField20 = unsupportedDateTimeField19.getDurationField();
//        boolean boolean21 = unsupportedDateTimeField19.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DurationField durationField13 = property12.getRangeDurationField();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology6);
        long long11 = gregorianChronology6.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology6.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField12, 19);
        java.lang.String str15 = skipDateTimeField14.toString();
        org.joda.time.DurationField durationField16 = skipDateTimeField14.getDurationField();
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant21 = instant18.withDurationAdded(readableDuration19, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = instant21.toDateTime(chronology22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeZone dateTimeZone26 = mutableDateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime(dateTimeZone26);
        org.joda.time.DateTime.Property property28 = dateTime23.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType29, 21797041, 4, 446);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime1.property(dateTimeFieldType29);
        org.joda.time.Instant instant36 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.Instant instant39 = instant36.withDurationAdded(readableDuration37, 0);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTime dateTime41 = instant39.toDateTime(chronology40);
        org.joda.time.DateTime dateTime43 = dateTime41.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime46 = dateTime41.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property47 = dateTime41.secondOfMinute();
        org.joda.time.LocalDate localDate48 = dateTime41.toLocalDate();
        org.joda.time.DateTime dateTime50 = dateTime41.plusHours(1439);
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560344592765L + "'", long11 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str15.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(instant39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(dateTime50);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfDay();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.years();
        long long4 = durationField1.subtract(1560344594181L, (long) (byte) 0);
        long long7 = durationField1.subtract(1560344594230L, (int) (byte) 0);
        long long10 = durationField1.subtract(1560344592817L, 21798701L);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField13 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType11, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344594181L + "'", long4 == 1560344594181L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560344594230L + "'", long7 == 1560344594230L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-687913093652207183L) + "'", long10 == (-687913093652207183L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfHour(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int49 = dividedDateTimeField48.getDivisor();
        int int50 = dividedDateTimeField48.getMaximumValue();
        long long52 = dividedDateTimeField48.remainder(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 18059 + "'", int49 == 18059);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfDay(100, 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("19", "1970-01-01T00:00:00.000Z", false, 59, 21806);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField8 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int8 = offsetDateTimeField4.getLeapAmount(1560344602184L);
        long long10 = offsetDateTimeField4.roundHalfCeiling(1560366407095L);
        long long12 = offsetDateTimeField4.roundHalfFloor((long) (short) 100);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        boolean boolean14 = offsetDateTimeField4.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        long long24 = gregorianChronology19.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField25, 19);
        java.lang.String str28 = skipDateTimeField27.toString();
        org.joda.time.DurationField durationField29 = skipDateTimeField27.getDurationField();
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime38.getZone();
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType42, 21797041, 4, 446);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 18059);
        int int50 = dividedDateTimeField48.get(35L);
        org.joda.time.DurationField durationField51 = dividedDateTimeField48.getRangeDurationField();
        try {
            long long53 = dividedDateTimeField48.roundFloor((-21792919L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [7,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560384000000L + "'", long10 == 1560384000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560344592765L + "'", long24 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str28.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(durationField51);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
        boolean boolean12 = dateTimeParserBucket6.restoreState((java.lang.Object) offsetDateTimeField11);
        long long15 = offsetDateTimeField11.add(21802794L, 1);
        long long18 = offsetDateTimeField11.add(1560366408091L, 0);
        long long20 = offsetDateTimeField11.roundHalfEven(475002278834720L);
        org.joda.time.DurationField durationField21 = offsetDateTimeField11.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 108202794L + "'", long15 == 108202794L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560366408091L + "'", long18 == 1560366408091L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 475002316800000L + "'", long20 == 475002316800000L);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfDay();
        int int10 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime6.minusMinutes(21797041);
        int int13 = dateTime12.getMinuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.withPeriodAdded(readablePeriod14, 1976);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = null;
        java.lang.String str18 = dateTime16.toString(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1928-07-23T03:59:00.097Z" + "'", str18.equals("1928-07-23T03:59:00.097Z"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 19);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField12.getWrappedField();
        long long16 = skipDateTimeField12.add(1560366407535L, 1560344601791L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField12.getAsShortText(762970915, locale18);
        org.joda.time.DurationField durationField20 = skipDateTimeField12.getDurationField();
        long long22 = skipDateTimeField12.remainder((long) 25200);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344592765L + "'", long9 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3120711009326L + "'", long16 == 3120711009326L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "762970915" + "'", str19.equals("762970915"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        org.joda.time.Chronology chronology3 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test218");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 31);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        java.lang.Object obj11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj11);
//        long long13 = mutableDateTime12.getMillis();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        boolean boolean17 = property15.isLeap();
//        org.joda.time.DurationField durationField18 = property15.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
//        org.joda.time.DurationField durationField20 = unsupportedDateTimeField19.getDurationField();
//        try {
//            long long23 = unsupportedDateTimeField19.addWrapField(1560344598701L, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test219");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.getMutableDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.weeks();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 6);
//        int int13 = offsetDateTimeField11.getLeapAmount(1560344602794L);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField11.getMaximumTextLength(locale14);
//        mutableDateTime6.setRounding((org.joda.time.DateTimeField) offsetDateTimeField11);
//        java.lang.String str17 = offsetDateTimeField11.toString();
//        boolean boolean18 = offsetDateTimeField11.isSupported();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str17.equals("DateTimeField[dayOfWeek]"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear(762970915);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        int int6 = offsetDateTimeField4.getLeapAmount(1560344602794L);
        int int9 = offsetDateTimeField4.getDifference(1560344604809L, (long) 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 6);
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = instant19.toDateTime(chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.withWeekyear((int) (short) 100);
        org.joda.time.DateTime dateTime26 = dateTime21.withDurationAdded(21794181L, (int) (byte) 10);
        org.joda.time.DateTime.Property property27 = dateTime21.secondOfMinute();
        org.joda.time.LocalDate localDate28 = dateTime21.toLocalDate();
        int int29 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        int int30 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18059 + "'", int9 == 18059);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(960, 960, 0, 163, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.joda.time.Instant instant2 = new org.joda.time.Instant(1560344597041L);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronolgy();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant4, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(35L, chronology10);
        mutableDateTime11.setYear(18059);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNull(chronology8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology0.add(readablePeriod5, (long) 10, 9);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime14 = dateTime7.withYear(2);
        org.joda.time.DateTime dateTime16 = dateTime7.withYearOfCentury(13);
        org.joda.time.DateTime dateTime18 = dateTime7.plusDays(277);
        org.joda.time.DateTime dateTime20 = dateTime18.plus((long) 356);
        org.joda.time.DateTime dateTime22 = dateTime18.withWeekOfWeekyear(3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 6);
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText((long) 20, locale6);
        boolean boolean9 = offsetDateTimeField4.isLeap(0L);
        long long11 = offsetDateTimeField4.roundCeiling(21798203L);
        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) 'a');
        org.joda.time.Instant instant15 = instant13.withMillis((long) '#');
        org.joda.time.DateTime dateTime16 = instant13.toDateTimeISO();
        int int17 = dateTime16.getCenturyOfEra();
        org.joda.time.DateMidnight dateMidnight18 = dateTime16.toDateMidnight();
        org.joda.time.LocalDate localDate19 = dateTime16.toLocalDate();
        int int20 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate19);
        int int21 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86400000L + "'", long11 == 86400000L);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test227");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.getMutableDateTime();
//        int int7 = property3.getLeapAmount();
//        boolean boolean8 = property3.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime9 = property3.roundHalfEven();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 0);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = instant4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime6.year();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withEra((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = mutableDateTime1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        int int6 = cachedDateTimeZone4.getOffset((long) 5);
        long long9 = cachedDateTimeZone4.adjustOffset(21803175L, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 21803175L + "'", long9 == 21803175L);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test231");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime1.toMutableDateTime(chronology2);
//        mutableDateTime1.setMillis(21794831L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology6);
//        boolean boolean8 = mutableDateTime1.equals((java.lang.Object) mutableDateTime7);
//        int int9 = mutableDateTime7.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.dayOfYear();
//        int int11 = mutableDateTime7.getDayOfWeek();
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test232");
//        java.lang.Object obj0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
//        long long2 = mutableDateTime1.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.dayOfWeek();
//        long long4 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundHalfCeiling();
//        java.util.Locale locale6 = null;
//        int int7 = property3.getMaximumTextLength(locale6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        boolean boolean9 = property3.equals((java.lang.Object) dateTimeFormatter8);
//        java.lang.Class<?> wildcardClass10 = dateTimeFormatter8.getClass();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 21);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeFormatter12.getZone();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNull(dateTimeZone13);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Wed");
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(20, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendClockhourOfDay(97);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfYear();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((-292278993L), (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) 20);
        long long8 = dateTimeParserBucket6.computeMillis(true);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology13);
        long long18 = gregorianChronology13.add(1560344592817L, (long) (byte) -1, (int) '4');
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField19, 19);
        org.joda.time.DurationField durationField22 = skipDateTimeField21.getDurationField();
        boolean boolean23 = dateTimeParserBucket6.restoreState((java.lang.Object) skipDateTimeField21);
        long long25 = dateTimeParserBucket6.computeMillis(false);
        java.util.Locale locale26 = dateTimeParserBucket6.getLocale();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.centuryOfEra();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime34 = dateTime31.toDateTime(dateTimeZone33);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology35.getZone();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.dayOfWeek();
        org.joda.time.DateTime dateTime39 = dateTime34.toDateTime((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTime dateTime41 = dateTime34.withYear(2);
        org.joda.time.DateTime dateTime43 = dateTime34.withYearOfCentury(13);
        org.joda.time.DateTime dateTime45 = dateTime34.plusDays(277);
        boolean boolean46 = dateTimeParserBucket6.restoreState((java.lang.Object) dateTime45);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292278993L) + "'", long8 == (-292278993L));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560344592765L + "'", long18 == 1560344592765L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-292278993L) + "'", long25 == (-292278993L));
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test235");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfDay();
//        java.lang.String str6 = gregorianChronology0.toString();
//        java.lang.Object obj7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj7);
//        long long9 = mutableDateTime8.getMillis();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (-10));
//        int int16 = offsetDateTimeField14.getLeapAmount(999L);
//        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.Instant instant20 = instant18.withMillis((long) '#');
//        org.joda.time.DateTime dateTime21 = instant18.toDateTimeISO();
//        int int22 = dateTime21.getCenturyOfEra();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime21.toDateMidnight();
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.util.Set<java.lang.String> strSet27 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean28 = iSOChronology26.equals((java.lang.Object) strSet27);
//        org.joda.time.DurationField durationField29 = iSOChronology26.minutes();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.Instant instant34 = instant31.withDurationAdded(readableDuration32, 0);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.DateTime dateTime36 = instant34.toDateTime(chronology35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime41 = dateTime36.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property42 = dateTime36.secondOfMinute();
//        org.joda.time.LocalDate localDate43 = dateTime36.toLocalDate();
//        int[] intArray45 = iSOChronology26.get((org.joda.time.ReadablePartial) localDate43, 21802794L);
//        int[] intArray47 = offsetDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localDate24, 0, intArray45, (int) (short) 10);
//        java.lang.Object obj48 = null;
//        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime(obj48);
//        long long50 = mutableDateTime49.getMillis();
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime49.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime49.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (-10));
//        int int57 = offsetDateTimeField55.getLeapAmount(999L);
//        org.joda.time.Instant instant59 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.Instant instant61 = instant59.withMillis((long) '#');
//        org.joda.time.DateTime dateTime62 = instant59.toDateTimeISO();
//        int int63 = dateTime62.getCenturyOfEra();
//        org.joda.time.DateMidnight dateMidnight64 = dateTime62.toDateMidnight();
//        org.joda.time.LocalDate localDate65 = dateTime62.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.util.Set<java.lang.String> strSet68 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean69 = iSOChronology67.equals((java.lang.Object) strSet68);
//        org.joda.time.DurationField durationField70 = iSOChronology67.minutes();
//        org.joda.time.Instant instant72 = new org.joda.time.Instant((long) 'a');
//        org.joda.time.ReadableDuration readableDuration73 = null;
//        org.joda.time.Instant instant75 = instant72.withDurationAdded(readableDuration73, 0);
//        org.joda.time.Chronology chronology76 = null;
//        org.joda.time.DateTime dateTime77 = instant75.toDateTime(chronology76);
//        org.joda.time.DateTime dateTime79 = dateTime77.withWeekyear((int) (short) 100);
//        org.joda.time.DateTime dateTime82 = dateTime77.withDurationAdded(21794181L, (int) (byte) 10);
//        org.joda.time.DateTime.Property property83 = dateTime77.secondOfMinute();
//        org.joda.time.LocalDate localDate84 = dateTime77.toLocalDate();
//        int[] intArray86 = iSOChronology67.get((org.joda.time.ReadablePartial) localDate84, 21802794L);
//        int[] intArray88 = offsetDateTimeField55.addWrapPartial((org.joda.time.ReadablePartial) localDate65, 0, intArray86, (int) (short) 10);
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate24, intArray86);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(strSet27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(instant34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(instant61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 19 + "'", int63 == 19);
//        org.junit.Assert.assertNotNull(dateMidnight64);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(strSet68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(instant75);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(localDate84);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertNotNull(intArray88);
//    }
//}

