import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime2 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("117", "2019-06-15T21:45:44.913", (-292275054), 23);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime2.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(10L);
        int int14 = property11.getMinimumValueOverall();
        int int15 = property11.getLeapAmount();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) (-1.0f), (java.lang.Number) 24, (java.lang.Number) 292278993);
        java.lang.Number number21 = illegalFieldValueException20.getUpperBound();
        java.lang.String str22 = illegalFieldValueException20.getIllegalValueAsString();
        java.lang.Number number23 = illegalFieldValueException20.getIllegalNumberValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = illegalFieldValueException20.getDateTimeFieldType();
        int int25 = mutableDateTime8.get(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 292278993 + "'", number21.equals(292278993));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1.0" + "'", str22.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0f) + "'", number23.equals((-1.0f)));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekyear", 0, (int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfMinute();
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfCentury((int) '#', (int) '#');
        dateTimeFormatterBuilder12.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendWeekyear(0, (int) (short) 1);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = property22.addToCopy(10L);
        int int25 = property22.getMinimumValueOverall();
        int int26 = property22.getLeapAmount();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder19.appendSignedDecimal(dateTimeFieldType27, 10, 15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType27, (int) (byte) 100);
        int int33 = offsetDateTimeField32.getMinimumValue();
        long long35 = offsetDateTimeField32.remainder(0L);
        try {
            long long38 = offsetDateTimeField32.add(14420733781L, (-85425858462140605L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -85425858462140605 * 1000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.DurationField durationField4 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.monthOfYear();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("weekyear", "weekyear", (int) (short) 100, (int) (byte) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long18 = zonedChronology14.add(1000L, (long) 70, 0);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime20.toDateTime(dateTimeZone23);
        org.joda.time.Chronology chronology26 = zonedChronology14.withZone(dateTimeZone23);
        java.lang.String str27 = dateTimeZone23.toString();
        org.joda.time.Chronology chronology28 = iSOChronology0.withZone(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1000L + "'", long18 == 1000L);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(chronology28);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
//        boolean boolean3 = property2.isLeap();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
//        int int7 = dateTime5.getCenturyOfEra();
//        boolean boolean8 = dateTime5.isEqualNow();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime5.toLocalDateTime();
//        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime9);
//        org.joda.time.DateTime dateTime12 = property2.addToCopy(134);
//        int int13 = property2.getMaximumValue();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278993 + "'", int13 == 292278993);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str8 = jodaTimePermission3.toString();
        java.security.PermissionCollection permissionCollection9 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(permissionCollection9);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        int int3 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) '4');
        int int7 = dateTime6.getYearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime6.minusWeeks((int) (short) -1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime12 = dateTime6.withMillis(0L);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.joda.time.DateTime dateTime17 = property15.addToCopy(10L);
        java.lang.String str18 = property15.getName();
        int int19 = property15.getMinimumValue();
        org.joda.time.DateTime dateTime20 = property15.roundHalfFloorCopy();
        java.lang.String str21 = property15.getAsText();
        org.joda.time.DateTime dateTime22 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks(10);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime dateTime27 = dateTime24.minusMillis(24);
        org.joda.time.DateTime dateTime29 = dateTime24.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime24.toYearMonthDay();
        org.joda.time.DateTime dateTime31 = dateTime12.withFields((org.joda.time.ReadablePartial) yearMonthDay30);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "weekyear" + "'", str18.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-292275054) + "'", int19 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(10L);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours(292336593);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "20190615T214523", "ISOChronology[]");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone11);
        java.lang.String str13 = dateTimeZone11.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        java.util.Locale locale17 = null;
        java.util.Calendar calendar18 = dateTime16.toCalendar(locale17);
        boolean boolean20 = dateTime16.isEqual((long) (byte) 0);
        boolean boolean21 = cachedDateTimeZone14.equals((java.lang.Object) boolean20);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone14.getUncachedZone();
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("weekyear", "weekyear", (int) (short) 100, (int) (byte) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance(chronology24, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
        java.lang.String str32 = fixedDateTimeZone29.getShortName((long) (byte) 100);
        long long34 = cachedDateTimeZone14.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone29, (long) (short) 10);
        int int36 = cachedDateTimeZone14.getOffset(10L);
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(1357, 27, 20, 2029, 4, 78393, 2000, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2029 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(calendar18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00:00.100" + "'", str32.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-90L) + "'", long34 == (-90L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, 100);
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.plusYears((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        int int4 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((-1));
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "hi!", 52);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        boolean boolean21 = cachedDateTimeZone18.equals((java.lang.Object) timeZone19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
        long long28 = gregorianChronology23.add((long) 17, (long) 292278993, (-292275054));
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(chronology29);
        org.joda.time.DateTime.Property property31 = dateTime30.weekyear();
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZoneRetainFields(dateTimeZone33);
        java.lang.String str35 = dateTimeZone33.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
        java.util.Locale locale39 = null;
        java.util.Calendar calendar40 = dateTime38.toCalendar(locale39);
        boolean boolean42 = dateTime38.isEqual((long) (byte) 0);
        boolean boolean43 = cachedDateTimeZone36.equals((java.lang.Object) boolean42);
        org.joda.time.DateTimeZone dateTimeZone44 = cachedDateTimeZone36.getUncachedZone();
        org.joda.time.ReadableInterval readableInterval45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("weekyear", "weekyear", (int) (short) 100, (int) (byte) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance(chronology46, (org.joda.time.DateTimeZone) fixedDateTimeZone51);
        java.lang.String str54 = fixedDateTimeZone51.getShortName((long) (byte) 100);
        long long56 = cachedDateTimeZone36.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone51, (long) (short) 10);
        org.joda.time.Chronology chronology57 = gregorianChronology23.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        long long59 = cachedDateTimeZone18.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone51, 35L);
        boolean boolean61 = cachedDateTimeZone18.isStandardOffset((long) 1305);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-53) + "'", int10 == (-53));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-85425858462140605L) + "'", long28 == (-85425858462140605L));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertNotNull(calendar40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(zonedChronology52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "+00:00:00.100" + "'", str54.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-90L) + "'", long56 == (-90L));
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-65L) + "'", long59 == (-65L));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(10L);
        java.lang.String str5 = property2.getName();
        int int6 = property2.getMinimumValue();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        java.lang.String str8 = property2.getAsText();
        org.joda.time.DateTime dateTime9 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(10);
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "weekyear" + "'", str5.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 0, 3657);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test16");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "weekyear", 0, (int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfMinute();
//        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfDay((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfCentury((int) '#', (int) '#');
//        dateTimeFormatterBuilder12.clear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendWeekyear(0, (int) (short) 1);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
//        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
//        org.joda.time.DateTime dateTime24 = property22.addToCopy(10L);
//        int int25 = property22.getMinimumValueOverall();
//        int int26 = property22.getLeapAmount();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder19.appendSignedDecimal(dateTimeFieldType27, 10, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType27, (int) (byte) 100);
//        int int35 = offsetDateTimeField32.getDifference(0L, (long) 57600);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        int int40 = dateTime38.getCenturyOfEra();
//        boolean boolean41 = dateTime38.isEqualNow();
//        org.joda.time.LocalDateTime localDateTime42 = dateTime38.toLocalDateTime();
//        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime42);
//        java.lang.String str44 = dateTimeFormatter36.print((org.joda.time.ReadablePartial) localDateTime42);
//        int[] intArray48 = new int[] { '4', 2000, 78316 };
//        int int49 = offsetDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) localDateTime42, intArray48);
//        long long51 = offsetDateTimeField32.roundHalfEven((-85425858462140605L));
//        java.lang.String str53 = offsetDateTimeField32.getAsText((long) '#');
//        int int55 = offsetDateTimeField32.getLeapAmount(1560635117542L);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-57) + "'", int35 == (-57));
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 20 + "'", int40 == 20);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "20190615T214643" + "'", str44.equals("20190615T214643"));
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-85425858462141000L) + "'", long51 == (-85425858462141000L));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "100" + "'", str53.equals("100"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (byte) 0, (long) (short) 100, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology0.minutes();
        long long9 = durationField6.subtract((long) 1306, 78316);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10000L + "'", long4 == 10000L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4698958694L) + "'", long9 == (-4698958694L));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(10L);
        java.lang.String str7 = property4.getName();
        int int8 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
        java.lang.String str10 = property4.getAsText();
        org.joda.time.DateTime dateTime11 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(10);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime16 = dateTime13.minusMillis(24);
        org.joda.time.DateTime dateTime18 = dateTime13.minusHours(24);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        java.lang.String str20 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "weekyear" + "'", str7.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����-��-��T00:00:00.000" + "'", str20.equals("����-��-��T00:00:00.000"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        int int3 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) '4');
        int int7 = dateTime6.getYearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime6.minusWeeks((int) (short) -1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime6.withDurationAdded((long) (-292275054), (int) (short) 100);
        org.joda.time.Instant instant15 = dateTime14.toInstant();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(instant15);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        int int3 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) '4');
        int int7 = dateTime6.getYearOfCentury();
        org.joda.time.DateTime dateTime9 = dateTime6.minusWeeks((int) (short) -1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime6.withDurationAdded((long) (-292275054), (int) (short) 100);
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded((-85425858462140605L), (int) (short) 10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("secondOfDay", 10, 20, (-1), '#', (int) (short) -1, 0, (int) '#', false, (-1));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder14.setStandardOffset(2018);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder16.addRecurringSavings("118", 1306, 0, 78393, '#', (int) (short) -1, (int) (byte) 100, 0, true, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        int int4 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.toDateTimeISO();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime8 = dateTime2.withYearOfEra(19);
        org.joda.time.DateTime dateTime10 = dateTime2.minusHours((int) (short) 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(10L);
        java.lang.String str7 = property4.getName();
        int int8 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
        java.lang.String str10 = property4.getAsText();
        org.joda.time.DateTime dateTime11 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(10);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime16 = dateTime13.minusMillis(24);
        org.joda.time.DateTime dateTime18 = dateTime13.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime13.toYearMonthDay();
        int[] intArray21 = gregorianChronology0.get((org.joda.time.ReadablePartial) yearMonthDay19, (long) (-1305));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "weekyear" + "'", str7.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(intArray21);
    }
}

