import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 100, (int) (short) 10, (int) (short) 100, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10L, (java.lang.Number) 1L, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        try {
            long long8 = gJChronology2.getDateTimeMillis(0L, (int) (byte) 0, (int) (byte) 1, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1), (-1), (int) (short) 10, (int) (short) 0, (-1), (int) (short) -1, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withFieldAdded(durationFieldType1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, 0, (int) '#', (int) '#', (int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.withYearOfCentury((int) 'a');
        boolean boolean7 = localDate3.equals((java.lang.Object) (short) -1);
        java.lang.Object obj8 = null;
        boolean boolean9 = localDate3.equals(obj8);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2019, (int) (short) 10, 0, (int) (short) 100, 1, (int) (byte) 100, (int) (short) -1, (org.joda.time.Chronology) gJChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withMonthOfYear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        long long5 = property4.remainder();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime0.withField(dateTimeFieldType8, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        try {
            java.lang.String str5 = localDate1.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000035d + "'", double1 == 2440587.500000035d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime3 = property1.setCopy((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, (int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withZoneRetainFields(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) yearMonthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DurationField durationField10 = gJChronology8.months();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (byte) 100, (int) (short) -1, 100, (int) (short) -1, (int) (byte) 100, (int) 'a', (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(100);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray3 = new int[] { 10, 0 };
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology9);
        try {
            org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray3, (org.joda.time.Chronology) gJChronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.yearOfCentury();
        java.lang.Class<?> wildcardClass6 = dateTimeField5.getClass();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gJChronology5);
        try {
            long long16 = gJChronology5.getDateTimeMillis((int) 'a', (int) ' ', 1, 100, 2019, (int) (byte) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.Partial partial3 = new org.joda.time.Partial(dateTimeFieldType0, 0, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) 0L, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (byte) 10, (long) 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField8 = gJChronology6.months();
        org.joda.time.DurationField durationField9 = gJChronology6.hours();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology6.getZone();
        org.joda.time.DurationField durationField11 = gJChronology6.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField12 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        int int7 = dateTime6.getDayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime6.withDayOfWeek((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DurationField durationField4 = gJChronology2.weeks();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gJChronology2.get(readablePeriod5, (long) '4', (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.util.Locale locale13 = null;
        try {
            long long14 = skipUndoDateTimeField8.set((long) ' ', "hi!", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DurationField durationField4 = gJChronology2.weeks();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gJChronology2.get(readablePeriod5, (long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withHourOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PST", number1, (java.lang.Number) 1L, (java.lang.Number) 10.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) ' ', (-1), 0, (int) 'a', 100, (-1), (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime28 = dateTime27.withTimeAtStartOfDay();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) dateTime28, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(999, 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        int int5 = dateTime4.getEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.secondOfDay();
        java.lang.String str8 = gJChronology2.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str8.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = dateTime5.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale67 = null;
//        int int68 = skipUndoDateTimeField8.getMaximumTextLength(locale67);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate(dateTimeZone69);
//        org.joda.time.LocalDate localDate72 = localDate70.withYearOfCentury((int) 'a');
//        boolean boolean74 = localDate70.equals((java.lang.Object) (short) -1);
//        java.lang.Object obj75 = null;
//        boolean boolean76 = localDate70.equals(obj75);
//        org.joda.time.LocalDate localDate78 = localDate70.minusDays(0);
//        java.util.Locale locale79 = null;
//        try {
//            java.lang.String str80 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate70, locale79);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(localDate78);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DurationField durationField8 = property6.getDurationField();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DurationField durationField5 = gJChronology4.centuries();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) 5, 0);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate1.withWeekyear((int) '#');
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate22);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        java.io.Writer writer9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withZoneRetainFields(dateTimeZone11);
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer9, (org.joda.time.ReadablePartial) yearMonthDay17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withFieldAdded(durationFieldType3, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        org.joda.time.DurationField durationField52 = gJChronology48.weekyears();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(durationField52);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 20, locale13);
        org.joda.time.DurationField durationField15 = skipUndoDateTimeField8.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        int int9 = property8.getMinimumValueOverall();
        boolean boolean10 = property8.isLeap();
        java.lang.String str11 = property8.toString();
        org.joda.time.DateTime dateTime12 = property8.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 0, 9, 9, (int) (byte) 1, (int) (byte) 100, 9, 3, dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[secondOfMinute]" + "'", str11.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PST");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        int int3 = property1.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) -1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        try {
//            long long59 = copticChronology11.getDateTimeMillis((int) (short) -1, (int) (short) 100, 9, (int) (byte) 1, 10, (int) (byte) 1, 6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate.Property property5 = localDate1.dayOfYear();
        org.joda.time.ReadableInstant readableInstant6 = null;
        try {
            int int7 = property5.compareTo(readableInstant6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 10, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-90L) + "'", long2 == (-90L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        org.joda.time.DateTime dateTime5 = property1.withMinimumValue();
        java.util.Locale locale6 = null;
        int int7 = property1.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate.Property property7 = localDate1.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        try {
            java.lang.String str11 = localDate9.toString("Property[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.withWeekyear(999);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(dateTime3);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1L), (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        org.joda.time.DateTime dateTime5 = property1.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfWeek(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZoneRetainFields(dateTimeZone5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        boolean boolean8 = yearMonthDay3.isEqual((org.joda.time.ReadablePartial) yearMonthDay7);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType10 = yearMonthDay3.getFieldType(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-61828157222000L), (long) 86399999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61828070822001L) + "'", long2 == (-61828070822001L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        try {
            org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) gJChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.LocalDateTime localDateTime33 = null;
//        try {
//            boolean boolean34 = dateTimeZone26.isLocalDateTimeGap(localDateTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        java.io.Writer writer9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
        int int12 = property11.getMinimumValueOverall();
        boolean boolean13 = property11.isLeap();
        java.lang.String str14 = property11.toString();
        org.joda.time.DateTime dateTime15 = property11.getDateTime();
        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
        try {
            dateTimeFormatter8.printTo(writer9, (org.joda.time.ReadableInstant) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfMinute]" + "'", str14.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(699L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        boolean boolean7 = dateTime4.isBefore((long) (byte) 1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) ' ', (int) '#', 3, 24, 20, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField8, 100);
//        int int12 = skipUndoDateTimeField10.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone13);
//        org.joda.time.LocalDate localDate16 = localDate14.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
//        org.joda.time.LocalDate localDate21 = localDate19.withYearOfCentury((int) 'a');
//        boolean boolean22 = localDate14.isBefore((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone23);
//        org.joda.time.LocalDate localDate26 = localDate24.withYearOfCentury((int) 'a');
//        boolean boolean28 = localDate24.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval30 = localDate24.toInterval(dateTimeZone29);
//        java.lang.String str32 = dateTimeZone29.getShortName((long) 'a');
//        org.joda.time.Interval interval33 = localDate14.toInterval(dateTimeZone29);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DurationField durationField40 = gJChronology39.centuries();
//        boolean boolean41 = dateTime34.equals((java.lang.Object) gJChronology39);
//        java.util.Locale locale42 = null;
//        java.util.Calendar calendar43 = dateTime34.toCalendar(locale42);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(dateTimeZone44);
//        org.joda.time.LocalDate localDate47 = localDate45.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property48 = localDate45.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone49);
//        org.joda.time.LocalDate localDate52 = localDate50.withYearOfCentury((int) 'a');
//        boolean boolean53 = localDate45.isBefore((org.joda.time.ReadablePartial) localDate52);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(dateTimeZone54);
//        org.joda.time.LocalDate localDate57 = localDate55.withYearOfCentury((int) 'a');
//        boolean boolean59 = localDate55.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval61 = localDate55.toInterval(dateTimeZone60);
//        java.lang.String str63 = dateTimeZone60.getShortName((long) 'a');
//        org.joda.time.Interval interval64 = localDate45.toInterval(dateTimeZone60);
//        org.joda.time.LocalDate localDate65 = org.joda.time.LocalDate.now(dateTimeZone60);
//        org.joda.time.DateTime dateTime66 = dateTime34.toDateTime(dateTimeZone60);
//        org.joda.time.DateTime dateTime67 = localDate14.toDateTimeAtStartOfDay(dateTimeZone60);
//        int int68 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate14);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PST" + "'", str32.equals("PST"));
//        org.junit.Assert.assertNotNull(interval33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(calendar43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(interval61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "PST" + "'", str63.equals("PST"));
//        org.junit.Assert.assertNotNull(interval64);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
        org.joda.time.LocalDate.Property property16 = localDate12.dayOfYear();
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate12, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        long long68 = skipUndoDateTimeField8.roundCeiling(0L);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate(dateTimeZone69);
//        org.joda.time.LocalDate localDate72 = localDate70.withYearOfCentury((int) 'a');
//        int[] intArray74 = null;
//        try {
//            int[] intArray76 = skipUndoDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate72, 10, intArray74, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(localDate72);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths(24);
        boolean boolean15 = dateTime11.isAfter((-61828157222000L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.minusWeeks(999);
        org.joda.time.LocalTime localTime7 = null;
        try {
            org.joda.time.LocalDateTime localDateTime8 = localDate6.toLocalDateTime(localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        try {
            org.joda.time.LocalDate localDate6 = property4.setCopy((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTime dateTime8 = instant7.toDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        int int7 = property6.getMaximumValue();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("14");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"14\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.millis();
        try {
            long long10 = gJChronology2.getDateTimeMillis((int) (byte) 10, 2, (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        boolean boolean6 = property4.equals((java.lang.Object) 0L);
        try {
            org.joda.time.LocalDate localDate8 = property4.setCopy(20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
//        org.joda.time.DurationField durationField13 = gJChronology12.centuries();
//        boolean boolean14 = dateTime7.equals((java.lang.Object) gJChronology12);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.Chronology chronology20 = gJChronology12.withZone(dateTimeZone16);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(3, 1, (-1), (-101), 1970, 97, 5, dateTimeZone16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -101 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology20);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(3, 24, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 1970, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("14", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"14\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        long long7 = durationField4.subtract((long) ' ', (long) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-26438399968L) + "'", long7 == (-26438399968L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        long long6 = durationField3.subtract((long) 1, 0L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 3, 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        java.util.Date date24 = localDate21.toDate();
//        java.util.Locale locale26 = null;
//        try {
//            java.lang.String str27 = localDate21.toString("PST", locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(date24);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        try {
            org.joda.time.LocalDate localDate8 = localDate6.withEra(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        java.lang.String str13 = property12.getName();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "weekOfWeekyear" + "'", str13.equals("weekOfWeekyear"));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = localDate1.equals(obj6);
//        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        boolean boolean13 = property11.equals((java.lang.Object) dateTimeFormatter12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate17 = localDate15.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate15.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval21 = localDate15.toInterval(dateTimeZone20);
//        java.lang.String str23 = dateTimeZone20.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, 3);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
//        org.joda.time.DurationField durationField32 = gJChronology31.centuries();
//        boolean boolean33 = dateTime26.equals((java.lang.Object) gJChronology31);
//        java.util.Locale locale34 = null;
//        java.util.Calendar calendar35 = dateTime26.toCalendar(locale34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property40 = localDate37.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean45 = localDate37.isBefore((org.joda.time.ReadablePartial) localDate44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
//        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate47.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval53 = localDate47.toInterval(dateTimeZone52);
//        java.lang.String str55 = dateTimeZone52.getShortName((long) 'a');
//        org.joda.time.Interval interval56 = localDate37.toInterval(dateTimeZone52);
//        org.joda.time.LocalDate localDate57 = org.joda.time.LocalDate.now(dateTimeZone52);
//        org.joda.time.DateTime dateTime58 = dateTime26.toDateTime(dateTimeZone52);
//        org.joda.time.Chronology chronology59 = copticChronology25.withZone(dateTimeZone52);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.ReadableInstant readableInstant61 = null;
//        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, readableInstant61);
//        org.joda.time.DateTimeField dateTimeField63 = gJChronology62.hourOfHalfday();
//        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology62);
//        boolean boolean65 = copticChronology25.equals((java.lang.Object) gJChronology62);
//        org.joda.time.DateTimeZone dateTimeZone66 = gJChronology62.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = dateTimeFormatter12.withZone(dateTimeZone66);
//        java.lang.String str68 = localDate1.toString(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(calendar35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PST" + "'", str55.equals("PST"));
//        org.junit.Assert.assertNotNull(interval56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(gJChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019-166T��:��:��" + "'", str68.equals("2019-166T��:��:��"));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology2.getZone();
        org.joda.time.DurationField durationField7 = gJChronology2.minutes();
        long long10 = durationField7.subtract((long) 999, (long) 5);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-299001L) + "'", long10 == (-299001L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gJChronology2.get(readablePeriod5, (-61967603212991L), 945060L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(699L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69900L + "'", long2 == 69900L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        java.lang.String str7 = property6.getAsString();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "57600003" + "'", str7.equals("57600003"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.Partial partial3 = partial0.with(dateTimeFieldType1, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((-61828070822001L), locale6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-07:52:58" + "'", str7.equals("-07:52:58"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-07:52:58", (java.lang.Number) (-26438399968L), (java.lang.Number) 100L, number3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZoneRetainFields(dateTimeZone4);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfMonth();
        int int10 = property9.getMaximumValueOverall();
        boolean boolean11 = dateTime2.equals((java.lang.Object) property9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("20", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"20/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1045, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1036L + "'", long2 == 1036L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        try {
//            org.joda.time.DateTime dateTime56 = dateTime54.withSecondOfMinute((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate9.era();
        try {
            org.joda.time.LocalDate localDate14 = property12.addToCopy((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        java.lang.String str47 = dateTimeZone38.getName((long) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.ReadableInstant readableInstant49 = null;
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, readableInstant49);
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DurationField durationField52 = gJChronology50.months();
//        org.joda.time.DurationField durationField53 = gJChronology50.hours();
//        org.joda.time.Chronology chronology54 = gJChronology50.withUTC();
//        org.joda.time.Instant instant55 = gJChronology50.getGregorianCutover();
//        org.joda.time.MutableDateTime mutableDateTime56 = instant55.toMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime57 = instant55.toMutableDateTimeISO();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) instant55, 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 59");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Pacific Standard Time" + "'", str47.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertNotNull(instant55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        int int4 = property1.getDifference(readableInstant3);
//        org.joda.time.Interval interval5 = property1.toInterval();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
//        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField12, 100);
//        int int16 = skipUndoDateTimeField14.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone17);
//        org.joda.time.LocalDate localDate20 = localDate18.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property21 = localDate18.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate18.isBefore((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean32 = localDate28.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval34 = localDate28.toInterval(dateTimeZone33);
//        java.lang.String str36 = dateTimeZone33.getShortName((long) 'a');
//        org.joda.time.Interval interval37 = localDate18.toInterval(dateTimeZone33);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.withZoneRetainFields(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
//        org.joda.time.DurationField durationField44 = gJChronology43.centuries();
//        boolean boolean45 = dateTime38.equals((java.lang.Object) gJChronology43);
//        java.util.Locale locale46 = null;
//        java.util.Calendar calendar47 = dateTime38.toCalendar(locale46);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(dateTimeZone48);
//        org.joda.time.LocalDate localDate51 = localDate49.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property52 = localDate49.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone53);
//        org.joda.time.LocalDate localDate56 = localDate54.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate49.isBefore((org.joda.time.ReadablePartial) localDate56);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(dateTimeZone58);
//        org.joda.time.LocalDate localDate61 = localDate59.withYearOfCentury((int) 'a');
//        boolean boolean63 = localDate59.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval65 = localDate59.toInterval(dateTimeZone64);
//        java.lang.String str67 = dateTimeZone64.getShortName((long) 'a');
//        org.joda.time.Interval interval68 = localDate49.toInterval(dateTimeZone64);
//        org.joda.time.LocalDate localDate69 = org.joda.time.LocalDate.now(dateTimeZone64);
//        org.joda.time.DateTime dateTime70 = dateTime38.toDateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = localDate18.toDateTimeAtStartOfDay(dateTimeZone64);
//        int int72 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate18);
//        try {
//            int int73 = property1.compareTo((org.joda.time.ReadablePartial) localDate18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(interval5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(interval34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PST" + "'", str36.equals("PST"));
//        org.junit.Assert.assertNotNull(interval37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(calendar47);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(interval65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "PST" + "'", str67.equals("PST"));
//        org.junit.Assert.assertNotNull(interval68);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        org.joda.time.DateTimeZone dateTimeZone52 = gJChronology48.getZone();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        try {
//            int[] intArray56 = gJChronology48.get(readablePeriod53, (long) 3, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 946);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-07:52:58/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@53d9f80");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Pacific Standard Time", (int) (short) 1, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for Pacific Standard Time must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
//        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
//        int int4 = property1.get();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationField durationField6 = gJChronology2.weeks();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getMinimumValue(100L);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
        boolean boolean21 = localDate17.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval23 = localDate17.toInterval(dateTimeZone22);
        org.joda.time.DateTimeField[] dateTimeFieldArray24 = localDate17.getFields();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = delegatedDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate17, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(interval23);
        org.junit.Assert.assertNotNull(dateTimeFieldArray24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        try {
            java.lang.String str5 = dateTime0.toString(dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("Property[secondOfMinute]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.LocalDate.Property property9 = localDate6.property(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        int int10 = dateTime9.getMillisOfDay();
//        try {
//            org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((java.lang.Object) int10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 56783643 + "'", int10 == 56783643);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        org.joda.time.DateTime dateTime5 = property1.getDateTime();
        org.joda.time.Instant instant6 = new org.joda.time.Instant((java.lang.Object) dateTime5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter3, dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        java.lang.String str12 = dateTimeZone6.toString();
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 46);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 46");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (byte) -1, dateTimeZone3);
        int int5 = localDate4.getWeekyear();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", number1, (java.lang.Number) 2440587.500000035d, (java.lang.Number) (short) 0);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value null for hi! must be in the range [2440587.500000035,0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value null for hi! must be in the range [2440587.500000035,0]"));
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        org.joda.time.DateTimeField dateTimeField52 = copticChronology11.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField53 = copticChronology11.weekyear();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getMinimumValue(100L);
        long long17 = delegatedDateTimeField13.remainder((long) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 1);
//        java.lang.String str10 = dateTime5.toString(dateTimeFormatter7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = dateTime5.isSupported(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-05" + "'", str10.equals("2019-06-05"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        org.joda.time.Partial partial17 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray18 = partial17.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.hourOfHalfday();
        org.joda.time.DurationField durationField24 = gJChronology22.months();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.withYearOfCentury((int) 'a');
        boolean boolean30 = localDate28.equals((java.lang.Object) "hi!");
        int[] intArray32 = gJChronology22.get((org.joda.time.ReadablePartial) localDate28, (long) (byte) 100);
        try {
            int[] intArray34 = offsetDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) partial17, 100, intArray32, 1045);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray18);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray32);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        int int68 = skipUndoDateTimeField8.get((long) 5);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gJChronology5);
//        int int9 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime11 = dateTime2.plus((long) 4);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate(dateTimeZone67);
//        org.joda.time.LocalDate localDate70 = localDate68.withYearOfCentury((int) 'a');
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate68, (int) (byte) 100, locale72);
//        java.lang.String str75 = skipUndoDateTimeField8.getAsText(2L);
//        org.joda.time.ReadablePartial readablePartial76 = null;
//        int[] intArray83 = new int[] { 3, 7, 1970, (byte) -1, 16, 7 };
//        int int84 = skipUndoDateTimeField8.getMinimumValue(readablePartial76, intArray83);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "100" + "'", str73.equals("100"));
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2" + "'", str75.equals("2"));
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
//        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
//        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone17);
//        org.joda.time.LocalDate localDate20 = localDate18.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property21 = localDate18.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate18.isBefore((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean32 = localDate28.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval34 = localDate28.toInterval(dateTimeZone33);
//        java.lang.String str36 = dateTimeZone33.getShortName((long) 'a');
//        org.joda.time.Interval interval37 = localDate18.toInterval(dateTimeZone33);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.withZoneRetainFields(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
//        org.joda.time.DurationField durationField44 = gJChronology43.centuries();
//        boolean boolean45 = dateTime38.equals((java.lang.Object) gJChronology43);
//        java.util.Locale locale46 = null;
//        java.util.Calendar calendar47 = dateTime38.toCalendar(locale46);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(dateTimeZone48);
//        org.joda.time.LocalDate localDate51 = localDate49.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property52 = localDate49.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone53);
//        org.joda.time.LocalDate localDate56 = localDate54.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate49.isBefore((org.joda.time.ReadablePartial) localDate56);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(dateTimeZone58);
//        org.joda.time.LocalDate localDate61 = localDate59.withYearOfCentury((int) 'a');
//        boolean boolean63 = localDate59.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval65 = localDate59.toInterval(dateTimeZone64);
//        java.lang.String str67 = dateTimeZone64.getShortName((long) 'a');
//        org.joda.time.Interval interval68 = localDate49.toInterval(dateTimeZone64);
//        org.joda.time.LocalDate localDate69 = org.joda.time.LocalDate.now(dateTimeZone64);
//        org.joda.time.DateTime dateTime70 = dateTime38.toDateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = localDate18.toDateTimeAtStartOfDay(dateTimeZone64);
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(dateTimeZone73);
//        org.joda.time.LocalDate localDate76 = localDate74.withYearOfCentury((int) 'a');
//        boolean boolean78 = localDate74.equals((java.lang.Object) (short) -1);
//        java.lang.Object obj79 = null;
//        boolean boolean80 = localDate74.equals(obj79);
//        org.joda.time.LocalDate localDate82 = localDate74.minusDays(0);
//        int[] intArray83 = localDate82.getValues();
//        try {
//            int[] intArray85 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) localDate18, 9, intArray83, 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(interval34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PST" + "'", str36.equals("PST"));
//        org.junit.Assert.assertNotNull(interval37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(calendar47);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(interval65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "PST" + "'", str67.equals("PST"));
//        org.junit.Assert.assertNotNull(interval68);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(localDate82);
//        org.junit.Assert.assertNotNull(intArray83);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        org.joda.time.LocalDate.Property property10 = localDate1.yearOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.withZoneRetainFields(dateTimeZone16);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        boolean boolean19 = yearMonthDay14.isEqual((org.joda.time.ReadablePartial) yearMonthDay18);
        int int20 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay14);
        java.util.Locale locale21 = null;
        int int22 = skipUndoDateTimeField8.getMaximumTextLength(locale21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale67 = null;
//        int int68 = skipUndoDateTimeField8.getMaximumTextLength(locale67);
//        long long70 = skipUndoDateTimeField8.roundCeiling((long) '4');
//        int int71 = skipUndoDateTimeField8.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 52L + "'", long70 == 52L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale67 = null;
//        int int68 = skipUndoDateTimeField8.getMaximumTextLength(locale67);
//        org.joda.time.DurationField durationField69 = skipUndoDateTimeField8.getLeapDurationField();
//        long long72 = skipUndoDateTimeField8.add(10L, 9);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 19L + "'", long72 == 19L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = property1.getDifference(readableInstant3);
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property1.setCopy("", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateMidnight dateMidnight21 = localDate1.toDateMidnight();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        try {
            int int9 = localDate1.getValue(946);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 946");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        java.util.Locale locale67 = null;
//        int int68 = skipUndoDateTimeField8.getMaximumTextLength(locale67);
//        java.util.Locale locale69 = null;
//        int int70 = skipUndoDateTimeField8.getMaximumTextLength(locale69);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        java.lang.String str6 = property4.getName();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfWeek" + "'", str6.equals("dayOfWeek"));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DurationFieldType durationFieldType67 = null;
//        try {
//            org.joda.time.LocalDate localDate69 = localDate12.withFieldAdded(durationFieldType67, 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField8.getAsText(86399999, locale17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        int int24 = localDate20.getYear();
        org.joda.time.LocalDate.Property property25 = localDate20.yearOfEra();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) -1, locale27);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "86399999" + "'", str18.equals("86399999"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("2");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) 86399999, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 4, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate5 = localDate3.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property6 = localDate3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.withYearOfCentury((int) 'a');
//        boolean boolean11 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
//        boolean boolean17 = localDate13.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval19 = localDate13.toInterval(dateTimeZone18);
//        java.lang.String str21 = dateTimeZone18.getShortName((long) 'a');
//        org.joda.time.Interval interval22 = localDate3.toInterval(dateTimeZone18);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZoneRetainFields(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
//        org.joda.time.DurationField durationField29 = gJChronology28.centuries();
//        boolean boolean30 = dateTime23.equals((java.lang.Object) gJChronology28);
//        java.util.Locale locale31 = null;
//        java.util.Calendar calendar32 = dateTime23.toCalendar(locale31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone33);
//        org.joda.time.LocalDate localDate36 = localDate34.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property37 = localDate34.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(dateTimeZone38);
//        org.joda.time.LocalDate localDate41 = localDate39.withYearOfCentury((int) 'a');
//        boolean boolean42 = localDate34.isBefore((org.joda.time.ReadablePartial) localDate41);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
//        org.joda.time.LocalDate localDate46 = localDate44.withYearOfCentury((int) 'a');
//        boolean boolean48 = localDate44.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval50 = localDate44.toInterval(dateTimeZone49);
//        java.lang.String str52 = dateTimeZone49.getShortName((long) 'a');
//        org.joda.time.Interval interval53 = localDate34.toInterval(dateTimeZone49);
//        org.joda.time.LocalDate localDate54 = org.joda.time.LocalDate.now(dateTimeZone49);
//        org.joda.time.DateTime dateTime55 = dateTime23.toDateTime(dateTimeZone49);
//        org.joda.time.DateTime dateTime56 = localDate3.toDateTimeAtStartOfDay(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.MutableDateTime mutableDateTime58 = dateTime56.toMutableDateTime(dateTimeZone57);
//        int int59 = mutableDateTime58.getYearOfEra();
//        int int62 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime58, "100", 100);
//        org.joda.time.Instant instant63 = mutableDateTime58.toInstant();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(interval19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(calendar32);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(interval50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PST" + "'", str52.equals("PST"));
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-101) + "'", int62 == (-101));
//        org.junit.Assert.assertNotNull(instant63);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        org.joda.time.DateTimeField dateTimeField16 = skipUndoDateTimeField8.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField8.getAsText(69900L, locale12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "900" + "'", str13.equals("900"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.millisOfSecond();
        long long9 = gJChronology2.add((-299001L), (long) 0, (int) '4');
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-299001L) + "'", long9 == (-299001L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray2 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeParserArray2);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 1);
//        java.lang.String str10 = dateTime5.toString(dateTimeFormatter7);
//        org.joda.time.DateTime.Property property11 = dateTime5.yearOfCentury();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime5.withHourOfDay(166);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-05" + "'", str10.equals("2019-06-05"));
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        int int4 = localDate1.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
        org.joda.time.LocalDate localDate10 = localDate1.minusYears(10);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate10.plus(readablePeriod11);
        org.joda.time.LocalDate.Property property13 = localDate10.dayOfMonth();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusYears(100);
//        org.joda.time.DateTime.Property property35 = dateTime32.secondOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, durationField15, dateTimeFieldType16, 1045);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.hourOfHalfday();
//        org.joda.time.DurationField durationField30 = gJChronology28.months();
//        org.joda.time.DurationField durationField31 = gJChronology28.hours();
//        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology28.getZone();
//        org.joda.time.Interval interval33 = localDate25.toInterval(dateTimeZone32);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(interval33);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        org.joda.time.DateTimeField dateTimeField52 = copticChronology11.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField53 = copticChronology11.dayOfWeek();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        int int10 = dateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.hourOfHalfday();
//        org.joda.time.DurationField durationField15 = gJChronology13.months();
//        org.joda.time.DurationField durationField16 = gJChronology13.hours();
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology13.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime6.toDateTime(dateTimeZone17);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) 'a', (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 946 + "'", int10 == 946);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        org.joda.time.DurationField durationField16 = gJChronology15.centuries();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField18, 100);
        int int22 = skipUndoDateTimeField20.getMaximumValue((long) (short) -1);
        java.lang.String str24 = skipUndoDateTimeField20.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 46);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
        boolean boolean32 = localDate28.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval34 = localDate28.toInterval(dateTimeZone33);
        int int35 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate28, (int) (short) 0, locale37);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(interval34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1045 + "'", int35 == 1045);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        java.io.Writer writer4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property9 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate11 = localDate6.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial12 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate11);
        try {
            dateTimeFormatter3.printTo(writer4, (org.joda.time.ReadablePartial) partial12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfDay();
        try {
            long long9 = gJChronology2.getDateTimeMillis((int) (byte) 1, (int) (short) -1, 9, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        boolean boolean3 = property1.equals((java.lang.Object) dateTimeFormatter2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate5.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
//        java.lang.String str13 = dateTimeZone10.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, 3);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.withZoneRetainFields(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
//        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
//        boolean boolean23 = dateTime16.equals((java.lang.Object) gJChronology21);
//        java.util.Locale locale24 = null;
//        java.util.Calendar calendar25 = dateTime16.toCalendar(locale24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone26);
//        org.joda.time.LocalDate localDate29 = localDate27.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property30 = localDate27.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        boolean boolean35 = localDate27.isBefore((org.joda.time.ReadablePartial) localDate34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean41 = localDate37.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval43 = localDate37.toInterval(dateTimeZone42);
//        java.lang.String str45 = dateTimeZone42.getShortName((long) 'a');
//        org.joda.time.Interval interval46 = localDate27.toInterval(dateTimeZone42);
//        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now(dateTimeZone42);
//        org.joda.time.DateTime dateTime48 = dateTime16.toDateTime(dateTimeZone42);
//        org.joda.time.Chronology chronology49 = copticChronology15.withZone(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.ReadableInstant readableInstant51 = null;
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, readableInstant51);
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology52.hourOfHalfday();
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology52);
//        boolean boolean55 = copticChronology15.equals((java.lang.Object) gJChronology52);
//        org.joda.time.DateTimeZone dateTimeZone56 = gJChronology52.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter2.withZone(dateTimeZone56);
//        java.io.Writer writer58 = null;
//        try {
//            dateTimeFormatter2.printTo(writer58, (long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(calendar25);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(interval43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PST" + "'", str45.equals("PST"));
//        org.junit.Assert.assertNotNull(interval46);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        int int4 = localDate1.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
        org.joda.time.LocalDate localDate10 = localDate1.minusYears(10);
        int int11 = localDate1.getYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone13);
        org.joda.time.LocalDate localDate16 = localDate14.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property17 = localDate14.dayOfWeek();
        org.joda.time.LocalDate localDate19 = localDate14.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial20 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate19);
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate19, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"PST\")", false);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone5.getName((long) 97, locale7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime2.toMutableDateTimeISO();
//        int int7 = mutableDateTime6.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = localDate8.getFieldTypes();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 69900L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Pacific Standard Time", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        try {
            java.lang.String str7 = localDate5.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.Interval interval22 = localDate21.toInterval();
//        try {
//            org.joda.time.LocalDate localDate24 = localDate21.withDayOfMonth(1045);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1045 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(interval22);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.era();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withWeekOfWeekyear(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears((int) (short) -1);
        int int9 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        int int4 = localDate1.getYearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
//        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
//        int int9 = localDate1.getWeekOfWeekyear();
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        try {
//            org.joda.time.LocalDate localDate12 = localDate1.withFieldAdded(durationFieldType10, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        boolean boolean4 = dateTime0.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.plus((long) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime0.withWeekOfWeekyear(2);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate(dateTimeZone67);
//        org.joda.time.LocalDate localDate70 = localDate68.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property71 = localDate68.dayOfWeek();
//        int int72 = localDate68.getYear();
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(dateTimeZone73);
//        org.joda.time.LocalDate localDate76 = localDate74.withYearOfCentury((int) 'a');
//        boolean boolean78 = localDate74.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval80 = localDate74.toInterval(dateTimeZone79);
//        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTime dateTime82 = localDate68.toDateTimeAtMidnight(dateTimeZone79);
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate68, 946, locale84);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(interval80);
//        org.junit.Assert.assertNotNull(iSOChronology81);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "946" + "'", str85.equals("946"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = iSOChronology0.get(readablePeriod1, 19L, (long) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        int int5 = localDate1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType2, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "86399999");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean36 = offsetDateTimeField14.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DurationField durationField41 = gJChronology39.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, durationField41, dateTimeFieldType42, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType7, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(0, locale16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        int int4 = gJChronology3.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology5.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("20", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(dateTimeZone9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        try {
//            long long16 = copticChronology11.getDateTimeMillis(3, 97, (int) (byte) 1, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        long long21 = offsetDateTimeField14.add((long) 16, (-61828157222000L));
        try {
            long long24 = offsetDateTimeField14.set(2L, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for millisOfSecond must be in the range [47,1045]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61828157221984L) + "'", long21 == (-61828157221984L));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
        boolean boolean20 = localDate16.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval22 = localDate16.toInterval(dateTimeZone21);
        int int23 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.LocalDate localDate25 = localDate16.withWeekyear(20);
        try {
            org.joda.time.DateTimeField dateTimeField27 = localDate25.getField(20);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 20");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1045 + "'", int23 == 1045);
        org.junit.Assert.assertNotNull(localDate25);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.secondOfDay();
//        java.lang.String str5 = julianChronology3.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str5.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        org.joda.time.LocalTime localTime6 = null;
        try {
            org.joda.time.LocalDateTime localDateTime7 = localDate5.toLocalDateTime(localTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str11 = dateTimeZone9.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
//        org.joda.time.Chronology chronology13 = gJChronology5.withZone(dateTimeZone9);
//        org.joda.time.DurationField durationField14 = gJChronology5.years();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.String str13 = dateTime9.toString(dateTimeFormatter12);
//        int int14 = dateTime9.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-05" + "'", str13.equals("2019-06-05"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 23 + "'", int14 == 23);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str8 = localDate1.toString();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundHalfEven(0L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField14.getAsText((int) (short) -1, locale20);
        long long24 = offsetDateTimeField14.add(0L, (-1));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant6);
        org.joda.time.DurationField durationField8 = gJChronology7.centuries();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology7);
        long long16 = gJChronology7.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean18 = gJChronology7.equals((java.lang.Object) gJChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology7.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.DurationField durationField24 = gJChronology23.centuries();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology23);
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField26, 100);
        int int30 = skipUndoDateTimeField28.getMaximumValue((long) (short) -1);
        java.lang.String str32 = skipUndoDateTimeField28.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, 46);
        long long36 = offsetDateTimeField34.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField34.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType37);
        try {
            org.joda.time.Partial partial40 = partial0.withField(dateTimeFieldType37, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-21589903L) + "'", long16 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 999 + "'", int30 == 999);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2" + "'", str32.equals("2"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-26438399968L) + "'", long36 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate3.equals((java.lang.Object) "hi!");
        org.joda.time.LocalDate localDate7 = localDate3.minusYears((int) '4');
        org.joda.time.LocalDate localDate9 = localDate3.withYearOfCentury((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        org.joda.time.DurationField durationField16 = gJChronology15.centuries();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology15);
        long long24 = gJChronology15.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean26 = gJChronology15.equals((java.lang.Object) gJChronology25);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology15.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
        org.joda.time.DurationField durationField32 = gJChronology31.centuries();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology31);
        org.joda.time.DateTimeField dateTimeField34 = gJChronology31.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField34, 100);
        int int38 = skipUndoDateTimeField36.getMaximumValue((long) (short) -1);
        java.lang.String str40 = skipUndoDateTimeField36.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, 46);
        long long44 = offsetDateTimeField42.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField42.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27, dateTimeFieldType45);
        try {
            org.joda.time.LocalDate localDate48 = localDate9.withField(dateTimeFieldType45, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-21589903L) + "'", long24 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 999 + "'", int38 == 999);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2" + "'", str40.equals("2"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-26438399968L) + "'", long44 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekOfWeekyear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
//        int int3 = dateTime2.getHourOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
//        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology56);
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        try {
//            int[] intArray60 = julianChronology56.get(readablePeriod58, 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//        org.junit.Assert.assertNotNull(julianChronology56);
//        org.junit.Assert.assertNotNull(chronology57);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        boolean boolean6 = property4.equals((java.lang.Object) 0L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        long long11 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime9.toYearMonthDay();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(yearMonthDay12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.withYearOfCentury((int) 'a');
        boolean boolean11 = localDate7.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval13 = localDate7.toInterval(dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.getID();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(16, 24, 476, (int) (byte) -1, 9, 23, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "(\"org.joda.time.JodaTimePermission\" \"PST\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        try {
//            long long63 = buddhistChronology55.getDateTimeMillis(999, (int) '#', 20, 100, (int) (short) 100, 16, 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.Partial partial4 = partial0.withField(dateTimeFieldType2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        try {
            org.joda.time.LocalDate localDate9 = localDate1.withDayOfWeek(24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        int int7 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.withYearOfCentury((int) 'a');
        boolean boolean19 = localDate17.equals((java.lang.Object) "hi!");
        org.joda.time.LocalDate localDate21 = localDate17.minusYears((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone23);
        org.joda.time.LocalDate localDate26 = localDate24.withYearOfCentury((int) 'a');
        boolean boolean28 = localDate24.equals((java.lang.Object) (short) -1);
        java.lang.Object obj29 = null;
        boolean boolean30 = localDate24.equals(obj29);
        org.joda.time.LocalDate localDate32 = localDate24.minusDays(0);
        int[] intArray33 = localDate32.getValues();
        try {
            int[] intArray35 = delegatedDateTimeField13.set((org.joda.time.ReadablePartial) localDate17, 6, intArray33, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendWeekOfWeekyear(946);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        java.lang.String str5 = dateTimeZone1.getName(9L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(23L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("86399999", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for 86399999 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for 86399999 is not supported"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.getAsString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean35 = offsetDateTimeField14.isSupported();
        long long38 = offsetDateTimeField14.add((long) 20, 24);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 44L + "'", long38 == 44L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        int int6 = localDate5.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate1.getFields();
        boolean boolean9 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate1);
        int int10 = localDate1.getYear();
        int int11 = localDate1.size();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (short) 1);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime.Property property10 = dateTime8.weekOfWeekyear();
        boolean boolean11 = property10.isLeap();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant9 = instant7.plus((long) 59);
        org.joda.time.Instant instant11 = instant7.minus((long) 59);
        org.joda.time.MutableDateTime mutableDateTime12 = instant7.toMutableDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        try {
            long long47 = unsupportedDateTimeField45.roundHalfFloor((long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("20");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '20' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DurationField durationField21 = gJChronology20.centuries();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology20);
        long long29 = gJChronology20.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean31 = gJChronology20.equals((java.lang.Object) gJChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gJChronology20.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, readableInstant35);
        org.joda.time.DurationField durationField37 = gJChronology36.centuries();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology36);
        org.joda.time.DateTimeField dateTimeField39 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField39, 100);
        int int43 = skipUndoDateTimeField41.getMaximumValue((long) (short) -1);
        java.lang.String str45 = skipUndoDateTimeField41.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, 46);
        long long49 = offsetDateTimeField47.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = offsetDateTimeField47.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType50);
        int int52 = dateTime14.get(dateTimeFieldType50);
        try {
            org.joda.time.Partial.Property property53 = partial0.property(dateTimeFieldType50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-21589903L) + "'", long29 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 999 + "'", int43 == 999);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2" + "'", str45.equals("2"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-26438399968L) + "'", long49 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 23 + "'", int52 == 23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("86399999");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property50 = localDate47.dayOfWeek();
        org.joda.time.LocalDate localDate52 = localDate47.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial53 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.Partial partial56 = partial53.withPeriodAdded(readablePeriod54, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate(dateTimeZone57);
        org.joda.time.LocalDate localDate60 = localDate58.withYearOfCentury((int) 'a');
        boolean boolean62 = localDate58.equals((java.lang.Object) (short) -1);
        java.lang.Object obj63 = null;
        boolean boolean64 = localDate58.equals(obj63);
        org.joda.time.LocalDate localDate66 = localDate58.minusDays(0);
        int[] intArray67 = localDate66.getValues();
        try {
            int int68 = unsupportedDateTimeField45.getMaximumValue((org.joda.time.ReadablePartial) partial56, intArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(partial56);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(intArray67);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        long long38 = delegatedDateTimeField36.remainder((long) 946);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 946L + "'", long38 == 946L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial10 = partial7.withPeriodAdded(readablePeriod8, (int) (short) 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        boolean boolean15 = dateTime11.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime17 = dateTime11.plus((long) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime11.withWeekOfWeekyear(2);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        boolean boolean22 = partial7.isMatch((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMinuteOfHour(10);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        long long21 = offsetDateTimeField14.getDifferenceAsLong((long) 9, 52L);
        long long23 = offsetDateTimeField14.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-43L) + "'", long21 == (-43L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str4 = dateTimeZone0.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        try {
            boolean boolean47 = unsupportedDateTimeField45.isLeap((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder1.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"PST\")", false);
        org.joda.time.DateTime dateTime7 = dateTime0.withZoneRetainFields(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(100);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        boolean boolean4 = dateTime0.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.plus((long) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime0.withWeekOfWeekyear(2);
        int int9 = dateTime0.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withPeriodAdded(readablePeriod7, (int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime5.withMillis((-60502176421900L));
        org.joda.time.Instant instant12 = dateTime5.toInstant();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        long long5 = property1.remainder();
        int int6 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 23L + "'", long5 == 23L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekyear();
        long long11 = gJChronology2.getDateTimeMillis(6, 5, 1, (int) (short) 1, 0, 9, 9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61967603212991L) + "'", long11 == (-61967603212991L));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate3.equals((java.lang.Object) "hi!");
        org.joda.time.DateMidnight dateMidnight6 = localDate3.toDateMidnight();
        org.joda.time.LocalTime localTime7 = null;
        try {
            org.joda.time.LocalDateTime localDateTime8 = localDate3.toLocalDateTime(localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) 100);
//        org.joda.time.LocalDate.Property property26 = localDate25.dayOfMonth();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDate(1045, 23, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        long long68 = skipUndoDateTimeField8.roundCeiling(0L);
//        org.joda.time.ReadablePartial readablePartial69 = null;
//        int[] intArray76 = new int[] { (short) -1, ' ', 100, 1969, (byte) 10 };
//        try {
//            int[] intArray78 = skipUndoDateTimeField8.addWrapPartial(readablePartial69, 6, intArray76, 86399999);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(intArray76);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        int int4 = localDate1.getYearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
//        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
//        int int9 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property10 = localDate1.year();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone27);
//        int int33 = localDate32.size();
//        org.joda.time.LocalDate.Property property34 = localDate32.yearOfCentury();
//        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) 100);
//        int int37 = property10.compareTo((org.joda.time.ReadablePartial) localDate36);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        boolean boolean6 = property4.equals((java.lang.Object) 0L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        long long11 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        int int12 = property4.getMaximumValue();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("57600003");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
        org.joda.time.DurationField durationField7 = gJChronology6.centuries();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology6);
        long long15 = gJChronology6.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean17 = gJChronology6.equals((java.lang.Object) gJChronology16);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology6.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.DurationField durationField23 = gJChronology22.centuries();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology22);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField25, 100);
        int int29 = skipUndoDateTimeField27.getMaximumValue((long) (short) -1);
        java.lang.String str31 = skipUndoDateTimeField27.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField27, 46);
        long long35 = offsetDateTimeField33.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField33.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology40.yearOfEra();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology40.hourOfHalfday();
        org.joda.time.Chronology chronology44 = gJChronology40.withUTC();
        org.joda.time.DurationField durationField45 = gJChronology40.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField45);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField47 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-21589903L) + "'", long15 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-26438399968L) + "'", long35 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        int int10 = dateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.hourOfHalfday();
        org.joda.time.DurationField durationField15 = gJChronology13.months();
        org.joda.time.DurationField durationField16 = gJChronology13.hours();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology13.getZone();
        org.joda.time.DateTime dateTime18 = dateTime6.toDateTime(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime6.withYearOfCentury((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 960 + "'", int10 == 960);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = property1.getDifference(readableInstant3);
        int int5 = property1.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-166T��:��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property51 = localDate48.dayOfWeek();
        int int52 = localDate48.getYear();
        int[] intArray58 = new int[] { 2019, 59, 57600, (byte) -1 };
        java.util.Locale locale60 = null;
        try {
            int[] intArray61 = unsupportedDateTimeField45.set((org.joda.time.ReadablePartial) localDate48, 721, intArray58, "900", locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1969 + "'", int52 == 1969);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology2.getZone();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = dateTime46.withZoneRetainFields(dateTimeZone47);
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
        org.joda.time.DateTime dateTime51 = dateTime48.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime52 = dateTime51.withTimeAtStartOfDay();
        org.joda.time.YearMonthDay yearMonthDay53 = dateTime52.toYearMonthDay();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((java.lang.Object) yearMonthDay53, chronology54);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, readableInstant58);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(dateTimeZone61);
        org.joda.time.LocalDate localDate64 = localDate62.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property65 = localDate62.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate(dateTimeZone66);
        org.joda.time.LocalDate localDate69 = localDate67.withYearOfCentury((int) 'a');
        boolean boolean70 = localDate62.isBefore((org.joda.time.ReadablePartial) localDate69);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.ReadableInstant readableInstant72 = null;
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone71, readableInstant72);
        org.joda.time.DateTimeField dateTimeField74 = gJChronology73.hourOfHalfday();
        org.joda.time.DurationField durationField75 = gJChronology73.months();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate(dateTimeZone76);
        org.joda.time.LocalDate localDate79 = localDate77.withYearOfCentury((int) 'a');
        boolean boolean81 = localDate79.equals((java.lang.Object) "hi!");
        int[] intArray83 = gJChronology73.get((org.joda.time.ReadablePartial) localDate79, (long) (byte) 100);
        gJChronology59.validate((org.joda.time.ReadablePartial) localDate69, intArray83);
        try {
            int[] intArray86 = unsupportedDateTimeField45.set((org.joda.time.ReadablePartial) yearMonthDay53, (int) ' ', intArray83, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(yearMonthDay53);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(intArray83);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1", "America/Los_Angeles");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "GJChronology[America/Los_Angeles]", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = unsupportedDateTimeField45.getAsShortText((-61967603212991L), locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        long long9 = gJChronology2.add((long) 6, (long) 946, 999);
        org.joda.time.Instant instant10 = gJChronology2.getGregorianCutover();
        long long11 = instant10.getMillis();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 945060L + "'", long9 == 945060L);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-12219292800000L) + "'", long11 == (-12219292800000L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate9.era();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "Pacific Standard Time", "1969-12-21");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        try {
            org.joda.time.Instant instant35 = new org.joda.time.Instant((java.lang.Object) intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: [I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        int int4 = localDate1.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
        org.joda.time.LocalDate localDate10 = localDate1.minusYears(10);
        int int11 = localDate10.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 53 + "'", int11 == 53);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField45.getType();
        try {
            long long49 = unsupportedDateTimeField45.roundHalfEven((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        int int5 = localDate1.getYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.withYearOfCentury((int) 'a');
        boolean boolean11 = localDate7.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval13 = localDate7.toInterval(dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = localDate1.toDateTimeAtMidnight(dateTimeZone12);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = localDate1.getFieldTypes();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay2 = dateTime0.toTimeOfDay();
        int int3 = dateTime0.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(timeOfDay2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 960 + "'", int3 == 960);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 1);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter3.parseMutableDateTime("1969-12-21");
        try {
            org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.parse("", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (short) 1);
        int int9 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(24, (int) (short) 100, (int) 'a', 47, 59, 24, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYearOfCentury(56778313, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParser9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundCeiling((long) 946);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 946L + "'", long18 == 946L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant9 = instant7.plus((long) 59);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant7.minus(readableDuration10);
        org.joda.time.Instant instant14 = instant7.withDurationAdded(1560638801572L, (int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        org.joda.time.LocalDate localDate7 = localDate5.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = localDate7.toDateTimeAtMidnight();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMinutes(6);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.getName();
        try {
            int int51 = unsupportedDateTimeField45.getMaximumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "millisOfSecond" + "'", str49.equals("millisOfSecond"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        try {
            int int48 = unsupportedDateTimeField45.get((long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long5 = dateTimeZone3.convertUTCToLocal((long) 56778313);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27978313L + "'", long5 == 27978313L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(19L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        org.joda.time.LocalDate localDate24 = property23.roundHalfCeilingCopy();
//        org.joda.time.LocalDate localDate25 = property23.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate25);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology8 = iSOChronology6.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.hourOfDay();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(853, 15, 1045, 17174488, 46, (int) (byte) 100, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 17174488 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        int int4 = localDate1.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate10 = localDate8.plus(readablePeriod9);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.halfdayOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        int int4 = property1.getLeapAmount();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial10 = partial7.withPeriodAdded(readablePeriod8, (int) (short) 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        boolean boolean15 = dateTime11.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime17 = dateTime11.plus((long) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime11.withWeekOfWeekyear(2);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        boolean boolean22 = partial7.isMatch((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
        org.joda.time.DurationField durationField29 = gJChronology28.centuries();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology28);
        long long37 = gJChronology28.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean39 = gJChronology28.equals((java.lang.Object) gJChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology28.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, readableInstant43);
        org.joda.time.DurationField durationField45 = gJChronology44.centuries();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology44);
        org.joda.time.DateTimeField dateTimeField47 = gJChronology44.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology41, dateTimeField47, 100);
        int int51 = skipUndoDateTimeField49.getMaximumValue((long) (short) -1);
        java.lang.String str53 = skipUndoDateTimeField49.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, 46);
        long long57 = offsetDateTimeField55.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField55.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40, dateTimeFieldType58);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, readableInstant61);
        org.joda.time.DateTimeField dateTimeField63 = gJChronology62.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology62.yearOfEra();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology62.hourOfHalfday();
        org.joda.time.Chronology chronology66 = gJChronology62.withUTC();
        org.joda.time.DurationField durationField67 = gJChronology62.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType58, durationField67);
        java.lang.String str69 = unsupportedDateTimeField68.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = unsupportedDateTimeField68.getType();
        try {
            org.joda.time.Partial partial72 = partial7.with(dateTimeFieldType70, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfSecond must not be smaller than 0");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-21589903L) + "'", long37 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 999 + "'", int51 == 999);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2" + "'", str53.equals("2"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-26438399968L) + "'", long57 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "millisOfSecond" + "'", str69.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withPeriodAdded(readablePeriod7, (int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime5.withMillis((-60502176421900L));
        org.joda.time.DateTime dateTime13 = dateTime5.plusSeconds(166);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate9.era();
        try {
            org.joda.time.LocalDate localDate14 = property12.setCopy("weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"weekOfWeekyear\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.Permission permission3 = null;
        boolean boolean4 = jodaTimePermission1.implies(permission3);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("-1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendDayOfWeek(99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        int int20 = offsetDateTimeField14.getMaximumValue((long) (short) 1);
        long long23 = offsetDateTimeField14.addWrapField((long) 24, 31);
        int int25 = offsetDateTimeField14.getMaximumValue((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1045 + "'", int20 == 1045);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 55L + "'", long23 == 55L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1045 + "'", int25 == 1045);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
        boolean boolean20 = localDate16.equals((java.lang.Object) (short) -1);
        java.lang.Object obj21 = null;
        boolean boolean22 = localDate16.equals(obj21);
        org.joda.time.LocalDate localDate24 = localDate16.minusDays(0);
        int[] intArray25 = localDate24.getValues();
        boolean boolean26 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
        org.joda.time.DurationField durationField31 = gJChronology30.centuries();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology30);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField33, 100);
        int int37 = skipUndoDateTimeField35.getMaximumValue((long) (short) -1);
        java.lang.String str39 = skipUndoDateTimeField35.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 46);
        long long43 = offsetDateTimeField41.roundHalfEven((long) '#');
        long long45 = offsetDateTimeField41.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property50 = localDate47.dayOfWeek();
        org.joda.time.LocalDate localDate52 = localDate47.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate54 = localDate47.withYearOfEra(1);
        int[] intArray60 = new int[] { 0, 2, 2019, 24, 'a' };
        int int61 = offsetDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) localDate54, intArray60);
        try {
            int int62 = skipUndoDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate24, intArray60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2" + "'", str39.equals("2"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 35L + "'", long43 == 35L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1045 + "'", int61 == 1045);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean35 = offsetDateTimeField14.isSupported();
        int int37 = offsetDateTimeField14.getMaximumValue(166L);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField14.getAsShortText(0, locale39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate46 = localDate42.withYearOfEra(9);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property56 = localDate53.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate(dateTimeZone57);
        org.joda.time.LocalDate localDate60 = localDate58.withYearOfCentury((int) 'a');
        boolean boolean61 = localDate53.isBefore((org.joda.time.ReadablePartial) localDate60);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, readableInstant63);
        org.joda.time.DateTimeField dateTimeField65 = gJChronology64.hourOfHalfday();
        org.joda.time.DurationField durationField66 = gJChronology64.months();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate(dateTimeZone67);
        org.joda.time.LocalDate localDate70 = localDate68.withYearOfCentury((int) 'a');
        boolean boolean72 = localDate70.equals((java.lang.Object) "hi!");
        int[] intArray74 = gJChronology64.get((org.joda.time.ReadablePartial) localDate70, (long) (byte) 100);
        gJChronology50.validate((org.joda.time.ReadablePartial) localDate60, intArray74);
        try {
            int[] intArray77 = offsetDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localDate42, 365, intArray74, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1045 + "'", int37 == 1045);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(gJChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(intArray74);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        boolean boolean6 = property4.equals((java.lang.Object) 0L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        long long11 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalDate localDate12 = property4.roundFloorCopy();
        org.joda.time.DurationField durationField13 = property4.getDurationField();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        java.lang.String str6 = gJChronology2.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant11);
        org.joda.time.DurationField durationField13 = gJChronology12.centuries();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology12);
        long long21 = gJChronology12.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean23 = gJChronology12.equals((java.lang.Object) gJChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology12.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
        org.joda.time.DurationField durationField29 = gJChronology28.centuries();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology28);
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField31, 100);
        int int35 = skipUndoDateTimeField33.getMaximumValue((long) (short) -1);
        java.lang.String str37 = skipUndoDateTimeField33.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 46);
        long long41 = offsetDateTimeField39.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField39.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, readableInstant45);
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology46.yearOfEra();
        org.joda.time.DateTimeField dateTimeField49 = gJChronology46.hourOfHalfday();
        org.joda.time.Chronology chronology50 = gJChronology46.withUTC();
        org.joda.time.DurationField durationField51 = gJChronology46.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField51);
        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str56 = unsupportedDateTimeField52.toString();
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) unsupportedDateTimeField52, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str6.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-21589903L) + "'", long21 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2" + "'", str37.equals("2"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-26438399968L) + "'", long41 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 17174488 + "'", int55 == 17174488);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "UnsupportedDateTimeField" + "'", str56.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = dateTime0.getYear();
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime0.toCalendar(locale6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(calendar7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-21589903L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.2501168633d + "'", double1 == 2440587.2501168633d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        long long11 = skipUndoDateTimeField8.set(0L, (int) (short) 10);
        java.lang.String str13 = skipUndoDateTimeField8.getAsShortText((long) (short) -1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "999" + "'", str13.equals("999"));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) 365, 4);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(gJChronology14);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        long long20 = offsetDateTimeField14.roundHalfEven((long) 166);
        long long23 = offsetDateTimeField14.add((long) (byte) 100, 946L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 166L + "'", long20 == 166L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1046L + "'", long23 == 1046L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 1);
        java.lang.String str10 = dateTime5.toString(dateTimeFormatter7);
        org.joda.time.DateTime.Property property11 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((int) ' ');
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-21" + "'", str10.equals("1969-12-21"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DurationField durationField21 = gJChronology20.centuries();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField23, 100);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField25.getAsShortText((long) (byte) 1, locale27);
        long long31 = skipUndoDateTimeField25.set((long) 'a', 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
        org.joda.time.DurationField durationField34 = gJChronology15.halfdays();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.centuries();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
        org.joda.time.DateTime dateTime21 = property20.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, readableInstant26);
        org.joda.time.DurationField durationField28 = gJChronology27.centuries();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology27);
        long long36 = gJChronology27.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean38 = gJChronology27.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeField dateTimeField39 = gJChronology27.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
        org.joda.time.DurationField durationField44 = gJChronology43.centuries();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology43);
        org.joda.time.DateTimeField dateTimeField46 = gJChronology43.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField46, 100);
        int int50 = skipUndoDateTimeField48.getMaximumValue((long) (short) -1);
        java.lang.String str52 = skipUndoDateTimeField48.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 46);
        long long56 = offsetDateTimeField54.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField54.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39, dateTimeFieldType57);
        int int59 = dateTime21.get(dateTimeFieldType57);
        try {
            org.joda.time.Partial partial61 = partial7.withField(dateTimeFieldType57, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-21589903L) + "'", long36 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2" + "'", str52.equals("2"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-26438399968L) + "'", long56 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 35 + "'", int59 == 35);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear(20);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimePrinter7, dateTimeParser8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 1970, "Property[secondOfMinute]");
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        org.joda.time.DateTime dateTime5 = property1.withMinimumValue();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField12, 100);
        int int16 = skipUndoDateTimeField14.getMaximumValue((long) (short) -1);
        java.lang.String str18 = skipUndoDateTimeField14.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField14, 46);
        long long22 = offsetDateTimeField20.roundHalfEven((long) '#');
        boolean boolean24 = offsetDateTimeField20.isLeap((long) 2019);
        int int25 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField20);
        try {
            long long28 = offsetDateTimeField20.set((long) 365, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 999 + "'", int16 == 999);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 82 + "'", int25 == 82);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        long long11 = skipUndoDateTimeField8.set(0L, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
        int int16 = localDate13.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = localDate13.isSupported(dateTimeFieldType17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        boolean boolean24 = localDate20.equals((java.lang.Object) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = localDate20.equals(obj25);
        org.joda.time.LocalDate localDate28 = localDate20.minusDays(0);
        int[] intArray29 = localDate28.getValues();
        int int30 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray29);
        org.joda.time.LocalDate.Property property31 = localDate13.era();
        org.joda.time.LocalDate localDate32 = property31.withMaximumValue();
        org.joda.time.DurationFieldType durationFieldType33 = null;
        try {
            org.joda.time.LocalDate localDate35 = localDate32.withFieldAdded(durationFieldType33, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate32);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"PST\")", false);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 46, false, (long) 46);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 46L + "'", long9 == 46L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = property8.getDifference(readableInstant10);
        org.joda.time.DateTime dateTime12 = property8.withMaximumValue();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 1, (java.lang.Object) property8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DurationField durationField21 = gJChronology20.centuries();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField23, 100);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField25.getAsShortText((long) (byte) 1, locale27);
        long long31 = skipUndoDateTimeField25.set((long) 'a', 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology36 = iSOChronology34.withZone(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology34.hourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial10 = partial7.withPeriodAdded(readablePeriod8, (int) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.Partial.Property property12 = partial10.property(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(partial10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        java.lang.String str10 = dateTimeFormatter8.print((long) 365);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        java.util.Date date2 = localDate1.toDate();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.fromDateFields(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField8.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.DurationField durationField9 = gJChronology8.centuries();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField11, 100);
        int int15 = skipUndoDateTimeField13.getMaximumValue((long) (short) -1);
        java.lang.String str17 = skipUndoDateTimeField13.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, 46);
        long long21 = offsetDateTimeField19.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField19.getType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType22, (-17174488));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -17174488");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-26438399968L) + "'", long21 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
//        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str5 = dateTimeZone3.getName((long) (short) 10);
//        org.joda.time.Chronology chronology6 = copticChronology0.withZone(dateTimeZone3);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology6);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField57 = julianChronology56.months();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//        org.junit.Assert.assertNotNull(julianChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-17174488), "1");
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 35L + "'", long0 == 35L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfDay(46);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime3.plus(0L);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DurationField durationField21 = gJChronology20.centuries();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField23, 100);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField25.getAsShortText((long) (byte) 1, locale27);
        long long31 = skipUndoDateTimeField25.set((long) 'a', 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
        java.util.Locale locale34 = null;
        int int35 = skipUndoDateTimeField25.getMaximumTextLength(locale34);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference((-61828157222000L), (long) (byte) 10);
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = unsupportedDateTimeField45.getAsText(0L, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-17174488) + "'", int49 == (-17174488));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DurationField durationField37 = delegatedDateTimeField36.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNull(durationField37);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        int int3 = dateTime2.getHourOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.plusMonths(946);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (byte) 10, 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfSecond(86399999, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(27978313L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology2.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -101");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZoneRetainFields(dateTimeZone5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        boolean boolean8 = yearMonthDay3.isEqual((org.joda.time.ReadablePartial) yearMonthDay7);
        try {
            org.joda.time.DateTimeField dateTimeField10 = yearMonthDay3.getField(57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 57600");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10, (java.lang.Number) (byte) 10, (java.lang.Number) (-1));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("dayOfWeek");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology26);
        long long35 = gJChronology26.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean37 = gJChronology26.equals((java.lang.Object) gJChronology36);
        org.joda.time.DateTimeField dateTimeField38 = gJChronology26.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, readableInstant41);
        org.joda.time.DurationField durationField43 = gJChronology42.centuries();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology42);
        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField45, 100);
        int int49 = skipUndoDateTimeField47.getMaximumValue((long) (short) -1);
        java.lang.String str51 = skipUndoDateTimeField47.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField47, 46);
        long long55 = offsetDateTimeField53.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType56);
        int int58 = dateTime20.get(dateTimeFieldType56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType56, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter61 = null;
        org.joda.time.format.DateTimeParser dateTimeParser62 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray63 = new org.joda.time.format.DateTimeParser[] { dateTimeParser62 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.append(dateTimePrinter61, dateTimeParserArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-21589903L) + "'", long35 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 999 + "'", int49 == 999);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2" + "'", str51.equals("2"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-26438399968L) + "'", long55 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 35 + "'", int58 == 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeParserArray63);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate5 = localDate3.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property6 = localDate3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.withYearOfCentury((int) 'a');
//        boolean boolean11 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
//        boolean boolean17 = localDate13.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval19 = localDate13.toInterval(dateTimeZone18);
//        java.lang.String str21 = dateTimeZone18.getShortName((long) 'a');
//        org.joda.time.Interval interval22 = localDate3.toInterval(dateTimeZone18);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZoneRetainFields(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
//        org.joda.time.DurationField durationField29 = gJChronology28.centuries();
//        boolean boolean30 = dateTime23.equals((java.lang.Object) gJChronology28);
//        java.util.Locale locale31 = null;
//        java.util.Calendar calendar32 = dateTime23.toCalendar(locale31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone33);
//        org.joda.time.LocalDate localDate36 = localDate34.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property37 = localDate34.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(dateTimeZone38);
//        org.joda.time.LocalDate localDate41 = localDate39.withYearOfCentury((int) 'a');
//        boolean boolean42 = localDate34.isBefore((org.joda.time.ReadablePartial) localDate41);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
//        org.joda.time.LocalDate localDate46 = localDate44.withYearOfCentury((int) 'a');
//        boolean boolean48 = localDate44.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval50 = localDate44.toInterval(dateTimeZone49);
//        java.lang.String str52 = dateTimeZone49.getShortName((long) 'a');
//        org.joda.time.Interval interval53 = localDate34.toInterval(dateTimeZone49);
//        org.joda.time.LocalDate localDate54 = org.joda.time.LocalDate.now(dateTimeZone49);
//        org.joda.time.DateTime dateTime55 = dateTime23.toDateTime(dateTimeZone49);
//        org.joda.time.DateTime dateTime56 = localDate3.toDateTimeAtStartOfDay(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.MutableDateTime mutableDateTime58 = dateTime56.toMutableDateTime(dateTimeZone57);
//        int int59 = mutableDateTime58.getYearOfEra();
//        int int62 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime58, "100", 100);
//        try {
//            org.joda.time.LocalDate localDate64 = dateTimeFormatter0.parseLocalDate("org.joda.time.IllegalFieldValueException: Value \"\" for 86399999 is not supported");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(interval19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(calendar32);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(interval50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PST" + "'", str52.equals("PST"));
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-101) + "'", int62 == (-101));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendWeekyear((int) (short) 10, 23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) 'a');
//        boolean boolean6 = localDate2.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval8 = localDate2.toInterval(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7, 3);
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology0.getZone();
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14, 24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 24");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.clockhourOfHalfday();
//        long long9 = julianChronology3.getDateTimeMillis((int) (short) 10, (int) (short) 10, (int) (byte) 1, 0);
//        long long14 = julianChronology3.getDateTimeMillis((int) '4', (int) (short) 10, 7, (int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        org.joda.time.DurationField durationField19 = gJChronology18.centuries();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField21, 100);
//        int int25 = skipUndoDateTimeField23.getMaximumValue((long) (short) -1);
//        java.lang.String str27 = skipUndoDateTimeField23.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 46);
//        long long31 = offsetDateTimeField29.roundHalfEven((long) '#');
//        long long33 = offsetDateTimeField29.roundFloor((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(dateTimeZone34);
//        org.joda.time.LocalDate localDate37 = localDate35.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property38 = localDate35.dayOfWeek();
//        org.joda.time.LocalDate localDate40 = localDate35.withYearOfEra((int) (byte) 100);
//        org.joda.time.LocalDate localDate42 = localDate35.withYearOfEra(1);
//        int[] intArray48 = new int[] { 0, 2, 2019, 24, 'a' };
//        int int49 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate42, intArray48);
//        boolean boolean51 = offsetDateTimeField29.isLeap(0L);
//        boolean boolean52 = offsetDateTimeField29.isSupported();
//        boolean boolean54 = offsetDateTimeField29.isLeap(55L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology3, (org.joda.time.DateTimeField) offsetDateTimeField29);
//        long long58 = skipDateTimeField55.add(3L, 53);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61828157222000L) + "'", long9 == (-61828157222000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60502176421900L) + "'", long14 == (-60502176421900L));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2" + "'", str27.equals("2"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1045 + "'", int49 == 1045);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 56L + "'", long58 == 56L);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.withZoneRetainFields(dateTimeZone16);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        boolean boolean19 = yearMonthDay14.isEqual((org.joda.time.ReadablePartial) yearMonthDay18);
        int int20 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay14);
        int int22 = skipUndoDateTimeField8.getLeapAmount(19L);
        try {
            long long25 = skipUndoDateTimeField8.set((long) 721, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime2.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean35 = offsetDateTimeField14.isSupported();
        int int37 = offsetDateTimeField14.getMaximumValue(166L);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField14.getAsShortText(0, locale39);
        org.joda.time.DurationField durationField41 = offsetDateTimeField14.getDurationField();
        int int43 = offsetDateTimeField14.getMinimumValue(44L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1045 + "'", int37 == 1045);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.clockhourOfHalfday();
//        long long9 = julianChronology3.getDateTimeMillis((int) (short) 10, (int) (short) 10, (int) (byte) 1, 0);
//        try {
//            long long17 = julianChronology3.getDateTimeMillis(2019, 10, 100, (int) (byte) 1, (int) (short) 100, 9, 56778313);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61828157222000L) + "'", long9 == (-61828157222000L));
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        boolean boolean15 = offsetDateTimeField14.isLenient();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsText(9, locale17);
        long long21 = offsetDateTimeField14.addWrapField((long) 10, 47);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9" + "'", str18.equals("9"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 57L + "'", long21 == 57L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        long long9 = gJChronology2.add((long) 6, (long) 946, 999);
        org.joda.time.Instant instant10 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology2.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 945060L + "'", long9 == 945060L);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        try {
//            long long18 = gregorianChronology10.getDateTimeMillis((int) (byte) 0, (int) (byte) 100, 24, 3, 853, 0, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 853 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfDay();
        java.lang.String str5 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
        boolean boolean10 = localDate8.equals((java.lang.Object) "hi!");
        int[] intArray12 = gJChronology2.get((org.joda.time.ReadablePartial) localDate8, (long) (byte) 100);
        org.joda.time.DurationField durationField13 = gJChronology2.days();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            long long16 = gJChronology2.set(readablePartial14, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        long long4 = dateTime2.getMillis();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((-1));
        long long7 = dateTime2.getMillis();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        java.lang.Object obj56 = null;
//        boolean boolean57 = buddhistChronology55.equals(obj56);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '#', 102L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3570 + "'", int2 == 3570);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        int int7 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfEra(946);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        boolean boolean5 = dateTimeZone0.isStandardOffset((long) (byte) -1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder35.appendDayOfMonth(1);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, readableInstant43);
        org.joda.time.DurationField durationField45 = gJChronology44.centuries();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology44);
        org.joda.time.DateTime dateTime48 = dateTime46.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.plus(readablePeriod52);
        org.joda.time.DateTime.Property property54 = dateTime53.weekOfWeekyear();
        org.joda.time.DateTime dateTime55 = property54.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter56.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone59, readableInstant60);
        org.joda.time.DurationField durationField62 = gJChronology61.centuries();
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology61);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) gJChronology61);
        long long70 = gJChronology61.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean72 = gJChronology61.equals((java.lang.Object) gJChronology71);
        org.joda.time.DateTimeField dateTimeField73 = gJChronology61.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.chrono.GJChronology gJChronology77 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone75, readableInstant76);
        org.joda.time.DurationField durationField78 = gJChronology77.centuries();
        org.joda.time.DateTime dateTime79 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology77);
        org.joda.time.DateTimeField dateTimeField80 = gJChronology77.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField82 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology74, dateTimeField80, 100);
        int int84 = skipUndoDateTimeField82.getMaximumValue((long) (short) -1);
        java.lang.String str86 = skipUndoDateTimeField82.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField82, 46);
        long long90 = offsetDateTimeField88.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType91 = offsetDateTimeField88.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField92 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73, dateTimeFieldType91);
        int int93 = dateTime55.get(dateTimeFieldType91);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType91, (int) (byte) 100);
        try {
            org.joda.time.LocalDate.Property property96 = localDate27.property(dateTimeFieldType91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-21589903L) + "'", long70 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(gJChronology77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 999 + "'", int84 == 999);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "2" + "'", str86.equals("2"));
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-26438399968L) + "'", long90 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 35 + "'", int93 == 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder95);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "Pacific Standard Time");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean3 = property1.equals((java.lang.Object) dateTimeFormatter2);
        java.lang.Integer int4 = dateTimeFormatter2.getPivotYear();
        java.lang.Appendable appendable5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.withYearOfCentury((int) 'a');
        boolean boolean11 = localDate7.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval13 = localDate7.toInterval(dateTimeZone12);
        int int14 = localDate7.getCenturyOfEra();
        try {
            dateTimeFormatter2.printTo(appendable5, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(int4);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology4 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(chronology4);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean36 = offsetDateTimeField14.isLeap(0L);
        long long38 = offsetDateTimeField14.roundHalfFloor((long) 20);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 20L + "'", long38 == 20L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) '#', "Property[secondOfMinute]");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 (Property[secondOfMinute])" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 (Property[secondOfMinute])"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        int int2 = gJChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gJChronology1.getDateTimeMillis(2, 476, 99, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 476 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        try {
            long long50 = unsupportedDateTimeField45.roundHalfFloor((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        int int35 = offsetDateTimeField14.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1045 + "'", int35 == 1045);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology11);
//        try {
//            long long54 = copticChronology11.getDateTimeMillis(35, 6, 7, (-101), 476, 10, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -101 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(chronology46);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.Interval interval22 = localDate21.toInterval();
//        try {
//            org.joda.time.LocalDate localDate24 = localDate21.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(interval22);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        int int8 = localDate1.getValue(0);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate1.withPeriodAdded(readablePeriod9, (-1));
        int int12 = localDate11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DurationField durationField5 = gJChronology3.months();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology3.getZone();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(0L, dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField45.getLeapDurationField();
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = unsupportedDateTimeField45.getAsShortText(55L, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField47);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.withZoneRetainFields(dateTimeZone16);
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
//        boolean boolean19 = yearMonthDay14.isEqual((org.joda.time.ReadablePartial) yearMonthDay18);
//        boolean boolean20 = gregorianChronology10.equals((java.lang.Object) yearMonthDay18);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        boolean boolean15 = offsetDateTimeField14.isLenient();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsText((long) 4, locale17);
        long long20 = offsetDateTimeField14.roundCeiling((-1L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "51" + "'", str18.equals("51"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = iSOChronology1.withZone(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        java.lang.String str47 = unsupportedDateTimeField45.toString();
        try {
            java.lang.String str49 = unsupportedDateTimeField45.getAsShortText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        long long9 = gJChronology2.add((long) 6, (long) 946, 999);
        org.joda.time.Instant instant10 = gJChronology2.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 945060L + "'", long9 == 945060L);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
        boolean boolean51 = localDate47.equals((java.lang.Object) (short) -1);
        java.lang.Object obj52 = null;
        boolean boolean53 = localDate47.equals(obj52);
        org.joda.time.LocalDate localDate55 = localDate47.minusDays(0);
        int[] intArray56 = localDate55.getValues();
        boolean boolean57 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, readableInstant59);
        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate(dateTimeZone62);
        org.joda.time.LocalDate localDate65 = localDate63.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property66 = localDate63.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate(dateTimeZone67);
        org.joda.time.LocalDate localDate70 = localDate68.withYearOfCentury((int) 'a');
        boolean boolean71 = localDate63.isBefore((org.joda.time.ReadablePartial) localDate70);
        org.joda.time.DateTimeZone dateTimeZone72 = null;
        org.joda.time.ReadableInstant readableInstant73 = null;
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone72, readableInstant73);
        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.hourOfHalfday();
        org.joda.time.DurationField durationField76 = gJChronology74.months();
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate(dateTimeZone77);
        org.joda.time.LocalDate localDate80 = localDate78.withYearOfCentury((int) 'a');
        boolean boolean82 = localDate80.equals((java.lang.Object) "hi!");
        int[] intArray84 = gJChronology74.get((org.joda.time.ReadablePartial) localDate80, (long) (byte) 100);
        gJChronology60.validate((org.joda.time.ReadablePartial) localDate70, intArray84);
        try {
            int int86 = unsupportedDateTimeField45.getMaximumValue((org.joda.time.ReadablePartial) localDate55, intArray84);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMinimumValueOverall();
        boolean boolean3 = property1.isLeap();
        java.lang.String str4 = property1.toString();
        org.joda.time.DateTime dateTime5 = property1.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTime8.getYearOfCentury();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMillisOfSecond(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTime();
        org.joda.time.DateTime dateTime9 = instant7.toDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        org.joda.time.LocalDate localDate7 = localDate5.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = localDate5.isSupported(dateTimeFieldType8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendDayOfMonth(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder10.appendCenturyOfEra((int) (byte) 10, 97);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        org.joda.time.DurationField durationField23 = gJChronology22.centuries();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology22);
        org.joda.time.DateTime dateTime26 = dateTime24.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
        org.joda.time.DateTime.Property property32 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTime dateTime33 = property32.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DurationField durationField40 = gJChronology39.centuries();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) gJChronology39);
        long long48 = gJChronology39.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean50 = gJChronology39.equals((java.lang.Object) gJChronology49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology39.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, readableInstant54);
        org.joda.time.DurationField durationField56 = gJChronology55.centuries();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology55);
        org.joda.time.DateTimeField dateTimeField58 = gJChronology55.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology52, dateTimeField58, 100);
        int int62 = skipUndoDateTimeField60.getMaximumValue((long) (short) -1);
        java.lang.String str64 = skipUndoDateTimeField60.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField60, 46);
        long long68 = offsetDateTimeField66.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = offsetDateTimeField66.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51, dateTimeFieldType69);
        int int71 = dateTime33.get(dateTimeFieldType69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder19.appendFixedDecimal(dateTimeFieldType69, 4);
        try {
            org.joda.time.LocalDate localDate75 = localDate5.withField(dateTimeFieldType69, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-21589903L) + "'", long48 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 999 + "'", int62 == 999);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2" + "'", str64.equals("2"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-26438399968L) + "'", long68 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 35 + "'", int71 == 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.Chronology chronology5 = gJChronology3.withUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(56L, (org.joda.time.Chronology) gJChronology3);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology11);
//        org.joda.time.DurationField durationField47 = copticChronology11.halfdays();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-1), "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 (Property[secondOfMinute])");
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.getName();
        try {
            int int50 = unsupportedDateTimeField45.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "millisOfSecond" + "'", str49.equals("millisOfSecond"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalDate localDate9 = localDate1.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.LocalDate localDate14 = localDate9.withFieldAdded(durationFieldType12, 476);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
        int int49 = localDate48.getYear();
        java.util.Locale locale50 = null;
        try {
            java.lang.String str51 = unsupportedDateTimeField45.getAsText((org.joda.time.ReadablePartial) localDate48, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) 'a');
//        boolean boolean6 = localDate2.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval8 = localDate2.toInterval(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7, 3);
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology0.getZone();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
//        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
//        org.joda.time.DateTime dateTime19 = dateTime15.plusYears((int) (short) 10);
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime15);
//        try {
//            org.joda.time.DateTime dateTime22 = dateTime15.withDayOfWeek(1969);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, readableInstant50);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone53);
        org.joda.time.LocalDate localDate56 = localDate54.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property57 = localDate54.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(dateTimeZone58);
        org.joda.time.LocalDate localDate61 = localDate59.withYearOfCentury((int) 'a');
        boolean boolean62 = localDate54.isBefore((org.joda.time.ReadablePartial) localDate61);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone63, readableInstant64);
        org.joda.time.DateTimeField dateTimeField66 = gJChronology65.hourOfHalfday();
        org.joda.time.DurationField durationField67 = gJChronology65.months();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate(dateTimeZone68);
        org.joda.time.LocalDate localDate71 = localDate69.withYearOfCentury((int) 'a');
        boolean boolean73 = localDate71.equals((java.lang.Object) "hi!");
        int[] intArray75 = gJChronology65.get((org.joda.time.ReadablePartial) localDate71, (long) (byte) 100);
        gJChronology51.validate((org.joda.time.ReadablePartial) localDate61, intArray75);
        java.util.Locale locale78 = null;
        try {
            java.lang.String str79 = unsupportedDateTimeField45.getAsText((org.joda.time.ReadablePartial) localDate61, (int) (byte) 0, locale78);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(gJChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone11.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone11);
//        int int15 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime14.withEra(476);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 476 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.append(dateTimePrinter6, dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone49);
        org.joda.time.LocalDate localDate52 = localDate50.withYearOfCentury((int) 'a');
        int int53 = localDate50.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        boolean boolean55 = localDate50.isSupported(dateTimeFieldType54);
        org.joda.time.LocalDate localDate57 = localDate50.minusMonths(31);
        int int58 = localDate50.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, readableInstant61);
        org.joda.time.DateTimeField dateTimeField63 = gJChronology62.hourOfHalfday();
        org.joda.time.DurationField durationField64 = gJChronology62.months();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate(dateTimeZone65);
        org.joda.time.LocalDate localDate68 = localDate66.withYearOfCentury((int) 'a');
        boolean boolean70 = localDate68.equals((java.lang.Object) "hi!");
        int[] intArray72 = gJChronology62.get((org.joda.time.ReadablePartial) localDate68, (long) (byte) 100);
        try {
            int[] intArray74 = unsupportedDateTimeField45.set((org.joda.time.ReadablePartial) localDate50, 6, intArray72, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1969 + "'", int53 == 1969);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.weekyear();
        long long19 = gJChronology10.getDateTimeMillis(6, 5, 1, (int) (short) 1, 0, 9, 9);
        org.joda.time.Partial partial20 = partial7.withChronologyRetainFields((org.joda.time.Chronology) gJChronology10);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.Partial partial22 = partial20.plus(readablePeriod21);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61967603212991L) + "'", long19 == (-61967603212991L));
        org.junit.Assert.assertNotNull(partial20);
        org.junit.Assert.assertNotNull(partial22);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DurationField durationField5 = gJChronology4.centuries();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = property14.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gJChronology21);
        long long30 = gJChronology21.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean32 = gJChronology21.equals((java.lang.Object) gJChronology31);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology21.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology37);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology37.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField40, 100);
        int int44 = skipUndoDateTimeField42.getMaximumValue((long) (short) -1);
        java.lang.String str46 = skipUndoDateTimeField42.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, 46);
        long long50 = offsetDateTimeField48.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = offsetDateTimeField48.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33, dateTimeFieldType51);
        int int53 = dateTime15.get(dateTimeFieldType51);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType51, 4, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-21589903L) + "'", long30 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 999 + "'", int44 == 999);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2" + "'", str46.equals("2"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-26438399968L) + "'", long50 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 35 + "'", int53 == 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }
}

