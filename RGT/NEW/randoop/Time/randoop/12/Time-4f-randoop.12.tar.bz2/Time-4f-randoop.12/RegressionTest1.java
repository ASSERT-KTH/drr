import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        int int2 = property1.getMinimumValueOverall();
//        boolean boolean3 = property1.isLeap();
//        java.lang.String str4 = property1.toString();
//        org.joda.time.DateTime dateTime5 = property1.withMinimumValue();
//        int int6 = dateTime5.getDayOfWeek();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusMinutes((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
//        org.joda.time.DurationField durationField12 = gJChronology11.centuries();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfDay();
//        java.lang.String str14 = gJChronology11.toString();
//        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology11);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str14.equals("GJChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.util.Locale locale49 = null;
        try {
            int int50 = unsupportedDateTimeField45.getMaximumTextLength(locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        java.util.Date date24 = localDate21.toDate();
//        org.joda.time.DurationFieldType durationFieldType25 = null;
//        try {
//            org.joda.time.LocalDate localDate27 = localDate21.withFieldAdded(durationFieldType25, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(date24);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 3, (-61967603212991L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61967603212988L) + "'", long2 == (-61967603212988L));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        org.joda.time.LocalDate localDate24 = property23.roundHalfCeilingCopy();
//        int int25 = property23.getMaximumValue();
//        java.lang.String str26 = property23.toString();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 99 + "'", int25 == 99);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[yearOfCentury]" + "'", str26.equals("Property[yearOfCentury]"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        int int9 = property8.getMinimumValueOverall();
        boolean boolean10 = property8.isLeap();
        java.lang.String str11 = property8.toString();
        org.joda.time.DateTime dateTime12 = property8.withMinimumValue();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime12);
        boolean boolean14 = dateTime12.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[secondOfMinute]" + "'", str11.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
//        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology26);
//        long long35 = gJChronology26.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean37 = gJChronology26.equals((java.lang.Object) gJChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology26.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.ReadableInstant readableInstant41 = null;
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, readableInstant41);
//        org.joda.time.DurationField durationField43 = gJChronology42.centuries();
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology42);
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField45, 100);
//        int int49 = skipUndoDateTimeField47.getMaximumValue((long) (short) -1);
//        java.lang.String str51 = skipUndoDateTimeField47.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField47, 46);
//        long long55 = offsetDateTimeField53.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType56);
//        int int58 = dateTime20.get(dateTimeFieldType56);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType56, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.ReadableInstant readableInstant63 = null;
//        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, readableInstant63);
//        org.joda.time.DateTimeField dateTimeField65 = gJChronology64.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField66 = gJChronology64.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField67 = gJChronology64.hourOfHalfday();
//        org.joda.time.Chronology chronology68 = gJChronology64.withUTC();
//        try {
//            org.joda.time.Partial partial69 = new org.joda.time.Partial(dateTimeFieldType56, 1970, chronology68);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must not be larger than 999");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-21589903L) + "'", long35 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 999 + "'", int49 == 999);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2" + "'", str51.equals("2"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-26438399968L) + "'", long55 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 72 + "'", int58 == 72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(chronology68);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property12.getAsShortText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property12.getField();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond(1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendPattern("2019-06-05");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.appendDayOfMonth(1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder17.appendCenturyOfEra((int) (byte) 10, 97);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, readableInstant28);
//        org.joda.time.DurationField durationField30 = gJChronology29.centuries();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology29);
//        org.joda.time.DateTime dateTime33 = dateTime31.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        org.joda.time.DateTime dateTime40 = property39.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter41.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.ReadableInstant readableInstant45 = null;
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, readableInstant45);
//        org.joda.time.DurationField durationField47 = gJChronology46.centuries();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology46);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter41.withChronology((org.joda.time.Chronology) gJChronology46);
//        long long55 = gJChronology46.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean57 = gJChronology46.equals((java.lang.Object) gJChronology56);
//        org.joda.time.DateTimeField dateTimeField58 = gJChronology46.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.ReadableInstant readableInstant61 = null;
//        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60, readableInstant61);
//        org.joda.time.DurationField durationField63 = gJChronology62.centuries();
//        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology62);
//        org.joda.time.DateTimeField dateTimeField65 = gJChronology62.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology59, dateTimeField65, 100);
//        int int69 = skipUndoDateTimeField67.getMaximumValue((long) (short) -1);
//        java.lang.String str71 = skipUndoDateTimeField67.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField67, 46);
//        long long75 = offsetDateTimeField73.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = offsetDateTimeField73.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58, dateTimeFieldType76);
//        int int78 = dateTime40.get(dateTimeFieldType76);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder26.appendFixedDecimal(dateTimeFieldType76, 4);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField84 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType76, (int) (byte) 0, 16, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "23" + "'", str15.equals("23"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-21589903L) + "'", long55 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(gJChronology62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 999 + "'", int69 == 999);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "2" + "'", str71.equals("2"));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-26438399968L) + "'", long75 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 108 + "'", int78 == 108);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        boolean boolean15 = offsetDateTimeField14.isLenient();
        long long17 = offsetDateTimeField14.roundHalfFloor((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.withYearOfCentury((int) 'a');
        int int22 = localDate19.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        boolean boolean24 = localDate19.isSupported(dateTimeFieldType23);
        org.joda.time.LocalDate localDate26 = localDate19.minusMonths(31);
        org.joda.time.LocalDate localDate28 = localDate19.minusYears(10);
        int[] intArray30 = null;
        try {
            int[] intArray32 = offsetDateTimeField14.add((org.joda.time.ReadablePartial) localDate19, 35, intArray30, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.withZoneRetainFields(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DurationField durationField14 = gJChronology13.centuries();
//        boolean boolean15 = dateTime8.equals((java.lang.Object) gJChronology13);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.Chronology chronology21 = gJChronology13.withZone(dateTimeZone17);
//        org.joda.time.Interval interval22 = localDate1.toInterval(dateTimeZone17);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pacific Standard Time" + "'", str19.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(interval22);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        try {
            long long13 = gJChronology2.getDateTimeMillis(166, 1970, 7, 4, 0, 1970, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        java.lang.String str6 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField7 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField7, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str6.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate5 = property4.roundFloorCopy();
        int int6 = localDate5.getYearOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.toString();
        java.util.Locale locale50 = null;
        try {
            int int51 = unsupportedDateTimeField45.getMaximumShortTextLength(locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UnsupportedDateTimeField" + "'", str49.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "51");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
        long long13 = skipUndoDateTimeField8.add((long) 3, 0);
        long long15 = skipUndoDateTimeField8.roundHalfEven((long) 6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 6L + "'", long15 == 6L);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        int int68 = skipUndoDateTimeField8.get((long) 6);
//        long long71 = skipUndoDateTimeField8.set((long) (-101), "51");
//        java.lang.String str73 = skipUndoDateTimeField8.getAsText((long) 53);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 7 + "'", int68 == 7);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-949L) + "'", long71 == (-949L));
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "53" + "'", str73.equals("53"));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField45.getType();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(dateTimeZone48);
        org.joda.time.LocalDate localDate51 = localDate49.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate53 = localDate49.withYearOfEra(9);
        org.joda.time.LocalDate localDate55 = localDate53.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
        boolean boolean57 = localDate53.isSupported(dateTimeFieldType56);
        int[] intArray59 = null;
        try {
            int[] intArray61 = unsupportedDateTimeField45.add((org.joda.time.ReadablePartial) localDate53, 1045, intArray59, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10, (java.lang.Number) (byte) 10, (java.lang.Number) (-1));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property56 = dateTime55.secondOfMinute();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone47, (org.joda.time.ReadableInstant) dateTime55, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property56);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField45.getLeapDurationField();
        long long50 = unsupportedDateTimeField45.add((long) 47, (-28800000));
        java.lang.String str51 = unsupportedDateTimeField45.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-103679999999953L) + "'", long50 == (-103679999999953L));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "UnsupportedDateTimeField" + "'", str51.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendHourOfHalfday(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay(946);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfYear(20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        java.util.Locale locale16 = null;
        int int17 = skipUndoDateTimeField8.getMaximumShortTextLength(locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property22 = localDate19.dayOfWeek();
        boolean boolean24 = property22.equals((java.lang.Object) 0L);
        org.joda.time.LocalDate localDate26 = property22.addWrapFieldToCopy(5);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone28);
        org.joda.time.LocalDate localDate31 = localDate29.withYearOfCentury((int) 'a');
        boolean boolean33 = localDate31.equals((java.lang.Object) "hi!");
        org.joda.time.LocalDate localDate35 = localDate31.minusYears((int) '4');
        org.joda.time.LocalDate localDate37 = localDate31.withYearOfCentury((int) '#');
        org.joda.time.LocalDate localDate39 = localDate31.minusDays(10);
        org.joda.time.Partial partial40 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate31);
        int[] intArray41 = partial40.getValues();
        try {
            int[] intArray43 = skipUndoDateTimeField8.add((org.joda.time.ReadablePartial) localDate26, 100, intArray41, (-17174488));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(intArray41);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = localDate21.toString("-07:52:58", locale23);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-07:52:58" + "'", str24.equals("-07:52:58"));
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.String str13 = dateTime9.toString(dateTimeFormatter12);
//        int int14 = dateTime9.getYearOfEra();
//        int int15 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime9.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-05" + "'", str13.equals("2019-06-05"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56829 + "'", int15 == 56829);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.DurationField durationField7 = gJChronology2.halfdays();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(47, 0, 721);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
//        int int7 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfEra(946);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = dateTime2.toDateTime(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 47 + "'", int7 == 47);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            long long3 = dateTimeFormatter0.parseMillis("9");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"9\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.Interval interval22 = localDate21.toInterval();
//        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval22);
//        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertNotNull(readableInterval23);
//        org.junit.Assert.assertNotNull(readableInterval24);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.LocalDate.Property property22 = localDate21.monthOfYear();
//        org.joda.time.LocalDate localDate23 = property22.withMinimumValue();
//        java.util.Locale locale25 = null;
//        try {
//            org.joda.time.LocalDate localDate26 = property22.setCopy("Pacific Standard Time", locale25);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(localDate23);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        boolean boolean4 = dateTime0.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.plus((long) (short) 0);
        try {
            org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear(721);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 721 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference((-61828157222000L), (long) (byte) 10);
        try {
            long long52 = unsupportedDateTimeField45.set((long) 70, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-17174488) + "'", int49 == (-17174488));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean35 = offsetDateTimeField14.isSupported();
        int int36 = offsetDateTimeField14.getMinimumValue();
        long long39 = offsetDateTimeField14.set((long) (byte) 10, "999");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 47 + "'", int36 == 47);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 953L + "'", long39 == 953L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PST\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"PST\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusYears((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
//        org.joda.time.DurationField durationField15 = gJChronology14.centuries();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology14);
//        long long23 = gJChronology14.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean25 = gJChronology14.equals((java.lang.Object) gJChronology24);
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology14.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
//        org.joda.time.DurationField durationField31 = gJChronology30.centuries();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField33, 100);
//        int int37 = skipUndoDateTimeField35.getMaximumValue((long) (short) -1);
//        java.lang.String str39 = skipUndoDateTimeField35.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 46);
//        long long43 = offsetDateTimeField41.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField41.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology48.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology48.hourOfHalfday();
//        org.joda.time.Chronology chronology52 = gJChronology48.withUTC();
//        org.joda.time.DurationField durationField53 = gJChronology48.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField54 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField53);
//        int int55 = dateTime8.get(dateTimeFieldType44);
//        try {
//            org.joda.time.DateTime dateTime57 = dateTime8.withDayOfMonth((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-21589903L) + "'", long23 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2" + "'", str39.equals("2"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-26438399968L) + "'", long43 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 624 + "'", int55 == 624);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        int int68 = skipUndoDateTimeField8.get((long) 6);
//        long long71 = skipUndoDateTimeField8.set((long) (-101), "51");
//        long long73 = skipUndoDateTimeField8.roundCeiling((-61967603212988L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 7 + "'", int68 == 7);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-949L) + "'", long71 == (-949L));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-61967603212988L) + "'", long73 == (-61967603212988L));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference((-61828157222000L), (long) (byte) 10);
        try {
            long long51 = unsupportedDateTimeField45.roundHalfEven((long) 56778313);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-17174488) + "'", int49 == (-17174488));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("(\"org.joda.time.JodaTimePermission\" \"PST\")", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addCutover(16, 'a', 0, 35, (int) (byte) 0, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate3.equals((java.lang.Object) "hi!");
        org.joda.time.LocalDate localDate7 = localDate3.minusYears((int) '4');
        org.joda.time.LocalDate localDate9 = localDate3.withYearOfCentury((int) '#');
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
//        org.joda.time.LocalDate localDate7 = localDate5.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property8 = localDate5.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate12 = localDate10.withYearOfCentury((int) 'a');
//        boolean boolean13 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate17 = localDate15.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate15.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval21 = localDate15.toInterval(dateTimeZone20);
//        java.lang.String str23 = dateTimeZone20.getShortName((long) 'a');
//        org.joda.time.Interval interval24 = localDate5.toInterval(dateTimeZone20);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
//        org.joda.time.DurationField durationField31 = gJChronology30.centuries();
//        boolean boolean32 = dateTime25.equals((java.lang.Object) gJChronology30);
//        java.util.Locale locale33 = null;
//        java.util.Calendar calendar34 = dateTime25.toCalendar(locale33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property39 = localDate36.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(dateTimeZone40);
//        org.joda.time.LocalDate localDate43 = localDate41.withYearOfCentury((int) 'a');
//        boolean boolean44 = localDate36.isBefore((org.joda.time.ReadablePartial) localDate43);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(dateTimeZone45);
//        org.joda.time.LocalDate localDate48 = localDate46.withYearOfCentury((int) 'a');
//        boolean boolean50 = localDate46.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval52 = localDate46.toInterval(dateTimeZone51);
//        java.lang.String str54 = dateTimeZone51.getShortName((long) 'a');
//        org.joda.time.Interval interval55 = localDate36.toInterval(dateTimeZone51);
//        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.now(dateTimeZone51);
//        org.joda.time.DateTime dateTime57 = dateTime25.toDateTime(dateTimeZone51);
//        org.joda.time.DateTime dateTime58 = localDate5.toDateTimeAtStartOfDay(dateTimeZone51);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology59 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone51);
//        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
//        org.joda.time.Chronology chronology61 = iSOChronology0.withZone(dateTimeZone51);
//        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(interval24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(calendar34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(interval52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PST" + "'", str54.equals("PST"));
//        org.junit.Assert.assertNotNull(interval55);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(buddhistChronology59);
//        org.junit.Assert.assertNotNull(julianChronology60);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(julianChronology62);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DurationField durationField5 = gJChronology3.months();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
//        org.joda.time.LocalDate localDate9 = localDate7.withYearOfCentury((int) 'a');
//        boolean boolean11 = localDate9.equals((java.lang.Object) "hi!");
//        int[] intArray13 = gJChronology3.get((org.joda.time.ReadablePartial) localDate9, (long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate17 = localDate15.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate15.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval21 = localDate15.toInterval(dateTimeZone20);
//        java.lang.String str23 = dateTimeZone20.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, 3);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
//        org.joda.time.DurationField durationField32 = gJChronology31.centuries();
//        boolean boolean33 = dateTime26.equals((java.lang.Object) gJChronology31);
//        java.util.Locale locale34 = null;
//        java.util.Calendar calendar35 = dateTime26.toCalendar(locale34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property40 = localDate37.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean45 = localDate37.isBefore((org.joda.time.ReadablePartial) localDate44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
//        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate47.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval53 = localDate47.toInterval(dateTimeZone52);
//        java.lang.String str55 = dateTimeZone52.getShortName((long) 'a');
//        org.joda.time.Interval interval56 = localDate37.toInterval(dateTimeZone52);
//        org.joda.time.LocalDate localDate57 = org.joda.time.LocalDate.now(dateTimeZone52);
//        org.joda.time.DateTime dateTime58 = dateTime26.toDateTime(dateTimeZone52);
//        org.joda.time.Chronology chronology59 = copticChronology25.withZone(dateTimeZone52);
//        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology25);
//        try {
//            org.joda.time.Partial partial61 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray13, chronology60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(calendar35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PST" + "'", str55.equals("PST"));
//        org.junit.Assert.assertNotNull(interval56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(chronology60);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        try {
            int[] intArray21 = gJChronology5.get(readablePeriod18, 0L, (-61828157222000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        boolean boolean4 = dateTime0.isEqual((long) (short) 0);
//        org.joda.time.DateTime dateTime6 = dateTime0.plus((long) (short) 0);
//        org.joda.time.DateTime dateTime8 = dateTime0.withWeekOfWeekyear(2);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours(1970);
//        java.lang.String str13 = dateTime12.toString();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-04-04T18:47:11.500-07:00" + "'", str13.equals("2019-04-04T18:47:11.500-07:00"));
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        int int4 = localDate1.getYearOfEra();
//        int int5 = localDate1.getDayOfYear();
//        org.joda.time.DurationFieldType durationFieldType6 = null;
//        boolean boolean7 = localDate1.isSupported(durationFieldType6);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 166 + "'", int5 == 166);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        java.lang.String str47 = unsupportedDateTimeField45.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField45.getLeapDurationField();
        try {
            java.lang.String str50 = unsupportedDateTimeField45.getAsText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField48);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate(dateTimeZone67);
//        org.joda.time.LocalDate localDate70 = localDate68.withYearOfCentury((int) 'a');
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate68, (int) (byte) 100, locale72);
//        java.lang.String str75 = skipUndoDateTimeField8.getAsText(2L);
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate(dateTimeZone76);
//        org.joda.time.LocalDate localDate79 = localDate77.withYearOfCentury((int) 'a');
//        boolean boolean81 = localDate77.equals((java.lang.Object) (short) -1);
//        java.lang.Object obj82 = null;
//        boolean boolean83 = localDate77.equals(obj82);
//        org.joda.time.LocalDate localDate85 = localDate77.minusDays(0);
//        int[] intArray86 = localDate85.getValues();
//        int int87 = skipUndoDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate85);
//        boolean boolean89 = skipUndoDateTimeField8.isLeap((long) (-1));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "100" + "'", str73.equals("100"));
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2" + "'", str75.equals("2"));
//        org.junit.Assert.assertNotNull(localDate79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(localDate85);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 999 + "'", int87 == 999);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        long long18 = skipUndoDateTimeField8.add(55L, (long) 47);
        int int19 = skipUndoDateTimeField8.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 102L + "'", long18 == 102L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", number1, (java.lang.Number) 2440587.500000035d, (java.lang.Number) (short) 0);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 56829);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField45.getLeapDurationField();
        try {
            long long49 = unsupportedDateTimeField45.roundFloor(23L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("BuddhistChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[America/Los_A...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.Chronology chronology4 = gJChronology2.withUTC();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology2.add(readablePeriod5, (long) '#', 999);
        try {
            long long14 = gJChronology2.getDateTimeMillis(1036L, (int) '4', 0, 31, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
//        org.joda.time.DurationField durationField4 = gJChronology2.months();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property9 = localDate6.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean14 = localDate6.isBefore((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate16.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval22 = localDate16.toInterval(dateTimeZone21);
//        java.lang.String str24 = dateTimeZone21.getShortName((long) 'a');
//        org.joda.time.Interval interval25 = localDate6.toInterval(dateTimeZone21);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
//        org.joda.time.DurationField durationField32 = gJChronology31.centuries();
//        boolean boolean33 = dateTime26.equals((java.lang.Object) gJChronology31);
//        java.util.Locale locale34 = null;
//        java.util.Calendar calendar35 = dateTime26.toCalendar(locale34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property40 = localDate37.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean45 = localDate37.isBefore((org.joda.time.ReadablePartial) localDate44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
//        org.joda.time.LocalDate localDate49 = localDate47.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate47.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval53 = localDate47.toInterval(dateTimeZone52);
//        java.lang.String str55 = dateTimeZone52.getShortName((long) 'a');
//        org.joda.time.Interval interval56 = localDate37.toInterval(dateTimeZone52);
//        org.joda.time.LocalDate localDate57 = org.joda.time.LocalDate.now(dateTimeZone52);
//        org.joda.time.DateTime dateTime58 = dateTime26.toDateTime(dateTimeZone52);
//        org.joda.time.DateTime dateTime59 = localDate6.toDateTimeAtStartOfDay(dateTimeZone52);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology60 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
//        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone52);
//        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology61);
//        org.joda.time.DateTimeZone dateTimeZone63 = julianChronology61.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology64 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone63);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertNotNull(interval25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(calendar35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PST" + "'", str55.equals("PST"));
//        org.junit.Assert.assertNotNull(interval56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(buddhistChronology60);
//        org.junit.Assert.assertNotNull(julianChronology61);
//        org.junit.Assert.assertNotNull(chronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(zonedChronology64);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.LocalDate.Property property22 = localDate21.monthOfYear();
//        org.joda.time.LocalDate localDate23 = property22.withMinimumValue();
//        org.joda.time.LocalDate localDate25 = property22.addToCopy(1);
//        org.joda.time.LocalDate localDate26 = property22.roundFloorCopy();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(localDate26);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, 3);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DurationField durationField18 = gJChronology17.centuries();
//        boolean boolean19 = dateTime12.equals((java.lang.Object) gJChronology17);
//        java.util.Locale locale20 = null;
//        java.util.Calendar calendar21 = dateTime12.toCalendar(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property26 = localDate23.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.withYearOfCentury((int) 'a');
//        boolean boolean31 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) 'a');
//        boolean boolean37 = localDate33.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
//        java.lang.String str41 = dateTimeZone38.getShortName((long) 'a');
//        org.joda.time.Interval interval42 = localDate23.toInterval(dateTimeZone38);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime12.toDateTime(dateTimeZone38);
//        org.joda.time.Chronology chronology45 = copticChronology11.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, readableInstant47);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.hourOfHalfday();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology48);
//        boolean boolean51 = copticChronology11.equals((java.lang.Object) gJChronology48);
//        org.joda.time.DateTimeZone dateTimeZone52 = gJChronology48.getZone();
//        org.joda.time.Chronology chronology53 = gJChronology48.withUTC();
//        org.joda.time.Chronology chronology54 = gJChronology48.withUTC();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(interval39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(interval42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(chronology54);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference((-61828157222000L), (long) (byte) 10);
        try {
            long long52 = unsupportedDateTimeField45.set((long) (byte) -1, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-17174488) + "'", int49 == (-17174488));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(47, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter9.getZone();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withLocale(locale11);
        java.lang.String str13 = instant8.toString(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1582-W41-5T00:00:00.000Z" + "'", str13.equals("1582-W41-5T00:00:00.000Z"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(69900L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
//        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
//        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
//        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
//        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
//        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
//        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
//        org.joda.time.DurationField durationField44 = gJChronology39.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
//        java.lang.String str46 = unsupportedDateTimeField45.getName();
//        java.lang.String str47 = unsupportedDateTimeField45.toString();
//        org.joda.time.DurationField durationField48 = unsupportedDateTimeField45.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str51 = dateTimeZone49.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
//        org.joda.time.LocalDate localDate53 = org.joda.time.LocalDate.now((org.joda.time.Chronology) julianChronology52);
//        java.util.Locale locale54 = null;
//        try {
//            java.lang.String str55 = unsupportedDateTimeField45.getAsShortText((org.joda.time.ReadablePartial) localDate53, locale54);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Pacific Standard Time" + "'", str51.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(localDate53);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology2.getZone();
        org.joda.time.DurationField durationField7 = gJChronology2.minutes();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology2.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference((-61828157222000L), (long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, readableInstant54);
        org.joda.time.DurationField durationField56 = gJChronology55.centuries();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology55);
        org.joda.time.DateTimeField dateTimeField58 = gJChronology55.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology52, dateTimeField58, 100);
        int int62 = skipUndoDateTimeField60.getMaximumValue((long) (short) -1);
        java.lang.String str64 = skipUndoDateTimeField60.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField60, 46);
        long long68 = offsetDateTimeField66.roundHalfEven((long) '#');
        long long70 = offsetDateTimeField66.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate(dateTimeZone71);
        org.joda.time.LocalDate localDate74 = localDate72.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property75 = localDate72.dayOfWeek();
        org.joda.time.LocalDate localDate77 = localDate72.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate79 = localDate72.withYearOfEra(1);
        int[] intArray85 = new int[] { 0, 2, 2019, 24, 'a' };
        int int86 = offsetDateTimeField66.getMaximumValue((org.joda.time.ReadablePartial) localDate79, intArray85);
        java.util.Locale locale88 = null;
        try {
            int[] intArray89 = unsupportedDateTimeField45.set(readablePartial50, (int) '4', intArray85, "Pacific Standard Time", locale88);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-17174488) + "'", int49 == (-17174488));
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 999 + "'", int62 == 999);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2" + "'", str64.equals("2"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 35L + "'", long68 == 35L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1045 + "'", int86 == 1045);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        int int5 = localDate1.getYear();
        org.joda.time.LocalDate localDate7 = localDate1.minusMonths(100);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        long long9 = gJChronology2.add((long) 6, (long) 946, 999);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 945060L + "'", long9 == 945060L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean3 = property1.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTime dateTime4 = property1.roundHalfEvenCopy();
        boolean boolean5 = property1.isLeap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.centuries();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField13, 100);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField15.getAsShortText((long) (byte) 1, locale17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
        org.joda.time.DurationField durationField23 = gJChronology21.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, durationField23, dateTimeFieldType24);
        int int26 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        boolean boolean8 = gJChronology2.equals((java.lang.Object) dateTime6);
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        java.lang.String str3 = property1.toString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[secondOfMinute]" + "'", str3.equals("Property[secondOfMinute]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DurationField durationField21 = gJChronology20.centuries();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField23, 100);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField25.getAsShortText((long) (byte) 1, locale27);
        long long31 = skipUndoDateTimeField25.set((long) 'a', 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 0);
        int int34 = skipUndoDateTimeField25.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Pacific Standard Time' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
//        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
//        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
//        long long18 = offsetDateTimeField14.roundFloor((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
//        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
//        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
//        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
//        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
//        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
//        boolean boolean35 = offsetDateTimeField14.isSupported();
//        int int37 = offsetDateTimeField14.getMaximumValue(166L);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField14.getAsShortText(0, locale39);
//        org.joda.time.DurationField durationField41 = offsetDateTimeField14.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.LocalDate.Property property64 = localDate63.monthOfYear();
//        java.util.Locale locale65 = null;
//        try {
//            java.lang.String str66 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate63, locale65);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1045 + "'", int37 == 1045);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(property64);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        boolean boolean6 = property4.equals((java.lang.Object) 0L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        long long11 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.joda.time.Instant instant10 = instant8.minus((long) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("JulianChronology[America/Los_Angeles]", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addCutover(853, 'a', 100, 100, (int) '4', true, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime14 = property12.setCopy(0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(9);
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(4);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology55.minuteOfDay();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-1), true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.centuries();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology10);
        long long19 = gJChronology10.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean21 = gJChronology10.equals((java.lang.Object) gJChronology20);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology10.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField29, 100);
        int int33 = skipUndoDateTimeField31.getMaximumValue((long) (short) -1);
        java.lang.String str35 = skipUndoDateTimeField31.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField31, 46);
        long long39 = offsetDateTimeField37.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField37.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType40);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, readableInstant43);
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology44.yearOfEra();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology44.hourOfHalfday();
        org.joda.time.Chronology chronology48 = gJChronology44.withUTC();
        org.joda.time.DurationField durationField49 = gJChronology44.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType40, 1, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-21589903L) + "'", long19 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2" + "'", str35.equals("2"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-26438399968L) + "'", long39 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate5 = localDate3.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property6 = localDate3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.withYearOfCentury((int) 'a');
//        boolean boolean11 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
//        boolean boolean17 = localDate13.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval19 = localDate13.toInterval(dateTimeZone18);
//        java.lang.String str21 = dateTimeZone18.getShortName((long) 'a');
//        org.joda.time.Interval interval22 = localDate3.toInterval(dateTimeZone18);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.withZoneRetainFields(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
//        org.joda.time.DurationField durationField29 = gJChronology28.centuries();
//        boolean boolean30 = dateTime23.equals((java.lang.Object) gJChronology28);
//        java.util.Locale locale31 = null;
//        java.util.Calendar calendar32 = dateTime23.toCalendar(locale31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone33);
//        org.joda.time.LocalDate localDate36 = localDate34.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property37 = localDate34.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(dateTimeZone38);
//        org.joda.time.LocalDate localDate41 = localDate39.withYearOfCentury((int) 'a');
//        boolean boolean42 = localDate34.isBefore((org.joda.time.ReadablePartial) localDate41);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
//        org.joda.time.LocalDate localDate46 = localDate44.withYearOfCentury((int) 'a');
//        boolean boolean48 = localDate44.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval50 = localDate44.toInterval(dateTimeZone49);
//        java.lang.String str52 = dateTimeZone49.getShortName((long) 'a');
//        org.joda.time.Interval interval53 = localDate34.toInterval(dateTimeZone49);
//        org.joda.time.LocalDate localDate54 = org.joda.time.LocalDate.now(dateTimeZone49);
//        org.joda.time.DateTime dateTime55 = dateTime23.toDateTime(dateTimeZone49);
//        org.joda.time.DateTime dateTime56 = localDate3.toDateTimeAtStartOfDay(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.MutableDateTime mutableDateTime58 = dateTime56.toMutableDateTime(dateTimeZone57);
//        int int59 = mutableDateTime58.getYearOfEra();
//        int int62 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime58, "100", 100);
//        boolean boolean63 = dateTimeFormatter0.isPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter64 = dateTimeFormatter0.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(interval19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(calendar32);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(interval50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PST" + "'", str52.equals("PST"));
//        org.junit.Assert.assertNotNull(interval53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-101) + "'", int62 == (-101));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter64);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks(0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(47, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate5 = property4.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.withYearOfCentury((int) 'a');
        boolean boolean11 = localDate7.equals((java.lang.Object) (short) -1);
        java.lang.Object obj12 = null;
        boolean boolean13 = localDate7.equals(obj12);
        org.joda.time.LocalDate localDate15 = localDate7.minusDays(0);
        int[] intArray16 = localDate15.getValues();
        boolean boolean17 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate.Property property18 = localDate15.yearOfCentury();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        boolean boolean4 = dateTime0.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.plus((long) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime0.withWeekOfWeekyear(2);
        org.joda.time.DateTime dateTime9 = dateTime8.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj6 = null;
        boolean boolean7 = localDate1.equals(obj6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate1.toDateTime(localTime8);
        boolean boolean11 = dateTime9.isBefore((long) '4');
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, (int) (byte) 1, 10, 0, (int) 'a', 3570);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYear();
        org.joda.time.LocalDate localDate4 = localDate1.withDayOfMonth(1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName((long) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.clockhourOfHalfday();
//        long long9 = julianChronology3.getDateTimeMillis((int) (short) 10, (int) (short) 10, (int) (byte) 1, 0);
//        long long14 = julianChronology3.getDateTimeMillis((int) '4', (int) (short) 10, 7, (int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        org.joda.time.DurationField durationField19 = gJChronology18.centuries();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField21, 100);
//        int int25 = skipUndoDateTimeField23.getMaximumValue((long) (short) -1);
//        java.lang.String str27 = skipUndoDateTimeField23.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 46);
//        long long31 = offsetDateTimeField29.roundHalfEven((long) '#');
//        long long33 = offsetDateTimeField29.roundFloor((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(dateTimeZone34);
//        org.joda.time.LocalDate localDate37 = localDate35.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property38 = localDate35.dayOfWeek();
//        org.joda.time.LocalDate localDate40 = localDate35.withYearOfEra((int) (byte) 100);
//        org.joda.time.LocalDate localDate42 = localDate35.withYearOfEra(1);
//        int[] intArray48 = new int[] { 0, 2, 2019, 24, 'a' };
//        int int49 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate42, intArray48);
//        boolean boolean51 = offsetDateTimeField29.isLeap(0L);
//        boolean boolean52 = offsetDateTimeField29.isSupported();
//        boolean boolean54 = offsetDateTimeField29.isLeap(55L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology3, (org.joda.time.DateTimeField) offsetDateTimeField29);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = skipDateTimeField55.getAsShortText((long) 56829, locale57);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61828157222000L) + "'", long9 == (-61828157222000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60502176421900L) + "'", long14 == (-60502176421900L));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2" + "'", str27.equals("2"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1045 + "'", int49 == 1045);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "875" + "'", str58.equals("875"));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Partial partial10 = partial7.withFieldAdded(durationFieldType8, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        boolean boolean35 = offsetDateTimeField14.isSupported();
        int int37 = offsetDateTimeField14.getMaximumValue(166L);
        long long40 = offsetDateTimeField14.getDifferenceAsLong((long) (short) 100, (long) (byte) -1);
        org.joda.time.DurationField durationField41 = offsetDateTimeField14.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1045 + "'", int37 == 1045);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 101L + "'", long40 == 101L);
        org.junit.Assert.assertNull(durationField41);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField45.getType();
        try {
            long long49 = unsupportedDateTimeField45.roundCeiling((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
//        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gJChronology5);
//        int int9 = dateTime2.getDayOfWeek();
//        int int10 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime17 = dateTime16.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTimeISO();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime17.withDurationAdded(readableDuration19, 0);
//        int int22 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundHalfEven(0L);
        int int19 = offsetDateTimeField14.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 47 + "'", int19 == 47);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, (-1));
        boolean boolean17 = skipUndoDateTimeField8.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("2019-06-05");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (byte) 10, 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfSecond(86399999, 2019);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendMinuteOfDay((-17174488));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 721, 97, 7, 47, 3570, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3570 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        long long68 = skipUndoDateTimeField8.roundCeiling(0L);
//        org.joda.time.DurationField durationField69 = skipUndoDateTimeField8.getLeapDurationField();
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = skipUndoDateTimeField8.getAsText(20, locale71);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate((long) 70);
//        int[] intArray78 = new int[] { 100, 6 };
//        try {
//            int[] intArray80 = skipUndoDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate74, 946, intArray78, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "20" + "'", str72.equals("20"));
//        org.junit.Assert.assertNotNull(intArray78);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime14 = property12.addToCopy(0L);
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        boolean boolean15 = offsetDateTimeField14.isLenient();
        long long17 = offsetDateTimeField14.remainder((long) 6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekyear();
        org.joda.time.DurationField durationField4 = gJChronology2.weekyears();
        int int5 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        int int4 = localDate1.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate localDate8 = localDate1.minusMonths(31);
        org.joda.time.LocalDate localDate10 = localDate1.minusYears(10);
        org.joda.time.LocalDate localDate12 = localDate1.minusMonths(10);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.hourOfHalfday();
        org.joda.time.DurationField durationField16 = gJChronology14.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, durationField16, dateTimeFieldType17);
        int int20 = skipUndoDateTimeField8.getMinimumValue((long) 99);
        java.util.Locale locale21 = null;
        int int22 = skipUndoDateTimeField8.getMaximumTextLength(locale21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(47, false);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean3 = property1.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTime dateTime4 = property1.getDateTime();
        java.lang.String str5 = property1.getName();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "secondOfMinute" + "'", str5.equals("secondOfMinute"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundHalfEven(0L);
        long long20 = offsetDateTimeField14.roundHalfFloor(19L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 19L + "'", long20 == 19L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
        boolean boolean20 = localDate16.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval22 = localDate16.toInterval(dateTimeZone21);
        int int23 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        org.joda.time.LocalDate localDate27 = localDate25.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property28 = localDate25.dayOfWeek();
        org.joda.time.LocalDate localDate30 = localDate25.minusWeeks(999);
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate25, (-1), locale32);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1045 + "'", int23 == 1045);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-1" + "'", str33.equals("-1"));
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, readableInstant25);
//        org.joda.time.DurationField durationField27 = gJChronology26.centuries();
//        boolean boolean28 = dateTime21.equals((java.lang.Object) gJChronology26);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime21.toCalendar(locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
//        org.joda.time.LocalDate localDate34 = localDate32.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property35 = localDate32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
//        boolean boolean40 = localDate32.isBefore((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone41);
//        org.joda.time.LocalDate localDate44 = localDate42.withYearOfCentury((int) 'a');
//        boolean boolean46 = localDate42.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval48 = localDate42.toInterval(dateTimeZone47);
//        java.lang.String str50 = dateTimeZone47.getShortName((long) 'a');
//        org.joda.time.Interval interval51 = localDate32.toInterval(dateTimeZone47);
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime21.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = localDate1.toDateTimeAtStartOfDay(dateTimeZone47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
//        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology56);
//        org.joda.time.DateTimeZone dateTimeZone58 = julianChronology56.getZone();
//        boolean boolean60 = dateTimeZone58.isStandardOffset((long) 57600);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(interval48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertNotNull(interval51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(buddhistChronology55);
//        org.junit.Assert.assertNotNull(julianChronology56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) 100);
//        long long26 = property23.remainder();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 14256000000L + "'", long26 == 14256000000L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay2 = dateTime0.toTimeOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(timeOfDay2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField14.getMaximumTextLength(locale19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("100");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial10 = partial7.withPeriodAdded(readablePeriod8, (int) (short) 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        boolean boolean15 = dateTime11.isEqual((long) (short) 0);
        org.joda.time.DateTime dateTime17 = dateTime11.plus((long) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime11.withWeekOfWeekyear(2);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        boolean boolean22 = partial7.isMatch((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.Partial partial24 = partial7.minus(readablePeriod23);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(partial24);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        int int10 = dateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.hourOfHalfday();
//        org.joda.time.DurationField durationField15 = gJChronology13.months();
//        org.joda.time.DurationField durationField16 = gJChronology13.hours();
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology13.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime6.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime6.toDateTimeISO();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 947 + "'", int10 == 947);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withPeriodAdded(readablePeriod7, (int) (short) 100);
        org.joda.time.DateTime.Property property10 = dateTime5.weekyear();
        java.lang.String str11 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate1.getFields();
        boolean boolean9 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate1.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate localDate13 = localDate1.plusDays(9);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        long long20 = offsetDateTimeField14.roundHalfEven((long) 166);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
        org.joda.time.DateTimeField[] dateTimeFieldArray29 = localDate22.getFields();
        boolean boolean30 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = localDate22.isSupported(dateTimeFieldType31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate22, (int) (byte) 0, locale34);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
        org.joda.time.LocalDate localDate39 = localDate37.withYearOfCentury((int) 'a');
        boolean boolean41 = localDate37.equals((java.lang.Object) (short) -1);
        java.lang.Object obj42 = null;
        boolean boolean43 = localDate37.equals(obj42);
        org.joda.time.LocalDate localDate45 = localDate37.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType46 = null;
        boolean boolean47 = localDate45.isSupported(durationFieldType46);
        org.joda.time.LocalDate.Property property48 = localDate45.era();
        int int49 = localDate45.getMonthOfYear();
        int int50 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate45);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 166L + "'", long20 == 166L);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(interval28);
        org.junit.Assert.assertNotNull(dateTimeFieldArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 47 + "'", int50 == 47);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.LocalDate.Property property23 = localDate21.yearOfCentury();
//        int int24 = localDate21.getCenturyOfEra();
//        org.joda.time.LocalDate localDate26 = localDate21.withYearOfEra(1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
//        org.junit.Assert.assertNotNull(localDate26);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        long long18 = skipUndoDateTimeField8.add(55L, (long) 47);
        java.lang.String str20 = skipUndoDateTimeField8.getAsText((long) 86399999);
        long long23 = skipUndoDateTimeField8.add(1046L, 0);
        org.joda.time.DurationField durationField24 = skipUndoDateTimeField8.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 102L + "'", long18 == 102L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "999" + "'", str20.equals("999"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1046L + "'", long23 == 1046L);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.joda.time.Chronology chronology7 = instant6.getChronology();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField45.getLeapDurationField();
        try {
            long long49 = unsupportedDateTimeField45.roundHalfEven((long) (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay2 = dateTime0.toTimeOfDay();
        org.joda.time.DateTime dateTime4 = dateTime0.withYear((-28800000));
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(timeOfDay2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundCeiling((-26438399968L));
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((java.lang.Object) long16, dateTimeZone17);
        int int19 = localDate18.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-26438399968L) + "'", long16 == (-26438399968L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField50 = unsupportedDateTimeField45.getDurationField();
        try {
            long long53 = unsupportedDateTimeField45.set((-61828070822001L), 960);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "millisOfSecond" + "'", str49.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField50);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant9 = instant7.plus((long) 59);
        org.joda.time.Instant instant12 = instant9.withDurationAdded((long) (short) 10, 99);
        org.joda.time.MutableDateTime mutableDateTime13 = instant12.toMutableDateTimeISO();
        int int14 = mutableDateTime13.getMinuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property23 = localDate20.dayOfWeek();
        org.joda.time.LocalDate localDate25 = localDate20.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(1);
        int[] intArray33 = new int[] { 0, 2, 2019, 24, 'a' };
        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray33);
        int int37 = offsetDateTimeField14.getDifference((long) 999, 23L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1045 + "'", int34 == 1045);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 976 + "'", int37 == 976);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
        org.joda.time.DurationField durationField8 = gJChronology5.halfdays();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology2.months();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.Chronology chronology6 = gJChronology2.withUTC();
        org.joda.time.Instant instant7 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant9 = instant7.minus(10L);
        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        java.lang.String str15 = gJChronology5.toString();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology5.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str15.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.centuries();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property12.getAsShortText(locale14);
//        java.util.Locale locale16 = null;
//        int int17 = property12.getMaximumTextLength(locale16);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "23" + "'", str15.equals("23"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 1);
//        java.lang.String str10 = dateTime5.toString(dateTimeFormatter7);
//        org.joda.time.DateTime.Property property11 = dateTime5.yearOfCentury();
//        org.joda.time.DurationField durationField12 = property11.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-05" + "'", str10.equals("2019-06-05"));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.getName();
        org.joda.time.DurationField durationField50 = unsupportedDateTimeField45.getDurationField();
        try {
            long long53 = unsupportedDateTimeField45.addWrapField((long) 721, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "millisOfSecond" + "'", str49.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(durationField50);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getLeapAmount((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property15 = localDate12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) 'a');
//        boolean boolean20 = localDate12.isBefore((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
//        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
//        java.lang.String str30 = dateTimeZone27.getShortName((long) 'a');
//        org.joda.time.Interval interval31 = localDate12.toInterval(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, readableInstant36);
//        org.joda.time.DurationField durationField38 = gJChronology37.centuries();
//        boolean boolean39 = dateTime32.equals((java.lang.Object) gJChronology37);
//        java.util.Locale locale40 = null;
//        java.util.Calendar calendar41 = dateTime32.toCalendar(locale40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate45 = localDate43.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property46 = localDate43.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone47);
//        org.joda.time.LocalDate localDate50 = localDate48.withYearOfCentury((int) 'a');
//        boolean boolean51 = localDate43.isBefore((org.joda.time.ReadablePartial) localDate50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone52);
//        org.joda.time.LocalDate localDate55 = localDate53.withYearOfCentury((int) 'a');
//        boolean boolean57 = localDate53.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval59 = localDate53.toInterval(dateTimeZone58);
//        java.lang.String str61 = dateTimeZone58.getShortName((long) 'a');
//        org.joda.time.Interval interval62 = localDate43.toInterval(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = org.joda.time.LocalDate.now(dateTimeZone58);
//        org.joda.time.DateTime dateTime64 = dateTime32.toDateTime(dateTimeZone58);
//        org.joda.time.DateTime dateTime65 = localDate12.toDateTimeAtStartOfDay(dateTimeZone58);
//        int int66 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DurationField durationField67 = skipUndoDateTimeField8.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(interval31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(calendar41);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PST" + "'", str61.equals("PST"));
//        org.junit.Assert.assertNotNull(interval62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(durationField67);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.withZoneRetainFields(dateTimeZone4);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra(100);
        org.joda.time.DateTime.Property property11 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.minusWeeks((int) (byte) 100);
        int int14 = property1.compareTo((org.joda.time.ReadableInstant) dateTime13);
        int int15 = property1.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (short) 1);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis(1045);
        int int14 = dateTime11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
        org.joda.time.DurationField durationField7 = gJChronology6.centuries();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField9, 100);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology3.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField(chronology2, dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.withYearOfCentury((int) 'a');
        boolean boolean19 = localDate15.equals((java.lang.Object) (short) -1);
        int int20 = skipDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 23 + "'", int20 == 23);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        long long20 = offsetDateTimeField14.roundHalfEven((long) 166);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.withYearOfCentury((int) 'a');
        boolean boolean26 = localDate22.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
        org.joda.time.DateTimeField[] dateTimeFieldArray29 = localDate22.getFields();
        boolean boolean30 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = localDate22.isSupported(dateTimeFieldType31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate22, (int) (byte) 0, locale34);
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField14.getMaximumShortTextLength(locale36);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 166L + "'", long20 == 166L);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(interval28);
        org.junit.Assert.assertNotNull(dateTimeFieldArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str12 = dateTimeZone10.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone10);
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        boolean boolean15 = dateTime13.isEqual(readableInstant14);
//        int int16 = dateTime13.getWeekyear();
//        org.joda.time.DateTime.Property property17 = dateTime13.yearOfCentury();
//        int int18 = dateTime13.getMinuteOfDay();
//        int int19 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 960 + "'", int18 == 960);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        java.lang.String str49 = unsupportedDateTimeField45.toString();
        try {
            int int51 = unsupportedDateTimeField45.getMinimumValue((long) 70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UnsupportedDateTimeField" + "'", str49.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        long long11 = skipUndoDateTimeField8.set(0L, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
        int int16 = localDate13.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = localDate13.isSupported(dateTimeFieldType17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        boolean boolean24 = localDate20.equals((java.lang.Object) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = localDate20.equals(obj25);
        org.joda.time.LocalDate localDate28 = localDate20.minusDays(0);
        int[] intArray29 = localDate28.getValues();
        int int30 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray29);
        org.joda.time.LocalDate.Property property31 = localDate13.era();
        org.joda.time.LocalDate localDate32 = property31.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtMidnight(dateTimeZone34);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.LocalDate localDate6 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
        boolean boolean20 = localDate16.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval22 = localDate16.toInterval(dateTimeZone21);
        int int23 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        long long25 = offsetDateTimeField14.roundHalfFloor(52L);
        int int26 = offsetDateTimeField14.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1045 + "'", int23 == 1045);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 47 + "'", int26 == 47);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
//        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
//        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
//        long long16 = offsetDateTimeField14.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DurationField durationField20 = gJChronology19.centuries();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime25 = dateTime23.minusYears((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
//        org.joda.time.DurationField durationField32 = gJChronology31.centuries();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology31);
//        long long40 = gJChronology31.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean42 = gJChronology31.equals((java.lang.Object) gJChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.ReadableInstant readableInstant46 = null;
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, readableInstant46);
//        org.joda.time.DurationField durationField48 = gJChronology47.centuries();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology47.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology44, dateTimeField50, 100);
//        int int54 = skipUndoDateTimeField52.getMaximumValue((long) (short) -1);
//        java.lang.String str56 = skipUndoDateTimeField52.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField52, 46);
//        long long60 = offsetDateTimeField58.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField58.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43, dateTimeFieldType61);
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.ReadableInstant readableInstant64 = null;
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone63, readableInstant64);
//        org.joda.time.DateTimeField dateTimeField66 = gJChronology65.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField67 = gJChronology65.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField68 = gJChronology65.hourOfHalfday();
//        org.joda.time.Chronology chronology69 = gJChronology65.withUTC();
//        org.joda.time.DurationField durationField70 = gJChronology65.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType61, durationField70);
//        int int72 = dateTime25.get(dateTimeFieldType61);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType61, 476, 6, (int) (short) 10);
//        int int78 = offsetDateTimeField14.getMaximumValue((long) (short) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-26438399968L) + "'", long16 == (-26438399968L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-21589903L) + "'", long40 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 999 + "'", int54 == 999);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2" + "'", str56.equals("2"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-26438399968L) + "'", long60 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 215 + "'", int72 == 215);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1045 + "'", int78 == 1045);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        try {
//            org.joda.time.Instant instant22 = new org.joda.time.Instant((java.lang.Object) dateTimeZone16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        int int48 = unsupportedDateTimeField45.getDifference((long) (byte) 1, (-61828157222000L));
        try {
            long long50 = unsupportedDateTimeField45.roundHalfFloor((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 17174488 + "'", int48 == 17174488);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate8 = localDate1.withYearOfEra(1);
        org.joda.time.LocalDate.Property property9 = localDate8.era();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        int int3 = property2.getMinimumValueOverall();
//        boolean boolean4 = property2.isLeap();
//        java.lang.String str5 = property2.toString();
//        org.joda.time.DateTime dateTime6 = property2.getDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) ' ');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
//        org.joda.time.DurationField durationField15 = gJChronology14.centuries();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology14);
//        long long23 = gJChronology14.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean25 = gJChronology14.equals((java.lang.Object) gJChronology24);
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology14.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
//        org.joda.time.DurationField durationField31 = gJChronology30.centuries();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField33, 100);
//        int int37 = skipUndoDateTimeField35.getMaximumValue((long) (short) -1);
//        java.lang.String str39 = skipUndoDateTimeField35.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 46);
//        long long43 = offsetDateTimeField41.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField41.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType44);
//        int int46 = dateTime6.get(dateTimeFieldType44);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType44, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-21589903L) + "'", long23 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 999 + "'", int37 == 999);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2" + "'", str39.equals("2"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-26438399968L) + "'", long43 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 639 + "'", int46 == 639);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DurationField durationField5 = gJChronology3.months();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        long long14 = gJChronology5.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean16 = gJChronology5.equals((java.lang.Object) gJChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology5.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DurationField durationField22 = gJChronology21.centuries();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, 100);
        int int28 = skipUndoDateTimeField26.getMaximumValue((long) (short) -1);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 46);
        long long34 = offsetDateTimeField32.roundCeiling((-26438399968L));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.yearOfEra();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.hourOfHalfday();
        org.joda.time.Chronology chronology43 = gJChronology39.withUTC();
        org.joda.time.DurationField durationField44 = gJChronology39.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        java.lang.String str47 = unsupportedDateTimeField45.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField45.getLeapDurationField();
        try {
            int int50 = unsupportedDateTimeField45.getLeapAmount((long) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-21589903L) + "'", long14 == (-21589903L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2" + "'", str30.equals("2"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-26438399968L) + "'", long34 == (-26438399968L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfSecond" + "'", str46.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField48);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
//        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property14 = localDate11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) 'a');
//        boolean boolean19 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) 'a');
//        boolean boolean25 = localDate21.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 'a');
//        org.joda.time.Interval interval30 = localDate11.toInterval(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime0.toDateTime(dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = dateTimeZone26.getShortName(46L, locale35);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(interval27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PST" + "'", str36.equals("PST"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        long long18 = offsetDateTimeField14.roundFloor((long) 10);
        java.lang.String str19 = offsetDateTimeField14.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str19.equals("DateTimeField[millisOfSecond]"));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DurationField durationField5 = gJChronology3.hours();
//        org.joda.time.DurationField durationField6 = gJChronology3.hours();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfSecond(1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("2019-06-05");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendDayOfMonth(1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder7.appendCenturyOfEra((int) (byte) 10, 97);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DurationField durationField20 = gJChronology19.centuries();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (byte) 10);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) 5, 0);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
//        org.joda.time.DateTime.Property property29 = dateTime28.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = property29.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.ReadableInstant readableInstant35 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, readableInstant35);
//        org.joda.time.DurationField durationField37 = gJChronology36.centuries();
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter31.withChronology((org.joda.time.Chronology) gJChronology36);
//        long long45 = gJChronology36.getDateTimeMillis((long) (byte) 10, (int) (short) 10, (int) (short) 0, (int) (short) 10, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean47 = gJChronology36.equals((java.lang.Object) gJChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology36.clockhourOfHalfday();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.ReadableInstant readableInstant51 = null;
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, readableInstant51);
//        org.joda.time.DurationField durationField53 = gJChronology52.centuries();
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology52.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology49, dateTimeField55, 100);
//        int int59 = skipUndoDateTimeField57.getMaximumValue((long) (short) -1);
//        java.lang.String str61 = skipUndoDateTimeField57.getAsText((long) 2);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField57, 46);
//        long long65 = offsetDateTimeField63.roundCeiling((-26438399968L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField63.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType66);
//        int int68 = dateTime30.get(dateTimeFieldType66);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType66, 4);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField6, dateTimeFieldType66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-21589903L) + "'", long45 == (-21589903L));
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 999 + "'", int59 == 999);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2" + "'", str61.equals("2"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-26438399968L) + "'", long65 == (-26438399968L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 905 + "'", int68 == 905);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
        boolean boolean5 = localDate1.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval7 = localDate1.toInterval(dateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str9 = dateTimeZone6.getID();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        int int22 = localDate21.size();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology25 = iSOChronology23.withZone(dateTimeZone24);
//        try {
//            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) int22, (org.joda.time.Chronology) iSOChronology23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("100", true);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withZoneRetainFields(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DurationField durationField6 = gJChronology5.centuries();
        boolean boolean7 = dateTime0.equals((java.lang.Object) gJChronology5);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime0.toCalendar(locale8);
        org.joda.time.DateTime.Property property10 = dateTime0.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
        org.joda.time.DurationField durationField7 = gJChronology6.centuries();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField9, 100);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology3.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField(chronology2, dateTimeField12);
        int int14 = skipDateTimeField13.getMinimumValue();
        try {
            long long17 = skipDateTimeField13.set(0L, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [1,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        int int10 = skipUndoDateTimeField8.getMaximumValue((long) (short) -1);
        java.lang.String str12 = skipUndoDateTimeField8.getAsText((long) 2);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, 46);
        long long16 = offsetDateTimeField14.roundHalfEven((long) '#');
        boolean boolean18 = offsetDateTimeField14.isLeap((long) 2019);
        int int20 = offsetDateTimeField14.getMaximumValue((long) (short) 1);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone23);
        org.joda.time.LocalDate localDate26 = localDate24.withYearOfCentury((int) 'a');
        boolean boolean28 = localDate24.equals((java.lang.Object) (short) -1);
        java.lang.Object obj29 = null;
        boolean boolean30 = localDate24.equals(obj29);
        org.joda.time.LocalDate localDate32 = localDate24.minusDays(0);
        int[] intArray33 = localDate32.getValues();
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = offsetDateTimeField14.set(readablePartial21, 47, intArray33, "", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1045 + "'", int20 == 1045);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((long) (byte) 1, locale10);
        long long14 = skipUndoDateTimeField8.set((long) 'a', 3);
        java.lang.String str15 = skipUndoDateTimeField8.getName();
        java.util.Locale locale16 = null;
        int int17 = skipUndoDateTimeField8.getMaximumShortTextLength(locale16);
        int int19 = skipUndoDateTimeField8.getMaximumValue((long) 6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 999 + "'", int19 == 999);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury((int) 'a');
//        org.joda.time.LocalDate.Property property4 = localDate1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury((int) 'a');
//        boolean boolean9 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury((int) 'a');
//        boolean boolean15 = localDate11.equals((java.lang.Object) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Interval interval17 = localDate11.toInterval(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 'a');
//        org.joda.time.Interval interval20 = localDate1.toInterval(dateTimeZone16);
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
//        org.joda.time.LocalDate.Property property22 = localDate21.monthOfYear();
//        org.joda.time.LocalDate localDate23 = property22.getLocalDate();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(interval20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(localDate23);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DurationField durationField4 = gJChronology3.centuries();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, 100);
        long long11 = skipUndoDateTimeField8.set(0L, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) 'a');
        int int16 = localDate13.getYearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = localDate13.isSupported(dateTimeFieldType17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) 'a');
        boolean boolean24 = localDate20.equals((java.lang.Object) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = localDate20.equals(obj25);
        org.joda.time.LocalDate localDate28 = localDate20.minusDays(0);
        int[] intArray29 = localDate28.getValues();
        int int30 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray29);
        org.joda.time.LocalDate.Property property31 = localDate13.era();
        org.joda.time.LocalDate localDate32 = property31.roundFloorCopy();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }
}

