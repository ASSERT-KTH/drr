import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 100, 1, 100, 1, (int) 'a', chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-1L), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (byte) 10, (int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, (-1), (int) (byte) 0, (int) '4', (int) (byte) 100, 1, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10L, (java.lang.Number) 100.0f, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Object obj0 = new java.lang.Object();
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Object");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime7.withField(dateTimeFieldType8, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 0, 0, (int) (byte) -1, (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate10);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime7.withYear((int) (byte) 1);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560634986788L + "'", long0 == 1560634986788L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 'a', (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser8);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone11.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter10, dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, (-1), 100, (int) '4', (int) (byte) 1, 10, 0, dateTimeZone15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 10, (int) (byte) 1, 32);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime7.withTime(10, 100, 1, 32);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (-28799968L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28799968) + "'", int2 == (-28799968));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 10);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime3.toString("2019-W24-6", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PST' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, (int) (byte) -1, (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withSecondOfMinute((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 32, (-28799968));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePeriod2, (long) 2, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime9.withTime(2, (int) 'a', 100, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Sat");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Sat\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.DurationFieldType durationFieldType11 = null;
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime7.withFieldAdded(durationFieldType11, 52989);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', (-28800000), (int) (byte) 100, 100, (int) (short) 100, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter7, dateTimeZone8);
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate12);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        java.lang.String str8 = dateTimeZone4.getID();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.plusMillis(0);
//        java.util.Date date14 = dateTime13.toDate();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime13.toMutableDateTime();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) mutableDateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.millisOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        boolean boolean26 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        java.util.GregorianCalendar gregorianCalendar27 = dateTime23.toGregorianCalendar();
//        try {
//            org.joda.time.DateTime dateTime29 = dateTime23.withMillisOfSecond((-28799968));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28799968 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 52989);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
//        org.joda.time.DateTime.Property property13 = dateTime12.hourOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis(0);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime12.withDurationAdded(readableDuration16, 0);
//        try {
//            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime9.toTimeOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime9.withField(dateTimeFieldType15, 14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("2019-W24-6");
        org.joda.time.ReadWritableInstant readWritableInstant3 = null;
        try {
            int int6 = dateTimeFormatter0.parseInto(readWritableInstant3, "", 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekyear((int) '#');
//        org.joda.time.DateTime dateTime12 = dateTime7.withWeekOfWeekyear((int) (byte) 1);
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime7.withMillisOfSecond((-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 100, 0, 2019, 0, 0, (int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-28799968));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        org.joda.time.DateTime dateTime14 = dateTime7.minusHours((int) '#');
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
//        org.joda.time.Chronology chronology16 = dateTime12.getChronology();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(0);
//        boolean boolean15 = dateTime11.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime11.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withDayOfYear((-28799968));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28799968 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(52989, 0, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(3, 2, 14, 1969, 0, (int) (short) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 32);
//        java.lang.StringBuffer stringBuffer4 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
//        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter8, dateTimeZone9);
//        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
//        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate13);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNull(dateTimePrinter8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusSeconds((int) (short) 10);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime12.withDate(0, 480, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 480 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) (short) 0, (-28799968), (-2020));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, 0, 14, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        boolean boolean26 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime7.withDate(480, (int) '#', (-2020));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter17, dateTimeZone18);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.plus(readableDuration22);
//        org.joda.time.DateTime.Property property24 = dateTime23.hourOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.minus(readablePeriod27);
//        boolean boolean29 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.Chronology chronology30 = dateTime26.getChronology();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(int1);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNull(dateTimePrinter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(chronology30);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.minus(readableDuration9);
//        int int11 = dateTime10.getMonthOfYear();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        try {
//            long long12 = gregorianChronology0.getDateTimeMillis((int) '4', 1, (int) ' ', 480);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((-28800000));
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType10, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) -1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) '#');
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("Sat");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Sat\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        boolean boolean12 = property10.equals((java.lang.Object) "PST");
//        org.joda.time.DurationField durationField13 = property10.getLeapDurationField();
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter17, dateTimeZone18);
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime24 = dateTime21.plusMillis(0);
//        org.joda.time.DateTime dateTime26 = dateTime21.withHourOfDay(0);
//        int int27 = property10.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        java.lang.String str28 = property10.getName();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertNull(dateTimePrinter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hourOfDay" + "'", str28.equals("hourOfDay"));
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.minus(readableDuration9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        try {
//            java.lang.String str12 = dateTime10.toString(dateTimeFormatter11);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 59, (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(readableDuration13, 0);
//        boolean boolean17 = dateTime9.isBefore((long) ' ');
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = property13.setCopy((int) (short) 10);
//        int int16 = property13.getMaximumValueOverall();
//        java.lang.String str17 = property13.getAsShortText();
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser19 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter18, dateTimeParser19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str24 = dateTimeZone22.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter21, dateTimeZone22);
//        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
//        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate26);
//        try {
//            int int28 = property13.compareTo((org.joda.time.ReadablePartial) localDate26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "43" + "'", str17.equals("43"));
//        org.junit.Assert.assertNull(dateTimePrinter21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getName((long) '#', locale11);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone6);
//        long long16 = dateTimeZone6.adjustOffset((long) '4', false);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        try {
//            boolean boolean9 = dateTimeZone0.isLocalDateTimeGap(localDateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone7);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        int int11 = property10.get();
//        int int12 = property10.getLeapAmount();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"19-W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime9.withField(dateTimeFieldType13, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(0);
//        boolean boolean15 = dateTime11.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime11.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        java.io.Writer writer1 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate10);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-28799968));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.util.Locale locale10 = null;
//        java.util.Calendar calendar11 = dateTime9.toCalendar(locale10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(calendar11);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        long long11 = dateTimeZone1.convertLocalToUTC((long) 6, false);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800006L + "'", long11 == 28800006L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(5L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2019, 52995, 59, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusYears((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.withDurationAdded(readableDuration15, (int) (byte) 10);
//        java.lang.String str18 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
//        try {
//            org.joda.time.LocalDate localDate20 = dateTimeFormatter0.parseLocalDate("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20190616T000000.000-0700" + "'", str18.equals("20190616T000000.000-0700"));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1023L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1023 + "'", int1 == 1023);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = dateTimeZone0.getOffset(readableInstant8);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-25200000) + "'", int9 == (-25200000));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 2, (java.lang.Number) 0.0d, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        long long12 = gregorianChronology0.add((long) (-1), (long) ' ', 32);
//        try {
//            long long17 = gregorianChronology0.getDateTimeMillis((int) (byte) -1, (int) '4', (-25200000), 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1023L + "'", long12 == 1023L);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        java.util.Date date11 = dateTime10.toDate();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime10.withWeekOfWeekyear((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        int int13 = offsetDateTimeField9.getLeapAmount((long) 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 52995);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        int int11 = dateTimeZone7.getOffsetFromLocal((long) 'a');
//        java.lang.String str13 = dateTimeZone7.getShortName(0L);
//        java.util.TimeZone timeZone14 = dateTimeZone7.toTimeZone();
//        org.joda.time.Chronology chronology15 = gregorianChronology5.withZone(dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(6, (-1), 100, 126, 2, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 126 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology(chronology10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 52997649);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2019, 1, (int) '4', 2000, 0, 52989, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withField(dateTimeFieldType13, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((-28800000));
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime11.getZone();
//        org.joda.time.DateTime.Property property15 = dateTime11.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = property15.getLeapDurationField();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNull(durationField16);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str22 = dateTimeZone20.getShortName((long) (byte) 10);
//        int int24 = dateTimeZone20.getOffsetFromLocal((long) 'a');
//        java.lang.String str26 = dateTimeZone20.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter19.withZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter18, dateTimeZone20);
//        try {
//            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) (-28799968), dateTimeZone20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PST" + "'", str26.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str11 = dateTimeZone1.getName((long) (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        try {
//            long long13 = gregorianChronology0.getDateTimeMillis(2, 86400009, 52997649, 173);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400009 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
//        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
//        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
//        org.junit.Assert.assertNotNull(gregorianCalendar20);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 6, (-1), 100, (int) (short) 1, 59, 173);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
//        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property20 = dateTime18.weekOfWeekyear();
//        java.util.Locale locale22 = null;
//        try {
//            org.joda.time.DateTime dateTime23 = property20.setCopy("0", locale22);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
//        org.junit.Assert.assertNotNull(property20);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.clockhourOfHalfday();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekyear();
//        try {
//            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimeField10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BasicWeekyearDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 10);
//        long long26 = offsetDateTimeField24.roundFloor((long) (-28799968));
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField24.getAsShortText(0, locale28);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str33 = dateTimeZone31.getShortName((long) (byte) 10);
//        int int35 = dateTimeZone31.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology36 = gregorianChronology30.withZone(dateTimeZone31);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology30.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology30.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology30.secondOfDay();
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate43 = dateTimeFormatter41.parseLocalDate("2019-W24-6");
//        int[] intArray45 = gregorianChronology30.get((org.joda.time.ReadablePartial) localDate43, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str50 = dateTimeZone48.getShortName((long) (byte) 10);
//        int int52 = dateTimeZone48.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology53 = gregorianChronology47.withZone(dateTimeZone48);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology47.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology47.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology47.secondOfDay();
//        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate60 = dateTimeFormatter58.parseLocalDate("2019-W24-6");
//        int[] intArray62 = gregorianChronology47.get((org.joda.time.ReadablePartial) localDate60, 1023L);
//        int[] intArray64 = offsetDateTimeField24.addWrapField((org.joda.time.ReadablePartial) localDate43, (int) (byte) 0, intArray62, (int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str69 = dateTimeZone67.getShortName((long) (byte) 10);
//        int int71 = dateTimeZone67.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology72 = gregorianChronology66.withZone(dateTimeZone67);
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology66.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology66.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology66.secondOfDay();
//        org.joda.time.Chronology chronology76 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate79 = dateTimeFormatter77.parseLocalDate("2019-W24-6");
//        int[] intArray81 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDate79, 1023L);
//        try {
//            int[] intArray83 = offsetDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) localDate43, 52997649, intArray81, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52997649");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-28800000) + "'", int35 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-28800000) + "'", int52 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertNotNull(dateTimeFormatter58);
//        org.junit.Assert.assertNotNull(localDate60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PST" + "'", str69.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-28800000) + "'", int71 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(chronology76);
//        org.junit.Assert.assertNotNull(dateTimeFormatter77);
//        org.junit.Assert.assertNotNull(localDate79);
//        org.junit.Assert.assertNotNull(intArray81);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-28799968), (long) 14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28799954L) + "'", long2 == (-28799954L));
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        int int21 = dateTimeZone17.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.dayOfWeek();
//        boolean boolean24 = property15.equals((java.lang.Object) dateTimeField23);
//        try {
//            org.joda.time.DateTime dateTime26 = property15.setCopy((-2020));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for secondOfDay must be in the range [0,86399]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray11 = gregorianChronology0.get(readablePeriod9, (long) (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        int int7 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.minutes();
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, 32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 44L, (java.lang.Number) 53001523);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.roundFloor((long) (-28799968));
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField9.getAsShortText(0, locale13);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28799968L) + "'", long11 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusMonths(6);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("ISOChronology[America/Los_Angeles]", (int) (short) -1, 480, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for ISOChronology[America/Los_Angeles] must be in the range [480,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        boolean boolean26 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        java.util.GregorianCalendar gregorianCalendar27 = dateTime23.toGregorianCalendar();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) gregorianCalendar27);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean1 = dateTime0.isAfterNow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Chronology chronology9 = dateTime7.getChronology();
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime12 = dateTime7.minusYears((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = dateTime7.plusMonths((int) (short) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime7.withField(dateTimeFieldType15, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(100L);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology8 = gregorianChronology7.withUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone13.getName((long) '#', locale18);
//        org.joda.time.Chronology chronology20 = gregorianChronology7.withZone(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) ' ', 0, 53001523, 1023, (-1), 2019, (int) '4', chronology20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1023 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pacific Standard Time" + "'", str19.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology20);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) (byte) 1, locale10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone0);
//        long long16 = dateTimeZone0.convertLocalToUTC((long) 1969, false, (long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28801969L + "'", long16 == 28801969L);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2019);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '#', 32, (int) (short) 1, (int) (short) 100, false, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str2 = dateTimeFormatter0.print(28801969L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01" + "'", str2.equals("1970-01"));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.hours();
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 126, (java.lang.Number) (-1), (java.lang.Number) 173);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hourOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2019);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("43", 1023, (int) (byte) 1, 36, '#', 4, (-1), 20, false, 52989);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) 6, (long) 14);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField9.getMaximumTextLength(locale15);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatter19.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str23 = dateTimeZone21.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter20, dateTimeZone21);
//        org.joda.time.LocalDate localDate25 = dateTime24.toLocalDate();
//        boolean boolean26 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate25);
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate25, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
//        org.junit.Assert.assertNull(dateTimePrinter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 1, 933);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 934 + "'", int2 == 934);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.hourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        java.lang.String str14 = offsetDateTimeField9.getAsShortText((long) 933);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "943" + "'", str14.equals("943"));
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        org.joda.time.DateTime.Property property13 = dateTime7.secondOfDay();
//        java.lang.String str14 = property13.getAsShortText();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "53007" + "'", str14.equals("53007"));
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
//        org.joda.time.DateTime.Property property23 = dateTime22.hourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusMillis(0);
//        boolean boolean26 = dateTime22.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime22.toTimeOfDay();
//        int int28 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay27);
//        long long31 = offsetDateTimeField9.add(52L, 14);
//        boolean boolean32 = offsetDateTimeField9.isSupported();
//        java.lang.String str34 = offsetDateTimeField9.getAsText(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 66L + "'", long31 == 66L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10" + "'", str34.equals("10"));
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
//        boolean boolean13 = dateTime10.isAfter((long) 53006089);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) '#', 0, 36);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((int) '#', (int) (short) 100, 53006089, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone1.convertUTCToLocal((long) '4');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28799948L) + "'", long3 == (-28799948L));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(480);
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter3.parseLocalDate("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        java.util.Date date15 = dateTime12.toDate();
//        int int16 = dateTime12.getHourOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14 + "'", int16 == 14);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear(0);
//        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfHour();
//        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.minusSeconds(1);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime17.withDayOfMonth((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
//        org.joda.time.DateTime.Property property13 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime16 = dateTime14.minusYears((int) (short) 1);
//        org.joda.time.DateTime.Property property17 = dateTime14.minuteOfHour();
//        org.joda.time.DateTime dateTime18 = property17.withMinimumValue();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField2, (java.lang.Object) property17);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        java.util.Date date11 = dateTime10.toDate();
//        int int12 = dateTime10.getYearOfEra();
//        int int13 = dateTime10.getMinuteOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime10.plusMinutes(32);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 883 + "'", int13 == 883);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (-28800000), 53001523);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfMonth();
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser17 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser17);
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str22 = dateTimeZone20.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter19, dateTimeZone20);
//        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusMillis(0);
//        java.util.Date date27 = dateTime26.toDate();
//        int int28 = dateTime26.getYearOfEra();
//        boolean boolean29 = property15.equals((java.lang.Object) int28);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNull(dateTimePrinter19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) (byte) 10);
//        int int7 = dateTimeZone3.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 10);
//        long long13 = offsetDateTimeField11.roundFloor((long) (-28799968));
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField11.getAsShortText(0, locale15);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        int int22 = dateTimeZone18.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology23 = gregorianChronology17.withZone(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology17.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology17.secondOfDay();
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate30 = dateTimeFormatter28.parseLocalDate("2019-W24-6");
//        int[] intArray32 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate30, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str37 = dateTimeZone35.getShortName((long) (byte) 10);
//        int int39 = dateTimeZone35.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology40 = gregorianChronology34.withZone(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology34.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology34.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology34.secondOfDay();
//        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate47 = dateTimeFormatter45.parseLocalDate("2019-W24-6");
//        int[] intArray49 = gregorianChronology34.get((org.joda.time.ReadablePartial) localDate47, 1023L);
//        int[] intArray51 = offsetDateTimeField11.addWrapField((org.joda.time.ReadablePartial) localDate30, (int) (byte) 0, intArray49, (int) (short) 100);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28799968L) + "'", long13 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PST" + "'", str37.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(intArray51);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekyear();
//        try {
//            long long16 = gregorianChronology0.getDateTimeMillis((long) (short) 0, (-28799968), 1023, (int) (byte) 100, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28799968 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
//        int int10 = dateTime8.getHourOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = null;
//        try {
//            int int12 = dateTime8.get(dateTimeField11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14 + "'", int10 == 14);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        int int11 = dateTime7.getHourOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfHour();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "6");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        java.lang.String str2 = jodaTimePermission1.getActions();
//        java.lang.String str3 = jodaTimePermission1.toString();
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter7, dateTimeZone8);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
//        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusMillis(0);
//        boolean boolean17 = dateTime13.isEqualNow();
//        org.joda.time.DateTime dateTime19 = dateTime13.withHourOfDay((int) (short) 0);
//        org.joda.time.Chronology chronology20 = dateTime19.getChronology();
//        jodaTimePermission1.checkGuard((java.lang.Object) chronology20);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
//        org.junit.Assert.assertNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(chronology20);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear(0);
//        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfHour();
//        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTime8);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.weekyearOfCentury();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) -1, (int) (short) 10, (-28800000), 2, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int17 = offsetDateTimeField9.getDifference(0L, (long) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate13 = dateTimeFormatter11.parseLocalDate("2019-W24-6");
//        int[] intArray15 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate13, 1023L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.hourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(52997649, 32, 126);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        int int22 = dateTimeZone18.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology23 = gregorianChronology17.withZone(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology17.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 10);
//        long long29 = offsetDateTimeField26.add((long) 4, (long) (byte) 1);
//        long long31 = offsetDateTimeField26.roundHalfEven((long) (-28799968));
//        int int32 = offsetDateTimeField26.getMaximumValue();
//        boolean boolean34 = offsetDateTimeField26.isLeap((long) 8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str38 = dateTimeZone36.getShortName((long) (byte) 10);
//        int int40 = dateTimeZone36.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology41 = gregorianChronology35.withZone(dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology35.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology35.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology35.secondOfDay();
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate48 = dateTimeFormatter46.parseLocalDate("2019-W24-6");
//        int[] intArray50 = gregorianChronology35.get((org.joda.time.ReadablePartial) localDate48, 1023L);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate48, 52995, locale52);
//        java.util.Locale locale54 = null;
//        try {
//            java.lang.String str55 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate48, locale54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28799968L) + "'", long31 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86400009 + "'", int32 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PST" + "'", str38.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "52995" + "'", str53.equals("52995"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(readableDuration14, (int) (byte) 10);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
//        int int19 = dateTime16.getSecondOfMinute();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 126 + "'", number5.equals(126));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5" + "'", str6.equals("5"));
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        boolean boolean18 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate17);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate17, (long) 52995);
//        try {
//            long long25 = gregorianChronology0.getDateTimeMillis((-25200000), 86400009, (int) '4', (-25200000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfDay must be in the range [0,86400000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560556852995L + "'", long20 == 1560556852995L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = property11.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime15 = property11.addToCopy(0);
//        org.joda.time.DateTime dateTime16 = property11.withMaximumValue();
//        org.joda.time.DateTime dateTime18 = property11.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property11.getFieldType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withFieldAdded(durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(0);
//        org.joda.time.DateTime dateTime14 = dateTime7.withYear(32);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Sat");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Sat/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) (byte) 10);
//        int int6 = dateTimeZone2.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 10);
//        long long13 = offsetDateTimeField10.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter17, dateTimeZone18);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.plus(readableDuration22);
//        org.joda.time.DateTime.Property property24 = dateTime23.hourOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusMillis(0);
//        boolean boolean27 = dateTime23.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime23.toTimeOfDay();
//        int int29 = offsetDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay28);
//        long long31 = iSOChronology0.set((org.joda.time.ReadablePartial) timeOfDay28, 20L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 53012865L + "'", long31 == 53012865L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("52995");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"52995\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str11 = dateTimeZone1.getName(0L);
//        java.lang.String str12 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusMillis(0);
//        org.joda.time.DateTime dateTime14 = dateTime9.withHourOfDay(0);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime7.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime7, (org.joda.time.Chronology) gregorianChronology14);
//        java.util.GregorianCalendar gregorianCalendar24 = dateTime7.toGregorianCalendar();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gregorianCalendar24);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property13.getAsText(locale14);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AD" + "'", str15.equals("AD"));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime13 = dateTime7.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime.Property property15 = dateTime13.centuryOfEra();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "53007", (int) (short) 100, (int) (byte) 10);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        long long5 = durationField2.subtract(0L, (int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType6, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60000L) + "'", long5 == (-60000L));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        long long22 = dateTimeZone15.convertUTCToLocal((long) ' ');
//        int int24 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime12.toMutableDateTime(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28799968L) + "'", long22 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2019);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("Property[hourOfDay]", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) (byte) 10);
//        int int6 = dateTimeZone2.getOffsetFromLocal((long) 'a');
//        java.lang.String str8 = dateTimeZone2.getShortName(0L);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone2);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        org.joda.time.DateTime.Property property14 = dateTime9.era();
//        int int15 = dateTime9.getSecondOfMinute();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 34 + "'", int15 == 34);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimePrinter6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNull(dateTimePrinter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        java.util.Date date11 = dateTime10.toDate();
//        int int12 = dateTime10.getYearOfEra();
//        try {
//            java.lang.String str14 = dateTime10.toString("Saturday");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(0);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateMidnight15);
//        try {
//            org.joda.time.LocalDate localDate18 = dateTimeFormatter0.parseLocalDate("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019166" + "'", str16.equals("2019166"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(12, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        boolean boolean17 = offsetDateTimeField9.isLeap((long) 8);
//        long long19 = offsetDateTimeField9.roundHalfEven((long) 933);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 933L + "'", long19 == 933L);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        java.lang.Object obj14 = null;
//        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property13, obj14);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(0);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime7.withTime(173, 2, 52, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 173 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long12 = gregorianChronology0.getDateTimeMillis(0L, (int) (short) 0, 6, 8, (int) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.clockhourOfHalfday();
//        try {
//            long long20 = gregorianChronology0.getDateTimeMillis(0L, 94, (int) (byte) 1, (int) (byte) 1, 94);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 94 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 368100L + "'", long12 == 368100L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, 53009442, (int) (short) 0, 0, 32, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (long) 883);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-883L) + "'", long2 == (-883L));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear(0);
//        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfHour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter18, dateTimeZone19);
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readableDuration23);
//        org.joda.time.DateTime.Property property25 = dateTime22.dayOfWeek();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime27 = property25.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime29 = property25.addToCopy(0);
//        org.joda.time.DateTime dateTime30 = property25.withMaximumValue();
//        org.joda.time.DateTime dateTime32 = property25.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property25.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "0");
//        int int36 = dateTime8.get(dateTimeFieldType33);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        java.util.GregorianCalendar gregorianCalendar8 = dateTime7.toGregorianCalendar();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianCalendar8);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime12 = property10.setCopy((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((-28800000));
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime11.getZone();
//        org.joda.time.DateTime.Property property15 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = property15.addToCopy((int) '#');
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "53007", (int) (short) 100, (int) (byte) 10);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        long long8 = fixedDateTimeZone4.nextTransition(0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53007" + "'", str6.equals("53007"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(86399621L, 28801969L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 115201590L + "'", long2 == 115201590L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 126 + "'", number5.equals(126));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32 + "'", number6.equals(32));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property10.getAsText(locale15);
//        java.lang.String str17 = property10.getAsText();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Saturday" + "'", str16.equals("Saturday"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Saturday" + "'", str17.equals("Saturday"));
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset((int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder2.setStandardOffset(934);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        int int11 = property10.getMinimumValue();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) (byte) 1, locale10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone13.getUncachedZone();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        int int17 = dateTimeZone13.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology18 = gregorianChronology12.withZone(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology12.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime11.toMutableDateTime((org.joda.time.Chronology) gregorianChronology12);
//        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime21, "America/Los_Angeles", 2019);
//        int int25 = mutableDateTime21.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-2020) + "'", int24 == (-2020));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 36 + "'", int25 == 36);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        org.joda.time.DurationField durationField16 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.DurationFieldType durationFieldType17 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField16, durationFieldType17, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.Locale locale10 = null;
//        java.util.Calendar calendar11 = dateTime9.toCalendar(locale10);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(calendar11);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property10.getAsShortText(locale12);
//        try {
//            org.joda.time.DateTime dateTime15 = property10.setCopy("2019-06-15T14");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T14\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Sat" + "'", str13.equals("Sat"));
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 86400009, 53006089);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(28799999L, (long) 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1497599948 + "'", int2 == 1497599948);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) (byte) 10);
//        int int7 = dateTimeZone3.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 10);
//        long long14 = offsetDateTimeField11.add((long) 4, (long) (byte) 1);
//        long long16 = offsetDateTimeField11.roundHalfEven((long) (-28799968));
//        int int17 = offsetDateTimeField11.getMaximumValue();
//        boolean boolean19 = offsetDateTimeField11.isLeap((long) 8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str23 = dateTimeZone21.getShortName((long) (byte) 10);
//        int int25 = dateTimeZone21.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology26 = gregorianChronology20.withZone(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology20.secondOfDay();
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate33 = dateTimeFormatter31.parseLocalDate("2019-W24-6");
//        int[] intArray35 = gregorianChronology20.get((org.joda.time.ReadablePartial) localDate33, 1023L);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate33, 52995, locale37);
//        long long40 = offsetDateTimeField11.roundHalfEven(1560556852995L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate43 = dateTimeFormatter41.parseLocalDate("2019-W24-6");
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate43, 934, locale45);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28799968L) + "'", long16 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400009 + "'", int17 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52995" + "'", str38.equals("52995"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560556852995L + "'", long40 == 1560556852995L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "934" + "'", str46.equals("934"));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("43", (java.lang.Number) (-28799948L), (java.lang.Number) 1560556852995L, (java.lang.Number) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-28799948" + "'", str6.equals("-28799948"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(480);
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter0.parseLocalDate("43");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"43\": Value 43 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime12.isEqualNow();
//        org.joda.time.DateTime dateTime15 = dateTime12.minusMonths(34);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) (byte) 1, locale10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        boolean boolean14 = cachedDateTimeZone13.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) 6, (long) 14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology15.secondOfDay();
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate28 = dateTimeFormatter26.parseLocalDate("2019-W24-6");
//        int[] intArray30 = gregorianChronology15.get((org.joda.time.ReadablePartial) localDate28, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str34 = dateTimeZone32.getShortName((long) (byte) 10);
//        int int36 = dateTimeZone32.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology37 = gregorianChronology31.withZone(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology31.secondOfDay();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate44 = dateTimeFormatter42.parseLocalDate("2019-W24-6");
//        int[] intArray46 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDate44, 1023L);
//        int int47 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate28, intArray46);
//        long long49 = offsetDateTimeField9.roundHalfFloor((long) (short) 10);
//        long long52 = offsetDateTimeField9.getDifferenceAsLong(86400109L, 488L);
//        java.util.Locale locale53 = null;
//        int int54 = offsetDateTimeField9.getMaximumShortTextLength(locale53);
//        boolean boolean56 = offsetDateTimeField9.isLeap(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 86399621L + "'", long52 == 86399621L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 8 + "'", int54 == 8);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (-1));
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = offsetDateTimeField16.getAsShortText(readablePartial17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        java.util.TimeZone timeZone7 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) (byte) 10);
//        int int12 = dateTimeZone8.getOffsetFromLocal((long) 'a');
//        java.lang.String str14 = dateTimeZone8.getShortName(0L);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone8);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone8.getShortName((long) (byte) 1, locale18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        long long23 = dateTimeZone0.getMillisKeepLocal(dateTimeZone8, 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        int int7 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.minutes();
//        int int9 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime12.withYearOfEra((int) (byte) 100);
//        org.joda.time.LocalTime localTime18 = dateTime12.toLocalTime();
//        boolean boolean19 = dateTime12.isAfterNow();
//        int int20 = dateTime12.getWeekyear();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((-25200000));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (-28799968L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfDay(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset((int) (byte) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder4.addCutover(126, '#', 0, (int) ' ', 52998580, false, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) (byte) 10);
//        int int6 = dateTimeZone2.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 8, chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology7);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset((int) (byte) 0);
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder4.writeTo("20190616T000000.000-0700", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter13, dateTimeZone14);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.plus(readableDuration18);
//        org.joda.time.DateTime.Property property20 = dateTime17.dayOfWeek();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime22 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime24 = property20.addToCopy(0);
//        org.joda.time.DateTime dateTime25 = property20.withMaximumValue();
//        org.joda.time.DateTime dateTime27 = property20.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property20.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, "0");
//        java.lang.Number number31 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, number31, (java.lang.Number) 100.0f, (java.lang.Number) 12);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType28, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNull(dateTimePrinter13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime9.toMutableDateTime();
//        int int14 = mutableDateTime13.getEra();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (-1));
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField9.getMaximumTextLength(locale17);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear(0);
//        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property14 = dateTime8.minuteOfHour();
//        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTime8);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime8.minus(readablePeriod16);
//        int int18 = dateTime8.getEra();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.roundFloor((long) (-28799968));
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField9.getAsShortText(0, locale13);
//        boolean boolean15 = offsetDateTimeField9.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28799968L) + "'", long11 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (-1));
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatter19.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str23 = dateTimeZone21.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter20, dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        org.joda.time.DateTime dateTime27 = dateTime24.withYear(0);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime24.minus(readableDuration28);
//        org.joda.time.DateTime dateTime31 = dateTime29.plusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime32 = dateTime29.toLocalTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str37 = dateTimeZone35.getShortName((long) (byte) 10);
//        int int39 = dateTimeZone35.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology40 = gregorianChronology34.withZone(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology34.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) 10);
//        long long45 = offsetDateTimeField43.roundFloor((long) (-28799968));
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField43.getAsShortText(0, locale47);
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str52 = dateTimeZone50.getShortName((long) (byte) 10);
//        int int54 = dateTimeZone50.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology55 = gregorianChronology49.withZone(dateTimeZone50);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology49.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology49.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology49.secondOfDay();
//        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology49);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate62 = dateTimeFormatter60.parseLocalDate("2019-W24-6");
//        int[] intArray64 = gregorianChronology49.get((org.joda.time.ReadablePartial) localDate62, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str69 = dateTimeZone67.getShortName((long) (byte) 10);
//        int int71 = dateTimeZone67.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology72 = gregorianChronology66.withZone(dateTimeZone67);
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology66.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology66.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology66.secondOfDay();
//        org.joda.time.Chronology chronology76 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate79 = dateTimeFormatter77.parseLocalDate("2019-W24-6");
//        int[] intArray81 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDate79, 1023L);
//        int[] intArray83 = offsetDateTimeField43.addWrapField((org.joda.time.ReadablePartial) localDate62, (int) (byte) 0, intArray81, (int) (short) 100);
//        java.util.Locale locale85 = null;
//        try {
//            int[] intArray86 = offsetDateTimeField16.set((org.joda.time.ReadablePartial) localTime32, 53016, intArray83, "2029", locale85);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53016");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertNull(dateTimePrinter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PST" + "'", str37.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-28800000) + "'", int39 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-28799968L) + "'", long45 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PST" + "'", str52.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-28800000) + "'", int54 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter60);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PST" + "'", str69.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-28800000) + "'", int71 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(chronology76);
//        org.junit.Assert.assertNotNull(dateTimeFormatter77);
//        org.junit.Assert.assertNotNull(localDate79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertNotNull(intArray83);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekyear((int) '#');
//        boolean boolean12 = dateTime7.isBefore(978307200000L);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 173, chronology1);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime7.plusMonths(52997649);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime7.withMonthOfYear((int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter2.parseMutableDateTime("millisOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(dateTimePrinter3);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
//        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property20 = dateTime18.weekOfWeekyear();
//        int int21 = property20.getMinimumValueOverall();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str25 = dateTimeZone23.getShortName((long) (byte) 10);
//        int int27 = dateTimeZone23.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology28 = gregorianChronology22.withZone(dateTimeZone23);
//        long long30 = dateTimeZone23.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter31 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser32 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter31, dateTimeParser32);
//        org.joda.time.format.DateTimePrinter dateTimePrinter34 = dateTimeFormatter33.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str37 = dateTimeZone35.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter34, dateTimeZone35);
//        org.joda.time.ReadableDuration readableDuration39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.plus(readableDuration39);
//        int int41 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime40);
//        boolean boolean42 = property20.equals((java.lang.Object) int41);
//        org.joda.time.DurationField durationField43 = property20.getRangeDurationField();
//        long long46 = durationField43.subtract(9972000000L, 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PST" + "'", str25.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-28799968L) + "'", long30 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PST" + "'", str37.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-25200000) + "'", int41 == (-25200000));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9972000000L + "'", long46 == 9972000000L);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 126 + "'", number5.equals(126));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime15 = dateTime12.toLocalTime();
//        org.joda.time.DateTime dateTime17 = dateTime12.plusDays(173);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Chronology chronology9 = dateTime7.getChronology();
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime12 = dateTime7.minusYears((int) (short) 10);
//        int int13 = dateTime7.getMinuteOfHour();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        java.lang.String str7 = dateTimeZone1.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter8.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter8.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28800006L, (java.lang.Number) 933L, (java.lang.Number) (-60000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        int int10 = dateTimeZone6.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology11 = gregorianChronology5.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology5.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology5.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology5.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology5.secondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(2, (-1), 8, 1, 53009442, (org.joda.time.Chronology) gregorianChronology5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53009442 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal((long) '4');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, dateTimeZone1);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getShortName((long) 36, locale6);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28799948L) + "'", long3 == (-28799948L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
//        org.joda.time.DateTime.Property property23 = dateTime22.hourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusMillis(0);
//        boolean boolean26 = dateTime22.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime22.toTimeOfDay();
//        int int28 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay27);
//        long long31 = offsetDateTimeField9.add(52L, 14);
//        long long33 = offsetDateTimeField9.roundHalfFloor((long) (short) 100);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField9.getAsShortText((long) 52998580, locale35);
//        java.util.Locale locale39 = null;
//        try {
//            long long40 = offsetDateTimeField9.set((long) 3, "5", locale39);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for millisOfDay must be in the range [10,86400009]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 66L + "'", long31 == 66L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "52998590" + "'", str36.equals("52998590"));
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.joda.time.DurationField durationField17 = property15.getRangeDurationField();
//        try {
//            org.joda.time.DateTime dateTime19 = property15.setCopy("-1");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = dateTime12.toCalendar(locale13);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime12.plus(readableDuration15);
//        int int17 = dateTime12.getDayOfMonth();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(calendar14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.centuries();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        long long12 = gregorianChronology0.add(readablePeriod9, (-883L), 59);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-883L) + "'", long12 == (-883L));
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        int int9 = dateTimeZone5.getOffsetFromLocal((long) 'a');
//        java.lang.String str11 = dateTimeZone5.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter4.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone5);
//        org.joda.time.Instant instant14 = dateTime13.toInstant();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(instant14);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(34, 9, 35, 53009442, 2019, 1497599948, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53009442 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withDayOfYear(12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
//        org.joda.time.DateTime dateTime13 = dateTime10.withYear(0);
//        org.joda.time.DateTime dateTime15 = dateTime10.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatter19.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str23 = dateTimeZone21.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter20, dateTimeZone21);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        org.joda.time.DateTime.Property property27 = dateTime24.dayOfWeek();
//        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime29 = property27.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime31 = property27.addToCopy(0);
//        org.joda.time.DateTime dateTime32 = property27.withMaximumValue();
//        org.joda.time.DateTime dateTime34 = property27.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property27.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "0");
//        int int38 = dateTime10.get(dateTimeFieldType35);
//        try {
//            org.joda.time.DateTime dateTime40 = dateTime2.withField(dateTimeFieldType35, 47);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNull(dateTimePrinter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime7.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime7, (org.joda.time.Chronology) gregorianChronology14);
//        try {
//            long long28 = gregorianChronology14.getDateTimeMillis(53006089, (-28800000), (-28800000), 15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(readableDuration13, 0);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusYears(480);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTimeISO();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("5", 480, 173, 100, '#', 2019, 883, 52997649, false, 14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder13.setFixedSavings("0", (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getLeapDurationField();
//        boolean boolean17 = offsetDateTimeField9.isLeap((long) (byte) -1);
//        long long20 = offsetDateTimeField9.add(9972000000L, (long) 14);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9972000014L + "'", long20 == 9972000014L);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-28799948");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-28799948\" is malformed at \"28799948\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        int int9 = dateTimeZone5.getOffsetFromLocal((long) 'a');
//        java.lang.String str11 = dateTimeZone5.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter4.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone5);
//        long long16 = dateTimeZone5.adjustOffset((long) (byte) 100, false);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Chronology chronology9 = dateTime7.getChronology();
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime12 = dateTime7.withDayOfYear((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime7.withSecondOfMinute(59);
//        int int15 = dateTime7.getDayOfWeek();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        java.lang.Class<?> wildcardClass13 = dateTime12.getClass();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withDayOfYear(52998580);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52998580 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("43", (java.lang.Number) (-28799948L), (java.lang.Number) 1560556852995L, (java.lang.Number) (byte) 1);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 126 + "'", number5.equals(126));
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        boolean boolean14 = dateTime12.isEqual(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.plusMillis((-1));
//        int int17 = dateTime12.getSecondOfMinute();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 42 + "'", int17 == 42);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        boolean boolean26 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        int int27 = dateTime23.getHourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str30 = dateTimeZone28.getShortName((long) (byte) 10);
//        int int32 = dateTimeZone28.getOffsetFromLocal((long) 'a');
//        java.lang.String str34 = dateTimeZone28.getShortName(0L);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone28);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone28.getShortName((long) (byte) 1, locale38);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone42 = cachedDateTimeZone41.getUncachedZone();
//        org.joda.time.DateTime dateTime43 = dateTime23.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone41);
//        org.joda.time.Chronology chronology44 = dateTime43.getChronology();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 14 + "'", int27 == 14);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-28800000) + "'", int32 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PST" + "'", str39.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(chronology44);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekyear((int) '#');
//        org.joda.time.DateTime.Property property11 = dateTime7.millisOfSecond();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-25200000), chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str10 = dateTimeZone1.getID();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Instant instant9 = dateTime7.toInstant();
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter18, dateTimeZone19);
//        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate23, 2, locale25);
//        org.joda.time.DurationField durationField27 = offsetDateTimeField9.getDurationField();
//        long long30 = durationField27.subtract((long) 1023, (long) '#');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 988L + "'", long30 == 988L);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) 6, (long) 14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology15.secondOfDay();
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate28 = dateTimeFormatter26.parseLocalDate("2019-W24-6");
//        int[] intArray30 = gregorianChronology15.get((org.joda.time.ReadablePartial) localDate28, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str34 = dateTimeZone32.getShortName((long) (byte) 10);
//        int int36 = dateTimeZone32.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology37 = gregorianChronology31.withZone(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology31.secondOfDay();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate44 = dateTimeFormatter42.parseLocalDate("2019-W24-6");
//        int[] intArray46 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDate44, 1023L);
//        int int47 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate28, intArray46);
//        long long49 = offsetDateTimeField9.roundHalfCeiling((long) (byte) -1);
//        long long52 = offsetDateTimeField9.add((long) 86400009, (long) (short) 100);
//        long long55 = offsetDateTimeField9.add((long) (short) -1, 1023);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 86400109L + "'", long52 == 86400109L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1022L + "'", long55 == 1022L);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusYears((int) (short) 1);
//        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
//        try {
//            java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianCalendar15);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone1.convertUTCToLocal((long) '4');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28799948L) + "'", long3 == (-28799948L));
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        boolean boolean12 = property10.equals((java.lang.Object) "PST");
//        org.joda.time.DurationField durationField13 = property10.getLeapDurationField();
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str20 = dateTimeZone18.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter17, dateTimeZone18);
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime24 = dateTime21.plusMillis(0);
//        org.joda.time.DateTime dateTime26 = dateTime21.withHourOfDay(0);
//        int int27 = property10.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        boolean boolean29 = dateTime26.isBefore((-28799968L));
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime26.getZone();
//        java.util.Date date31 = dateTime26.toDate();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertNull(dateTimePrinter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(date31);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime14.toMutableDateTime(dateTimeZone16);
//        org.joda.time.DateTime.Property property20 = dateTime14.minuteOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimePrinter3, dateTimeParser5);
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser8);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone11.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter10, dateTimeZone11);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readableDuration15);
//        org.joda.time.DateTime.Property property17 = dateTime14.dayOfWeek();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime19 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime21 = property17.addToCopy(0);
//        org.joda.time.DateTime dateTime22 = property17.withMaximumValue();
//        org.joda.time.DateTime dateTime24 = property17.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property17.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType25, 480, (int) (short) 1);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeParser5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNull(dateTimePrinter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        boolean boolean17 = offsetDateTimeField9.isLeap((long) 8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        int int23 = dateTimeZone19.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology18.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology18.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology18.secondOfDay();
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate31 = dateTimeFormatter29.parseLocalDate("2019-W24-6");
//        int[] intArray33 = gregorianChronology18.get((org.joda.time.ReadablePartial) localDate31, 1023L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate31, 52995, locale35);
//        long long38 = offsetDateTimeField9.roundHalfEven(1560556852995L);
//        long long40 = offsetDateTimeField9.remainder((long) 86400009);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "52995" + "'", str36.equals("52995"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560556852995L + "'", long38 == 1560556852995L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        java.lang.Class<?> wildcardClass13 = dateTime12.getClass();
//        org.joda.time.DateTime.Property property14 = dateTime12.weekyear();
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfMinute();
//        java.lang.String str16 = property15.toString();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Property[secondOfMinute]" + "'", str16.equals("Property[secondOfMinute]"));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime17 = property10.addToCopy((long) (short) -1);
//        int int18 = dateTime17.getWeekyear();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfMonth();
//        org.joda.time.DurationField durationField16 = property15.getLeapDurationField();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNull(durationField16);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32 + "'", number5.equals(32));
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        java.lang.String str7 = dateTimeZone1.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone1);
//        java.io.Writer writer9 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str16 = dateTimeZone14.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter13, dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        org.joda.time.DateTime dateTime20 = dateTime17.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter21 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser22 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter21, dateTimeParser22);
//        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatter23.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str27 = dateTimeZone25.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter24, dateTimeZone25);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.plus(readableDuration29);
//        org.joda.time.DateTime.Property property31 = dateTime30.hourOfDay();
//        org.joda.time.DateTime dateTime33 = dateTime30.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.minus(readablePeriod34);
//        boolean boolean36 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str40 = dateTimeZone38.getShortName((long) (byte) 10);
//        int int42 = dateTimeZone38.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology43 = gregorianChronology37.withZone(dateTimeZone38);
//        long long45 = dateTimeZone38.convertUTCToLocal((long) ' ');
//        int int47 = dateTimeZone38.getOffsetFromLocal((long) 'a');
//        org.joda.time.DateTime dateTime48 = dateTime17.withZone(dateTimeZone38);
//        try {
//            dateTimeFormatter8.printTo(writer9, (org.joda.time.ReadableInstant) dateTime48);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNull(dateTimePrinter13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNull(dateTimePrinter24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PST" + "'", str27.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PST" + "'", str40.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-28799968L) + "'", long45 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-28800000) + "'", int47 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime48);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) 6, (long) 14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology15.secondOfDay();
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate28 = dateTimeFormatter26.parseLocalDate("2019-W24-6");
//        int[] intArray30 = gregorianChronology15.get((org.joda.time.ReadablePartial) localDate28, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str34 = dateTimeZone32.getShortName((long) (byte) 10);
//        int int36 = dateTimeZone32.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology37 = gregorianChronology31.withZone(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology31.secondOfDay();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate44 = dateTimeFormatter42.parseLocalDate("2019-W24-6");
//        int[] intArray46 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDate44, 1023L);
//        int int47 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate28, intArray46);
//        java.util.Locale locale50 = null;
//        try {
//            long long51 = offsetDateTimeField9.set((long) 53009442, "", locale50);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.hours();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        java.lang.String str9 = dateTimeZone8.getID();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 34, 934);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime14 = property10.roundHalfCeilingCopy();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillis(0L);
//        org.joda.time.DurationFieldType durationFieldType18 = null;
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime15.withFieldAdded(durationFieldType18, (-28799968));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime13 = dateTime7.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology15.dayOfMonth();
//        org.joda.time.DurationField durationField24 = gregorianChronology15.minutes();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology15.era();
//        int int26 = dateTime14.get(dateTimeField25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str29 = dateTimeZone27.getShortName((long) (byte) 10);
//        int int31 = dateTimeZone27.getOffsetFromLocal((long) 'a');
//        java.lang.String str33 = dateTimeZone27.getShortName(0L);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.DateTime dateTime35 = dateTime14.withZoneRetainFields(dateTimeZone27);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        boolean boolean17 = offsetDateTimeField9.isLeap((long) 8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        int int23 = dateTimeZone19.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology18.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology18.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology18.secondOfDay();
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate31 = dateTimeFormatter29.parseLocalDate("2019-W24-6");
//        int[] intArray33 = gregorianChronology18.get((org.joda.time.ReadablePartial) localDate31, 1023L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate31, 52995, locale35);
//        long long38 = offsetDateTimeField9.roundHalfEven(1560556852995L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate41 = dateTimeFormatter39.parseLocalDate("2019-W24-6");
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate41, 934, locale43);
//        long long46 = offsetDateTimeField9.roundHalfEven((long) (-25200000));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "52995" + "'", str36.equals("52995"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560556852995L + "'", long38 == 1560556852995L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "934" + "'", str44.equals("934"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-25200000L) + "'", long46 == (-25200000L));
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
//        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withWeekyear((int) (byte) -1);
//        int int22 = dateTime21.getYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        long long22 = dateTimeZone15.convertUTCToLocal((long) ' ');
//        int int24 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime12.toMutableDateTime(dateTimeZone15);
//        org.joda.time.DateTime.Property property26 = dateTime12.dayOfMonth();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28799968L) + "'", long22 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("52995", "2019-06-15T14", 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 52989);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15T14" + "'", str6.equals("2019-06-15T14"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(53023613L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53023613 + "'", int1 == 53023613);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((-1));
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560635027208L + "'", long17 == 1560635027208L);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        int int21 = gregorianChronology14.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField22 = gregorianChronology14.minutes();
//        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime dateTime25 = dateTime11.minusHours(0);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        int int9 = dateTimeZone5.getOffsetFromLocal((long) 'a');
//        java.lang.String str11 = dateTimeZone5.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter4.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone5);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMinutes(1497599948);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sat");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str4 = jodaTimePermission3.getActions();
        java.lang.String str5 = jodaTimePermission3.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str7 = jodaTimePermission3.toString();
        java.lang.String str8 = jodaTimePermission3.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission10 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str11 = jodaTimePermission10.getActions();
        java.lang.String str12 = jodaTimePermission10.toString();
        boolean boolean13 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str12.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("2019-06-15T14", 53024);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long12 = gregorianChronology0.getDateTimeMillis(0L, (int) (short) 0, 6, 8, (int) (byte) 100);
//        try {
//            long long17 = gregorianChronology0.getDateTimeMillis(934, (int) (byte) 1, 43, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 43 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 368100L + "'", long12 == 368100L);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) (byte) 1, locale10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int15 = cachedDateTimeZone13.getStandardOffset((long) 1023);
//        java.lang.String str17 = cachedDateTimeZone13.getName((long) 53006089);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str14 = dateTimeZone12.getShortName((long) (byte) 10);
//        int int16 = dateTimeZone12.getOffsetFromLocal((long) 'a');
//        java.lang.String str18 = dateTimeZone12.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withZone(dateTimeZone12);
//        org.joda.time.Chronology chronology20 = gregorianChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.hourOfHalfday();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = dateTime12.toCalendar(locale13);
//        org.joda.time.DateTime dateTime15 = dateTime12.withEarlierOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(calendar14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime10.toMutableDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
//        org.joda.time.DateTime.Property property23 = dateTime20.dayOfWeek();
//        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime25 = property23.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property23.addToCopy(0);
//        org.joda.time.DateTime dateTime28 = property23.withMaximumValue();
//        org.joda.time.DateTime dateTime30 = property23.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property23.getFieldType();
//        boolean boolean32 = dateTime10.isSupported(dateTimeFieldType31);
//        try {
//            org.joda.time.DateTime dateTime34 = dateTime10.withDayOfYear((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime9.toMutableDateTime();
//        long long14 = dateTime9.getMillis();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635029018L + "'", long14 == 1560635029018L);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) (short) 1);
//        org.joda.time.DateMidnight dateMidnight14 = dateTime11.toDateMidnight();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateMidnight14.toCalendar(locale15);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(calendar16);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(0);
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        int int21 = dateTimeZone17.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone17);
//        long long24 = dateTimeZone17.convertUTCToLocal((long) ' ');
//        int int26 = dateTimeZone17.getOffsetFromLocal((long) 'a');
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime14.toMutableDateTime(dateTimeZone17);
//        int int30 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime27, "", 53001523);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28799968L) + "'", long24 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-53001524) + "'", int30 == (-53001524));
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T14:43:49-07:00" + "'", str2.equals("2019-06-15T14:43:49-07:00"));
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str14 = dateTimeZone12.getShortName((long) (byte) 10);
//        int int16 = dateTimeZone12.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology17 = gregorianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology11.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology11.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTime dateTime22 = dateTime10.minusMonths(0);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        long long8 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
//        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property20 = dateTime18.weekOfWeekyear();
//        int int21 = property20.getMaximumValue();
//        org.joda.time.DurationField durationField22 = property20.getDurationField();
//        org.joda.time.DurationField durationField23 = property20.getLeapDurationField();
//        org.joda.time.DateTime dateTime25 = property20.addWrapFieldToCopy(933);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799968L) + "'", long8 == (-28799968L));
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) (byte) 1, locale10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.lang.String str13 = dateTimeZone0.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone15.convertUTCToLocal((long) '4');
//        long long19 = dateTimeZone0.getMillisKeepLocal(dateTimeZone15, 28801969L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28799948L) + "'", long17 == (-28799948L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28801969L + "'", long19 == 28801969L);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sat");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        java.lang.String str7 = dateTimeZone1.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone1);
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds((int) (byte) 10);
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.Chronology chronology14 = dateTimeFormatter0.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15T14" + "'", str13.equals("2019-06-15T14"));
//        org.junit.Assert.assertNull(chronology14);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readablePeriod10);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, 53001523);
//        org.joda.time.DateTime.Property property15 = dateTime11.weekyear();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 10);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 'a');
//        java.lang.String str6 = dateTimeZone0.getShortName(0L);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone0.getName(0L, locale9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime13 = dateTime7.minusMonths((int) (byte) 10);
//        int int14 = dateTime13.getMillisOfDay();
//        java.util.Date date15 = dateTime13.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime13.withWeekyear((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime13.minusMinutes(10);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53029982 + "'", int14 == 53029982);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-28799968L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        boolean boolean17 = offsetDateTimeField9.isLeap((long) 8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        int int23 = dateTimeZone19.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology18.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology18.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology18.secondOfDay();
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate31 = dateTimeFormatter29.parseLocalDate("2019-W24-6");
//        int[] intArray33 = gregorianChronology18.get((org.joda.time.ReadablePartial) localDate31, 1023L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate31, 52995, locale35);
//        long long38 = offsetDateTimeField9.roundHalfEven(1560556852995L);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        int[] intArray41 = null;
//        try {
//            int[] intArray43 = offsetDateTimeField9.set(readablePartial39, 1023, intArray41, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [10,86400009]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "52995" + "'", str36.equals("52995"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560556852995L + "'", long38 == 1560556852995L);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter5, dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(0);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateMidnight15);
//        java.lang.Appendable appendable17 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser19 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter18, dateTimeParser19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str24 = dateTimeZone22.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter21, dateTimeZone22);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.plus(readableDuration26);
//        org.joda.time.DateTime.Property property28 = dateTime27.hourOfDay();
//        org.joda.time.DateTime dateTime30 = dateTime27.minusMillis(0);
//        boolean boolean31 = dateTime27.isEqualNow();
//        int int32 = dateTime27.getSecondOfDay();
//        org.joda.time.DateTime dateTime34 = dateTime27.minusMinutes(3);
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        try {
//            dateTimeFormatter0.printTo(appendable17, (org.joda.time.ReadablePartial) localDateTime35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019166" + "'", str16.equals("2019166"));
//        org.junit.Assert.assertNull(dateTimePrinter21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53030 + "'", int32 == 53030);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfMonth();
//        org.joda.time.DurationField durationField14 = property13.getDurationField();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(34);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        long long14 = offsetDateTimeField9.roundHalfEven((long) (-28799968));
//        int int15 = offsetDateTimeField9.getMaximumValue();
//        org.joda.time.DurationField durationField16 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.DurationFieldType durationFieldType17 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField18 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28799968L) + "'", long14 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86400009 + "'", int15 == 86400009);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("52995", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"52995/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        java.io.Writer writer3 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter7, dateTimeZone8);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
//        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusMillis(0);
//        boolean boolean17 = dateTime13.isEqualNow();
//        org.joda.time.DateTime.Property property18 = dateTime13.yearOfCentury();
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser20);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter21.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str25 = dateTimeZone23.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter22, dateTimeZone23);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.plus(readableDuration27);
//        org.joda.time.DateTime.Property property29 = dateTime28.hourOfDay();
//        org.joda.time.DateTime dateTime31 = dateTime28.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.minus(readablePeriod32);
//        long long34 = property18.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime33);
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-W24-6" + "'", str2.equals("2019-W24-6"));
//        org.junit.Assert.assertNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PST" + "'", str25.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime14 = property10.roundFloorCopy();
//        int int15 = dateTime14.getDayOfYear();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 166 + "'", int15 == 166);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withDayOfYear(12);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(86400009);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str6 = dateTime0.toString(dateTimeFormatter5);
//        org.joda.time.DateTime dateTime8 = dateTime0.plusWeeks((-2020));
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "14:43:50-07:00" + "'", str6.equals("14:43:50-07:00"));
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("5", 53025507, (-52997649), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53025507 for 5 must be in the range [-52997649,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime17 = property10.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "0");
//        java.lang.String str21 = illegalFieldValueException20.toString();
//        java.lang.Number number22 = illegalFieldValueException20.getUpperBound();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"0\" for dayOfWeek is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: Value \"0\" for dayOfWeek is not supported"));
//        org.junit.Assert.assertNull(number22);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime17 = property10.addToCopy((long) (short) -1);
//        int int18 = dateTime17.getCenturyOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.dayOfYear();
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser21 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter20, dateTimeParser21);
//        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatter22.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str26 = dateTimeZone24.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter23, dateTimeZone24);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readableDuration28);
//        org.joda.time.DateTime.Property property30 = dateTime29.hourOfDay();
//        org.joda.time.DateTime dateTime32 = dateTime29.minusMillis(0);
//        boolean boolean33 = dateTime29.isEqualNow();
//        org.joda.time.DateTime.Property property34 = dateTime29.yearOfCentury();
//        org.joda.time.DateTime dateTime36 = dateTime29.minus((long) (short) -1);
//        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
//        try {
//            int int38 = property19.compareTo((org.joda.time.ReadablePartial) localTime37);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(dateTimePrinter23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PST" + "'", str26.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localTime37);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusYears((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.withDurationAdded(readableDuration15, (int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.plusYears(59);
//        boolean boolean21 = dateTime17.isBefore((long) 'a');
//        boolean boolean23 = dateTime17.isAfter((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str27 = dateTimeZone25.getShortName((long) (byte) 10);
//        int int29 = dateTimeZone25.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology30 = gregorianChronology24.withZone(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology24.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 10);
//        long long36 = offsetDateTimeField33.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter37 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser38 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter37, dateTimeParser38);
//        org.joda.time.format.DateTimePrinter dateTimePrinter40 = dateTimeFormatter39.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str43 = dateTimeZone41.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter40, dateTimeZone41);
//        org.joda.time.ReadableDuration readableDuration45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime44.plus(readableDuration45);
//        org.joda.time.DateTime.Property property47 = dateTime46.hourOfDay();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusMillis(0);
//        boolean boolean50 = dateTime46.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay51 = dateTime46.toTimeOfDay();
//        int int52 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay51);
//        long long55 = offsetDateTimeField33.add(52L, 14);
//        long long57 = offsetDateTimeField33.roundHalfFloor((long) (short) 100);
//        java.lang.String str59 = offsetDateTimeField33.getAsShortText((-60000L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField33.getType();
//        int int61 = dateTime17.get(dateTimeFieldType60);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType60);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PST" + "'", str27.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 5L + "'", long36 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PST" + "'", str43.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(timeOfDay51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 66L + "'", long55 == 66L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "86340010" + "'", str59.equals("86340010"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.minus(readableDuration9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone11.getShortName((long) (byte) 10);
//        int int15 = dateTimeZone11.getOffsetFromLocal((long) 'a');
//        java.lang.String str17 = dateTimeZone11.getShortName(0L);
//        java.util.TimeZone timeZone18 = dateTimeZone11.toTimeZone();
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime10.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTime.Property property20 = dateTime10.secondOfMinute();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str15 = dateTimeZone13.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter12, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
//        org.joda.time.DateTime dateTime19 = dateTime16.withYear(0);
//        org.joda.time.DateTime dateTime21 = dateTime16.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property22 = dateTime16.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str26 = dateTimeZone24.getShortName((long) (byte) 10);
//        int int28 = dateTimeZone24.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology29 = gregorianChronology23.withZone(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology23.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology23.secondOfDay();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) dateTime16, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTime dateTime34 = dateTime16.plusMinutes((-2020));
//        org.joda.time.format.DateTimePrinter dateTimePrinter35 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser36 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter35, dateTimeParser36);
//        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatter37.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str41 = dateTimeZone39.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter38, dateTimeZone39);
//        org.joda.time.ReadableDuration readableDuration43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime42.plus(readableDuration43);
//        org.joda.time.DateTime.Property property45 = dateTime42.dayOfWeek();
//        org.joda.time.DateTime dateTime46 = property45.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime47 = property45.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime49 = property45.addToCopy(0);
//        org.joda.time.DateTime dateTime50 = property45.withMaximumValue();
//        org.joda.time.DateTime dateTime52 = property45.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property45.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "0");
//        java.lang.Number number56 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, number56, (java.lang.Number) 100.0f, (java.lang.Number) 12);
//        int int60 = dateTime16.get(dateTimeFieldType53);
//        boolean boolean61 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNull(dateTimePrinter12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PST" + "'", str26.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNull(dateTimePrinter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(2019);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("-1", (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        java.lang.String str11 = property10.getAsString();
//        org.joda.time.DateTime dateTime13 = property10.addWrapFieldToCopy(53009442);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6" + "'", str11.equals("6"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property10.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime17 = property10.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "0");
//        java.lang.Number number21 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, number21, (java.lang.Number) 100.0f, (java.lang.Number) 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatter26.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.append(dateTimePrinter27, dateTimeParser29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMillisOfSecond(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendSecondOfMinute((int) (short) 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter35 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser36 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter35, dateTimeParser36);
//        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatter37.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str41 = dateTimeZone39.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter38, dateTimeZone39);
//        org.joda.time.ReadableDuration readableDuration43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime42.plus(readableDuration43);
//        org.joda.time.DateTime.Property property45 = dateTime42.dayOfWeek();
//        org.joda.time.DateTime dateTime46 = property45.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime47 = property45.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime49 = property45.addToCopy(0);
//        org.joda.time.DateTime dateTime50 = property45.withMaximumValue();
//        org.joda.time.DateTime dateTime52 = property45.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property45.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder32.appendFixedDecimal(dateTimeFieldType53, 1023);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray56 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType18, dateTimeFieldType53 };
//        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList57 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
//        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList57, dateTimeFieldTypeArray56);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList57, true, true);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimePrinter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNull(dateTimePrinter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.joda.time.DurationField durationField17 = property15.getRangeDurationField();
//        java.lang.String str18 = property15.getAsString();
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser20);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter21.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str25 = dateTimeZone23.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter22, dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.DateTime dateTime29 = dateTime26.withYear(0);
//        org.joda.time.ReadableDuration readableDuration30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime26.minus(readableDuration30);
//        long long32 = property15.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime31);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PST" + "'", str25.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 52989, dateTimeZone6);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '#');
//        long long12 = offsetDateTimeField10.roundHalfCeiling(12L);
//        long long14 = offsetDateTimeField10.roundHalfCeiling((long) 52995);
//        java.lang.String str16 = offsetDateTimeField10.getAsText((long) 52989);
//        org.joda.time.format.DateTimePrinter dateTimePrinter17 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
//        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatter19.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str23 = dateTimeZone21.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter20, dateTimeZone21);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        org.joda.time.DateTime.Property property27 = dateTime24.dayOfWeek();
//        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime30 = dateTime28.minusYears((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime28.withDurationAdded(readableDuration31, (int) (byte) 10);
//        org.joda.time.DateTime dateTime35 = dateTime33.plusYears(59);
//        boolean boolean37 = dateTime33.isBefore((long) 'a');
//        boolean boolean39 = dateTime33.isAfter((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str43 = dateTimeZone41.getShortName((long) (byte) 10);
//        int int45 = dateTimeZone41.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology46 = gregorianChronology40.withZone(dateTimeZone41);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology40.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) (byte) 10);
//        long long52 = offsetDateTimeField49.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter53 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser54 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter53, dateTimeParser54);
//        org.joda.time.format.DateTimePrinter dateTimePrinter56 = dateTimeFormatter55.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str59 = dateTimeZone57.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter56, dateTimeZone57);
//        org.joda.time.ReadableDuration readableDuration61 = null;
//        org.joda.time.DateTime dateTime62 = dateTime60.plus(readableDuration61);
//        org.joda.time.DateTime.Property property63 = dateTime62.hourOfDay();
//        org.joda.time.DateTime dateTime65 = dateTime62.minusMillis(0);
//        boolean boolean66 = dateTime62.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay67 = dateTime62.toTimeOfDay();
//        int int68 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay67);
//        long long71 = offsetDateTimeField49.add(52L, 14);
//        long long73 = offsetDateTimeField49.roundHalfFloor((long) (short) 100);
//        java.lang.String str75 = offsetDateTimeField49.getAsShortText((-60000L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = offsetDateTimeField49.getType();
//        int int77 = dateTime33.get(dateTimeFieldType76);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType76, 52);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 978307200000L + "'", long12 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 978307200000L + "'", long14 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "55" + "'", str16.equals("55"));
//        org.junit.Assert.assertNull(dateTimePrinter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PST" + "'", str43.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 5L + "'", long52 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "PST" + "'", str59.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeOfDay67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 10 + "'", int68 == 10);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 66L + "'", long71 == 66L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "86340010" + "'", str75.equals("86340010"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusWeeks(2);
//        int int14 = dateTime13.getMillisOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53033776 + "'", int14 == 53033776);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        org.joda.time.DateTime.Property property14 = dateTime9.yearOfCentury();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter15, dateTimeParser16);
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str21 = dateTimeZone19.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter18, dateTimeZone19);
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readableDuration23);
//        org.joda.time.DateTime.Property property25 = dateTime24.hourOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.minus(readablePeriod28);
//        long long30 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DurationField durationField31 = property14.getLeapDurationField();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNull(durationField31);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        org.joda.time.DateTime.Property property14 = dateTime9.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        java.util.Locale locale16 = null;
//        int int17 = property14.getMaximumShortTextLength(locale16);
//        int int18 = property14.getMaximumValue();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 99 + "'", int18 == 99);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        java.lang.String str2 = jodaTimePermission1.getActions();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str9 = dateTimeZone7.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter6, dateTimeZone7);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
//        org.joda.time.DateTime.Property property13 = dateTime12.hourOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
//        org.joda.time.DateTime.Property property18 = dateTime15.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str22 = dateTimeZone20.getShortName((long) (byte) 10);
//        int int24 = dateTimeZone20.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology25 = gregorianChronology19.withZone(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology19.dayOfWeek();
//        boolean boolean27 = property18.equals((java.lang.Object) dateTimeField26);
//        boolean boolean28 = jodaTimePermission1.equals((java.lang.Object) boolean27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter29);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime32 = dateTimeFormatter29.parseMutableDateTime("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.monthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.append(dateTimePrinter5, dateTimeParser7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.append(dateTimePrinter5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfSecond(14, 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.DateTime dateTime23 = dateTime20.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter24 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser25 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter24, dateTimeParser25);
//        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatter26.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str30 = dateTimeZone28.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter27, dateTimeZone28);
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readableDuration32);
//        org.joda.time.DateTime.Property property34 = dateTime33.hourOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime33.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.minus(readablePeriod37);
//        boolean boolean39 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime36);
//        java.util.GregorianCalendar gregorianCalendar40 = dateTime36.toGregorianCalendar();
//        long long41 = dateTime36.getMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter42 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser43 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter42, dateTimeParser43);
//        org.joda.time.format.DateTimePrinter dateTimePrinter45 = dateTimeFormatter44.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str48 = dateTimeZone46.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter45, dateTimeZone46);
//        org.joda.time.ReadableDuration readableDuration50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime49.plus(readableDuration50);
//        org.joda.time.DateTime.Property property52 = dateTime49.dayOfWeek();
//        org.joda.time.DateTime dateTime53 = property52.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime54 = property52.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime56 = property52.addToCopy(0);
//        org.joda.time.DateTime dateTime57 = property52.withMaximumValue();
//        org.joda.time.DateTime dateTime59 = property52.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property52.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "0");
//        boolean boolean63 = dateTime36.isSupported(dateTimeFieldType60);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType60, (-2020), (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeParser7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNull(dateTimePrinter27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560635034095L + "'", long41 == 1560635034095L);
//        org.junit.Assert.assertNull(dateTimePrinter45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PST" + "'", str48.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.DateTime.Property property13 = dateTime12.era();
//        int int14 = dateTime12.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property16 = dateTime12.dayOfWeek();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53034 + "'", int14 == 53034);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(0);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        boolean boolean26 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        java.util.GregorianCalendar gregorianCalendar27 = dateTime23.toGregorianCalendar();
//        org.joda.time.DateTime dateTime29 = dateTime23.minusMonths((int) (short) 100);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekyear();
//        try {
//            long long18 = gregorianChronology0.getDateTimeMillis(0, (-53001524), 53006089, 32, (int) (short) 1, 934, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.plusWeeks((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis(2019);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.append(dateTimePrinter5, dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.append(dateTimePrinter5);
        boolean boolean10 = dateTimeFormatterBuilder1.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 28800006L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = dateTime12.toCalendar(locale13);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime12.plus(readableDuration15);
//        org.joda.time.DateTime dateTime18 = dateTime12.minusSeconds(20);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(calendar14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 883 + "'", int19 == 883);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyearOfCentury();
//        try {
//            long long13 = gregorianChronology0.getDateTimeMillis(53033776, (-53001524), 53001523, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53001524 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime7.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        int int19 = dateTimeZone15.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime7, (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime dateTime25 = dateTime7.plusMinutes((-2020));
//        org.joda.time.DateTime.Property property26 = dateTime7.hourOfDay();
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-28799921L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.remainder(5L);
//        long long14 = offsetDateTimeField9.add(1L, 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 101L + "'", long14 == 101L);
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime13 = dateTime7.minusMonths((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(53006089);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
//        org.joda.time.DurationField durationField10 = gregorianChronology0.weekyears();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.era();
//        long long14 = gregorianChronology0.add((long) 126, (long) 2000, (int) (short) 1);
//        org.joda.time.DurationField durationField15 = gregorianChronology0.seconds();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2126L + "'", long14 == 2126L);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DurationField durationField3 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 52997649, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5352762549L + "'", long2 == 5352762549L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter2, dateTimeParser4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond(0);
        boolean boolean8 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) ' ', 12);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (-1));
//        long long18 = offsetDateTimeField16.roundFloor((long) 1497599948);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 44L + "'", long14 == 44L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1497599948L + "'", long18 == 1497599948L);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfCentury();
//        org.joda.time.DurationField durationField10 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "53007", (int) (short) 100, (int) (byte) 10);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.nextTransition((long) 12);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(1560635027208L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53007" + "'", str6.equals("53007"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53007" + "'", str11.equals("53007"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 173);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(readableDuration14, (int) (byte) 10);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
//        java.util.Locale locale20 = null;
//        int int21 = property19.getMaximumShortTextLength(locale20);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        int int11 = offsetDateTimeField9.getLeapAmount((long) 1969);
//        long long14 = offsetDateTimeField9.add((long) 6, (long) 14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str18 = dateTimeZone16.getShortName((long) (byte) 10);
//        int int20 = dateTimeZone16.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology21 = gregorianChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology15.secondOfDay();
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate28 = dateTimeFormatter26.parseLocalDate("2019-W24-6");
//        int[] intArray30 = gregorianChronology15.get((org.joda.time.ReadablePartial) localDate28, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str34 = dateTimeZone32.getShortName((long) (byte) 10);
//        int int36 = dateTimeZone32.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology37 = gregorianChronology31.withZone(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology31.secondOfDay();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate44 = dateTimeFormatter42.parseLocalDate("2019-W24-6");
//        int[] intArray46 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDate44, 1023L);
//        int int47 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate28, intArray46);
//        org.joda.time.DurationField durationField48 = offsetDateTimeField9.getRangeDurationField();
//        java.lang.String str49 = offsetDateTimeField9.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20L + "'", long14 == 20L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "DateTimeField[millisOfDay]" + "'", str49.equals("DateTimeField[millisOfDay]"));
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTwoDigitYear(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneOffset("ISOChronology[UTC]", false, (-52997649), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        org.joda.time.DateTime dateTime15 = dateTime9.withHourOfDay((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        int int21 = dateTimeZone17.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology16.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology16.secondOfDay();
//        org.joda.time.format.DateTimePrinter dateTimePrinter26 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser27 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter26, dateTimeParser27);
//        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatter28.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str32 = dateTimeZone30.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter29, dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone34 = dateTime33.getZone();
//        org.joda.time.DateTime dateTime36 = dateTime33.withYear(0);
//        org.joda.time.DateTime dateTime38 = dateTime33.withYear((int) (byte) 100);
//        org.joda.time.DateTime.Property property39 = dateTime33.minuteOfHour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter40 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser41 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter40, dateTimeParser41);
//        org.joda.time.format.DateTimePrinter dateTimePrinter43 = dateTimeFormatter42.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str46 = dateTimeZone44.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter43, dateTimeZone44);
//        org.joda.time.ReadableDuration readableDuration48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime47.plus(readableDuration48);
//        org.joda.time.DateTime.Property property50 = dateTime47.dayOfWeek();
//        org.joda.time.DateTime dateTime51 = property50.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime52 = property50.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime54 = property50.addToCopy(0);
//        org.joda.time.DateTime dateTime55 = property50.withMaximumValue();
//        org.joda.time.DateTime dateTime57 = property50.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property50.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, "0");
//        int int61 = dateTime33.get(dateTimeFieldType58);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType58, 1023, (int) (byte) 1, 12);
//        int int66 = dateTime15.get(dateTimeFieldType58);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNull(dateTimePrinter29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PST" + "'", str32.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNull(dateTimePrinter43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "PST" + "'", str46.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) (byte) 10);
//        int int6 = dateTimeZone2.getOffsetFromLocal((long) 'a');
//        java.lang.String str8 = dateTimeZone2.getShortName(0L);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone2);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter4, dateTimeZone5);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime8.toGregorianCalendar();
//        java.util.GregorianCalendar gregorianCalendar12 = dateTime8.toGregorianCalendar();
//        org.joda.time.DateTime dateTime14 = dateTime8.minusMonths((int) (byte) 10);
//        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(gregorianCalendar12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T14:43:57.786-07:00" + "'", str15.equals("T14:43:57.786-07:00"));
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Chronology chronology9 = dateTime7.getChronology();
//        org.joda.time.DateTime.Property property10 = dateTime7.era();
//        org.joda.time.DateTime dateTime12 = dateTime7.plusWeeks((-1));
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
//        org.joda.time.DateTime.Property property23 = dateTime22.hourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusMillis(0);
//        boolean boolean26 = dateTime22.isEqualNow();
//        int int27 = dateTime22.getSecondOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime22.minusMinutes(3);
//        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str35 = dateTimeZone33.getShortName((long) (byte) 10);
//        int int37 = dateTimeZone33.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology38 = gregorianChronology32.withZone(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology32.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology32.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology32.secondOfDay();
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate45 = dateTimeFormatter43.parseLocalDate("2019-W24-6");
//        int[] intArray47 = gregorianChronology32.get((org.joda.time.ReadablePartial) localDate45, 1023L);
//        try {
//            int[] intArray49 = offsetDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDateTime30, 53029982, intArray47, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53029982");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53037 + "'", int27 == 53037);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PST" + "'", str35.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28800000) + "'", int37 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(intArray47);
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.era();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (byte) 10);
//        int int9 = dateTimeZone5.getOffsetFromLocal((long) 'a');
//        java.lang.String str11 = dateTimeZone5.getShortName(0L);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone5);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = zonedChronology13.equals(obj14);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.secondOfMinute();
//        long long15 = gregorianChronology0.add(20L, 2126L, 53024);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 112729044L + "'", long15 == 112729044L);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear((int) (short) -1);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 52997649);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52997649 + "'", int2 == 52997649);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.append(dateTimePrinter4, dateTimeParser6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear((int) ' ', 32);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder8.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        java.lang.String str7 = dateTimeZone1.getShortName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter8.withOffsetParsed();
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimePrinter10);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long12 = offsetDateTimeField9.add((long) 4, (long) (byte) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
//        org.joda.time.DateTime.Property property23 = dateTime22.hourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusMillis(0);
//        boolean boolean26 = dateTime22.isEqualNow();
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime22.toTimeOfDay();
//        int int28 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay27);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        int int30 = offsetDateTimeField9.getMinimumValue(readablePartial29);
//        long long33 = offsetDateTimeField9.getDifferenceAsLong(0L, (long) 52997649);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-52997649L) + "'", long33 == (-52997649L));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32 + "'", number5.equals(32));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 5 for Sat must be in the range [32,126]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 5 for Sat must be in the range [32,126]"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("millisOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        boolean boolean13 = dateTime9.isEqualNow();
//        int int14 = dateTime9.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime9.withTime(53024, 2, 52, 86400009);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53024 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53038 + "'", int14 == 53038);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("2019-06-15T14", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T14\" is malformed at \"-06-15T14\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Sat");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str4 = jodaTimePermission3.getActions();
        java.lang.String str5 = jodaTimePermission3.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str7 = jodaTimePermission3.toString();
        java.security.PermissionCollection permissionCollection8 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(permissionCollection8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("Sat", (java.lang.Number) 5L, (java.lang.Number) 32, (java.lang.Number) 126);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException9.getSuppressed();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 126 + "'", number10.equals(126));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str14 = dateTimeZone12.getShortName((long) (byte) 10);
//        int int16 = dateTimeZone12.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology17 = gregorianChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology11.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 10);
//        int int22 = offsetDateTimeField20.getLeapAmount((long) 1969);
//        long long25 = offsetDateTimeField20.add((long) ' ', 12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str29 = dateTimeZone27.getShortName((long) (byte) 10);
//        int int31 = dateTimeZone27.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology32 = gregorianChronology26.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology26.minuteOfHour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter35 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser36 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter35, dateTimeParser36);
//        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatter37.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str41 = dateTimeZone39.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter38, dateTimeZone39);
//        org.joda.time.LocalDate localDate43 = dateTime42.toLocalDate();
//        boolean boolean44 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate43);
//        long long46 = gregorianChronology26.set((org.joda.time.ReadablePartial) localDate43, (long) 52995);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str50 = dateTimeZone48.getShortName((long) (byte) 10);
//        int int52 = dateTimeZone48.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology53 = gregorianChronology47.withZone(dateTimeZone48);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology47.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, (int) (byte) 10);
//        long long58 = offsetDateTimeField56.roundFloor((long) (-28799968));
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = offsetDateTimeField56.getAsShortText(0, locale60);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str65 = dateTimeZone63.getShortName((long) (byte) 10);
//        int int67 = dateTimeZone63.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology68 = gregorianChronology62.withZone(dateTimeZone63);
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology62.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology62.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology62.secondOfDay();
//        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology62);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate75 = dateTimeFormatter73.parseLocalDate("2019-W24-6");
//        int[] intArray77 = gregorianChronology62.get((org.joda.time.ReadablePartial) localDate75, 1023L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str82 = dateTimeZone80.getShortName((long) (byte) 10);
//        int int84 = dateTimeZone80.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology85 = gregorianChronology79.withZone(dateTimeZone80);
//        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology79.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField87 = gregorianChronology79.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField88 = gregorianChronology79.secondOfDay();
//        org.joda.time.Chronology chronology89 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology79);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter90 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.LocalDate localDate92 = dateTimeFormatter90.parseLocalDate("2019-W24-6");
//        int[] intArray94 = gregorianChronology79.get((org.joda.time.ReadablePartial) localDate92, 1023L);
//        int[] intArray96 = offsetDateTimeField56.addWrapField((org.joda.time.ReadablePartial) localDate75, (int) (byte) 0, intArray94, (int) (short) 100);
//        int int97 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate43, intArray94);
//        int int98 = dateTime7.get((org.joda.time.DateTimeField) offsetDateTimeField20);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 44L + "'", long25 == 44L);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNull(dateTimePrinter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560556852995L + "'", long46 == 1560556852995L);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-28800000) + "'", int52 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28799968L) + "'", long58 == (-28799968L));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "0" + "'", str61.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "PST" + "'", str65.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-28800000) + "'", int67 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertNotNull(gregorianChronology79);
//        org.junit.Assert.assertNotNull(dateTimeZone80);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "PST" + "'", str82.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-28800000) + "'", int84 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(dateTimeField87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertNotNull(chronology89);
//        org.junit.Assert.assertNotNull(dateTimeFormatter90);
//        org.junit.Assert.assertNotNull(localDate92);
//        org.junit.Assert.assertNotNull(intArray94);
//        org.junit.Assert.assertNotNull(intArray96);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 86400009 + "'", int97 == 86400009);
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 78238511 + "'", int98 == 78238511);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(0);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(readableDuration13, 0);
//        org.joda.time.DateTime dateTime17 = dateTime9.withMillisOfDay(14);
//        org.joda.time.DurationFieldType durationFieldType18 = null;
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime9.withFieldAdded(durationFieldType18, 35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, (int) (byte) -1, 3, 53009442);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("43", (java.lang.Number) (-28799948L), (java.lang.Number) 1560556852995L, (java.lang.Number) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-28799948" + "'", str8.equals("-28799948"));
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter3, dateTimeZone4);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str17 = dateTimeZone15.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter14, dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime18.getZone();
//        org.joda.time.DateTime dateTime21 = dateTime18.withYear(0);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime18.minus(readableDuration22);
//        org.joda.time.DateTime dateTime25 = dateTime23.plusSeconds((int) ' ');
//        org.joda.time.YearMonthDay yearMonthDay26 = dateTime23.toYearMonthDay();
//        int int27 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(yearMonthDay26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (byte) 10);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '#');
//        long long12 = offsetDateTimeField10.roundHalfCeiling(12L);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str19 = dateTimeZone17.getShortName((long) (byte) 10);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimePrinter16, dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.DateTime dateTime23 = dateTime20.withYear(0);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.minus(readableDuration24);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime28 = dateTime25.toLocalTime();
//        java.util.Locale locale29 = null;
//        try {
//            java.lang.String str30 = offsetDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localTime28, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 978307200000L + "'", long12 == 978307200000L);
//        org.junit.Assert.assertNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localTime28);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter2, dateTimeParser4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(3);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }
}

