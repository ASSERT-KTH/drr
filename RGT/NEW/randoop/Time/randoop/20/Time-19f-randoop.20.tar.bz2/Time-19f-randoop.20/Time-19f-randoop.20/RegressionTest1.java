import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.hours();
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime dateTime19 = dateTime6.withWeekyear(2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
//        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        java.security.PermissionCollection permissionCollection5 = jodaTimePermission3.newPermissionCollection();
//        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
//        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
//        boolean boolean10 = jodaTimePermission7.implies((java.security.Permission) jodaTimePermission9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean12 = dateTimeFormatter11.isParser();
//        java.lang.String str14 = dateTimeFormatter11.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean18 = dateTimeFormatter17.isParser();
//        java.lang.String str20 = dateTimeFormatter17.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZoneUTC();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean25 = dateTimeFormatter24.isParser();
//        java.lang.String str27 = dateTimeFormatter24.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
//        boolean boolean30 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime33 = dateTime29.toDateTimeISO();
//        org.joda.time.DateTime dateTime34 = dateTime29.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property35 = dateTime34.era();
//        org.joda.time.DateTime dateTime37 = dateTime34.plusWeeks((int) (short) 1);
//        java.lang.String str38 = dateTimeFormatter15.print((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.TimeOfDay timeOfDay39 = dateTime34.toTimeOfDay();
//        org.joda.time.DateTime.Property property40 = dateTime34.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime34.toMutableDateTimeISO();
//        jodaTimePermission7.checkGuard((java.lang.Object) mutableDateTime41);
//        boolean boolean43 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission7);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(permissionCollection5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970001T000000Z" + "'", str20.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970001T000000Z" + "'", str38.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(timeOfDay39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTimeISO();
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime18.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.Class<?> wildcardClass22 = dateTimeFormatter21.getClass();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean25 = dateTimeFormatter24.isParser();
//        java.lang.String str27 = dateTimeFormatter24.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean32 = dateTimeFormatter31.isParser();
//        java.lang.String str34 = dateTimeFormatter31.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
//        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property40 = dateTime36.weekOfWeekyear();
//        int int41 = property40.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime42 = property40.roundHalfCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean45 = dateTimeFormatter44.isParser();
//        java.lang.String str47 = dateTimeFormatter44.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter44.withZoneUTC();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter48);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean52 = dateTimeFormatter51.isParser();
//        java.lang.String str54 = dateTimeFormatter51.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter51.withZoneUTC();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter55);
//        boolean boolean57 = dateTime49.isEqual((org.joda.time.ReadableInstant) dateTime56);
//        org.joda.time.DateTime dateTime59 = dateTime56.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime60 = dateTime56.toDateTimeISO();
//        org.joda.time.DateTime dateTime61 = dateTime56.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime62 = dateTime61.toDateTimeISO();
//        org.joda.time.MutableDateTime mutableDateTime63 = dateTime61.toMutableDateTimeISO();
//        int int64 = property40.compareTo((org.joda.time.ReadableInstant) mutableDateTime63);
//        int int67 = dateTimeFormatter21.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime63, "1969365T160000-0800", (int) '#');
//        int int68 = mutableDateTime63.getSecondOfDay();
//        boolean boolean69 = mutableDateTime20.equals((java.lang.Object) mutableDateTime63);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000Z" + "'", str34.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970001T000000Z" + "'", str47.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1970001T000000Z" + "'", str54.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(mutableDateTime63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-36) + "'", int67 == (-36));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        boolean boolean9 = dateTime6.isAfterNow();
//        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
//        int int13 = dateTime12.getSecondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime();
//        org.joda.time.DateTime dateTime16 = dateTime12.plusWeeks((-36));
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property19.getAsShortText(locale21);
//        org.joda.time.DateTime dateTime23 = property19.roundHalfEvenCopy();
//        boolean boolean24 = property19.isLeap();
//        int int25 = property19.get();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean7 = dateTimeFormatter6.isParser();
//        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter6.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser8);
//        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear((int) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        int int21 = offsetDateTimeField11.getMaximumValue((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 153 + "'", int21 == 153);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTimeISO();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.plus(readableDuration9);
//        int int11 = dateTime6.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology1.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.monthOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = gregorianChronology1.equals(obj7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 41529999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean4 = dateTimeFormatter3.isParser();
//        java.lang.String str6 = dateTimeFormatter3.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        java.lang.String str13 = dateTimeFormatter10.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
//        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime20 = dateTime15.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime.Property property21 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime22 = property21.withMaximumValue();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000Z" + "'", str6.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000Z" + "'", str13.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            long long3 = dateTimeFormatter1.parseMillis("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("AD", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder0.addRecurringSavings("era", 2000, 70, (int) (short) 10, '#', (int) '4', (-292275054), 5141, true, (int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder0.addRecurringSavings("ISOChronology[UTC]", 2000, (int) (byte) 1, (int) (short) 100, ' ', (int) ' ', (int) '4', 23, true, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        long long16 = offsetDateTimeField11.roundHalfCeiling((long) 3);
        int int18 = offsetDateTimeField11.getMaximumValue((long) 19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200032L) + "'", long16 == (-259200032L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        java.lang.String str20 = property19.getName();
//        org.joda.time.DurationField durationField21 = property19.getRangeDurationField();
//        boolean boolean22 = property19.isLeap();
//        org.joda.time.DateTime dateTime23 = property19.roundHalfEvenCopy();
//        boolean boolean24 = property19.isLeap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
//        org.junit.Assert.assertNull(durationField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField12 = gregorianChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType13, 5200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00:00.032", (int) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean15 = dateTimeFormatter14.isParser();
        java.lang.String str17 = dateTimeFormatter14.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZoneUTC();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter18);
        boolean boolean20 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTimeISO();
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property25 = dateTime24.era();
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((int) (short) 1);
        java.lang.String str28 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.TimeOfDay timeOfDay29 = dateTime24.toTimeOfDay();
        org.joda.time.DateTime.Property property30 = dateTime24.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime24.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean34 = dateTimeFormatter33.isParser();
        java.lang.String str36 = dateTimeFormatter33.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean41 = dateTimeFormatter40.isParser();
        java.lang.String str43 = dateTimeFormatter40.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter44);
        boolean boolean46 = dateTime38.isEqual((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime dateTime48 = dateTime45.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime49 = dateTime45.toDateTimeISO();
        org.joda.time.DateTime dateTime50 = dateTime45.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property51 = dateTime50.era();
        org.joda.time.DateTime dateTime53 = dateTime50.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property54 = dateTime53.dayOfYear();
        org.joda.time.DurationField durationField55 = property54.getDurationField();
        org.joda.time.DateTime dateTime56 = property54.roundHalfEvenCopy();
        boolean boolean57 = mutableDateTime31.isBefore((org.joda.time.ReadableInstant) dateTime56);
        int int60 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime31, "era", 366);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000-0000" + "'", str10.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970001T000000-0000" + "'", str17.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970001T000000Z" + "'", str28.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970001T000000-0000" + "'", str36.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970001T000000-0000" + "'", str43.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-367) + "'", int60 == (-367));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology1.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.minuteOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean24 = fixedDateTimeZone23.isFixed();
        java.lang.String str25 = fixedDateTimeZone23.getID();
        org.joda.time.DateTime dateTime26 = dateTime18.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTime dateTime28 = dateTime18.minusMillis(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        long long21 = offsetDateTimeField11.roundHalfEven((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-259200032L) + "'", long21 == (-259200032L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 53, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
        int int25 = dateTime24.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 363 + "'", int25 == 363);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969365T160000-0800" + "'", str5.equals("1969365T160000-0800"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        int int18 = dateTime13.getSecondOfDay();
        int int19 = dateTime13.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        try {
            long long44 = zonedChronology12.getDateTimeMillis((long) 4, 5200, 4, (int) 'a', (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000-0000" + "'", str19.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000-0000" + "'", str3.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime13.minusYears(0);
        org.joda.time.DateTime.Property property22 = dateTime13.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        int int40 = property39.getLeapAmount();
        org.joda.time.DateTime dateTime41 = property39.withMinimumValue();
        org.joda.time.DateTime dateTime43 = dateTime41.minusMinutes(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000-0000" + "'", str22.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000-0000" + "'", str29.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        int int21 = property19.getMinimumValueOverall();
        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
        java.lang.String str23 = property19.getAsString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getYearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        org.joda.time.DateTime.Property property13 = dateTime10.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTime dateTime9 = dateTime6.minusDays((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 363);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime.Property property20 = dateTime18.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            org.joda.time.LocalDate localDate12 = dateTimeFormatter0.parseLocalDate("ZonedChronology[GregorianChronology[UTC], ]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = dateTime18.plusMillis(19);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1", "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported\")");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(2);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder13.addCutover((int) (short) 100, '#', (int) (short) 0, (-1), 2000, false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean44 = fixedDateTimeZone43.isFixed();
        java.lang.String str45 = fixedDateTimeZone43.getID();
        org.joda.time.DateTime dateTime46 = dateTime38.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        int int47 = dateTime38.getMillisOfDay();
        boolean boolean48 = dateTime18.isAfter((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime50 = dateTime18.minusMinutes(27);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        boolean boolean52 = dateTime18.isSupported(dateTimeFieldType51);
        org.joda.time.DateTime.Property property53 = dateTime18.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000-0000" + "'", str24.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000-0000" + "'", str31.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime22 = dateTime20.withSecondOfMinute((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime dateTime41 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime41.era();
        org.joda.time.DurationField durationField43 = property42.getLeapDurationField();
        java.util.Locale locale44 = null;
        java.lang.String str45 = property42.getAsShortText(locale44);
        org.joda.time.DateTime dateTime46 = property42.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean49 = dateTimeFormatter48.isParser();
        java.lang.String str51 = dateTimeFormatter48.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter48.withZoneUTC();
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean56 = dateTimeFormatter55.isParser();
        java.lang.String str58 = dateTimeFormatter55.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter55.withZoneUTC();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter59);
        boolean boolean61 = dateTime53.isEqual((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime63 = dateTime60.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property64 = dateTime60.weekOfWeekyear();
        boolean boolean66 = property64.equals((java.lang.Object) 100);
        boolean boolean68 = property64.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime70 = property64.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime75 = dateTime70.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime77 = dateTime70.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long82 = dateTimeZone79.convertLocalToUTC((long) (short) 1, false);
        long long85 = dateTimeZone79.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField87 = iSOChronology86.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField87, (int) (short) 100);
        java.lang.String str90 = offsetDateTimeField89.getName();
        long long92 = offsetDateTimeField89.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField89.getType();
        int int94 = dateTime70.get(dateTimeFieldType93);
        int int95 = dateTime46.get(dateTimeFieldType93);
        org.joda.time.DateTime dateTime97 = dateTime22.withField(dateTimeFieldType93, 27);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000-0000" + "'", str27.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000-0000" + "'", str34.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "AD" + "'", str45.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1970001T000000-0000" + "'", str51.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970001T000000-0000" + "'", str58.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-31L) + "'", long82 == (-31L));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1L + "'", long85 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "weekOfWeekyear" + "'", str90.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 345599968L + "'", long92 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 11 + "'", int94 == 11);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
        org.junit.Assert.assertNotNull(dateTime97);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        boolean boolean23 = dateTime21.isBefore((long) 32);
        org.joda.time.DateTime dateTime24 = dateTime21.toDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str31 = fixedDateTimeZone29.getName((long) 1);
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = fixedDateTimeZone29.isLocalDateTimeGap(localDateTime32);
        long long37 = fixedDateTimeZone29.convertLocalToUTC((-33L), false, 132L);
        java.util.Locale locale39 = null;
        java.lang.String str40 = fixedDateTimeZone29.getName((-2678400000L), locale39);
        org.joda.time.DateTime dateTime41 = dateTime21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.001" + "'", str31.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-34L) + "'", long37 == (-34L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+00:00:00.001" + "'", str40.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField10 = gregorianChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.year();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 0, 363, (-1), 5141, (int) (byte) 10, 5141, chronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5141 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        boolean boolean21 = dateTime18.isAfterNow();
        boolean boolean23 = dateTime18.isBefore((long) 5200);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField12 = gregorianChronology1.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (short) 10);
        int int13 = dateTime12.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, 22L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) (byte) 100, 0, 0, (int) (short) 1, (int) (byte) -1, 153, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int18 = offsetDateTimeField11.getMaximumValue();
        java.lang.String str19 = offsetDateTimeField11.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "weekOfWeekyear" + "'", str19.equals("weekOfWeekyear"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime23.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime30 = dateTime23.withHourOfDay(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DurationField durationField36 = gregorianChronology32.days();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.monthOfYear();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology32.dayOfMonth();
        int int39 = dateTime30.get(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 11 + "'", int39 == 11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970001T000000-0000", 0, 11, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 1970001T000000-0000 must be in the range [11,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-35), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology12.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = zonedChronology12.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000-0000" + "'", str19.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969365T160000-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean37 = property19.equals((java.lang.Object) dateTime28);
        org.joda.time.DateTime dateTime38 = property19.getDateTime();
        java.lang.String str39 = property19.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000-0000" + "'", str26.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000-0000" + "'", str33.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "AD" + "'", str39.equals("AD"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        long long22 = offsetDateTimeField11.add((long) 5200, (long) (-36));
        java.util.Locale locale25 = null;
        try {
            long long26 = offsetDateTimeField11.set(1L, "Property[era]", locale25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[era]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-21772794800L) + "'", long22 == (-21772794800L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        org.joda.time.DateTime dateTime22 = property19.setCopy((int) (short) 0);
        java.lang.String str23 = property19.toString();
        try {
            org.joda.time.DateTime dateTime25 = property19.setCopy("Jan");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jan\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[era]" + "'", str23.equals("Property[era]"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter0.printTo(writer4, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str7 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long12 = dateTimeZone9.convertLocalToUTC((long) (short) 1, false);
        long long15 = dateTimeZone9.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) 100);
        java.lang.String str20 = offsetDateTimeField19.getName();
        long long22 = offsetDateTimeField19.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean26 = dateTimeFormatter25.isParser();
        java.lang.String str28 = dateTimeFormatter25.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withZoneUTC();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean33 = dateTimeFormatter32.isParser();
        java.lang.String str35 = dateTimeFormatter32.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
        boolean boolean38 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime37.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readableDuration41);
        int int43 = dateTime40.getMillisOfDay();
        org.joda.time.DateTime dateTime45 = dateTime40.minusMonths(32);
        org.joda.time.YearMonthDay yearMonthDay46 = dateTime40.toYearMonthDay();
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField19.getAsText((org.joda.time.ReadablePartial) yearMonthDay46, 1, locale48);
        int[] intArray50 = new int[] {};
        try {
            gregorianChronology1.validate((org.joda.time.ReadablePartial) yearMonthDay46, intArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31L) + "'", long12 == (-31L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "weekOfWeekyear" + "'", str20.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 345599968L + "'", long22 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970001T000000-0000" + "'", str28.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970001T000000-0000" + "'", str35.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 32 + "'", int43 == 32);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(yearMonthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.hourOfDay();
        long long17 = gregorianChronology1.getDateTimeMillis((long) 32, (int) (short) 0, 1, (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60011L + "'", long17 == 60011L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) -1, 1, 100, (int) (byte) 10, 1970, (int) (byte) 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property19.getAsText(locale21);
        java.util.Locale locale23 = null;
        int int24 = property19.getMaximumTextLength(locale23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.hours();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.minuteOfDay();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
        boolean boolean9 = gregorianChronology3.equals((java.lang.Object) dateTime8);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime8.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) timeOfDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        java.util.Locale locale39 = null;
        java.lang.String str40 = property17.getAsText(locale39);
        org.joda.time.DurationField durationField41 = property17.getDurationField();
        org.joda.time.DateTime dateTime42 = property17.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000-0000" + "'", str22.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000-0000" + "'", str29.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = dateTime15.isSupported(dateTimeFieldType19);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMillis((int) (short) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks((int) ' ');
        org.joda.time.DateMidnight dateMidnight25 = dateTime22.toDateMidnight();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000-0000" + "'", str10.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateMidnight25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.getID();
        long long8 = fixedDateTimeZone4.previousTransition(132L);
        long long10 = fixedDateTimeZone4.convertUTCToLocal(22L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 23L + "'", long10 == 23L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        int int13 = offsetDateTimeField11.getLeapAmount(97L);
        long long15 = offsetDateTimeField11.roundHalfFloor((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200032L) + "'", long15 == (-259200032L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        int int21 = property19.getMinimumValueOverall();
        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField24 = gregorianChronology23.hours();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.clockhourOfHalfday();
        int int26 = dateTime22.get(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, 5200, (int) '#', 5200, (int) (short) 0, 5200, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 153);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean6 = dateTimeFormatter5.isParser();
        java.lang.String str8 = dateTimeFormatter5.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isParser();
        java.lang.String str15 = dateTimeFormatter12.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
        boolean boolean18 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime17.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property21 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime22 = dateTime17.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology23 = dateTime22.getChronology();
        org.joda.time.TimeOfDay timeOfDay24 = dateTime22.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) timeOfDay24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T000000-0000" + "'", str8.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001T000000-0000" + "'", str15.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(timeOfDay24);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("DateTimeField[weekOfWeekyear]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(2700L);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds(11);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("AD", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.setStandardOffset(1970);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology12.getZone();
        try {
            long long22 = zonedChronology12.getDateTimeMillis(19, 363, 10, (int) (byte) 100, 366, 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime24 = dateTime20.minus(32L);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean5 = dateTimeFormatter4.isParser();
        java.lang.String str7 = dateTimeFormatter4.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean12 = dateTimeFormatter11.isParser();
        java.lang.String str14 = dateTimeFormatter11.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
        boolean boolean17 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property20 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime dateTime21 = dateTime16.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime23 = dateTime21.minusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean26 = dateTimeFormatter25.isParser();
        java.lang.String str28 = dateTimeFormatter25.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withZoneUTC();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean33 = dateTimeFormatter32.isParser();
        java.lang.String str35 = dateTimeFormatter32.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
        boolean boolean38 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime37.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime41 = dateTime37.toDateTimeISO();
        org.joda.time.DateTime dateTime42 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property43 = dateTime42.era();
        org.joda.time.DurationField durationField44 = property43.getLeapDurationField();
        java.util.Locale locale45 = null;
        java.lang.String str46 = property43.getAsShortText(locale45);
        org.joda.time.DateTime dateTime47 = property43.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean49 = dateTimeFormatter48.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatter48.getParser();
        org.joda.time.LocalDate localDate52 = dateTimeFormatter48.parseLocalDate("1969365T160000-0800");
        int int53 = property43.compareTo((org.joda.time.ReadablePartial) localDate52);
        org.joda.time.DateTime dateTime54 = dateTime21.withFields((org.joda.time.ReadablePartial) localDate52);
        long long56 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate52, (long) (-292275054));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970001T000000-0000" + "'", str7.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000-0000" + "'", str14.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970001T000000-0000" + "'", str28.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970001T000000-0000" + "'", str35.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNull(durationField44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "AD" + "'", str46.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-33075054L) + "'", long56 == (-33075054L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getYearOfCentury();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        long long22 = offsetDateTimeField11.add((long) 5200, (long) (-36));
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = offsetDateTimeField11.getAsText(readablePartial23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-21772794800L) + "'", long22 == (-21772794800L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        int int9 = dateTimeZone7.getOffsetFromLocal((long) 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        java.lang.String str18 = dateTime13.toString();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime13.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str18.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(yearMonthDay19);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DurationField durationField21 = property19.getRangeDurationField();
        org.joda.time.DateTime dateTime22 = property19.withMaximumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
        org.joda.time.DateMidnight dateMidnight40 = dateTime39.toDateMidnight();
        org.joda.time.DateTime dateTime42 = dateTime39.withWeekyear((int) (short) 1);
        try {
            long long43 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000-0000" + "'", str27.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000-0000" + "'", str34.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateMidnight40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField22 = gregorianChronology21.hours();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField27 = gregorianChronology21.hours();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) dateTime16, (org.joda.time.Chronology) gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        long long13 = offsetDateTimeField11.roundCeiling(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 345599968L + "'", long13 == 345599968L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 4, (int) (short) 10, 5141, 31, (int) (byte) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5141 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int15 = cachedDateTimeZone13.getStandardOffset(58707129999L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField11.getType();
        long long15 = offsetDateTimeField11.add((long) '#', 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean18 = dateTimeFormatter17.isParser();
        java.lang.String str20 = dateTimeFormatter17.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZoneUTC();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        boolean boolean30 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property33 = dateTime29.weekOfWeekyear();
        org.joda.time.DateTime dateTime34 = dateTime29.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology35 = dateTime34.getChronology();
        org.joda.time.TimeOfDay timeOfDay36 = dateTime34.toTimeOfDay();
        int int37 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay36);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology39.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology39.weekyear();
        long long48 = gregorianChronology39.add(0L, 27L, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean51 = dateTimeFormatter50.isParser();
        java.lang.String str53 = dateTimeFormatter50.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter50.withZoneUTC();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter54);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean58 = dateTimeFormatter57.isParser();
        java.lang.String str60 = dateTimeFormatter57.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter57.withZoneUTC();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter61);
        boolean boolean63 = dateTime55.isEqual((org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.DateTime dateTime65 = dateTime62.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration66 = null;
        org.joda.time.DateTime dateTime67 = dateTime65.minus(readableDuration66);
        int int68 = dateTime65.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean71 = dateTimeFormatter70.isParser();
        java.lang.String str73 = dateTimeFormatter70.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter70.withZoneUTC();
        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter74);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean78 = dateTimeFormatter77.isParser();
        java.lang.String str80 = dateTimeFormatter77.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = dateTimeFormatter77.withZoneUTC();
        org.joda.time.DateTime dateTime82 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter81);
        boolean boolean83 = dateTime75.isEqual((org.joda.time.ReadableInstant) dateTime82);
        org.joda.time.DateTime dateTime85 = dateTime82.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property86 = dateTime82.weekOfWeekyear();
        org.joda.time.DateTime dateTime87 = dateTime82.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology88 = dateTime87.getChronology();
        org.joda.time.TimeOfDay timeOfDay89 = dateTime87.toTimeOfDay();
        boolean boolean90 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int68, (java.lang.Object) timeOfDay89);
        int[] intArray92 = gregorianChronology39.get((org.joda.time.ReadablePartial) timeOfDay89, 0L);
        int int93 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay89);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1814400035L + "'", long15 == 1814400035L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970001T000000-0000" + "'", str20.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000-0000" + "'", str27.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(timeOfDay36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 153 + "'", int37 == 153);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2700L + "'", long48 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970001T000000-0000" + "'", str53.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1970001T000000-0000" + "'", str60.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 32 + "'", int68 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1970001T000000-0000" + "'", str73.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "1970001T000000-0000" + "'", str80.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(property86);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(chronology88);
        org.junit.Assert.assertNotNull(timeOfDay89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 153 + "'", int93 == 153);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology12.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime dateTime21 = dateTime16.minusMonths(32);
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = dateTime21.toString("1970001T000000Z", locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology2.weekyears();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime18.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime18.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean23 = dateTimeFormatter22.isParser();
        java.lang.String str25 = dateTimeFormatter22.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime27.getZone();
        org.joda.time.DateTimeZone dateTimeZone29 = dateTime27.getZone();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone29);
        int int32 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970001T000000-0000" + "'", str25.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readableDuration8);
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (-36));
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime21.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.DateTime dateTime25 = property22.roundHalfCeilingCopy();
        long long26 = property22.remainder();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology1.seconds();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology1.add(readablePeriod7, 0L, 32);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean4 = dateTimeFormatter3.isParser();
        java.lang.String str6 = dateTimeFormatter3.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property19 = dateTime15.weekOfWeekyear();
        int int20 = property19.getMinimumValueOverall();
        org.joda.time.DateTime dateTime21 = property19.roundHalfCeilingCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime38 = dateTime35.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTimeISO();
        org.joda.time.DateTime dateTime40 = dateTime35.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime41 = dateTime40.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime42 = dateTime40.toMutableDateTimeISO();
        int int43 = property19.compareTo((org.joda.time.ReadableInstant) mutableDateTime42);
        int int46 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime42, "1969365T160000-0800", (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable48 = null;
        try {
            dateTimeFormatter0.printTo(appendable48, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000-0000" + "'", str6.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000-0000" + "'", str13.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000-0000" + "'", str26.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000-0000" + "'", str33.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-36) + "'", int46 == (-36));
        org.junit.Assert.assertNull(dateTimeZone47);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime22 = dateTime20.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime24 = dateTime22.minusYears((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime24.withHourOfDay(3);
        org.joda.time.DateTime dateTime27 = dateTime24.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000-0000" + "'", str4.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000-0000" + "'", str11.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "101");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.centuryOfEra();
        org.joda.time.DurationField durationField10 = gregorianChronology6.days();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology6.dayOfMonth();
        org.joda.time.DurationField durationField13 = gregorianChronology6.years();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) "", (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean4 = dateTimeFormatter3.isParser();
        java.lang.String str6 = dateTimeFormatter3.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000-0000" + "'", str6.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000-0000" + "'", str13.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int18 = offsetDateTimeField11.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.yearOfCentury();
        org.joda.time.DurationField durationField24 = gregorianChronology21.centuries();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.centuryOfEra();
        org.joda.time.DurationField durationField26 = gregorianChronology21.weekyears();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology21.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean38 = dateTimeFormatter37.isParser();
        java.lang.String str40 = dateTimeFormatter37.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withZoneUTC();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter41);
        boolean boolean43 = dateTime35.isEqual((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime45 = dateTime42.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.minus(readableDuration46);
        int int48 = dateTime45.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean51 = dateTimeFormatter50.isParser();
        java.lang.String str53 = dateTimeFormatter50.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter50.withZoneUTC();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter54);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean58 = dateTimeFormatter57.isParser();
        java.lang.String str60 = dateTimeFormatter57.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter57.withZoneUTC();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter61);
        boolean boolean63 = dateTime55.isEqual((org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.DateTime dateTime65 = dateTime62.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property66 = dateTime62.weekOfWeekyear();
        org.joda.time.DateTime dateTime67 = dateTime62.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology68 = dateTime67.getChronology();
        org.joda.time.TimeOfDay timeOfDay69 = dateTime67.toTimeOfDay();
        boolean boolean70 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int48, (java.lang.Object) timeOfDay69);
        int[] intArray72 = gregorianChronology21.get((org.joda.time.ReadablePartial) timeOfDay69, 0L);
        int int73 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay69);
        long long75 = offsetDateTimeField11.roundCeiling(0L);
        int int77 = offsetDateTimeField11.get((-31L));
        org.joda.time.DurationField durationField78 = offsetDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000-0000" + "'", str33.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1970001T000000-0000" + "'", str40.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 32 + "'", int48 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970001T000000-0000" + "'", str53.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1970001T000000-0000" + "'", str60.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertNotNull(timeOfDay69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 153 + "'", int73 == 153);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 345599968L + "'", long75 == 345599968L);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 101 + "'", int77 == 101);
        org.junit.Assert.assertNull(durationField78);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        long long16 = offsetDateTimeField11.roundHalfCeiling(10L);
        long long18 = offsetDateTimeField11.roundHalfEven((long) 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean28 = dateTimeFormatter27.isParser();
        java.lang.String str30 = dateTimeFormatter27.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter31);
        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property36 = dateTime32.weekOfWeekyear();
        org.joda.time.DateTime dateTime37 = dateTime32.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = dateTime37.getChronology();
        org.joda.time.TimeOfDay timeOfDay39 = dateTime37.toTimeOfDay();
        boolean boolean40 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay39);
        boolean boolean41 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay39);
        int int42 = offsetDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay39);
        long long45 = offsetDateTimeField11.add((-21772794800L), (long) 5200);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200032L) + "'", long16 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200032L) + "'", long18 == (-259200032L));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000-0000" + "'", str23.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970001T000000-0000" + "'", str30.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 153 + "'", int42 == 153);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3123187205200L + "'", long45 == 3123187205200L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText(32, locale16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32" + "'", str17.equals("32"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean6 = dateTimeFormatter5.isParser();
        java.lang.String str8 = dateTimeFormatter5.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean12 = dateTimeFormatter11.isParser();
        java.lang.String str14 = dateTimeFormatter11.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean19 = dateTimeFormatter18.isParser();
        java.lang.String str21 = dateTimeFormatter18.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter22);
        boolean boolean24 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTimeISO();
        org.joda.time.DateTime dateTime28 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime28.era();
        org.joda.time.DateTime dateTime31 = dateTime28.plusWeeks((int) (short) 1);
        java.lang.String str32 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.TimeOfDay timeOfDay33 = dateTime28.toTimeOfDay();
        org.joda.time.DateTime.Property property34 = dateTime28.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime28.toMutableDateTimeISO();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime35);
        org.joda.time.JodaTimePermission jodaTimePermission38 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean41 = dateTimeFormatter40.isParser();
        java.lang.String str43 = dateTimeFormatter40.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter44);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean48 = dateTimeFormatter47.isParser();
        java.lang.String str50 = dateTimeFormatter47.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter47.withZoneUTC();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter51);
        boolean boolean53 = dateTime45.isEqual((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime55 = dateTime52.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property56 = dateTime52.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = dateTime52.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology58 = dateTime57.getChronology();
        int int59 = dateTime57.getWeekOfWeekyear();
        boolean boolean60 = jodaTimePermission38.equals((java.lang.Object) int59);
        boolean boolean61 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission38);
        org.joda.time.JodaTimePermission jodaTimePermission63 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.JodaTimePermission jodaTimePermission65 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        boolean boolean66 = jodaTimePermission63.implies((java.security.Permission) jodaTimePermission65);
        boolean boolean67 = jodaTimePermission38.implies((java.security.Permission) jodaTimePermission65);
        java.lang.String str68 = jodaTimePermission65.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T000000-0000" + "'", str8.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000-0000" + "'", str14.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970001T000000-0000" + "'", str21.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970001T000000Z" + "'", str32.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970001T000000-0000" + "'", str43.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1970001T000000-0000" + "'", str50.equals("1970001T000000-0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int15 = cachedDateTimeZone13.getOffset((long) 31);
        java.lang.String str17 = cachedDateTimeZone13.getShortName((-65L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.001" + "'", str17.equals("+00:00:00.001"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        long long6 = dateTimeZone3.adjustOffset(0L, false);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean24 = fixedDateTimeZone23.isFixed();
        java.lang.String str25 = fixedDateTimeZone23.getID();
        org.joda.time.DateTime dateTime26 = dateTime18.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        int int27 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property28 = dateTime18.era();
        long long29 = dateTime18.getMillis();
        org.joda.time.DateTime dateTime31 = dateTime18.plusMinutes(4);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        java.util.Date date22 = dateTime18.toDate();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime18.getZone();
        int int24 = dateTime18.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long5 = dateTimeZone2.convertLocalToUTC((long) (short) 1, false);
        long long8 = dateTimeZone2.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) 100);
        java.lang.String str13 = offsetDateTimeField12.getName();
        long long15 = offsetDateTimeField12.roundCeiling((long) 100);
        long long17 = offsetDateTimeField12.roundHalfCeiling(10L);
        long long19 = offsetDateTimeField12.roundHalfEven((long) 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property37 = dateTime33.weekOfWeekyear();
        boolean boolean39 = property37.equals((java.lang.Object) 100);
        boolean boolean41 = property37.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime43 = property37.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime48 = dateTime43.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime50 = dateTime43.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long55 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false);
        long long58 = dateTimeZone52.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) (short) 100);
        java.lang.String str63 = offsetDateTimeField62.getName();
        long long65 = offsetDateTimeField62.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField62.getType();
        int int67 = dateTime43.get(dateTimeFieldType66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType66, (int) '4', (int) '#', 363);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31L) + "'", long5 == (-31L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "weekOfWeekyear" + "'", str13.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345599968L + "'", long15 == 345599968L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200032L) + "'", long17 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-31L) + "'", long55 == (-31L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "weekOfWeekyear" + "'", str63.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 345599968L + "'", long65 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 11 + "'", int67 == 11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
        org.joda.time.DurationField durationField23 = property22.getDurationField();
        org.joda.time.DateTime dateTime24 = property22.withMinimumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.yearOfCentury();
        org.joda.time.DurationField durationField29 = gregorianChronology26.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean35 = fixedDateTimeZone34.isFixed();
        java.lang.String str36 = fixedDateTimeZone34.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.Chronology chronology39 = zonedChronology37.withZone(dateTimeZone38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean42 = dateTimeFormatter41.isParser();
        java.lang.String str44 = dateTimeFormatter41.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter41.withZoneUTC();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.DateTimeZone dateTimeZone48 = dateTime46.getZone();
        boolean boolean49 = dateTime46.isAfterNow();
        org.joda.time.DateTime dateTime50 = dateTime46.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime52 = dateTime46.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property53 = dateTime52.monthOfYear();
        boolean boolean54 = zonedChronology37.equals((java.lang.Object) dateTime52);
        org.joda.time.DateTimeZone dateTimeZone55 = zonedChronology37.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology57);
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology57.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology57.year();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology57.clockhourOfDay();
        boolean boolean63 = zonedChronology37.equals((java.lang.Object) gregorianChronology57);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean66 = dateTimeFormatter65.isParser();
        java.lang.String str68 = dateTimeFormatter65.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = dateTimeFormatter65.withZoneUTC();
        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter69);
        org.joda.time.DateTimeZone dateTimeZone71 = dateTime70.getZone();
        org.joda.time.DateTimeZone dateTimeZone72 = dateTime70.getZone();
        boolean boolean73 = zonedChronology37.equals((java.lang.Object) dateTime70);
        org.joda.time.MutableDateTime mutableDateTime74 = dateTime24.toMutableDateTime((org.joda.time.Chronology) zonedChronology37);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970001T000000Z" + "'", str44.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1970001T000000Z" + "'", str68.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(mutableDateTime74);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        boolean boolean18 = offsetDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime13.minusMonths(100);
        org.joda.time.DateTime.Property property21 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime23 = dateTime13.withWeekyear(27);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1), 11, (int) '4', 2000, 27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 5200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        int int15 = offsetDateTimeField11.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(2);
        java.io.DataOutput dataOutput15 = null;
        try {
            dateTimeZoneBuilder11.writeTo("Jan", dataOutput15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean4 = dateTimeFormatter3.isParser();
        java.lang.String str6 = dateTimeFormatter3.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property19 = dateTime15.weekOfWeekyear();
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        int int22 = dateTime20.getWeekOfWeekyear();
        boolean boolean23 = jodaTimePermission1.equals((java.lang.Object) int22);
        java.lang.String str24 = jodaTimePermission1.toString();
        java.lang.String str25 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000Z" + "'", str6.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000Z" + "'", str13.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported\")" + "'", str24.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported\")"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[1970-W01-4T00:00:00.000Z]" + "'", str3.equals("GregorianChronology[1970-W01-4T00:00:00.000Z]"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.Interval interval18 = property17.toInterval();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval18);
        org.joda.time.ReadableInterval readableInterval20 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval18);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(readableInterval20);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        int int15 = dateTime13.getMinuteOfHour();
        int int16 = dateTime13.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime18 = dateTime13.withDayOfMonth(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        java.util.Locale locale39 = null;
        java.lang.String str40 = property17.getAsText(locale39);
        java.lang.String str41 = property17.toString();
        java.lang.String str42 = property17.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property17.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Property[weekOfWeekyear]" + "'", str41.equals("Property[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Property[weekOfWeekyear]" + "'", str42.equals("Property[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) true);
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        java.lang.String str4 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00:00.032", (int) (short) -1, (int) (short) 0);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((-65L), true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-64L) + "'", long7 == (-64L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("AD", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.setStandardOffset(1970);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder0.addCutover(5141, '#', 366, 100, 0, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(32L, 32054400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32054400032L + "'", long2 == 32054400032L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime22 = dateTime18.minusSeconds((int) (short) 1);
        java.util.Locale locale23 = null;
        java.util.Calendar calendar24 = dateTime18.toCalendar(locale23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(calendar24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        java.io.Writer writer3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.weekyear();
        long long14 = gregorianChronology5.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2700L + "'", long14 == 2700L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-36), 0, 5200, 19, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean5 = dateTimeFormatter4.isParser();
        java.lang.String str7 = dateTimeFormatter4.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((-21772794800L), false, (long) (byte) 1);
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970001T000000Z" + "'", str7.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-21772794800L) + "'", long15 == (-21772794800L));
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        int int22 = property19.getMinimumValue();
        int int23 = property19.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 70, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime41 = property39.addToCopy((long) 32);
        org.joda.time.Interval interval42 = property39.toInterval();
        org.joda.time.ReadableInterval readableInterval43 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval42);
        org.joda.time.ReadableInterval readableInterval44 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval42);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(interval42);
        org.junit.Assert.assertNotNull(readableInterval43);
        org.junit.Assert.assertNotNull(readableInterval44);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime41 = property39.addToCopy((long) 32);
        int int42 = dateTime41.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime40 = property39.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime42 = property39.setCopy((int) (byte) 10);
        boolean boolean43 = dateTime42.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int18 = offsetDateTimeField11.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField11.getWrappedField();
        int int21 = offsetDateTimeField11.getMaximumValue((long) 100);
        boolean boolean23 = offsetDateTimeField11.isLeap((long) 27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 153 + "'", int21 == 153);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime40 = property39.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(2);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder11.toDateTimeZone("", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology32.era();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology32.era();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int18 = offsetDateTimeField11.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField11.getWrappedField();
        int int21 = offsetDateTimeField11.getMaximumValue((long) 100);
        long long24 = offsetDateTimeField11.add((long) (short) 0, 53);
        java.lang.String str25 = offsetDateTimeField11.getName();
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField11.getMaximumTextLength(locale26);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 153 + "'", int21 == 153);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32054400000L + "'", long24 == 32054400000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "weekOfWeekyear" + "'", str25.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime40 = property39.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime42 = dateTime40.minusMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((-33L), false, 132L);
        java.lang.String str14 = fixedDateTimeZone4.getShortName((long) 53);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean37 = property19.equals((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long42 = dateTimeZone39.convertLocalToUTC((long) (short) 1, false);
        java.lang.String str44 = dateTimeZone39.getShortName(100L);
        org.joda.time.DateTime dateTime45 = dateTime28.withZone(dateTimeZone39);
        boolean boolean46 = dateTime45.isBeforeNow();
        org.joda.time.DateTime dateTime48 = dateTime45.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime51 = dateTime45.withPeriodAdded(readablePeriod49, 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000Z" + "'", str26.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000Z" + "'", str33.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31L) + "'", long42 == (-31L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00:00.032" + "'", str44.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
        int int23 = dateTime21.getSecondOfDay();
        long long24 = dateTime21.getMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604800000L + "'", long24 == 604800000L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean24 = fixedDateTimeZone23.isFixed();
        java.lang.String str25 = fixedDateTimeZone23.getID();
        org.joda.time.DateTime dateTime26 = dateTime18.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        int int27 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property28 = dateTime18.era();
        org.joda.time.DateTimeField dateTimeField29 = property28.getField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        boolean boolean18 = fixedDateTimeZone4.isStandardOffset((long) 27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean28 = dateTimeFormatter27.isParser();
        java.lang.String str30 = dateTimeFormatter27.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter31);
        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTimeISO();
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTimeISO();
        boolean boolean39 = fixedDateTimeZone4.equals((java.lang.Object) dateTime37);
        long long41 = fixedDateTimeZone4.nextTransition((-86400000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970001T000000Z" + "'", str30.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-86400000L) + "'", long41 == (-86400000L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime13.minusYears(0);
        int int22 = dateTime13.getYear();
        org.joda.time.DateTime dateTime24 = dateTime13.withHourOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.Chronology chronology31 = zonedChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology12.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean18 = dateTimeFormatter17.isParser();
        java.lang.String str20 = dateTimeFormatter17.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZoneUTC();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        boolean boolean30 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.minus(readableDuration33);
        int int35 = dateTime32.getMillisOfDay();
        org.joda.time.DateTime dateTime37 = dateTime32.minusMonths(32);
        org.joda.time.YearMonthDay yearMonthDay38 = dateTime32.toYearMonthDay();
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField11.getAsText((org.joda.time.ReadablePartial) yearMonthDay38, 1, locale40);
        long long44 = offsetDateTimeField11.addWrapField((long) 5141, 32);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970001T000000Z" + "'", str20.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 32 + "'", int35 == 32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(yearMonthDay38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 19353605141L + "'", long44 == 19353605141L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) true);
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean18 = fixedDateTimeZone17.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
        org.joda.time.DateTime dateTime28 = dateTime25.withMinuteOfHour((int) (byte) 0);
        boolean boolean29 = fixedDateTimeZone17.equals((java.lang.Object) dateTime28);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology30);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property19.getAsShortText(locale21);
        org.joda.time.DateTime dateTime23 = property19.withMinimumValue();
        java.lang.String str24 = property19.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[era]" + "'", str24.equals("Property[era]"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) true);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DurationField durationField9 = gregorianChronology6.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.centuryOfEra();
        org.joda.time.DurationField durationField11 = gregorianChronology6.weekyears();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean16 = dateTimeFormatter15.isParser();
        java.lang.String str18 = dateTimeFormatter15.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter15.withZoneUTC();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean23 = dateTimeFormatter22.isParser();
        java.lang.String str25 = dateTimeFormatter22.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter26);
        boolean boolean28 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.minus(readableDuration31);
        int int33 = dateTime30.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean36 = dateTimeFormatter35.isParser();
        java.lang.String str38 = dateTimeFormatter35.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter35.withZoneUTC();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean43 = dateTimeFormatter42.isParser();
        java.lang.String str45 = dateTimeFormatter42.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter42.withZoneUTC();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter46);
        boolean boolean48 = dateTime40.isEqual((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property51 = dateTime47.weekOfWeekyear();
        org.joda.time.DateTime dateTime52 = dateTime47.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology53 = dateTime52.getChronology();
        org.joda.time.TimeOfDay timeOfDay54 = dateTime52.toTimeOfDay();
        boolean boolean55 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int33, (java.lang.Object) timeOfDay54);
        int[] intArray57 = gregorianChronology6.get((org.joda.time.ReadablePartial) timeOfDay54, 0L);
        boolean boolean58 = iSOChronology0.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970001T000000Z" + "'", str18.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970001T000000Z" + "'", str25.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 32 + "'", int33 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970001T000000Z" + "'", str38.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970001T000000Z" + "'", str45.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(timeOfDay54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTimeField59);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean41 = dateTimeFormatter40.isParser();
        java.lang.String str43 = dateTimeFormatter40.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter44);
        org.joda.time.DateTimeZone dateTimeZone46 = dateTime45.getZone();
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime45.getZone();
        boolean boolean48 = zonedChronology12.equals((java.lang.Object) dateTime45);
        boolean boolean49 = dateTime45.isEqualNow();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970001T000000Z" + "'", str43.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField11.getType();
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.hourOfHalfday();
        org.joda.time.DurationField durationField19 = gregorianChronology16.eras();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean28 = dateTimeFormatter27.isParser();
        java.lang.String str30 = dateTimeFormatter27.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean35 = dateTimeFormatter34.isParser();
        java.lang.String str37 = dateTimeFormatter34.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter38);
        boolean boolean40 = dateTime32.isEqual((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime42 = dateTime39.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime43 = dateTime39.toDateTimeISO();
        org.joda.time.DateTime dateTime44 = dateTime39.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property45 = dateTime44.era();
        org.joda.time.DateTime dateTime47 = dateTime44.plusWeeks((int) (short) 1);
        java.lang.String str48 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.TimeOfDay timeOfDay49 = dateTime44.toTimeOfDay();
        int[] intArray51 = gregorianChronology16.get((org.joda.time.ReadablePartial) timeOfDay49, (long) (short) 100);
        try {
            int[] intArray53 = offsetDateTimeField11.addWrapField(readablePartial13, 70, intArray51, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 70");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970001T000000Z" + "'", str30.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970001T000000Z" + "'", str37.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1970001T000000Z" + "'", str48.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay49);
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        long long16 = offsetDateTimeField11.roundHalfCeiling(10L);
        long long18 = offsetDateTimeField11.roundHalfEven((long) 31);
        long long21 = offsetDateTimeField11.add((-4550L), 0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200032L) + "'", long16 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200032L) + "'", long18 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-4550L) + "'", long21 == (-4550L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology1.seconds();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology1.add(readablePeriod7, 0L, 32);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime13.minusMonths(100);
        org.joda.time.DateTime.Property property21 = dateTime13.monthOfYear();
        org.joda.time.DurationFieldType durationFieldType22 = null;
        try {
            org.joda.time.DateTime dateTime24 = dateTime13.withFieldAdded(durationFieldType22, 363);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.toString();
        illegalFieldValueException2.prependMessage("+00:00:00.032");
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        illegalFieldValueException2.prependMessage("AD");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        java.util.Locale locale39 = null;
        java.lang.String str40 = property17.getAsText(locale39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean43 = dateTimeFormatter42.isParser();
        java.lang.String str45 = dateTimeFormatter42.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter42.withZoneUTC();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter46);
        org.joda.time.LocalDate localDate48 = dateTime47.toLocalDate();
        org.joda.time.MutableDateTime mutableDateTime49 = dateTime47.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime51 = dateTime47.plusMillis(70);
        long long52 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DurationField durationField53 = property17.getDurationField();
        org.joda.time.DurationFieldType durationFieldType54 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField55 = new org.joda.time.field.DecoratedDurationField(durationField53, durationFieldType54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970001T000000Z" + "'", str45.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(durationField53);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField15 = gregorianChronology12.seconds();
        org.joda.time.DurationField durationField16 = gregorianChronology12.minutes();
        org.joda.time.DurationField durationField17 = gregorianChronology12.seconds();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = gregorianChronology12.add(readablePeriod18, 0L, 32);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology12.yearOfEra();
        org.joda.time.DateTime dateTime23 = dateTime10.toDateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-21772794800L), (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2199052274800L) + "'", long2 == (-2199052274800L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        try {
            long long20 = offsetDateTimeField11.set((long) 53, "1970-W01-4T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W01-4T00:00:00.000Z\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime23.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime30 = dateTime23.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long35 = dateTimeZone32.convertLocalToUTC((long) (short) 1, false);
        long long38 = dateTimeZone32.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (short) 100);
        java.lang.String str43 = offsetDateTimeField42.getName();
        long long45 = offsetDateTimeField42.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField42.getType();
        int int47 = dateTime23.get(dateTimeFieldType46);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField49 = gregorianChronology48.hours();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.weekyearOfCentury();
        org.joda.time.DurationField durationField52 = gregorianChronology48.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean55 = dateTimeFormatter54.isParser();
        java.lang.String str57 = dateTimeFormatter54.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter54.withZoneUTC();
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter58);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean62 = dateTimeFormatter61.isParser();
        java.lang.String str64 = dateTimeFormatter61.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = dateTimeFormatter61.withZoneUTC();
        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter65);
        boolean boolean67 = dateTime59.isEqual((org.joda.time.ReadableInstant) dateTime66);
        org.joda.time.DateTime dateTime69 = dateTime66.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property70 = dateTime66.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean73 = dateTimeFormatter72.isParser();
        java.lang.String str75 = dateTimeFormatter72.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = dateTimeFormatter72.withZoneUTC();
        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter76);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean80 = dateTimeFormatter79.isParser();
        java.lang.String str82 = dateTimeFormatter79.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter83 = dateTimeFormatter79.withZoneUTC();
        org.joda.time.DateTime dateTime84 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter83);
        boolean boolean85 = dateTime77.isEqual((org.joda.time.ReadableInstant) dateTime84);
        org.joda.time.DateTime dateTime87 = dateTime84.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration88 = null;
        org.joda.time.DateTime dateTime89 = dateTime87.minus(readableDuration88);
        org.joda.time.DateTimeZone dateTimeZone90 = dateTime87.getZone();
        int int91 = property70.compareTo((org.joda.time.ReadableInstant) dateTime87);
        org.joda.time.DateTime.Property property92 = dateTime87.year();
        org.joda.time.DateTime dateTime93 = property92.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime95 = property92.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime97 = property92.addWrapFieldToCopy(31);
        org.joda.time.DurationField durationField98 = property92.getLeapDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField99 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType46, durationField52, durationField98);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31L) + "'", long35 == (-31L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "weekOfWeekyear" + "'", str43.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 345599968L + "'", long45 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1970001T000000Z" + "'", str57.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1970001T000000Z" + "'", str64.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1970001T000000Z" + "'", str75.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "1970001T000000Z" + "'", str82.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter83);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(dateTimeZone90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNotNull(property92);
        org.junit.Assert.assertNotNull(dateTime93);
        org.junit.Assert.assertNotNull(dateTime95);
        org.junit.Assert.assertNotNull(dateTime97);
        org.junit.Assert.assertNotNull(durationField98);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.year();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        int int13 = offsetDateTimeField11.getLeapAmount(97L);
        int int15 = offsetDateTimeField11.getLeapAmount((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTime();
        boolean boolean9 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime19 = property17.roundHalfCeilingCopy();
        java.util.Locale locale20 = null;
        java.util.Calendar calendar21 = dateTime19.toCalendar(locale20);
        org.joda.time.DateTime.Property property22 = dateTime19.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime dateTime41 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime41.era();
        java.lang.String str43 = property42.getName();
        org.joda.time.DurationField durationField44 = property42.getRangeDurationField();
        boolean boolean45 = property42.isLeap();
        org.joda.time.DateTime dateTime46 = property42.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((-259200032L), (int) (byte) 0);
        boolean boolean50 = dateTime19.isAfter((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.LocalDate localDate51 = dateTime19.toLocalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(calendar21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000Z" + "'", str34.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "era" + "'", str43.equals("era"));
        org.junit.Assert.assertNull(durationField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(localDate51);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj10 = null;
        boolean boolean11 = iSOChronology9.equals(obj10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        org.joda.time.Chronology chronology14 = iSOChronology9.withZone(dateTimeZone13);
        java.lang.String str15 = iSOChronology9.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[]" + "'", str15.equals("ISOChronology[]"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        boolean boolean16 = offsetDateTimeField11.isLeap(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime13.secondOfMinute();
        org.joda.time.DateTime.Property property19 = dateTime13.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean6 = dateTimeFormatter5.isParser();
        java.lang.String str8 = dateTimeFormatter5.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean12 = dateTimeFormatter11.isParser();
        java.lang.String str14 = dateTimeFormatter11.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean19 = dateTimeFormatter18.isParser();
        java.lang.String str21 = dateTimeFormatter18.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter22);
        boolean boolean24 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTimeISO();
        org.joda.time.DateTime dateTime28 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property29 = dateTime28.era();
        org.joda.time.DateTime dateTime31 = dateTime28.plusWeeks((int) (short) 1);
        java.lang.String str32 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.TimeOfDay timeOfDay33 = dateTime28.toTimeOfDay();
        org.joda.time.DateTime.Property property34 = dateTime28.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime28.toMutableDateTimeISO();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime35);
        org.joda.time.JodaTimePermission jodaTimePermission38 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean41 = dateTimeFormatter40.isParser();
        java.lang.String str43 = dateTimeFormatter40.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter44);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean48 = dateTimeFormatter47.isParser();
        java.lang.String str50 = dateTimeFormatter47.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter47.withZoneUTC();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter51);
        boolean boolean53 = dateTime45.isEqual((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime55 = dateTime52.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property56 = dateTime52.weekOfWeekyear();
        org.joda.time.DateTime dateTime57 = dateTime52.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology58 = dateTime57.getChronology();
        int int59 = dateTime57.getWeekOfWeekyear();
        boolean boolean60 = jodaTimePermission38.equals((java.lang.Object) int59);
        boolean boolean61 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.hour();
        jodaTimePermission38.checkGuard((java.lang.Object) dateTimeFormatter62);
        java.lang.String str64 = jodaTimePermission38.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T000000Z" + "'", str8.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970001T000000Z" + "'", str21.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970001T000000Z" + "'", str32.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970001T000000Z" + "'", str43.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1970001T000000Z" + "'", str50.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        boolean boolean23 = dateTime21.isBefore((long) 32);
        org.joda.time.DateTime.Property property24 = dateTime21.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfYear();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.getID();
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (short) 100);
        long long10 = fixedDateTimeZone4.nextTransition((-64L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-64L) + "'", long10 == (-64L));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean15 = dateTimeFormatter14.isParser();
        java.lang.String str17 = dateTimeFormatter14.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZoneUTC();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        boolean boolean27 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime dateTime29 = dateTime26.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTimeISO();
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property32 = dateTime31.era();
        java.lang.String str33 = property32.getName();
        org.joda.time.DurationField durationField34 = property32.getRangeDurationField();
        boolean boolean35 = property32.isLeap();
        org.joda.time.DateTime dateTime36 = property32.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 1L, (java.lang.Number) 1560636072367L, (java.lang.Number) 97L);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType37, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970001T000000Z" + "'", str17.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "era" + "'", str33.equals("era"));
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime.Property property18 = dateTime13.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime23.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.LocalTime localTime29 = dateTime23.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localTime29);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long44 = dateTimeZone41.convertLocalToUTC((long) (short) 1, false);
        org.joda.time.DateTime dateTime45 = dateTime34.toDateTime(dateTimeZone41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean48 = dateTimeFormatter47.isParser();
        java.lang.String str50 = dateTimeFormatter47.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter47.withZoneUTC();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean55 = dateTimeFormatter54.isParser();
        java.lang.String str57 = dateTimeFormatter54.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter54.withZoneUTC();
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter58);
        boolean boolean60 = dateTime52.isEqual((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime62 = dateTime59.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime63 = dateTime59.toDateTimeISO();
        java.lang.String str64 = dateTime59.toString();
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.DateTime dateTime66 = dateTime59.plus(readablePeriod65);
        org.joda.time.DateTime.Property property67 = dateTime66.year();
        boolean boolean68 = dateTime45.equals((java.lang.Object) property67);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-31L) + "'", long44 == (-31L));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1970001T000000Z" + "'", str50.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1970001T000000Z" + "'", str57.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str64.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.hourOfDay();
        try {
            long long17 = gregorianChronology1.getDateTimeMillis(0L, (int) (short) 100, (-367), (int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(366, 101, 1, (-36));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology1.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField8 = gregorianChronology1.hours();
        org.joda.time.DurationField durationField9 = gregorianChronology1.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean44 = fixedDateTimeZone43.isFixed();
        java.lang.String str45 = fixedDateTimeZone43.getID();
        org.joda.time.DateTime dateTime46 = dateTime38.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        int int47 = dateTime38.getMillisOfDay();
        boolean boolean48 = dateTime18.isAfter((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime50 = dateTime18.minusMinutes(27);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        boolean boolean52 = dateTime18.isSupported(dateTimeFieldType51);
        org.joda.time.DateTime.Property property53 = dateTime18.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfDay();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology1.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology1.hours();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime16.getZone();
        org.joda.time.Instant instant20 = dateTime16.toInstant();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime16.withZone(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(dateTime22);
    }
}

