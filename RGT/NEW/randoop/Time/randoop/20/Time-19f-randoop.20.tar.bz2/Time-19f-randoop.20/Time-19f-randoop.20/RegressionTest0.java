import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 0, (int) (short) -1, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 1, 0, (int) (short) 1, (int) '4', (int) (short) 1, (int) (byte) -1, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560636072367L + "'", long0 == 1560636072367L);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 10, (int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '#', (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) '#', (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            org.joda.time.DateTime.Property property9 = dateTime6.property(dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1), (int) (byte) -1, (-1), 0, (int) (short) 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(10, (-1), (-1), (int) '4', (int) (byte) 10, 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean4 = dateTimeFormatter3.isParser();
//        java.lang.String str6 = dateTimeFormatter3.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T160000-0800" + "'", str6.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Object obj0 = new java.lang.Object();
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Object");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime6.withHourOfDay((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
//        java.io.Writer writer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean4 = dateTimeFormatter3.isParser();
//        java.lang.String str6 = dateTimeFormatter3.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T160000-0800" + "'", str6.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 100, (int) (short) 1, (int) (short) 100, 0, (int) '#', (int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, (int) (byte) 1, 0, (int) '#', (int) (byte) 10, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        java.lang.String str20 = property19.getName();
//        try {
//            org.joda.time.DateTime dateTime22 = property19.addToCopy(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean20 = dateTimeFormatter19.isParser();
//        java.lang.String str22 = dateTimeFormatter19.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean27 = dateTimeFormatter26.isParser();
//        java.lang.String str29 = dateTimeFormatter26.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
//        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
//        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
//        try {
//            org.joda.time.DateTime dateTime40 = property17.setCopy("era");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969365T160000-0800" + "'", str22.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1969365T160000-0800" + "'", str29.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0d, (java.lang.Number) 1L, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long7 = gregorianChronology1.getDateTimeMillis(1, (int) (short) 10, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean8 = dateTimeFormatter7.isParser();
//        java.lang.String str10 = dateTimeFormatter7.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '4', (int) 'a', (int) (short) 10, 10, 0, (int) (byte) -1, dateTimeZone14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969365T160000-0800" + "'", str10.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        java.io.Writer writer5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean8 = dateTimeFormatter7.isParser();
//        java.lang.String str10 = dateTimeFormatter7.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean15 = dateTimeFormatter14.isParser();
//        java.lang.String str17 = dateTimeFormatter14.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZoneUTC();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter18);
//        boolean boolean20 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime22 = dateTime19.withMillisOfSecond((int) ' ');
//        org.joda.time.DateMidnight dateMidnight23 = dateTime22.toDateMidnight();
//        org.joda.time.DateTime dateTime25 = dateTime22.withWeekyear((int) (short) 1);
//        try {
//            dateTimeFormatter4.printTo(writer5, (org.joda.time.ReadableInstant) dateTime22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365T160000-0800" + "'", str3.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969365T160000-0800" + "'", str10.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969365T160000-0800" + "'", str17.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) -1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime16.getZone();
//        long long21 = dateTimeZone19.convertUTCToLocal(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', (int) '#', (-1), (int) (byte) -1, 100, (int) (byte) 1, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        java.lang.StringBuffer stringBuffer7 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean10 = dateTimeFormatter9.isParser();
//        java.lang.String str12 = dateTimeFormatter9.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter9.withZoneUTC();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter13);
//        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
//        try {
//            dateTimeFormatter5.printTo(stringBuffer7, (org.joda.time.ReadablePartial) localDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969365T160000-0800" + "'", str12.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate15);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        java.lang.String str20 = property19.getName();
//        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean24 = dateTimeFormatter23.isParser();
//        java.lang.String str26 = dateTimeFormatter23.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean31 = dateTimeFormatter30.isParser();
//        java.lang.String str33 = dateTimeFormatter30.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
//        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime38 = dateTime35.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTimeISO();
//        org.joda.time.DateTime dateTime40 = dateTime35.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property41 = dateTime40.era();
//        try {
//            int int42 = property19.getDifference((org.joda.time.ReadableInstant) dateTime40);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969365T160000-0800" + "'", str26.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969365T160000-0800" + "'", str33.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean7 = dateTimeFormatter6.isParser();
//        java.lang.String str9 = dateTimeFormatter6.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        java.lang.String str16 = dateTimeFormatter13.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
//        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
//        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
//        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
//        try {
//            org.joda.time.DateTime dateTime29 = dateTime23.withDayOfMonth((int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365T160000-0800" + "'", str3.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969365T160000-0800" + "'", str9.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969365T160000-0800" + "'", str16.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1970001T000000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970001T000000Z\" is malformed at \"70001T000000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime21.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560636072367L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560636072367");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '4', (int) (byte) 10, (-1), (int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 'a');
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        long long12 = dateTimeZone8.convertLocalToUTC((long) 100, false, (long) (byte) -1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((long) 100, (int) (short) -1, 0, (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        try {
            long long12 = gregorianChronology1.getDateTimeMillis((int) (byte) 1, (-1), 0, 100, 32, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.032", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.032/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfMonth();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (byte) -1, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [35,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
//        int int21 = property19.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 100, (int) '#', (int) (short) -1, 1, 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        long long4 = durationField1.subtract((long) 0, 1L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2678400000L) + "'", long4 == (-2678400000L));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
//        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        java.lang.Appendable appendable11 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        java.lang.String str16 = dateTimeFormatter13.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean21 = dateTimeFormatter20.isParser();
//        java.lang.String str23 = dateTimeFormatter20.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
//        boolean boolean26 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property29 = dateTime25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime30 = dateTime25.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime30.toTimeOfDay();
//        try {
//            dateTimeFormatter10.printTo(appendable11, (org.joda.time.ReadablePartial) timeOfDay32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969365T160000-0800" + "'", str16.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969365T160000-0800" + "'", str23.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("+00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.001\" is malformed at \":00:00.001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.centuryOfEra();
        long long13 = gregorianChronology6.add(132L, (long) (byte) 0, 100);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 10, (int) 'a', (int) '4', (int) (short) 1, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 132L + "'", long13 == 132L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePeriod2, (long) ' ', (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str12 = dateTimeFormatter10.print((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970001T000000+0000" + "'", str12.equals("1970001T000000+0000"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        boolean boolean9 = dateTime6.isAfterNow();
//        org.joda.time.DateTime dateTime11 = dateTime6.minusHours((int) (short) 100);
//        int int12 = dateTime11.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 27 + "'", int12 == 27);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean7 = dateTimeFormatter6.isParser();
//        java.lang.String str9 = dateTimeFormatter6.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        java.lang.String str16 = dateTimeFormatter13.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
//        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
//        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
//        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime23.toTimeOfDay();
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime23.withEra((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365T160000-0800" + "'", str3.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969365T160000-0800" + "'", str9.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969365T160000-0800" + "'", str16.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(timeOfDay28);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
//        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime18.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '4', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5200 + "'", int2 == 5200);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
//        try {
//            org.joda.time.DateTime dateTime22 = property19.addToCopy((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(durationField20);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 5200, (java.lang.Number) 32, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = zonedChronology12.get(readablePeriod13, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean5 = dateTimeFormatter4.isParser();
//        java.lang.String str7 = dateTimeFormatter4.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean12 = dateTimeFormatter11.isParser();
//        java.lang.String str14 = dateTimeFormatter11.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
//        boolean boolean17 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property20 = dateTime16.weekOfWeekyear();
//        org.joda.time.DateTime dateTime21 = dateTime16.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology22 = dateTime21.getChronology();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay23);
//        int[] intArray26 = new int[] { 32 };
//        try {
//            gregorianChronology0.validate((org.joda.time.ReadablePartial) timeOfDay23, intArray26);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must not be larger than 23");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365T160000-0800" + "'", str7.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969365T160000-0800" + "'", str14.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis((long) 10, (int) (short) 100, 0, (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0L, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
//        boolean boolean24 = fixedDateTimeZone23.isFixed();
//        java.lang.String str25 = fixedDateTimeZone23.getID();
//        org.joda.time.DateTime dateTime26 = dateTime18.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        int int28 = fixedDateTimeZone23.getOffset((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.weekyear();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1, 1, 1, (int) (short) 10, (int) (byte) 0, (int) (byte) -1, (int) (byte) -1, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime21.toMutableDateTime(chronology22);
//        int int24 = mutableDateTime23.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.convertLocalToUTC((long) (short) -1, true);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 27");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-33L) + "'", long7 == (-33L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter1.printTo(writer2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
//        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
//        try {
//            org.joda.time.DateTime dateTime29 = dateTime23.withDate((int) '4', (int) (short) -1, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "1970001T000000Z", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(27, (int) (byte) 100, (int) (byte) 100, (int) (short) -1, (int) ' ', dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        java.io.Writer writer7 = null;
//        try {
//            dateTimeFormatter5.printTo(writer7, (long) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField7 = gregorianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 1, 0, (int) (byte) 10, 0, 0, 5200, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
//        java.lang.String str21 = property19.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean7 = dateTimeFormatter6.isParser();
//        java.lang.String str9 = dateTimeFormatter6.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        java.lang.String str16 = dateTimeFormatter13.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
//        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
//        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
//        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime23.toTimeOfDay();
//        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
//        int int30 = dateTime23.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365T160000-0800" + "'", str3.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969365T160000-0800" + "'", str9.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969365T160000-0800" + "'", str16.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
//        java.io.Writer writer3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean6 = dateTimeFormatter5.isParser();
//        java.lang.String str8 = dateTimeFormatter5.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime10.toMutableDateTimeISO();
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(locale2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969365T160000-0800" + "'", str8.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        java.lang.String str13 = dateTimeFormatter10.print(10L);
//        java.lang.String str14 = dateTime9.toString(dateTimeFormatter10);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withLocale(locale15);
//        int int17 = dateTimeFormatter16.getDefaultYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969365T160000-0800" + "'", str13.equals("1969365T160000-0800"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        java.lang.String str20 = property19.getName();
//        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean24 = dateTimeFormatter23.isParser();
//        java.lang.String str26 = dateTimeFormatter23.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean31 = dateTimeFormatter30.isParser();
//        java.lang.String str33 = dateTimeFormatter30.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
//        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
//        boolean boolean37 = property19.equals((java.lang.Object) dateTime28);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
//        long long42 = dateTimeZone39.convertLocalToUTC((long) (short) 1, false);
//        java.lang.String str44 = dateTimeZone39.getShortName(100L);
//        org.joda.time.DateTime dateTime45 = dateTime28.withZone(dateTimeZone39);
//        try {
//            org.joda.time.DateTime dateTime47 = dateTime28.withDayOfWeek(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969365T160000-0800" + "'", str26.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969365T160000-0800" + "'", str33.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31L) + "'", long42 == (-31L));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00:00.032" + "'", str44.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime45);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        try {
            long long19 = zonedChronology12.getDateTimeMillis((-1), (int) (byte) 1, (-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean4 = dateTimeFormatter3.isParser();
//        java.lang.String str6 = dateTimeFormatter3.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean11 = dateTimeFormatter10.isParser();
//        java.lang.String str13 = dateTimeFormatter10.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
//        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readableDuration19);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T160000-0800" + "'", str6.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969365T160000-0800" + "'", str13.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean3 = dateTimeFormatter2.isParser();
//        java.lang.String str5 = dateTimeFormatter2.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean16 = dateTimeFormatter15.isParser();
//        java.lang.String str18 = dateTimeFormatter15.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter15.withZoneUTC();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter19);
//        boolean boolean21 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime24 = dateTime20.toDateTimeISO();
//        org.joda.time.DateTime dateTime25 = dateTime20.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((int) (short) 1);
//        java.lang.String str29 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.TimeOfDay timeOfDay30 = dateTime25.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969365T160000-0800" + "'", str5.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969365T160000-0800" + "'", str18.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(timeOfDay30);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean20 = dateTimeFormatter19.isParser();
//        java.lang.String str22 = dateTimeFormatter19.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean27 = dateTimeFormatter26.isParser();
//        java.lang.String str29 = dateTimeFormatter26.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
//        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
//        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime.Property property39 = dateTime34.year();
//        org.joda.time.DateTime dateTime41 = property39.addToCopy((long) 32);
//        java.util.Locale locale43 = null;
//        try {
//            org.joda.time.DateTime dateTime44 = property39.setCopy("era", locale43);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969365T160000-0800" + "'", str22.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1969365T160000-0800" + "'", str29.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTimeISO();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.yearOfCentury();
//        org.joda.time.DurationField durationField24 = gregorianChronology21.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
//        boolean boolean30 = fixedDateTimeZone29.isFixed();
//        java.lang.String str31 = fixedDateTimeZone29.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology21, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.Chronology chronology34 = zonedChronology32.withZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime18.toDateTime(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.hours();
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean13 = dateTimeFormatter12.isParser();
//        java.lang.String str15 = dateTimeFormatter12.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean20 = dateTimeFormatter19.isParser();
//        java.lang.String str22 = dateTimeFormatter19.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
//        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) ' ');
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.minus(readableDuration28);
//        int int30 = dateTime27.getMillisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean33 = dateTimeFormatter32.isParser();
//        java.lang.String str35 = dateTimeFormatter32.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean40 = dateTimeFormatter39.isParser();
//        java.lang.String str42 = dateTimeFormatter39.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter39.withZoneUTC();
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter43);
//        boolean boolean45 = dateTime37.isEqual((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime47 = dateTime44.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property48 = dateTime44.weekOfWeekyear();
//        org.joda.time.DateTime dateTime49 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology50 = dateTime49.getChronology();
//        org.joda.time.TimeOfDay timeOfDay51 = dateTime49.toTimeOfDay();
//        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int30, (java.lang.Object) timeOfDay51);
//        int[] intArray53 = null;
//        try {
//            gregorianChronology8.validate((org.joda.time.ReadablePartial) timeOfDay51, intArray53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969365T160000-0800" + "'", str15.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969365T160000-0800" + "'", str22.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32 + "'", int30 == 32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969365T160000-0800" + "'", str35.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1969365T160000-0800" + "'", str42.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(timeOfDay51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 100, (int) (byte) 100, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        boolean boolean19 = property17.equals((java.lang.Object) 100);
//        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
//        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property17.getAsText(locale24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        boolean boolean19 = property17.equals((java.lang.Object) 100);
//        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
//        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
//        try {
//            org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear(366);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
//        boolean boolean19 = property17.equals((java.lang.Object) 100);
//        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
//        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
//        java.util.Locale locale25 = null;
//        try {
//            java.lang.String str26 = dateTime23.toString("hi!", locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean3 = dateTimeFormatter2.isParser();
//        java.lang.String str5 = dateTimeFormatter2.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean16 = dateTimeFormatter15.isParser();
//        java.lang.String str18 = dateTimeFormatter15.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter15.withZoneUTC();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter19);
//        boolean boolean21 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime24 = dateTime20.toDateTimeISO();
//        org.joda.time.DateTime dateTime25 = dateTime20.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((int) (short) 1);
//        java.lang.String str29 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.TimeOfDay timeOfDay30 = dateTime25.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969365T160000-0800" + "'", str5.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969365T160000-0800" + "'", str18.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(timeOfDay30);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod2, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1970001T000000+0000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970001T000000+0000\" is malformed at \"70001T000000+0000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(2, (-1), 32, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(1560636072367L, (int) (byte) 100, 0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 5200, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.year();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean9 = dateTimeFormatter8.isParser();
//        java.lang.String str11 = dateTimeFormatter8.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
//        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        java.lang.String str20 = property19.getName();
//        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
//        org.joda.time.DateTime.Property property22 = dateTime21.era();
//        boolean boolean24 = dateTime21.isBefore((long) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969365T160000-0800" + "'", str11.equals("1969365T160000-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        boolean boolean11 = dateTime6.equals((java.lang.Object) 32);
        int int12 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 0);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
        try {
            java.lang.String str14 = dateTime6.toString("1970001T000000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DurationField durationField12 = property11.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime22 = dateTime20.minusDays(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        int int21 = dateTime19.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970001T000000+0000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(32);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getYearOfCentury();
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = dateTime10.toString("UTC", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(366, 0, (int) (short) -1, (int) (short) 10, 366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) ' ', (int) (byte) -1, (int) (byte) 0, 10, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1970001T000000+0000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970001T000000+0000\" is malformed at \"T000000+0000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property39 = dateTime38.era();
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((int) (short) 1);
        boolean boolean42 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean3 = dateTimeFormatter2.isParser();
        java.lang.String str5 = dateTimeFormatter2.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean10 = dateTimeFormatter9.isParser();
        java.lang.String str12 = dateTimeFormatter9.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter9.withZoneUTC();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter13);
        boolean boolean15 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime14.toDateTimeISO();
        org.joda.time.DateTime dateTime19 = dateTime14.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime19.toMutableDateTimeISO();
        java.lang.String str22 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970001T000000Z" + "'", str5.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970001T000000Z" + "'", str12.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-W01-4T00:00:00.000Z" + "'", str22.equals("1970-W01-4T00:00:00.000Z"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.getID();
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean37 = property19.equals((java.lang.Object) dateTime28);
        org.joda.time.LocalDate localDate38 = dateTime28.toLocalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000Z" + "'", str26.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000Z" + "'", str33.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDate38);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean23 = dateTimeFormatter22.isParser();
        java.lang.String str25 = dateTimeFormatter22.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean30 = dateTimeFormatter29.isParser();
        java.lang.String str32 = dateTimeFormatter29.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter29.withZoneUTC();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter33);
        boolean boolean35 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime38 = dateTime34.toDateTimeISO();
        org.joda.time.DateTime dateTime39 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime40 = dateTime34.toDateTimeISO();
        try {
            int int41 = property19.getDifference((org.joda.time.ReadableInstant) dateTime40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970001T000000Z" + "'", str25.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970001T000000Z" + "'", str32.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.getID();
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = fixedDateTimeZone4.getOffset(readableInstant8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DurationField durationField21 = property19.getRangeDurationField();
        boolean boolean22 = property19.isLeap();
        org.joda.time.DurationField durationField23 = property19.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        try {
            long long9 = gregorianChronology1.getDateTimeMillis((int) '#', (int) ' ', 32, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withEarlierOffsetAtOverlap();
        java.lang.String str12 = dateTime6.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str12.equals("1970-01-01T00:00:00.000Z"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        int int21 = dateTime19.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.String str2 = dateTimeFormatter0.print((-31L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969" + "'", str2.equals("1969"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) (short) 0, (int) (short) 0, 2, 0, (int) (short) 1, (int) (byte) 0, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            org.joda.time.DateTime dateTime12 = dateTimeFormatter0.parseDateTime("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        int int20 = dateTime13.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', (int) (byte) -1, (int) (byte) 1, 70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology1.hours();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField7 = gregorianChronology6.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField8 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField5, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1.0d, number2, (java.lang.Number) 1560636072367L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 0, (int) (byte) 10, (-1), (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(27L, dateTimeZone1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "era");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        try {
            org.joda.time.DateTime.Property property26 = dateTime24.property(dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        int int22 = property19.getMinimumValue();
        java.util.Locale locale23 = null;
        int int24 = property19.getMaximumShortTextLength(locale23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.monthOfYear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 32, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (byte) 100, (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [97,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        int int23 = dateTime18.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        java.lang.String str9 = dateTimeFormatter6.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.TimeOfDay timeOfDay28 = dateTime23.toTimeOfDay();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        long long30 = property29.remainder();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        boolean boolean8 = dateTimeFormatter6.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long15 = fixedDateTimeZone13.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) 10, 0, (int) (short) 1, (int) 'a', (int) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.Instant instant19 = dateTime13.toInstant();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(instant19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
        org.joda.time.DateMidnight dateMidnight26 = dateTime25.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateMidnight26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        try {
            java.lang.String str16 = dateTime6.toString("1970-01-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
        boolean boolean39 = dateTime36.isAfterNow();
        org.joda.time.DateTime dateTime40 = dateTime36.withTimeAtStartOfDay();
        boolean boolean42 = dateTime36.isEqual((long) 10);
        org.joda.time.DateTime dateTime44 = dateTime36.minusMillis((int) '#');
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime27, (org.joda.time.ReadableInstant) dateTime44);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000Z" + "'", str34.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.year();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.era();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withTime(100, (int) (short) 10, 2, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        java.lang.String str14 = dateTime9.toString(dateTimeFormatter10);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withLocale(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeFormatter10.getZone();
        java.lang.StringBuffer stringBuffer18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean28 = dateTimeFormatter27.isParser();
        java.lang.String str30 = dateTimeFormatter27.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter31);
        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property36 = dateTime32.weekOfWeekyear();
        org.joda.time.DateTime dateTime37 = dateTime32.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = dateTime37.getChronology();
        org.joda.time.TimeOfDay timeOfDay39 = dateTime37.toTimeOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.toDateTimeISO();
        boolean boolean42 = dateTime40.isBefore((long) 32);
        org.joda.time.LocalTime localTime43 = dateTime40.toLocalTime();
        try {
            dateTimeFormatter10.printTo(stringBuffer18, (org.joda.time.ReadablePartial) localTime43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000Z" + "'", str13.equals("1970001T000000Z"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970001T000000Z" + "'", str30.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(localTime43);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean16 = dateTimeFormatter15.isParser();
        java.lang.String str18 = dateTimeFormatter15.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter15.withZoneUTC();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean23 = dateTimeFormatter22.isParser();
        java.lang.String str25 = dateTimeFormatter22.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter26);
        boolean boolean28 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property31 = dateTime27.weekOfWeekyear();
        int int32 = property13.compareTo((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970001T000000Z" + "'", str18.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970001T000000Z" + "'", str25.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970001T000000+0000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970001T000000+0000' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) ' ', 10, 0, 1970, 0, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean7 = dateTimeFormatter6.isParser();
//        java.lang.String str9 = dateTimeFormatter6.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        java.lang.String str15 = dateTimeZone13.getShortName(1560636072367L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone13.getShortName(0L, locale17);
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) ' ', 5200, 4, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, 0, 5200, 0, 366, 2000, 0, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.weekyear();
        long long16 = gregorianChronology7.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology7.hourOfDay();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(2000, 0, (int) (short) 100, (int) (short) -1, 1, 0, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2700L + "'", long16 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser8);
        try {
            org.joda.time.LocalDate localDate11 = dateTimeFormatter9.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime16.withEra((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int12 = fixedDateTimeZone7.getOffsetFromLocal((long) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((-1), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1970-01-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        boolean boolean11 = dateTime6.equals((java.lang.Object) 32);
        org.joda.time.DateTime.Property property12 = dateTime6.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime.Property property14 = dateTime6.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-31L), (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-124L) + "'", long2 == (-124L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        org.joda.time.Instant instant19 = dateTime16.toInstant();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(instant19);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime19 = property17.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime20 = property17.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getShortName(27L, locale12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime38 = dateTime35.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTimeISO();
        java.lang.String str40 = dateTime35.toString();
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime35.plus(readablePeriod41);
        try {
            int int43 = property19.getDifference((org.joda.time.ReadableInstant) dateTime35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000Z" + "'", str26.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000Z" + "'", str33.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str40.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfCentury();
        org.joda.time.DurationField durationField11 = gregorianChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) 'a', 366, 1970, 5200, (int) (byte) 100, (int) '#', (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.monthOfYear();
        org.joda.time.ReadableInstant readableInstant20 = null;
        try {
            int int21 = property19.compareTo(readableInstant20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        long long8 = gregorianChronology1.add(132L, (long) (byte) 0, 100);
        try {
            long long16 = gregorianChronology1.getDateTimeMillis((int) (byte) 10, (int) (byte) 1, (int) (short) 1, (int) (byte) 10, 27, 1970, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 132L, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long17 = zonedChronology12.getDateTimeMillis((int) (byte) 10, (int) (short) 100, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property12 = dateTime6.weekyear();
        int int13 = property12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275054) + "'", int13 == (-292275054));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((int) (short) 1);
        boolean boolean25 = dateTime24.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset(1L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
        org.joda.time.DateTime dateTime25 = property17.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean15 = dateTimeFormatter14.isParser();
        java.lang.String str17 = dateTimeFormatter14.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZoneUTC();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter18);
        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
        org.joda.time.DateTime dateTime22 = dateTime19.withMinuteOfHour((int) (byte) 0);
        boolean boolean23 = fixedDateTimeZone11.equals((java.lang.Object) dateTime22);
        long long25 = fixedDateTimeZone11.convertUTCToLocal(27L);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(10, 4, 1, 2, (int) (byte) -1, (int) '4', 2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970001T000000Z" + "'", str17.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28L + "'", long25 == 28L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime11 = dateTime6.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime11.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfFloorCopy();
        org.joda.time.DurationField durationField22 = property19.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology1.days();
        long long8 = durationField5.subtract(0L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology3.days();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.monthOfYear();
        java.lang.Object obj9 = null;
        boolean boolean10 = gregorianChronology3.equals(obj9);
        org.joda.time.DurationField durationField11 = gregorianChronology3.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField12 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
        int int13 = dateTime12.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean44 = fixedDateTimeZone43.isFixed();
        java.lang.String str45 = fixedDateTimeZone43.getID();
        org.joda.time.DateTime dateTime46 = dateTime38.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        int int47 = dateTime38.getMillisOfDay();
        boolean boolean48 = dateTime18.isAfter((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime.Property property49 = dateTime38.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(property49);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) -1);
        org.joda.time.DateTime dateTime22 = dateTime18.minusHours(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTimeISO();
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime18, (org.joda.time.ReadableInstant) dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000Z" + "'", str34.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(chronology41);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
        java.util.Date date14 = dateTime12.toDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        int int22 = property19.getMinimumValue();
        java.util.Locale locale23 = null;
        java.lang.String str24 = property19.getAsShortText(locale23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "AD" + "'", str24.equals("AD"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DurationField durationField21 = property19.getRangeDurationField();
        org.joda.time.DateTime dateTime22 = property19.withMaximumValue();
        java.util.Locale locale23 = null;
        int int24 = property19.getMaximumShortTextLength(locale23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        java.lang.Integer int4 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
        org.joda.time.DurationField durationField11 = gregorianChronology8.seconds();
        org.joda.time.DurationField durationField12 = gregorianChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.monthOfYear();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(2, 32, 31, 31, 0, (int) (short) 0, 1970, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.io.Writer writer4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        java.lang.String str9 = dateTimeFormatter6.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property22 = dateTime18.weekOfWeekyear();
        org.joda.time.DateTime dateTime23 = dateTime18.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology24 = dateTime23.getChronology();
        org.joda.time.TimeOfDay timeOfDay25 = dateTime23.toTimeOfDay();
        boolean boolean26 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay25);
        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay25);
        try {
            dateTimeFormatter2.printTo(writer4, (org.joda.time.ReadablePartial) timeOfDay25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((long) (byte) 0, (int) (short) 1, 5200, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfSecond((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withSecondOfMinute(366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZoneUTC();
        boolean boolean12 = dateTimeFormatter11.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology1.weekyears();
        long long9 = durationField6.subtract(0L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField9 = gregorianChronology6.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.year();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, (int) 'a', 70, (int) (byte) -1, 10, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        boolean boolean18 = fixedDateTimeZone4.isStandardOffset((long) 27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean28 = dateTimeFormatter27.isParser();
        java.lang.String str30 = dateTimeFormatter27.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter31);
        boolean boolean33 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTimeISO();
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTimeISO();
        boolean boolean39 = fixedDateTimeZone4.equals((java.lang.Object) dateTime37);
        int int40 = dateTime37.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970001T000000Z" + "'", str30.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property19.getAsShortText(locale21);
        org.joda.time.DateTime dateTime23 = property19.roundHalfEvenCopy();
        boolean boolean24 = property19.isLeap();
        try {
            org.joda.time.DateTime dateTime26 = property19.addToCopy(70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long20 = zonedChronology12.getDateTimeMillis(0, 19, (int) '#', 100, 1, 70, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.year();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis((long) (byte) -1, 31, 0, 366, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        java.lang.String str14 = dateTime9.toString(dateTimeFormatter10);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withLocale(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeFormatter10.getZone();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter10.getPrinter();
        java.lang.Appendable appendable19 = null;
        try {
            dateTimeFormatter10.printTo(appendable19, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000Z" + "'", str13.equals("1970001T000000Z"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime19 = property17.roundHalfCeilingCopy();
        int int20 = property17.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("", (int) '#', (int) 'a', (int) (short) 10, ' ', (int) (byte) -1, (int) (short) 10, 27, true, 31);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology12);
        try {
            long long18 = zonedChronology12.getDateTimeMillis((int) '4', 0, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getShortName(0L);
        long long10 = fixedDateTimeZone4.nextTransition((long) (byte) 0);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime22 = property20.setCopy((int) (short) 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property20.getAsShortText(locale23);
        long long25 = property20.remainder();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DurationField durationField21 = property19.getRangeDurationField();
        org.joda.time.DateTime dateTime22 = property19.withMaximumValue();
        java.lang.String str23 = property19.getAsText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AD" + "'", str23.equals("AD"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        boolean boolean26 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime.Property property30 = dateTime25.secondOfMinute();
        boolean boolean31 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime22 = dateTime18.minusSeconds((int) (short) 1);
        int int23 = dateTime22.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 23 + "'", int23 == 23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime18.year();
        java.lang.Class<?> wildcardClass23 = property22.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        boolean boolean12 = dateTime6.isAfter((long) 70);
        org.joda.time.DateTime dateTime14 = dateTime6.minusDays(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        java.lang.String str9 = dateTimeFormatter6.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime28 = dateTime26.withSecondOfMinute(1);
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime27 = dateTime23.withWeekyear((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime23.secondOfMinute();
        java.util.Locale locale30 = null;
        try {
            org.joda.time.DateTime dateTime31 = property28.setCopy("1970001T000000Z", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970001T000000Z\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfCentury();
        org.joda.time.DurationField durationField11 = gregorianChronology8.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean17 = fixedDateTimeZone16.isFixed();
        java.lang.String str18 = fixedDateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = zonedChronology19.withZone(dateTimeZone20);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(70, 70, 0, (-35), 0, (int) '#', 0, chronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property12 = dateTime6.weekyear();
        try {
            org.joda.time.DateTime dateTime14 = property12.setCopy("1970001T000000Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970001T000000Z\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.Chronology chronology8 = dateTime6.getChronology();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder9.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) chronology8, (java.lang.Object) 31);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withLocale(locale11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getYearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.hours();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.minuteOfDay();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology15);
        boolean boolean19 = gregorianChronology13.equals((java.lang.Object) dateTime18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology24.centuries();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.centuryOfEra();
        org.joda.time.DurationField durationField29 = gregorianChronology24.weekyears();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology24.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean34 = dateTimeFormatter33.isParser();
        java.lang.String str36 = dateTimeFormatter33.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean41 = dateTimeFormatter40.isParser();
        java.lang.String str43 = dateTimeFormatter40.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter44);
        boolean boolean46 = dateTime38.isEqual((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime dateTime48 = dateTime45.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime50 = dateTime48.minus(readableDuration49);
        int int51 = dateTime48.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean54 = dateTimeFormatter53.isParser();
        java.lang.String str56 = dateTimeFormatter53.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter53.withZoneUTC();
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter57);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean61 = dateTimeFormatter60.isParser();
        java.lang.String str63 = dateTimeFormatter60.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter60.withZoneUTC();
        org.joda.time.DateTime dateTime65 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter64);
        boolean boolean66 = dateTime58.isEqual((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.DateTime dateTime68 = dateTime65.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property69 = dateTime65.weekOfWeekyear();
        org.joda.time.DateTime dateTime70 = dateTime65.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology71 = dateTime70.getChronology();
        org.joda.time.TimeOfDay timeOfDay72 = dateTime70.toTimeOfDay();
        boolean boolean73 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int51, (java.lang.Object) timeOfDay72);
        int[] intArray75 = gregorianChronology24.get((org.joda.time.ReadablePartial) timeOfDay72, 0L);
        try {
            int[] intArray77 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) timeOfDay20, (int) (short) -1, intArray75, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [101,153]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970001T000000Z" + "'", str36.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970001T000000Z" + "'", str43.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 32 + "'", int51 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1970001T000000Z" + "'", str56.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1970001T000000Z" + "'", str63.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertNotNull(timeOfDay72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 1, false);
        long long13 = dateTimeZone7.convertLocalToUTC((long) (short) -1, true);
        long long16 = dateTimeZone7.adjustOffset((long) 27, true);
        long long20 = dateTimeZone7.convertLocalToUTC((-33L), false, 0L);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((-292275054), 1970, 27, (int) ' ', (int) (byte) 10, 1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31L) + "'", long10 == (-31L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-33L) + "'", long13 == (-33L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 27L + "'", long16 == 27L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-65L) + "'", long20 == (-65L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = dateTime15.isSupported(dateTimeFieldType19);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMillis((int) (short) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks((int) ' ');
        int int25 = dateTime22.getYearOfEra();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.convertLocalToUTC((long) (short) -1, true);
        long long10 = dateTimeZone1.adjustOffset((long) 27, true);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-33L) + "'", long7 == (-33L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 27L + "'", long10 == 27L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) true);
        java.lang.String str3 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField11.set((long) 366, "+00:00:00.001", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.001\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(97L, (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3007L + "'", long2 == 3007L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean24 = dateTimeFormatter23.isParser();
        java.lang.String str26 = dateTimeFormatter23.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean31 = dateTimeFormatter30.isParser();
        java.lang.String str33 = dateTimeFormatter30.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter30.withZoneUTC();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter34);
        boolean boolean36 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean37 = property19.equals((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long42 = dateTimeZone39.convertLocalToUTC((long) (short) 1, false);
        java.lang.String str44 = dateTimeZone39.getShortName(100L);
        org.joda.time.DateTime dateTime45 = dateTime28.withZone(dateTimeZone39);
        boolean boolean46 = dateTime45.isBeforeNow();
        int int47 = dateTime45.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970001T000000Z" + "'", str26.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970001T000000Z" + "'", str33.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31L) + "'", long42 == (-31L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00:00.032" + "'", str44.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology1.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray12 = gregorianChronology1.get(readablePeriod9, (long) (-292275054), (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZoneUTC();
        boolean boolean12 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((-33L), false, 132L);
        int int14 = fixedDateTimeZone4.getOffset(3007L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(5200, ' ', (int) 'a', 0, 31, true, 2000);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("0", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("1969365T160000-0800");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withOffsetParsed();
        java.lang.String str7 = dateTimeFormatter5.print(3007L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970001T000003Z" + "'", str7.equals("1970001T000003Z"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.032\" is malformed at \":00:00.032\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1969365T160000-0800", 70, 2000, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for 1969365T160000-0800 must be in the range [2000,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long7 = dateTimeZone4.convertLocalToUTC((long) (short) 1, false);
        long long9 = dateTimeZone4.convertUTCToLocal((long) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean21 = dateTimeFormatter20.isParser();
        java.lang.String str23 = dateTimeFormatter20.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withZoneUTC();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter24);
        boolean boolean26 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property29 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime30 = dateTime25.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.TimeOfDay timeOfDay32 = dateTime30.toTimeOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.toDateTimeISO();
        boolean boolean35 = dateTime33.isBefore((long) 32);
        org.joda.time.LocalTime localTime36 = dateTime33.toLocalTime();
        long long38 = gregorianChronology1.set((org.joda.time.ReadablePartial) localTime36, (-31L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31L) + "'", long7 == (-31L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 132L + "'", long9 == 132L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970001T000000Z" + "'", str23.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(localTime36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-86400000L) + "'", long38 == (-86400000L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.centuryOfEra();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis((int) (short) -1, 70, 23, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean11 = fixedDateTimeZone10.isFixed();
        java.lang.String str12 = fixedDateTimeZone10.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = zonedChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean18 = dateTimeFormatter17.isParser();
        java.lang.String str20 = dateTimeFormatter17.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZoneUTC();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter21);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime22.getZone();
        boolean boolean25 = dateTime22.isAfterNow();
        org.joda.time.DateTime dateTime26 = dateTime22.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime28 = dateTime22.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property29 = dateTime28.monthOfYear();
        boolean boolean30 = zonedChronology13.equals((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone31 = zonedChronology13.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology33.year();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology33.clockhourOfDay();
        boolean boolean39 = zonedChronology13.equals((java.lang.Object) gregorianChronology33);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology33);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970001T000000Z" + "'", str20.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond((int) (byte) 0);
        int int13 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime16 = dateTime12.plusMinutes((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.DateTime dateTime25 = property22.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long5 = dateTimeZone2.convertLocalToUTC((long) (short) 1, false);
        long long8 = dateTimeZone2.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) 100);
        java.lang.String str13 = offsetDateTimeField12.getName();
        long long15 = offsetDateTimeField12.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField12.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31L) + "'", long5 == (-31L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "weekOfWeekyear" + "'", str13.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345599968L + "'", long15 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((int) (short) 1);
        int int25 = dateTime24.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(53, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5141 + "'", int2 == 5141);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365T160000-0800" + "'", str4.equals("1969365T160000-0800"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour(27);
        try {
            org.joda.time.DateTime dateTime31 = dateTime26.withTime((int) '4', 11, (-36), 366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        java.lang.String str9 = dateTimeFormatter6.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter4.withPivotYear((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        int int32 = dateTimeZone30.getOffsetFromLocal(28L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean4 = dateTimeFormatter3.isParser();
        java.lang.String str6 = dateTimeFormatter3.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000Z" + "'", str6.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay19);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long7 = dateTimeZone4.convertLocalToUTC((long) (short) 1, false);
        long long9 = dateTimeZone4.convertUTCToLocal((long) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField12 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31L) + "'", long7 == (-31L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 132L + "'", long9 == 132L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMinutes(4);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(chronology4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 1, false);
        long long8 = dateTimeZone3.convertUTCToLocal((long) 100);
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean12 = dateTimeFormatter11.isParser();
        java.lang.String str14 = dateTimeFormatter11.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean19 = dateTimeFormatter18.isParser();
        java.lang.String str21 = dateTimeFormatter18.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter22);
        boolean boolean24 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property27 = dateTime23.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean30 = dateTimeFormatter29.isParser();
        java.lang.String str32 = dateTimeFormatter29.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter29.withZoneUTC();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean37 = dateTimeFormatter36.isParser();
        java.lang.String str39 = dateTimeFormatter36.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter36.withZoneUTC();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter40);
        boolean boolean42 = dateTime34.isEqual((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime44 = dateTime41.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.minus(readableDuration45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime44.getZone();
        int int48 = property27.compareTo((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime.Property property49 = dateTime44.year();
        org.joda.time.DateTime dateTime51 = property49.addToCopy((long) 32);
        org.joda.time.DateTime dateTime52 = dateTime51.toDateTime();
        int int53 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime52);
        java.util.Locale locale55 = null;
        java.lang.String str56 = dateTimeZone3.getName((long) 5200, locale55);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31L) + "'", long6 == (-31L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970001T000000Z" + "'", str21.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970001T000000Z" + "'", str32.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970001T000000Z" + "'", str39.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "+00:00:00.032" + "'", str56.equals("+00:00:00.032"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 32);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime18.toDateTimeISO();
        int int20 = dateTime19.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        long long16 = offsetDateTimeField11.roundHalfCeiling(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean19 = dateTimeFormatter18.isParser();
        java.lang.String str21 = dateTimeFormatter18.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean26 = dateTimeFormatter25.isParser();
        java.lang.String str28 = dateTimeFormatter25.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withZoneUTC();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter29);
        boolean boolean31 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property34 = dateTime30.weekOfWeekyear();
        org.joda.time.DateTime dateTime35 = dateTime30.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology36 = dateTime35.getChronology();
        org.joda.time.TimeOfDay timeOfDay37 = dateTime35.toTimeOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.toDateTimeISO();
        boolean boolean40 = dateTime38.isBefore((long) 32);
        org.joda.time.LocalTime localTime41 = dateTime38.toLocalTime();
        int[] intArray45 = new int[] { 31, 0 };
        try {
            int[] intArray47 = offsetDateTimeField11.addWrapPartial((org.joda.time.ReadablePartial) localTime41, 3, intArray45, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200032L) + "'", long16 == (-259200032L));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970001T000000Z" + "'", str21.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970001T000000Z" + "'", str28.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(timeOfDay37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(localTime41);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        int int18 = dateTime13.getSecondOfDay();
        org.joda.time.DateTime dateTime20 = dateTime13.withCenturyOfEra((int) (byte) 10);
        org.joda.time.DateTime dateTime22 = dateTime13.minusHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isParser();
        java.lang.String str15 = dateTimeFormatter12.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime28 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean35 = fixedDateTimeZone34.isFixed();
        java.lang.String str36 = fixedDateTimeZone34.getID();
        org.joda.time.DateTime dateTime37 = dateTime29.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime6.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        int int39 = mutableDateTime38.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001T000000Z" + "'", str15.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime13.minusMonths(100);
        org.joda.time.DateTime.Property property21 = dateTime13.monthOfYear();
        java.lang.String str22 = property21.getAsShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.hourOfHalfday();
        org.joda.time.DurationField durationField27 = gregorianChronology24.eras();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean30 = dateTimeFormatter29.isParser();
        java.lang.String str32 = dateTimeFormatter29.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter29.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean36 = dateTimeFormatter35.isParser();
        java.lang.String str38 = dateTimeFormatter35.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter35.withZoneUTC();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean43 = dateTimeFormatter42.isParser();
        java.lang.String str45 = dateTimeFormatter42.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter42.withZoneUTC();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter46);
        boolean boolean48 = dateTime40.isEqual((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime51 = dateTime47.toDateTimeISO();
        org.joda.time.DateTime dateTime52 = dateTime47.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property53 = dateTime52.era();
        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((int) (short) 1);
        java.lang.String str56 = dateTimeFormatter33.print((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.TimeOfDay timeOfDay57 = dateTime52.toTimeOfDay();
        int[] intArray59 = gregorianChronology24.get((org.joda.time.ReadablePartial) timeOfDay57, (long) (short) 100);
        try {
            int int60 = property21.compareTo((org.joda.time.ReadablePartial) timeOfDay57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Jan" + "'", str22.equals("Jan"));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970001T000000Z" + "'", str32.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970001T000000Z" + "'", str38.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970001T000000Z" + "'", str45.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1970001T000000Z" + "'", str56.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay57);
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean5 = dateTimeFormatter4.isParser();
        java.lang.String str7 = dateTimeFormatter4.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean12 = dateTimeFormatter11.isParser();
        java.lang.String str14 = dateTimeFormatter11.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter15);
        boolean boolean17 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property20 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime dateTime21 = dateTime16.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology22 = dateTime21.getChronology();
        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime dateTime26 = dateTime21.withCenturyOfEra(0);
        int int27 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.Chronology chronology28 = gregorianChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970001T000000Z" + "'", str7.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970001T000000Z" + "'", str14.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            long long2 = dateTimeFormatter0.parseMillis("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj10 = null;
        boolean boolean11 = iSOChronology9.equals(obj10);
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        long long16 = offsetDateTimeField11.roundHalfCeiling(10L);
        boolean boolean17 = offsetDateTimeField11.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200032L) + "'", long16 == (-259200032L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property19.getAsShortText(locale21);
        org.joda.time.DateTime dateTime23 = property19.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean26 = dateTimeFormatter25.isParser();
        java.lang.String str28 = dateTimeFormatter25.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withZoneUTC();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean33 = dateTimeFormatter32.isParser();
        java.lang.String str35 = dateTimeFormatter32.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
        boolean boolean38 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime37.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property41 = dateTime37.weekOfWeekyear();
        boolean boolean43 = property41.equals((java.lang.Object) 100);
        boolean boolean45 = property41.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime47 = property41.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime52 = dateTime47.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime54 = dateTime47.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long59 = dateTimeZone56.convertLocalToUTC((long) (short) 1, false);
        long long62 = dateTimeZone56.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, (int) (short) 100);
        java.lang.String str67 = offsetDateTimeField66.getName();
        long long69 = offsetDateTimeField66.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField66.getType();
        int int71 = dateTime47.get(dateTimeFieldType70);
        int int72 = dateTime23.get(dateTimeFieldType70);
        int int73 = dateTime23.getEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean76 = dateTimeFormatter75.isParser();
        java.lang.String str78 = dateTimeFormatter75.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = dateTimeFormatter75.withZoneUTC();
        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter79);
        org.joda.time.DateTimeZone dateTimeZone81 = dateTime80.getZone();
        org.joda.time.DateTimeZone dateTimeZone82 = dateTime80.getZone();
        boolean boolean83 = dateTime80.isAfterNow();
        org.joda.time.DateTime dateTime85 = dateTime80.minusHours((int) (short) 100);
        org.joda.time.Chronology chronology86 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime85);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970001T000000Z" + "'", str28.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970001T000000Z" + "'", str35.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-31L) + "'", long59 == (-31L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "weekOfWeekyear" + "'", str67.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 345599968L + "'", long69 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 11 + "'", int71 == 11);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "1970001T000000Z" + "'", str78.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(chronology86);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime13.getZone();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) '#', 10, (int) ' ', (int) (byte) 100, (int) (byte) -1, 2, 1970, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime16.minus(readableDuration21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime15.plusWeeks((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField11.set(1L, "era", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long9 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false);
        long long11 = dateTimeZone6.convertUTCToLocal((long) 100);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter2, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31L) + "'", long9 == (-31L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 132L + "'", long11 == 132L);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long12 = dateTimeFormatter0.parseMillis("ZonedChronology[GregorianChronology[UTC], ]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getYearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        org.joda.time.DateTime dateTime14 = dateTime10.withMillis((long) 5200);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = dateMidnight17.toMutableDateTime(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        boolean boolean18 = fixedDateTimeZone4.isStandardOffset((long) 53);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean4 = dateTimeFormatter3.isParser();
        java.lang.String str6 = dateTimeFormatter3.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean11 = dateTimeFormatter10.isParser();
        java.lang.String str13 = dateTimeFormatter10.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter14);
        boolean boolean16 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property19 = dateTime15.weekOfWeekyear();
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        org.joda.time.DateTime dateTime23 = dateTime20.toDateTimeISO();
        org.joda.time.DateTime dateTime25 = dateTime20.withCenturyOfEra(0);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime20);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = dateTime20.toString("", locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001T000000Z" + "'", str6.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970001T000000Z" + "'", str13.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int18 = offsetDateTimeField11.getMaximumValue();
        boolean boolean19 = offsetDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 153 + "'", int18 == 153);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        java.io.Writer writer5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime12.withDurationAdded(readableDuration15, 2);
        try {
            dateTimeFormatter4.printTo(writer5, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        int int20 = dateTime18.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property21 = dateTime18.weekOfWeekyear();
        int int22 = property21.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        long long11 = dateTimeZone8.convertLocalToUTC((long) 1970, false);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(100, (-36), 32, 5141, (int) '#', 153, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5141 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1970L + "'", long11 == 1970L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey(97L);
        long long11 = fixedDateTimeZone4.adjustOffset(0L, false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        java.lang.Number number18 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 2, (java.lang.Number) 1970L, number18);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, 5141, 366, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5141 for weekOfWeekyear must be in the range [366,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isParser();
        java.lang.String str15 = dateTimeFormatter12.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime28 = dateTime24.toDateTimeISO();
        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean35 = fixedDateTimeZone34.isFixed();
        java.lang.String str36 = fixedDateTimeZone34.getID();
        org.joda.time.DateTime dateTime37 = dateTime29.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime6.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField40 = gregorianChronology39.hours();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.minuteOfDay();
        int int42 = mutableDateTime38.get(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001T000000Z" + "'", str15.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMinutes(4);
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property5 = dateTime1.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (-36), 5141);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readableDuration17);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "1969365T160000-0800", 53, 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField20 = property17.getField();
        org.joda.time.Interval interval21 = property17.toInterval();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(interval21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser8);
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withLocale(locale10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        java.util.Locale locale39 = null;
        java.lang.String str40 = property17.getAsText(locale39);
        org.joda.time.DateTime dateTime41 = property17.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property19.getAsShortText(locale21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        long long27 = dateTimeZone24.convertLocalToUTC((long) 1970, false);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) str22, dateTimeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AD" + "'", str22.equals("AD"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1970L + "'", long27 == 1970L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(27L, (-2678400000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2678399973L) + "'", long2 == (-2678399973L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime23 = dateTime21.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean7 = dateTimeFormatter6.isParser();
        java.lang.String str9 = dateTimeFormatter6.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isParser();
        java.lang.String str16 = dateTimeFormatter13.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter17);
        boolean boolean19 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusWeeks((int) (short) 1);
        java.lang.String str27 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.TimeOfDay timeOfDay28 = dateTime23.toTimeOfDay();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        org.joda.time.DateTime dateTime31 = dateTime23.minus((long) 53);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001T000000Z" + "'", str9.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970001T000000Z" + "'", str16.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(timeOfDay28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((-33L), false, 132L);
        long long15 = fixedDateTimeZone4.adjustOffset((long) 3, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970-01-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970-01-01T00:00:00.000Z/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime22 = property20.setCopy((int) (short) 0);
        int int23 = property20.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[weekOfWeekyear]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[weekOfWeekyear]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 4, (java.lang.Number) (byte) 100, (java.lang.Number) 4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        try {
            org.joda.time.DateTime dateTime20 = dateTime13.withDate((int) (short) 10, 53, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Property[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[weekOfWeekyear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.weekyear();
        long long15 = gregorianChronology6.add(0L, 27L, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean18 = dateTimeFormatter17.isParser();
        java.lang.String str20 = dateTimeFormatter17.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZoneUTC();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        boolean boolean30 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.minus(readableDuration33);
        int int35 = dateTime32.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean38 = dateTimeFormatter37.isParser();
        java.lang.String str40 = dateTimeFormatter37.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withZoneUTC();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean45 = dateTimeFormatter44.isParser();
        java.lang.String str47 = dateTimeFormatter44.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter44.withZoneUTC();
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter48);
        boolean boolean50 = dateTime42.isEqual((org.joda.time.ReadableInstant) dateTime49);
        org.joda.time.DateTime dateTime52 = dateTime49.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property53 = dateTime49.weekOfWeekyear();
        org.joda.time.DateTime dateTime54 = dateTime49.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology55 = dateTime54.getChronology();
        org.joda.time.TimeOfDay timeOfDay56 = dateTime54.toTimeOfDay();
        boolean boolean57 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int35, (java.lang.Object) timeOfDay56);
        int[] intArray59 = gregorianChronology6.get((org.joda.time.ReadablePartial) timeOfDay56, 0L);
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime(5141, (int) 'a', 1, (int) '#', (int) (byte) 0, dateTimeZone60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2700L + "'", long15 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970001T000000Z" + "'", str20.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 32 + "'", int35 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1970001T000000Z" + "'", str40.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970001T000000Z" + "'", str47.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertNotNull(timeOfDay56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime18.plusDays(19);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.joda.time.DateTime dateTime19 = dateTime16.withWeekyear((int) (short) 1);
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime19.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean3 = dateTimeFormatter2.isParser();
        java.lang.String str5 = dateTimeFormatter2.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean10 = dateTimeFormatter9.isParser();
        java.lang.String str12 = dateTimeFormatter9.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter9.withZoneUTC();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter13);
        boolean boolean15 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property18 = dateTime14.weekOfWeekyear();
        boolean boolean20 = property18.equals((java.lang.Object) 100);
        boolean boolean22 = property18.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime24 = property18.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime29 = dateTime24.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime31 = dateTime24.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long36 = dateTimeZone33.convertLocalToUTC((long) (short) 1, false);
        long long39 = dateTimeZone33.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) 100);
        java.lang.String str44 = offsetDateTimeField43.getName();
        long long46 = offsetDateTimeField43.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField43.getType();
        int int48 = dateTime24.get(dateTimeFieldType47);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970001T000000Z" + "'", str5.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970001T000000Z" + "'", str12.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31L) + "'", long36 == (-31L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "weekOfWeekyear" + "'", str44.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 345599968L + "'", long46 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        int int10 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime18.withFieldAdded(durationFieldType21, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        boolean boolean2 = dateTimeFormatter1.isParser();
//        java.lang.String str4 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName(1560636072367L);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName(0L, locale12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("101");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"101\" is malformed at \"1\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime27 = dateTime23.withWeekyear((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime23.secondOfMinute();
        org.joda.time.DateTime dateTime29 = property28.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long12 = fixedDateTimeZone4.convertLocalToUTC(0L, false, (long) (byte) 0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean11 = fixedDateTimeZone10.isFixed();
        java.lang.String str12 = fixedDateTimeZone10.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology13);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology17.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology17.weekyear();
        long long26 = gregorianChronology17.add(0L, 27L, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean36 = dateTimeFormatter35.isParser();
        java.lang.String str38 = dateTimeFormatter35.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter35.withZoneUTC();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter39);
        boolean boolean41 = dateTime33.isEqual((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime43 = dateTime40.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime45 = dateTime43.minus(readableDuration44);
        int int46 = dateTime43.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean49 = dateTimeFormatter48.isParser();
        java.lang.String str51 = dateTimeFormatter48.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter48.withZoneUTC();
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean56 = dateTimeFormatter55.isParser();
        java.lang.String str58 = dateTimeFormatter55.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter55.withZoneUTC();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter59);
        boolean boolean61 = dateTime53.isEqual((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime63 = dateTime60.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property64 = dateTime60.weekOfWeekyear();
        org.joda.time.DateTime dateTime65 = dateTime60.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology66 = dateTime65.getChronology();
        org.joda.time.TimeOfDay timeOfDay67 = dateTime65.toTimeOfDay();
        boolean boolean68 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int46, (java.lang.Object) timeOfDay67);
        int[] intArray70 = gregorianChronology17.get((org.joda.time.ReadablePartial) timeOfDay67, 0L);
        boolean boolean71 = zonedChronology13.equals((java.lang.Object) 0L);
        java.lang.String str72 = zonedChronology13.toString();
        try {
            long long80 = zonedChronology13.getDateTimeMillis((int) (byte) 100, 31, 3, (int) (byte) 100, (int) '4', (int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2700L + "'", long26 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970001T000000Z" + "'", str38.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 32 + "'", int46 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1970001T000000Z" + "'", str51.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970001T000000Z" + "'", str58.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertNotNull(timeOfDay67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "ZonedChronology[GregorianChronology[UTC], ]" + "'", str72.equals("ZonedChronology[GregorianChronology[UTC], ]"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        long long9 = dateTimeZone6.convertLocalToUTC((long) 1970, false);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) -1, 31, (int) (byte) 100, (int) (byte) 100, (-1), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1970L + "'", long9 == 1970L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, (long) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean27 = dateTimeFormatter26.isParser();
        java.lang.String str29 = dateTimeFormatter26.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter30);
        boolean boolean32 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
        int int38 = property17.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property39 = dateTime34.year();
        org.joda.time.DateTime dateTime40 = property39.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime42 = property39.setCopy((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970001T000000Z" + "'", str29.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "ZonedChronology[GregorianChronology[UTC], ]", "Property[weekOfWeekyear]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
        org.joda.time.DurationField durationField23 = property22.getDurationField();
        int int24 = property22.getMaximumValueOverall();
        org.joda.time.DateTime dateTime25 = property22.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 366 + "'", int24 == 366);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMinutes(4);
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfWeek();
        int int5 = dateTime1.getYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.getID();
        long long8 = fixedDateTimeZone4.previousTransition(132L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfHalfday();
        org.joda.time.DurationField durationField15 = gregorianChronology12.seconds();
        org.joda.time.DurationField durationField16 = gregorianChronology12.minutes();
        org.joda.time.DurationField durationField17 = gregorianChronology12.seconds();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = gregorianChronology12.add(readablePeriod18, 0L, 32);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology12.yearOfEra();
        org.joda.time.DateTime dateTime23 = dateTime10.toDateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        int int10 = dateTime6.getDayOfMonth();
        int int11 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        java.lang.String str31 = dateTimeFormatter28.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter32);
        boolean boolean34 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean44 = fixedDateTimeZone43.isFixed();
        java.lang.String str45 = fixedDateTimeZone43.getID();
        org.joda.time.DateTime dateTime46 = dateTime38.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        int int47 = dateTime38.getMillisOfDay();
        boolean boolean48 = dateTime18.isAfter((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime50 = dateTime18.minusMinutes(27);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        boolean boolean52 = dateTime18.isSupported(dateTimeFieldType51);
        org.joda.time.DateTime dateTime54 = dateTime18.plusWeeks(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970001T000000Z" + "'", str31.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dateTime54);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField15 = gregorianChronology14.hours();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime12.toMutableDateTime((org.joda.time.Chronology) gregorianChronology14);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (byte) 0, (int) (byte) 1, (-292275054), (-1), 153, 27, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long18 = zonedChronology12.getDateTimeMillis(0L, (int) (byte) -1, 153, (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1970-W01-4T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        boolean boolean9 = dateTimeZone1.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField11.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField11.getDifferenceAsLong((long) 19, (long) 5200);
        int int19 = offsetDateTimeField11.get(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField11.getType();
        try {
            long long15 = offsetDateTimeField11.set((long) 2000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [101,153]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = gregorianChronology1.hours();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-65L), 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4550L) + "'", long2 == (-4550L));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property12 = dateTime6.weekyear();
        int int13 = dateTime6.getHourOfDay();
        org.joda.time.DateTime.Property property14 = dateTime6.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime21.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long23 = fixedDateTimeZone21.previousTransition((long) (byte) 100);
        int int25 = fixedDateTimeZone21.getOffsetFromLocal((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime15.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.String str3 = dateTimeFormatter0.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.LocalDate localDate7 = dateTimeFormatter4.parseLocalDate("1970001T000003Z");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970001T000000Z" + "'", str3.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime13 = dateTime6.withYear(70);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology2.weekyears();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField9 = gregorianChronology2.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean15 = dateTimeFormatter14.isParser();
        java.lang.String str17 = dateTimeFormatter14.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZoneUTC();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter18);
        boolean boolean20 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTimeISO();
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean30 = fixedDateTimeZone29.isFixed();
        java.lang.String str31 = fixedDateTimeZone29.getID();
        org.joda.time.DateTime dateTime32 = dateTime24.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        java.lang.String str33 = fixedDateTimeZone29.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970001T000000Z" + "'", str17.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology34);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("Property[weekOfWeekyear]");
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.DurationField durationField39 = zonedChronology12.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-W01-4T00:00:00.000Z", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("AD", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder0.addRecurringSavings("era", 2000, 70, (int) (short) 10, '#', (int) '4', (-292275054), 5141, true, (int) (short) 0);
        java.io.OutputStream outputStream19 = null;
        try {
            dateTimeZoneBuilder17.writeTo("ISOChronology[UTC]", outputStream19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
        org.joda.time.DurationField durationField23 = property22.getDurationField();
        org.joda.time.DateTime dateTime24 = property22.roundHalfEvenCopy();
        org.joda.time.DurationField durationField25 = property22.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        long long22 = offsetDateTimeField11.add((long) 5200, (long) (-36));
        java.lang.String str23 = offsetDateTimeField11.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-21772794800L) + "'", long22 == (-21772794800L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str23.equals("DateTimeField[weekOfWeekyear]"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        long long35 = zonedChronology12.getDateTimeMillis((long) (byte) 100, 11, 32, 10, (int) (byte) 0);
        java.lang.String str36 = zonedChronology12.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 41529999L + "'", long35 == 41529999L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ZonedChronology[GregorianChronology[UTC], ]" + "'", str36.equals("ZonedChronology[GregorianChronology[UTC], ]"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology1.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime13.getZone();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusWeeks((int) (short) 1);
        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
        org.joda.time.DurationField durationField23 = property22.getDurationField();
        long long24 = property22.remainder();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long16 = fixedDateTimeZone9.convertLocalToUTC((long) 23, false, (long) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 22L + "'", long16 == 22L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isParser();
        java.lang.String str15 = dateTimeFormatter12.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.minus(readableDuration28);
        int int30 = dateTime27.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean33 = dateTimeFormatter32.isParser();
        java.lang.String str35 = dateTimeFormatter32.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean40 = dateTimeFormatter39.isParser();
        java.lang.String str42 = dateTimeFormatter39.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter39.withZoneUTC();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter43);
        boolean boolean45 = dateTime37.isEqual((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime47 = dateTime44.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property48 = dateTime44.weekOfWeekyear();
        org.joda.time.DateTime dateTime49 = dateTime44.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology50 = dateTime49.getChronology();
        org.joda.time.TimeOfDay timeOfDay51 = dateTime49.toTimeOfDay();
        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int30, (java.lang.Object) timeOfDay51);
        int[] intArray54 = gregorianChronology1.get((org.joda.time.ReadablePartial) timeOfDay51, 0L);
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology1.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone60 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long62 = fixedDateTimeZone60.previousTransition((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime63 = null;
        boolean boolean64 = fixedDateTimeZone60.isLocalDateTimeGap(localDateTime63);
        long long66 = dateTimeZone55.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone60, (long) 27);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001T000000Z" + "'", str15.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32 + "'", int30 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970001T000000Z" + "'", str35.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1970001T000000Z" + "'", str42.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(timeOfDay51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 26L + "'", long66 == 26L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        boolean boolean19 = property17.equals((java.lang.Object) 100);
        boolean boolean21 = property17.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime23 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime23.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime30 = dateTime23.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long35 = dateTimeZone32.convertLocalToUTC((long) (short) 1, false);
        long long38 = dateTimeZone32.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (short) 100);
        java.lang.String str43 = offsetDateTimeField42.getName();
        long long45 = offsetDateTimeField42.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField42.getType();
        int int47 = dateTime23.get(dateTimeFieldType46);
        int int48 = dateTime23.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31L) + "'", long35 == (-31L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "weekOfWeekyear" + "'", str43.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 345599968L + "'", long45 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime22 = property20.setCopy((int) (short) 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property20.getAsShortText(locale23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = property20.getAsShortText(locale25);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean11 = iSOChronology9.equals((java.lang.Object) (short) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long18 = fixedDateTimeZone16.previousTransition((long) (byte) 100);
        java.lang.String str20 = fixedDateTimeZone16.getShortName(0L);
        long long22 = fixedDateTimeZone16.nextTransition((long) (byte) 0);
        java.util.TimeZone timeZone23 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.Chronology chronology24 = iSOChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.001" + "'", str20.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        org.joda.time.DateTime.Property property23 = dateTime21.era();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long15 = offsetDateTimeField11.add(41529999L, 97L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 58707129999L + "'", long15 == 58707129999L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) 1);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        int int9 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        long long10 = gregorianChronology1.add(0L, 27L, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isParser();
        java.lang.String str15 = dateTimeFormatter12.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean20 = dateTimeFormatter19.isParser();
        java.lang.String str22 = dateTimeFormatter19.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter19.withZoneUTC();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter23);
        boolean boolean25 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.minus(readableDuration28);
        int int30 = dateTime27.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean33 = dateTimeFormatter32.isParser();
        java.lang.String str35 = dateTimeFormatter32.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean40 = dateTimeFormatter39.isParser();
        java.lang.String str42 = dateTimeFormatter39.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter39.withZoneUTC();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter43);
        boolean boolean45 = dateTime37.isEqual((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime47 = dateTime44.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property48 = dateTime44.weekOfWeekyear();
        org.joda.time.DateTime dateTime49 = dateTime44.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology50 = dateTime49.getChronology();
        org.joda.time.TimeOfDay timeOfDay51 = dateTime49.toTimeOfDay();
        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int30, (java.lang.Object) timeOfDay51);
        int[] intArray54 = gregorianChronology1.get((org.joda.time.ReadablePartial) timeOfDay51, 0L);
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField56 = gregorianChronology1.years();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2700L + "'", long10 == 2700L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001T000000Z" + "'", str15.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T000000Z" + "'", str22.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32 + "'", int30 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970001T000000Z" + "'", str35.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1970001T000000Z" + "'", str42.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(timeOfDay51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(durationField56);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean8 = dateTimeFormatter7.isParser();
        java.lang.String str10 = dateTimeFormatter7.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 0);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusDays((int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = dateTime15.isSupported(dateTimeFieldType19);
        org.joda.time.DateTime.Property property21 = dateTime15.monthOfYear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970001T000000Z" + "'", str10.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime21 = property19.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property22 = dateTime21.era();
        org.joda.time.DateTime.Property property23 = dateTime21.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "era" + "'", str20.equals("era"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 2000, 70, 2, 3, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 1, false);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-292275054), (int) '#', 19, (int) (short) -1, 0, (-292275054), (int) (short) 1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31L) + "'", long11 == (-31L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.previousTransition((long) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean11 = dateTimeFormatter10.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField11.getName();
        long long14 = offsetDateTimeField11.roundCeiling((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField11.getAsText((long) 4, locale16);
        long long19 = offsetDateTimeField11.roundHalfFloor((long) 366);
        long long22 = offsetDateTimeField11.add((long) 5200, (long) (-36));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean25 = dateTimeFormatter24.isParser();
        java.lang.String str27 = dateTimeFormatter24.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean32 = dateTimeFormatter31.isParser();
        java.lang.String str34 = dateTimeFormatter31.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter31.withZoneUTC();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter35);
        boolean boolean37 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTimeISO();
        org.joda.time.DateTime dateTime41 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime41.era();
        org.joda.time.DurationField durationField43 = property42.getLeapDurationField();
        java.util.Locale locale44 = null;
        java.lang.String str45 = property42.getAsShortText(locale44);
        org.joda.time.DateTime dateTime46 = property42.roundHalfEvenCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean49 = dateTimeFormatter48.isParser();
        java.lang.String str51 = dateTimeFormatter48.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter48.withZoneUTC();
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean56 = dateTimeFormatter55.isParser();
        java.lang.String str58 = dateTimeFormatter55.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter55.withZoneUTC();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter59);
        boolean boolean61 = dateTime53.isEqual((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime63 = dateTime60.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property64 = dateTime60.weekOfWeekyear();
        boolean boolean66 = property64.equals((java.lang.Object) 100);
        boolean boolean68 = property64.equals((java.lang.Object) (-1L));
        org.joda.time.DateTime dateTime70 = property64.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime75 = dateTime70.withTime(0, (int) ' ', (int) ' ', (int) (short) 100);
        org.joda.time.DateTime dateTime77 = dateTime70.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long82 = dateTimeZone79.convertLocalToUTC((long) (short) 1, false);
        long long85 = dateTimeZone79.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField87 = iSOChronology86.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField87, (int) (short) 100);
        java.lang.String str90 = offsetDateTimeField89.getName();
        long long92 = offsetDateTimeField89.roundCeiling((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField89.getType();
        int int94 = dateTime70.get(dateTimeFieldType93);
        int int95 = dateTime46.get(dateTimeFieldType93);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField97 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType93, (int) '4');
        int int99 = dividedDateTimeField97.get((long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekOfWeekyear" + "'", str12.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345599968L + "'", long14 == 345599968L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "101" + "'", str17.equals("101"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200032L) + "'", long19 == (-259200032L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-21772794800L) + "'", long22 == (-21772794800L));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001T000000Z" + "'", str27.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970001T000000Z" + "'", str34.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "AD" + "'", str45.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1970001T000000Z" + "'", str51.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970001T000000Z" + "'", str58.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-31L) + "'", long82 == (-31L));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1L + "'", long85 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "weekOfWeekyear" + "'", str90.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 345599968L + "'", long92 == 345599968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 11 + "'", int94 == 11);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1 + "'", int99 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DurationField durationField9 = gregorianChronology6.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean15 = fixedDateTimeZone14.isFixed();
        java.lang.String str16 = fixedDateTimeZone14.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = zonedChronology17.withZone(dateTimeZone18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean22 = dateTimeFormatter21.isParser();
        java.lang.String str24 = dateTimeFormatter21.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter25);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        boolean boolean29 = dateTime26.isAfterNow();
        org.joda.time.DateTime dateTime30 = dateTime26.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime32 = dateTime26.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        boolean boolean34 = zonedChronology17.equals((java.lang.Object) dateTime32);
        org.joda.time.DateTimeZone dateTimeZone35 = zonedChronology17.getZone();
        try {
            org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((int) (short) 100, (int) (short) 10, 11, (int) (short) 0, (-35), dateTimeZone35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970001T000000Z" + "'", str24.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone35);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        illegalFieldValueException2.prependMessage("1969");
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false);
        long long7 = dateTimeZone1.adjustOffset((long) 1, false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField11.getType();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField11.getWrappedField();
        long long15 = offsetDateTimeField11.roundCeiling((long) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-31L) + "'", long4 == (-31L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345599968L + "'", long15 == 345599968L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) 4);
        java.lang.String str9 = fixedDateTimeZone4.getName(28L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime23 = dateTime18.withCenturyOfEra(0);
        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime22 = property20.setCopy((int) (short) 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property20.getAsShortText(locale23);
        org.joda.time.DateTime dateTime25 = property20.roundFloorCopy();
        org.joda.time.DateTime dateTime26 = property20.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime18.toTimeOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        boolean boolean23 = dateTime21.isBefore((long) 32);
        org.joda.time.DateTime dateTime24 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMinutes(4);
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.centuryOfEra();
        long long13 = gregorianChronology6.add(132L, (long) (byte) 0, 100);
        org.joda.time.DateTime dateTime14 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 132L + "'", long13 == 132L);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 1, false);
        long long8 = dateTimeZone3.convertUTCToLocal((long) 100);
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField10 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31L) + "'", long6 == (-31L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTimeISO();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.plus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long15 = dateTimeZone12.convertLocalToUTC((long) (short) 1, false);
        java.lang.String str17 = dateTimeZone12.getShortName(100L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone12.getShortName((long) ' ', locale19);
        org.joda.time.DateTime dateTime21 = dateTime6.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMonths(31);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31L) + "'", long15 == (-31L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.032" + "'", str17.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.032" + "'", str20.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) '#', 101);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        boolean boolean4 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long9 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false);
        long long12 = dateTimeZone6.convertLocalToUTC((long) (short) -1, true);
        long long15 = dateTimeZone6.adjustOffset((long) 27, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31L) + "'", long9 == (-31L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-33L) + "'", long12 == (-33L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 27L + "'", long15 == 27L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365T160000-0800", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for 1969365T160000-0800 is not supported"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        boolean boolean9 = dateTime6.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime6.withTimeAtStartOfDay();
        boolean boolean11 = dateTime6.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime13.minusYears(0);
        int int22 = dateTime13.getYear();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime13.minus(readableDuration23);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isParser();
        java.lang.String str4 = dateTimeFormatter1.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean9 = dateTimeFormatter8.isParser();
        java.lang.String str11 = dateTimeFormatter8.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter12);
        boolean boolean14 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfSecond((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000000Z" + "'", str4.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970001T000000Z" + "'", str11.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, (int) (byte) -1);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.lang.String str11 = fixedDateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean17 = dateTimeFormatter16.isParser();
        java.lang.String str19 = dateTimeFormatter16.print(10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1969365T160000-0800", dateTimeFormatter20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        boolean boolean24 = dateTime21.isAfterNow();
        org.joda.time.DateTime dateTime25 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
        boolean boolean29 = zonedChronology12.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology12.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology32.year();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.clockhourOfDay();
        boolean boolean38 = zonedChronology12.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology32.era();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology32.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970001T000000Z" + "'", str19.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }
}

